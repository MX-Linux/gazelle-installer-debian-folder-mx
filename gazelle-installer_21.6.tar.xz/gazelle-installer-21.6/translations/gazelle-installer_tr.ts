<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Bilgisayarı Kapat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation>%1 Yükleyici</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 Desteği

%1 sizin gibi kişiler tarafından destekleniyor. Bazıları destek forumunda diğerlerine yardım ediyor -% 2 veya yardım dosyalarını farklı dillere çeviriyor, önerilerde bulunuyor, belgelendirme yazıyor veya yeni yazılımın denenmesine yardımcı oluyor.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Yükleyici, zaten arka planda çalışıyor göründüğü için başlamıyor.

Lütfen mümkünse kapatın veya uçbirimde &apos;pkill minstall&apos; komutunu çalıştırın.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>64 bit UEFI modunda başlatılan 32 bit işletim sistemini çalıştırıyorsunuz. Yeniden başlatma sırasında Legacy Boot veya benzerini seçmediğiniz sürece sistem önyükleme yapamayacaktır.
Şimdi çıkmanızı ve Legacy Boot&apos;da yeniden başlatmanızı öneririz.

Kuruluma devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1, Debian Kararlı tabanlı bağımsız bir Linux dağıtımıdır.

%1, Apache özgür lisansı altında dağıtılan MEPİS Linux&apos;un bazı bileşenlerini kullanıyor. Bazı MEPİS bileşenleri %1 için değiştirildi.

%1&apos;in keyfini çıkarın</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation>%1 kuruluma hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="532"/>
        <source>Preparing to install %1</source>
        <translation>%1 kuruluma hazırlanıyor</translation>
    </message>
    <message>
        <source>Failed to format required partitions.</source>
        <translation type="vanished">Berekli bölümler biçimlendirilemedi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="558"/>
        <source>Paused for required operator input</source>
        <translation>Gerekli operatör girişi için duraklatıldı</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="569"/>
        <source>Setting system configuration</source>
        <translation>Sistem yapılandırma ayarları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="588"/>
        <source>Cleaning up</source>
        <translation>Temizleniyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="590"/>
        <source>Finished</source>
        <translation>Bitti</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="754"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation> (% 1) Yapılandırma dosyasında geçersiz ayarlar bulundu. Lütfen işaretli alanları karşılaştıkça inceleyin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="810"/>
        <source>Deleting old system</source>
        <translation>Eski sistem siliniyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="814"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Hedefteki eski %1 silinemedi.
1. Adıma Geri Dön.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>Creating system directories</source>
        <translation>Sistem dizinleri oluşturuluyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>Fixing configuration</source>
        <translation>Yapılandırma onarılıyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="888"/>
        <source>Copying new system</source>
        <translation>Yeni sistem kopyalanıyor</translation>
    </message>
    <message>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="vanished">Kopya ilerleme durumu bilinmiyor. Dosya sistemi istatistikleri yok.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="911"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Hedefteki %1 yazılamadı.
1. Adıma Geri Dön.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="955"/>
        <location filename="../minstall.cpp" line="1070"/>
        <source>Updating initramfs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="965"/>
        <source>Installing GRUB</source>
        <translation>GRUB Kurulumu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1000"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>GRUB kurulumu başarısız oldu. Kurulumu onarmak için canlı ortamı yeniden başlatabilir ve GRUB Kurtarma menüsünü kullanabilirsiniz.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">NVRAM önyükleme değişkeni güncelleme hatası. Sistem önyüklenemeyebilir, ancak GRUB Kurtarma önyükleme menüsü ile onarılabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Kullanıcı adı özel karakterler veya boşluk içeremez.
Lütfen devam etmeden önce başka bir ad seçin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1140"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Üzgünüm bu ad kullanılıyor.
Farklı bir ad seçin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1150"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>The home directory for %1 already exists.</source>
        <translation>%1 için ev dizini zaten mevcut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>Failed to set user account passwords.</source>
        <translation>Kullanıcı hesabı parolası oluşturma başarısız oldu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1205"/>
        <source>Failed to save old home directory.</source>
        <translation>Eski ev dizini kaydedilemedi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1210"/>
        <source>Failed to delete old home directory.</source>
        <translation>Eski ev dizini silinemedi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1228"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Üzgünüm,kullanıcı dizini oluşturma başarısız.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1233"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Üzgünüm,kullanıcı dizini adı başarısız.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1254"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Üzgünüz, kullanıcı dizininin aidiyeti ayarlanırken hata oluştu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1300"/>
        <source>Please enter a computer name.</source>
        <translation>Lütfen bir bilgisayar adı girin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1304"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Üzgünüm, bilgisayar adınız geçersiz karakterler içeriyor.
Farklı bir seçim yapmanız gerek
İşleme devam etmeden önce ad gerekli.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1310"/>
        <source>Please enter a domain name.</source>
        <translation>Lütfen bir etki alanı adı girin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1314"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Üzgünüm, bilgisayar alan adınız geçersiz karakterler içeriyor.
Devam etmeden önce
farklı bir alan adı seçmeniz gerekiyor.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1321"/>
        <source>Please enter a workgroup.</source>
        <translation>Lütfen bir çalışma grubu adı girin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1511"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>% 2 için tüm diski (% 1) biçimlendirilip kullanılacak. Tamam mı?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1515"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>UYARI: Seçilen sürücü en az 2TB kapasiteye sahip ve GPT kullanılarak formatlanması gerekiyor. Bazı sistemlerde GPT biçimli bir disk önyükleme yapamaz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1541"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Gerekli bilgiler elde edilemediği için /home içindeki veriler korunamaz.</translation>
    </message>
    <message>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="vanished">/home bölümü içeriği şifrelenecekse,  lütfen doğru &quot;şifreleme&quot; kutularının seçildiğinden ve girilen parolanın doğru olduğundan emin olun.</translation>
    </message>
    <message>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="vanished">Yükleyici, varolan bir /home dizinini veya bölümü şifreleyemez.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1603"/>
        <source>General Instructions</source>
        <translation>Genel Yönergeler</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1604"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>DEVAM ETMEDEN ÖNCE, DİĞER UYGULAMALARIN TÜMÜNÜ KAPATIN.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1605"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Lütfen her sayfadaki yönergeleri okuyun, seçimlerinizi yapın ve devam etmeye hazır olduğunuzda İler&apos;yi tıklayın. Herhangi bir yıkıcı eylem gerçekleştirilmeden önce sizden onay istenecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1607"/>
        <source>Limitations</source>
        <translation>Sınırlamalar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1608"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Unutmayın, bu yazılım herhangi bir garanti olmaksızın OLDUĞU GİBİ sağlanır. Devam etmeden önce verilerinizi yedeklemek yalnızca sizin sorumluluğunuzdadır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1613"/>
        <source>Installation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1614"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1615"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Mac veya Windows işletim sistemi kullanıyorsanız (Vista&apos;dan itibaren), yüklemeden önce, bölümleri ve Önyükleme Yöneticisini kurmak için bu sistemin yazılımını kullanmanız gerekebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1616"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1617"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1619"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1620"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1621"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1623"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1625"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1627"/>
        <location filename="../minstall.cpp" line="1694"/>
        <source>Encryption</source>
        <translation>Şifreleme</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1628"/>
        <location filename="../minstall.cpp" line="1695"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Şifreleme LUKS ile mümkündür. Bir parola gereklidir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1629"/>
        <location filename="../minstall.cpp" line="1696"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Ayrı bir şifrelenmemiş önyükleme bölümü gereklidir. Şifre seçimi dahil ek ayarlar için &lt;b&gt;Gelişmiş şifreleme ayarları&lt;/b&gt; düğmesini kullanın.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1631"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Otomatik kurulum ile şifreleme kullanılırsa, ayrı bir önyükleme bölümü otomatik olarak oluşturulacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1632"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1633"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1648"/>
        <source>Choose Partitions</source>
        <translation>Bölüm Seçimi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1649"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1650"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1651"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1652"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1653"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1656"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1658"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>ext2, ext3, ext4, jfs, xfs, btrfs ve reiserfs Linux dosya sistemleri desteklenir ve ext4 önerilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1659"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1660"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1661"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1662"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1663"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1666"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1667"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 bir kök bölümü gerektirir. Takas bölümü isteğe bağlıdır ancak şiddetle önerilir. %1&apos;in diski askıya alma özelliğini kullanmak istiyorsanız, fiziksel bellek boyutunuzdan daha büyük bir takas alanına gereksiniminiz olacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1669"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Ayrı bir /home bölümü seçerseniz, gelecekte yükseltmeniz daha kolay olacaktır, ancak ayrı bir ev bölümü olmayan bir kurulumdan yükseltiyorsanız bu olanaksızdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1677"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>Upgrading</source>
        <translation>Yükseltiliyor</translation>
    </message>
    <message>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="vanished">Kök bölümünüzde bulunan önceki /home dizin ağacını koruyorsanız, yükleyici kök bölümü yeniden biçimlendirmeyecektir. Sonuç olarak, kurulum normalden daha uzun sürecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <source>Failed to prepare required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <location filename="../minstall.cpp" line="2470"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1655"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>Partition boot flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1672"/>
        <source>For the installed operating system to boot, the boot flag must be set on the appropriate partition. This is usually the boot or root partition. The flag can be changed using the &lt;b&gt;Set boot flag&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <source>A partition whose boot flag will be set is shown with its device name in &lt;i&gt;italic&lt;/i&gt; type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1680"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1681"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1683"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tercih Edilen Dosya Sistemi Türü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>% 1 için bölümleri ext2, ext3, ext4, f2fs, jfs, xfs, btrfs veya reiser olarak biçimlendirmeyi seçebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Btrfs kullanan sürücüler için ek sıkıştırma seçenekleri mevcuttur. Lzo hızlıdır, ancak sıkıştırma daha düşüktür. Zlib, daha yüksek sıkıştırma ile daha yavaştır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1687"/>
        <source>Bad Blocks</source>
        <translation>Bozuk Öbekler</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Biçimlendirme türü olarak ext2, ext3 veya ext4&apos;ü seçerseniz, sürücüdeki bozuk blokları kontrol etme ve düzeltme seçeneğiniz vardır. Bozuk blok kontrolü çok zaman alır. Bu nedenle sürücünüzde bozuk bloklar olduğundan şüphelenmediğiniz sürece bu adımı atlayabilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1691"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1699"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1700"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1701"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>Subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1709"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1710"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>Advanced Encryption Settings</source>
        <translation>Gelişmiş Şifreleme Ayarları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Bu sayfa, LUKS ile şifrelenmiş bölümlerin ince ayarına izin verir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1718"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Çoğu durumda, öntanımlılar, hassas uygulamalar için uygun olan güvenlik ve başarım arasında pratik bir denge sağlar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Bu metin, LUKS ile kullanılan parametrelerin temellerini kapsar, ancak şifreyazım için kapsamlı bir kılavuz olması amaçlanmamıştır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Şifreleme konusunda sağlam bilgi sahibi olmadan bu ayarlardan herhangi birinin değiştirilmesi, zayıf şifrelemenin kullanılmasına neden olabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Bir alanı düzenlemek, genellikle altındaki mevcut seçenekleri etkiler. Aşağıdaki alanlar otomatik olarak önerilen değerlere değiştirilebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Ayarları önerilen değerlerden değiştirerek daha iyi başarım veya daha yüksek güvenlik elde edilebilirsiniz. Ancak oluşacak risk tamamen sizin sorumluluğunuzdadır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1725"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Lütfen &lt;i&gt;şifreleme kurulum kıyaslamasının&lt;/i&gt; mümkün olan tüm kombinasyonları veya seçimleri kapsamadığını ve genellikle en sık kullanılan seçimleri kapsadığını unutmayın.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <source>Cipher</source>
        <translation>Şifreleme</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <source>A variety of ciphers are available.</source>
        <translation>Şifreleme türevleri kullanılabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>beş AES finalistinden biriydi. Rijndael ve diğer tüm AES finalistlerinden daha yüksek bir güvenlik genişliğine sahip olduğu düşünülmektedir. Bazı 64-bit işlemcilerde daha iyi başarım gösterir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1731"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>Blowfish&apos;in ardılıdır. Standart olarak seçilmese de beş AES finalistinden biri oldu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) AES yarışmasına aday oldu, ancak finalist olmadı.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>Bruce Schneier tarafından oluşturulan 64 bitlik bir öbek şifreleyicidir. Yalnızca CBC ve ECB kipleri desteklendiğinden hassas uygulamalar için önerilmez. Blowfish, 8&apos;in katları olan 32 ile 448 bit arasındaki anahtar boyutlarını destekler.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1735"/>
        <source>Chain mode</source>
        <translation>Zincir kipi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1735"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Öbeklerin hepsi aynı anahtar kullanılarak şifrelenmişse, bir desen ortaya çıkabilir ve düz metin tahmin edilebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1736"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic CodeBook) CBC&apos;den daha az güvenlidir ve hassas uygulamalar için kullanılmamalıdır. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>IV generator</source>
        <translation>IV üreteci</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1741"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>ECB kipi bir IV kullanmaz, bu nedenle zincir kipi için ECB seçilirse bu alanların tümü devre dışı bırakılacak.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Key size</source>
        <translation>Anahtar boyutu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Anahtar boyutunu bit cinsinden ayarlar. Kullanılabilir anahtar boyutları, şifreleme ve zincir kipi ile sınırlıdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>XTS şifreleme zinciri kipi, anahtarı yarıya böler (örneğin, XTS modunda AES-256, 512 bitlik bir anahtar boyutu gerektirir).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>LUKS key hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>PBKDF2 ve AF splitter için kullanılan karma.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 ve RIPEMD-160, bozuk oldukları tespit edildiği için hassas uygulamalar için artık önerilmemektedir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF döngü süresi&lt;/b&gt;&lt;br/&gt; PBKDF2 parolası işleme ile harcanacak süre miktarıdır (milisaniye olarak).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>0 değeri derlenmiş öntanımlıyı seçer (ayrıntılar için &lt;i&gt;cryptsetup --help&lt;/i&gt; komutunu çalıştırın).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Yavaş bir makineniz varsa, bir parola girildikten sonra birimin kilidini açmak için harcanan süre karşılığında ekstra güvenlik için bu değeri artırmak isteyebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Önyükleme Yöntemi Seçimi&lt;/b&gt;&lt;br/&gt; %1 kendisi ve MS-Windows&apos;u birlikte açmak için GRUB önyükleyici kullanır.&lt;p&gt;GRUB2 öntanımlı olarak, önyükleme sürücünüzün Ana Önyükleme Kaydı&apos;na(MBR) veya ESP&apos;ye (64 bit UEFI önyükleme sistemleri için EFI Sistem Bölümü) yüklenir ve daha önce kullandığınız önyükleme yükleyicisinin yerini alır. Bu olağandır.&lt;/p&gt;&lt;p&gt;Eğer GRUB2&apos;yi Bölüm Önyükleme Kaydı (PBR)&apos;na kurmayı seçerseniz GRUB2 belirtilen bölümün başlangıcına kurulacaktır. Bu seçenek yalnızca uzmanlar içindir.&lt;/p&gt;&lt;p&gt;GRUB&apos;u Yükle kutusunun işaretini kaldırırsanız, GRUB şu anda yüklenmeyecektir. Bu seçenek yalnızca uzmanlar içindir.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Etkinleştirilecek Genel Hizmetler&lt;/b&gt;&lt;br/&gt;Sistem yapılandırmanızda gereksinim duyabileceğiniz bu genel hizmetlerden herhangi birini seçin. %1&apos;u başlattığınızda hizmetler otomatik olarak başlayacaktır.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Bilgisayar Kimliği&lt;/b&gt;&lt;br/&gt;Bilgisayar adı, bilgisayarınızı bir ağ üzerindeyse onu tanımlayacak ortak benzersiz bir addır. İSS&apos;niz veya yerel ağınız gerektirmedikçe bilgisayar alan adı olarak kullanılamaz.&lt;/p&gt;&lt;p&gt;Bilgisayar ve  alan adları yalnızca abecesayısal karakterler, noktalar, kısa çizgiler içerebilir. Boşluk, kısa çizgi ile başlangıç veya bitiş içeremezler&lt;/p&gt;&lt;p&gt;Bazı dizinlerinizi veya yazıcınızı MS-Windows veya Mac OSX çalıştıran yerel bir bilgisayarla paylaşarak kullanmak istiyorsanız SaMBa Sunucusunun etkinleştirilmesi gerekir.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>Localization Defaults</source>
        <translation>Yerelleştirme Öntanımlıları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>Configure Clock</source>
        <translation>Saati Yapılandır</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1794"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1805"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>Passwords</source>
        <translation>Parolalar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1811"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1825"/>
        <source>Old Home Directory</source>
        <translation>Eski Ev Dizini</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1826"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Seçtiğiniz kullanıcı adı için bir ev dizini zaten var. Bu ekran, bu dizine ne olacağını seçmenize izin verir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>Re-use it for this installation</source>
        <translation>Bu kurulum için yeniden kullanın</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1829"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Bu kullanıcı hesabı için eski ev dizini kullanılacak. Bu, yükseltme yaparken iyi bir seçimdir. Çünkü dosyalarınız ve ayarlarınız hazır durumda olacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1831"/>
        <source>Rename it and create a new directory</source>
        <translation>Yeniden adlandır ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1832"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Kullanıcı için yeni bir ev dizini oluşturulacak ve eski ev dizini de yeniden adlandırılacaktır. Dosyalarınız ve ayarlarınız yeni kurulumda hemen görünmeyecek, ancak yeniden adlandırılan dizin kullanılarak erişilebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Eski dizinin sonunda, dizinin önceden kaç kez yeniden adlandırıldığını gösteren bir sayı bulunur.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1835"/>
        <source>Delete it and create a new directory</source>
        <translation>Sil ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1836"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Eski ev dizini silinecek ve sıfırdan yeni bir dizin oluşturulacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1837"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Bu seçenek belirlenirse tüm dosyalar ve ayarlar kalıcı olarak silinir. Onları kurtarma şansınız düşüktür.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1854"/>
        <source>Installation in Progress</source>
        <translation>Kurulum devam ediyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1855"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 kuruluyor. Yeni bir kurulumda, sisteminizin hızına ve yeniden biçimlendirdiğiniz bölümlerin boyutuna bağlı olarak bu işlem muhtemelen 3-20 dakika sürer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1857"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>İptal düğmesine tıklarsanız, kurulum mümkün olan en kısa sürede durdurulacak.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>Change settings while you wait</source>
        <translation>Beklerken ayarları değiştirin</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1860"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>% 1 kurulurken, kurulum için gerekli diğer bilgileri girmek için &lt;b&gt;İleri&lt;/b&gt; veya &lt;b&gt;Geri&lt;/b&gt; düğmelerine tıklayabilirsiniz. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1862"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Bu adımları kendi hızınızda tamamlayın. Yükleyici, gerekirse girişinizi bekleyecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kutlarız!&lt;/b&gt;&lt;br/&gt;%1 kurulumunu tamamladınız&lt;/p&gt;&lt;p&gt;&lt;b&gt;Uygulamaları Bulma&lt;/b&gt;&lt;br/&gt;%1 ile yüklenmiş yüzlerce mükemmel uygulama var. Onlar hakkında bilgi edinmenin en iyi yolu Menü&apos;ye göz atmak ve onları denemektir. Uygulamaların çoğu, %1 tasarımı için özel olarak geliştirilmiştir. Bunlar ana menülerde gösterilmektedir. &lt;p&gt;Ek olarak, antiX Linux, yalnızca komut satırından çalıştırılan ve bu nedenle Menüde görünmeyen birçok standart Linux uygulamasını içerir.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>%1 kullanmanın tadını çıkarın&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1881"/>
        <location filename="../minstall.cpp" line="2295"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;b&gt;&lt;p&gt;%1 Desteği&lt;/b&gt;&lt;br/&gt;%1 sizin gibi kişiler tarafından destekleniyor. Bazıları destek forumunda diğerlerine yardım ediyor -% 2 veya yardım dosyalarını farklı dillere çeviriyor, önerilerde bulunuyor, belgelendirme yazıyor veya yeni yazılımın denenmesine yardımcı oluyor.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1912"/>
        <source>Finish</source>
        <translation>Son</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1916"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1918"/>
        <source>Next</source>
        <translation>İleri</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1953"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1956"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1960"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Loading...</source>
        <translation>Yükleniyor...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2019"/>
        <location filename="../minstall.cpp" line="2405"/>
        <source>Root</source>
        <translation>Kök</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2021"/>
        <location filename="../minstall.cpp" line="2413"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2220"/>
        <source>Confirmation</source>
        <translation>Onay</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2220"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Kurulum ve yapılandırma tamamlanmadı.
Gerçekten şimdi durdurmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2281"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Yardım Alma&lt;/b&gt;&lt;br/&gt;%1 ile ilgili temel bilgiler %2&apos;dedir.&lt;/p&gt;&lt;p&gt;%4 adresindeki %3 forumda size yardımcı olacak gönüllüler var&lt;/p&gt;&lt;p&gt;Yardım istediğinizde lütfen sorununuzu ve bilgisayarınızı ayrıntılı bir şekilde açıklamayı unutmayın. Genellikle &apos;işe yaramadı&apos; gibi ifadeler yardımcı olmaz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2289"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kurulumunuzu Onarma&lt;/b&gt;&lt;br/&gt;%1 sabit sürücüden çalışmayı durdurursa, bazen CanlıDVD veya CanlıUSB&apos;den önyükleme yaparak ve Sistem %1 yardımcı programlarından birini çalıştırarak veya sistemi onarmak için normal Linux araçlarından birini kullanarak sorunu çözmek mümkündür.&lt;/p&gt;&lt;p&gt;MS-Windows sistemlerinden veri kurtarmak için de %1 CanlıDVD veya CanlıUSB&apos;nizi kullanabilirsiniz!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2303"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ses Kartınızı Ayarlayıcı&lt;/b&gt;&lt;br/&gt; %1, ses karıştırıcısını sizin için yapılandırmaya çalışır, ancak bazen sesi duymak için karıştırıcının ses düzeylerini yükseltmeniz ve kanalların sesini açmanız gerekebilir.&lt;/p&gt; &lt;p&gt;Karıştırıcı kısayolu menüde bulunur. Karıştırıcıyı açmak için üzerine tıklayın. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2311"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%1 Kopyanızı Güncel Tutun&lt;/b&gt;&lt;br/&gt;Daha çok bilgi ve güncellemeler için şurayı ziyaret edin&lt;/p&gt;&lt;p&gt;%2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2316"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Teşekkürler&lt;/b&gt;&lt;br/&gt;%1&apos;i zamanı, parası, önerileri, çalışmaları, övgüleri, düşünceleri, tanıtımları ve/veya teşvikleriyle desteklemeyi seçen herkese teşekkürler.&lt;/p&gt;&lt;p&gt;Siz olmadan %1 olamazdı.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2368"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2368"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2410"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2458"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2469"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2589"/>
        <source>System boot disk:</source>
        <translation>Sistem Önyükleme Diski:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2603"/>
        <location filename="../minstall.cpp" line="2612"/>
        <source>Partition to use:</source>
        <translation>Kullanılacak bölüm:</translation>
    </message>
</context>
<context>
    <name>MPassEdit</name>
    <message>
        <location filename="../mpassedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>İleri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Bilgi toplanıyor, lütfen hazır bekleyin.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Kullanım Koşulları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klavye Ayarları&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt; </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Alt Çeşit:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation>Klavye Ayarlarını Değiştir</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Düzen:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Kurulum türünü seçin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="400"/>
        <location filename="../meinstall.ui" line="781"/>
        <source>Confirm password:</source>
        <translation>Parolayı onayla:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="407"/>
        <location filename="../meinstall.ui" line="798"/>
        <source>Encryption password:</source>
        <translation>Şifreleme parolası:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="423"/>
        <location filename="../meinstall.ui" line="821"/>
        <location filename="../meinstall.ui" line="853"/>
        <source>Advanced encryption settings</source>
        <translation>Gelişmiş Şifreleme Ayarları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="439"/>
        <source>Use disk:</source>
        <translation>Şu diski kullan:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="465"/>
        <location filename="../meinstall.ui" line="702"/>
        <source>Encrypt</source>
        <translation>Şifrele</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="522"/>
        <source>Root</source>
        <translation>Kök</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="557"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="621"/>
        <source>Choose partitions</source>
        <translation>Bölümleri seçin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="720"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="682"/>
        <source>Device</source>
        <translation>Aygıt</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="687"/>
        <source>Size</source>
        <translation>Boyut</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="692"/>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="697"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="707"/>
        <source>Format</source>
        <translation>Biçim</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="712"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="639"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="646"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="731"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="742"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="765"/>
        <source>Encryption options</source>
        <translation>Şifreleme seçenekleri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1135"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1140"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1145"/>
        <source>Whirlpool</source>
        <translation>Burgaç</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1150"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1155"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="881"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1175"/>
        <source> mS</source>
        <translation> mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="865"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="995"/>
        <source>Key size:</source>
        <translation>Anahtar boyutu:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1105"/>
        <source>KDF round time:</source>
        <translation>KDF döngü süresi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1092"/>
        <source>Cipher:</source>
        <translation>Şifre:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="935"/>
        <source>Serpent</source>
        <translation>Kıvrılan</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="940"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="945"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="950"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="955"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="982"/>
        <source>Benchmark...</source>
        <translation>Benchmark...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1051"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1056"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1061"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1066"/>
        <source>Plain</source>
        <translation>Yalın</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1071"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1008"/>
        <source>IV generator:</source>
        <translation>IV üreteci:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1034"/>
        <source>Chain mode:</source>
        <translation>Zincir kipi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="901"/>
        <source>Kernel RNG:</source>
        <translation>Çekirdek RNG (rastgele numara oluşturucu):</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="909"/>
        <source>urandom</source>
        <translation>rastgele olmayan</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="914"/>
        <source>random</source>
        <translation>rasgele</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1210"/>
        <source>Select Boot Method</source>
        <translation>Önyükleme Yöntemini Seçin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1310"/>
        <source>EFI System Partition</source>
        <translation>EFİ Sistem Bölümü</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1313"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1259"/>
        <source>Partition Boot Record</source>
        <translation>Bölüm Önyükleme Kaydı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1262"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation>Kurulacak yer:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1222"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Windows ve Linux için GRUB kur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1079"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1225"/>
        <location filename="../meinstall.ui" line="2410"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>System boot disk:</source>
        <translation>Sistem Önyükleme Diski:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1335"/>
        <source>Master Boot Record</source>
        <translation>Ana Önyükleme Kaydı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1341"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1344"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1418"/>
        <source>Common Services to Enable</source>
        <translation>Etkinleştirilecek Ortak Hizmetler</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1437"/>
        <source>Service</source>
        <translation>Hizmet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1442"/>
        <source>Description</source>
        <translation>Açıklama</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1475"/>
        <source>Computer Network Names</source>
        <translation>Bilgisayar Ağ Adları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1502"/>
        <source>Workgroup</source>
        <translation>Çalışmagrubu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1515"/>
        <source>Workgroup:</source>
        <translation>Çalışma grubu:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1528"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>MS Ağ iletişimi için SaMBa Sunucusu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1544"/>
        <source>example.dom</source>
        <translation>örnek.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1557"/>
        <source>Computer domain:</source>
        <translation>Bilgisayar alan adı:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1583"/>
        <source>Computer name:</source>
        <translation>Bilgisayar adı:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1644"/>
        <source>Configure Clock</source>
        <translation>Saati Yapılandır</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1685"/>
        <source>Format:</source>
        <translation>Biçimlendirme:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1713"/>
        <source>Timezone:</source>
        <translation>Saat dilimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1758"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1790"/>
        <source>Localization Defaults</source>
        <translation>Yerelleştirme Öntanımlıları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1830"/>
        <source>Locale:</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1852"/>
        <source>Service Settings (advanced)</source>
        <translation>Hizmet Ayarları (gelişmiş)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1870"/>
        <source>Adjust which services should run at startup</source>
        <translation>Hangi hizmetlerin başlangıçta çalışacağını ayarlayın</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1873"/>
        <source>View</source>
        <translation>Görünüm</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1931"/>
        <source>Root (administrator) Account</source>
        <translation>Kök (yönetici) Hesabı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1943"/>
        <source>Root password:</source>
        <translation>Kök parolası:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1988"/>
        <source>Confirm root password:</source>
        <translation>Kök parolasını onayla:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2017"/>
        <source>Default User Account</source>
        <translation>Öntanımlı Kullanıcı Hesabı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2029"/>
        <source>Default user login name:</source>
        <translation>Öntanımlı kullanıcı giriş adı:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2045"/>
        <source>Default user password:</source>
        <translation>Öntanımlı kullanıcı parolası:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2058"/>
        <source>Confirm user password:</source>
        <translation>Kullanıcı parolasını onayla:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2119"/>
        <source>username</source>
        <translation>kullanıcı adı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2135"/>
        <source>Autologin</source>
        <translation>Otomatik Oturum Aç</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2148"/>
        <source>Show passwords</source>
        <translation>Parolayı göster</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2161"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Canlı ortamda yapılan masaüstü değişiklikleri kurulu işletim sistemine taşınır</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2164"/>
        <source>Save live desktop changes</source>
        <translation>Canlı ortamdaki değişiklikleri kaydet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2187"/>
        <source>Existing Home Directory</source>
        <translation>Mevcut Ev Dizini</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2196"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Eski dizine ne yapmak istersiniz?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2203"/>
        <source>Re-use it for this installation</source>
        <translation>Bu kurulum için yeniden kullanın</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2210"/>
        <source>Rename it and create a new directory</source>
        <translation>Yeniden adlandır ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2217"/>
        <source>Delete it and create a new directory</source>
        <translation>Sil ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2262"/>
        <source>Tips</source>
        <translation>İpuçları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2306"/>
        <source>Installation complete</source>
        <translation>Kurulum tamamlandı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2312"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Yükleyici kapalıyken sistemi otomatik olarak yeniden başlat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2331"/>
        <source>Reminders</source>
        <translation>Anımsatıcılar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2372"/>
        <source>Back</source>
        <translation>Geri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2379"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2392"/>
        <source>Installation in progress</source>
        <translation>Kurulum devam ediyor</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2407"/>
        <source>Abort</source>
        <translation>Vazgeç</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="395"/>
        <source>EFI System Partition</source>
        <translation>EFİ Sistem Bölümü</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="396"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="397"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="510"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="703"/>
        <location filename="../partman.cpp" line="761"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="705"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="138"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="398"/>
        <source>format only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="510"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="553"/>
        <location filename="../partman.cpp" line="971"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="715"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="719"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="726"/>
        <location filename="../partman.cpp" line="858"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="732"/>
        <source>Set boot flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="739"/>
        <source>New subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="740"/>
        <source>Scan subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="764"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="765"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="766"/>
        <location filename="../partman.cpp" line="800"/>
        <source>&amp;Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="768"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="786"/>
        <source>Remove subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="803"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="805"/>
        <source>Compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="855"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="861"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="862"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="897"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="933"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1005"/>
        <source>Preserve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1046"/>
        <source>Invalid subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1056"/>
        <source>Duplicate subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1066"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1078"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1113"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1122"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Bir kök bölümü seçmelisiniz.
Kök bölümü en az %1 olmalıdır.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1128"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Kök bölümünü şifrelerken ayrı bir önyükleme bölümü seçmelisiniz.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1140"/>
        <source>Delete the data on %1 except for /home</source>
        <translation>/home dışında %1 üzerindeki verileri sil</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1143"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1149"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1152"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Seçtiğiniz aşağıdaki bölümler Linux bölümleri değil:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1160"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Bölümleri yeniden biçimlendirmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1168"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>% 1 yükleyicisi şimdi aşağıdaki bölümlerdeki verileri yok edecek ve biçimlendirecek:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1176"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>% 1 yükleyicisi şimdi aşağıdaki işlemleri gerçekleştirecektir:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1180"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Bu eylemler geri alınamaz. Devam etmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1278"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Kurulum için bölümlerini seçtiğiniz diskler başarısız oluyor:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1282"/>
        <source>Smartmon tool output:</source>
        <translation>Smartmon aracı çıktısı:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1283"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Kurulum için seçtiğiniz bölümlü disk SMART izleme testini (smartctl) geçiyor, ancak testler yakın gelecekte ortalama hata oranından daha yüksek olacağını gösteriyor.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1288"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Emin değilseniz, lütfen kurulumdan çıkın ve daha fazla bilgi için GSmartControl&apos;u çalıştırın</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1290"/>
        <source>Do you want to abort the installation?</source>
        <translation>Kurulumu iptal etmek mi istiyorsunuz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1295"/>
        <source>Do you want to continue?</source>
        <translation>Devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1442"/>
        <source>Preparing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1462"/>
        <source>Preparing required partitions</source>
        <translation>Gerekli bölümler hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1530"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>LUKS şifreli kaplarını ayarlama</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1550"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1642"/>
        <source>Preparing subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1786"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Yapılandırma dosyası (%1) bulunamadı.</translation>
    </message>
</context>
</TS>
