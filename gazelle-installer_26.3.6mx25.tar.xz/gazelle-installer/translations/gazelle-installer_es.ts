<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="es">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="175"/>
        <source>The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>La unidad seleccionada tiene una capacidad de al menos 2 TB y debe estar formateada con GPT. En algunos sistemas, un disco formateado con GPT no arrancará.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="177"/>
        <source>Are you sure you want to continue?</source>
        <translation>¿Estás seguro que quieres continuar?</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="183"/>
        <source>The system and home drives cannot be the same for this type of installation.</source>
        <translation>Las unidades del sistema y de home no pueden ser las mismas para este tipo de instalación.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="187"/>
        <source>Format and use drives entirely for %1</source>
        <translation>Formatear y utilizar unidades exclusivamente para %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="189"/>
        <source>System drive: %1</source>
        <translation>Unidad del sistema: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="191"/>
        <source>Home drive: %1</source>
        <translation>Unidad de home: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="194"/>
        <source>Format and use the entire drive for %1: %2</source>
        <translation>Formatear y usar todo el disco para %1: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="224"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>Recomendado: %1
Mínimo: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="226"/>
        <source>Minimum for hibernation support: %1</source>
        <translation>Mínimo para soporte de hibernación: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="268"/>
        <source>Layout Builder</source>
        <translation>Generador de diseños</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="468"/>
        <source>%1% root
%2% home</source>
        <translation>%1% root
%2% home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="470"/>
        <source>Combined root and home</source>
        <translation>Root y home combinados</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="89"/>
        <source>Cannot access installation media.</source>
        <translation>No se puede acceder a los medios de instalación.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="253"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Fallo al eliminar el sistema antiguo en el destino.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="256"/>
        <source>Deleting old system</source>
        <translation>Borrando sistema anterior</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="280"/>
        <source>Failed to set the system configuration.</source>
        <translation>Ha fallado la configuración del sistema.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="282"/>
        <source>Setting system configuration</source>
        <translation>Estableciendo la configuración del sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="437"/>
        <source>Copying new system</source>
        <translation>Copiando el sistema nuevo</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="609"/>
        <source>Failed to copy the new system.</source>
        <translation>Fallo al copiar el nuevo sistema.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="117"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>La instalación de GRUB falló. Puede reiniciar al medio en vivo y usar el menú de rescate de GRUB para reparar la instalación.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="191"/>
        <source>Installing GRUB</source>
        <translation>Instalando GRUB</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="438"/>
        <source>Updating initramfs</source>
        <translation>Actualizando initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="439"/>
        <source>Failed to update initramfs.</source>
        <translation>Fallo al actualizar initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="497"/>
        <source>System boot disk:</source>
        <translation>Disco de arranque del sistema:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="512"/>
        <location filename="../bootman.cpp" line="522"/>
        <source>Partition to use:</source>
        <translation>Partición a utilizar:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="67"/>
        <source>The installation media is corrupt.</source>
        <translation>El medio de instalación está corrupto.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="76"/>
        <source>The installation media is still being checked.</source>
        <translation>El medio de instalación aún se está comprobando.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="77"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>¿Está seguro que desea omitir la comprobación de los medios de instalación?</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="231"/>
        <source>Checking installation media.</source>
        <translation>Comprobación de los medios de instalación.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="232"/>
        <source>Press ESC to skip.</source>
        <translation>Presione ESC para omitir.</translation>
    </message>
</context>
<context>
    <name>Crypto</name>
    <message>
        <location filename="../crypto.cpp" line="63"/>
        <source>Failed to format LUKS container.</source>
        <translation>Fallo al formatear el contenedor LUKS.</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="67"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Creando volumen cifrado: %1</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="72"/>
        <source>Failed to open LUKS container.</source>
        <translation>Fallo al abrir el contenedor LUKS.</translation>
    </message>
</context>
<context>
    <name>Device</name>
    <message>
        <location filename="../partman.cpp" line="2261"/>
        <source>Overwrite</source>
        <translation>Sobrescribir</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2261"/>
        <source>Create</source>
        <translation>Crear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2262"/>
        <source>Delete</source>
        <translation>Borrar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2265"/>
        <source>Preserve</source>
        <translation>Preservar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2266"/>
        <source>Preserve (%1)</source>
        <translation>Conservar (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2267"/>
        <source>Preserve /home (%1)</source>
        <translation>Conservar /home (%1)</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="408"/>
        <source>Unknown release</source>
        <translation>Versión desconocida</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="114"/>
        <source>Shutdown</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="235"/>
        <source>You are running 32-bit OS started in 64-bit UEFI mode.</source>
        <translation>Está ejecutando un sistema operativo de 32 bits iniciado en modo UEFI de 64 bits.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="236"/>
        <source>The system will not be able to boot unless you restart the system in Legacy Boot (or similar mode) before proceeding.</source>
        <translation>El sistema no podrá arrancar a menos que lo reinicie en modo Legacy Boot (o similar) antes de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="238"/>
        <source>Do you want to continue the installation?</source>
        <translation>¿Desea continuar con la instalación?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="280"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>El instalador %1 realizará ahora las acciones solicitadas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="281"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Estas acciones no podrán deshacerse. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="293"/>
        <source>Support %1</source>
        <translation>Soporte %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="294"/>
        <source>%1 is supported by people like you. Some help others at the support forum, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 cuenta con el apoyo de personas como tú. Algunas ayudan a otras en el foro de soporte, traducen archivos de ayuda a diferentes idiomas, hacen sugerencias, escriben documentación o ayudan a probar nuevo software.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="339"/>
        <location filename="../minstall.cpp" line="1442"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 es una distribución independiente de Linux basada en Debian Estable.

%1 utiliza algunos componentes de MEPIS Linux, los cuales están bajo una licencia libre de Apache. Algunos componentes de MEPIS han sido modificados para %1. 

¡Disfrute  %1! </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="440"/>
        <source>Preparing to install %1</source>
        <translation>Preparando la instalación de %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="457"/>
        <source>Paused for required operator input</source>
        <translation>Pausado para la intervención requerida del operador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="469"/>
        <source>Setting system configuration</source>
        <translation>Estableciendo la configuración del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="481"/>
        <source>Cleaning up</source>
        <translation>Limpiando</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="485"/>
        <source>Finished</source>
        <translation>El proceso ha terminado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="497"/>
        <source>Configuring system. Please wait.</source>
        <translation>Configurando el sistema. Espere por favor.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="501"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Configuración completa. Reiniciando el sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="508"/>
        <source>The installation was aborted.</source>
        <translation>La instalación se ha interrumpido.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="532"/>
        <source>Pretending to install %1</source>
        <translation>Empezando a instalar %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="571"/>
        <source>Invalid settings found in configuration file (%1).</source>
        <translation>Se han encontrado ajustes no válidos en el archivo de configuración (%1).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="572"/>
        <source>Please review marked fields as you encounter them.</source>
        <translation>Revise los campos marcados a medida que los encuentre.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="665"/>
        <location filename="../minstall.cpp" line="693"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Los datos en /home no se pueden conservar porque no se pudo obtener la información requerida.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="725"/>
        <source>Cannot find selected drive.</source>
        <translation>No se encontró la unidad seleccionada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="774"/>
        <source>The home directory for %1 already exists.</source>
        <translation>El directorio home para %1 ya existe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="815"/>
        <source>General Instructions</source>
        <translation>Instrucciones Generales</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="816"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ANTES DE CONTINUAR, CIERRE TODAS LAS DEMÁS APLICACIONES.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>En cada página, por favor lea las instrucciones, haga sus selecciones y luego haga clic en Siguiente cuando esté listo para continuar. Se le pedirá confirmación antes de realizar cualquier acción que resulte destructiva.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="819"/>
        <source>Limitations</source>
        <translation>Limitaciones</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="820"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Recuerde, este software se proporciona TAL CUAL, sin garantía alguna. Es su exclusiva responsabilidad hacer una copia de seguridad de sus datos antes de proceder.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>Installation Options</source>
        <translation>Opciones de instalación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="825"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Si utiliza Mac OS o Windows OS (a partir de Vista), es posible que tenga que utilizar el software de ese sistema para configurar las particiones y el gestor de arranque antes de la instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="826"/>
        <source>Dual drive</source>
        <translation>Doble unidad</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="827"/>
        <source>If your system has multiple storage drives, this option allows you to have the system files on one drive (the System drive), while keeping the data of all users on a separate drive (the Home drive).</source>
        <translation>Si su sistema tiene varias unidades de almacenamiento, esta opción le permite tener los archivos del sistema en una unidad (la unidad del sistema), mientras que los datos de todos los usuarios se guardan en una unidad separada (la unidad Home)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="829"/>
        <source>Using the root-home space slider</source>
        <translation>Usar el deslizador de espacio root-home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="830"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>La unidad se puede dividir en particiones separadas de sistema (root) y de datos de usuario (home) usando el control deslizante.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="831"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>La partición &lt;b&gt;root&lt;/b&gt; contendrá el sistema operativo y las aplicaciones.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>La partición &lt;b&gt;home&lt;/b&gt; contendrá los datos de todos los usuarios, como su configuración, archivos, documentos, imágenes, música, videos, etc.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="833"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Mueva el deslizador hacia la derecha para aumentar el espacio para &lt;b&gt;root&lt;/b&gt;. Muévalo hacia la izquierda para aumentar el espacio para &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="834"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Mueva el deslizador completamente hacia la derecha si desea que tanto root como home estén en la misma partición.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Mantener el directorio de inicio en una partición separada mejora la confiabilidad de las actualizaciones del sistema operativo. También facilita la realización de copias de seguridad y la recuperación. Esto también puede mejorar el rendimiento general al restringir los archivos del sistema a una parte definida de la unidad.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="837"/>
        <location filename="../minstall.cpp" line="935"/>
        <location filename="../minstall.cpp" line="955"/>
        <source>Encryption</source>
        <translation>Encriptación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="838"/>
        <location filename="../minstall.cpp" line="936"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>La encriptación es posible a través de LUKS. Se requiere una contraseña.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="839"/>
        <location filename="../minstall.cpp" line="937"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Se requiere una partición de arranque no cifrada por separado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="840"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Cuando se utiliza el cifrado con la autoinstalación, la partición de arranque separada se creará automáticamente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="841"/>
        <source>Using a custom disk layout</source>
        <translation>Usar un diseño de disco personalizado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="842"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Si necesita más control sobre dónde está instalado %1, seleccione &quot;&lt;b&gt;%2&lt;/b&gt;&quot; y haga clic en &lt;b&gt;Siguiente&lt;/b&gt;. En la página siguiente, podrá seleccionar y configurar los dispositivos de almacenamiento y las particiones que necesite.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <location filename="../minstall.cpp" line="850"/>
        <source>Replace existing installation</source>
        <translation>Sustituir la instalación existente</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <source>Replace existing installation option will attempt to replace an existing installation with the same disk configuration as the existing installation.  Home directories are preserved.</source>
        <translation>La opción &quot;Reemplazar la instalación existente&quot; intentará reemplazar la instalación actual con la misma configuración de disco existente en la instalación. Los directorios personales se conservan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="851"/>
        <source>If you have an existing installation, you can use this function to replace it with a fresh installation.</source>
        <translation>Si ya tiene una instalación, puede utilizar esta función para sustituirla por una nueva instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="852"/>
        <source>This is particularly useful if you are upgrading from a previous version and want to preserve your data.</source>
        <translation>Esto resulta especialmente útil si está actualizando desde una versión anterior y desea conservar sus datos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="854"/>
        <source>There is no guarantee of this working successfully. Ensure you have a good working backup of all important data before continuing.</source>
        <translation>No hay garantía de que esto funcione correctamente. Asegúrese de tener una copia de seguridad en buen estado de todos los datos importantes antes de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="855"/>
        <source>This feature is designed to replace an installation performed using the regular install method, and may fail to replace an installation with a complex layout or storage scheme. Corruption or data loss may occur.</source>
        <translation>Esta función está diseñada para sustituir una instalación realizada mediante el método de instalación habitual y es posible que no pueda sustituir una instalación con una estructura o un esquema de almacenamiento complejos. Se pueden producir daños o pérdidas de datos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="857"/>
        <source>To replace an installation with a complex layout or storage scheme, it is recommended to use the custom layout option instead.</source>
        <translation>Para sustituir una instalación con un diseño o esquema de almacenamiento complejo, se recomienda utilizar la opción de diseño personalizado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="865"/>
        <source>Choose Partitions</source>
        <translation>Seleccione Particiones</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="866"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>La lista de particiones le permite elegir qué particiones se utilizan para esta instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="867"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Dispositivo&lt;/i&gt; - Este es el nombre del dispositivo de bloque que se asigna o se asignará a la partición creada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="868"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Tamaño&lt;/i&gt; - El tamaño de la partición. Esto solo se puede cambiar en un nuevo diseño.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="869"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Usar para&lt;/i&gt; - Para usar esta partición en una instalación, debe seleccionar algo aquí.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="871"/>
        <source>Format without mounting</source>
        <translation>Formato sin montaje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="872"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>Partición GPT de arranque de BIOS para GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="873"/>
        <location filename="../minstall.cpp" line="912"/>
        <source>EFI System Partition</source>
        <translation>Sistema de partición EFI</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="875"/>
        <source>Boot manager</source>
        <translation>Gestor de arranque</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="876"/>
        <source>System root</source>
        <translation>Raíz del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="877"/>
        <source>User data</source>
        <translation>Datos del usuario</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="878"/>
        <source>Static data</source>
        <translation>Datos estáticos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="879"/>
        <source>Variable data</source>
        <translation>Datos variables</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="880"/>
        <source>Temporary files</source>
        <translation>Archivos temporales</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="881"/>
        <source>Swap files</source>
        <translation>Archivos swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="882"/>
        <source>Swap partition</source>
        <translation>Partición swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="884"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Además de lo anterior, también puede escribir su propio punto de montaje. Los puntos de montaje personalizados deben comenzar con una barra (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="885"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etiqueta&lt;/i&gt; - La etiqueta que se asigna a la partición una vez que se ha formateado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="886"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Encriptar&lt;/i&gt; - Utilice el cifrado LUKS para esta partición. La contraseña se aplica a todas las particiones seleccionadas para el cifrado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="887"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Formato&lt;/i&gt; -  Este es el formato de la partición. Los formatos disponibles dependen de para qué se utiliza la partición. Cuando trabaje con un diseño existente, es posible que pueda conservar el formato de la partición seleccionando &lt;b&gt;Conservar&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="889"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>Seleccionando &lt;b&gt;Preservar /home&lt;/b&gt; para la partición raíz se preserva el contenido del directorio /home, borrando todo lo demás. Esta opción sólo se puede utilizar cuando /home está en la misma partición que la partición raíz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="891"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Los sistemas de archivos de Linux ext2, ext3, ext4, jfs, xfs y btrfs son soportados se recomienda ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="892"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Verificar&lt;/i&gt; - Verificar y corregir los bloques defectuosos en la unidad (no es compatible con todos los formatos). Esto lleva mucho tiempo, por lo que es posible que desee omitir este paso a menos que sospeche que su unidad tiene bloques defectuosos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="894"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Opciones de montaje&lt;/i&gt; - Especifica las opciones de montaje que se utilizarán para esta partición.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="895"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Volcado&lt;/i&gt; - Indica a la utilidad de volcado que incluya esta partición en la copia de seguridad.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="896"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Pasadas&lt;/i&gt; - La secuencia en la que este sistema de archivos debe ser comprobado en el arranque. Si es cero, el sistema de archivos no se comprueba.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="897"/>
        <source>Menus and actions</source>
        <translation>Menús y acciones</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="898"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Hay una variedad de acciones disponibles al hacer clic con el botón derecho en cualquier unidad o elemento de partición de la lista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="899"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Los botones a la derecha de la lista también se pueden utilizar para manipular las entradas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="900"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>El instalador no puede modificar el diseño que ya está en la unidad. Para crear un diseño personalizado, marque la unidad para un nuevo diseño con la acción del menú &lt;b&gt;Nuevo diseño&lt;/b&gt; o el botón (%1). Esto borra el diseño existente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="903"/>
        <source>Basic layout requirements</source>
        <translation>Requisitos básicos de diseño</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="904"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 requiere una partición root. La partición swap es opcional pero muy recomendable. Si desea utilizar la función suspender a disco de %1, necesitará una partición de intercambio (swap) que sea mayor que el tamaño de su memoria física.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="906"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Si elige una partición /home separada, le será más fácil actualizar en el futuro, pero esto no será posible si está actualizando desde una instalación que no tiene una partición home separada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="908"/>
        <source>Active partition</source>
        <translation>Partición activa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="909"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Para que el sistema operativo instalado arranque, la partición adecuada (generalmente la partición de arranque o root) debe estar marcada como activa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="910"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>La partición activa de una unidad se puede elegir mediante la acción &lt;b&gt;Partición activa&lt;/b&gt; del menú.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="911"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Una partición con un asterisco (*) junto al nombre de su dispositivo es, o se convertirá en, la partición activa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="913"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Si su sistema utiliza la Interfaz de Firmware Extensible (EFI), se requiere una partición conocida como Partición del Sistema EFI (ESP) para que el sistema arranque.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="914"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Estos sistemas no requieren ninguna partición marcada como Activa, sino que requieren una partición formateada con un sistema de archivos FAT, marcada como ESP.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="915"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>La mayoría de los sistemas construidos en los últimos 10 años utilizan EFI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="916"/>
        <source>Boot partition</source>
        <translation>Partición de arranque</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="917"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Esta partición generalmente sólo es necesaria para las particiones raíz en dispositivos virtuales como volúmenes cifrados, LVM o RAID por software.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="918"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Contiene un kernel básico y los controladores utilizados para acceder al disco cifrado o a los dispositivos virtuales.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="919"/>
        <source>BIOS-GRUB partition</source>
        <translation>Partición BIOS-GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="920"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>Cuando se utiliza una unidad con formato GPT en un sistema no EFI, se requiere una partición de arranque de la BIOS de 1MB cuando se utiliza GRUB.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="921"/>
        <source>Need help creating a layout?</source>
        <translation>¿Necesita ayuda para crear un diseño?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="922"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Basta con hacer clic con el botón derecho en una unidad y seleccionar &lt;b&gt;Generador de diseños&lt;/b&gt; en el menú. Esto puede crear un diseño similar al de la instalación normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="923"/>
        <source>Upgrading</source>
        <translation>Actualización</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="924"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Para actualizar desde una instalación de Linux existente, seleccione la misma partición de inicio que antes y seleccione &lt;b&gt;Conservar&lt;/b&gt; como formato.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="925"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Si no usa una partición de inicio separada, seleccione &lt;b&gt;Preservar /home&lt;/b&gt; en la entrada del sistema de archivos root para preservar el directorio /home existente ubicado en su partición root. El instalador solo conservará /home y eliminará todo lo demás. Como resultado, la instalación tardará mucho más de lo habitual.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="927"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipo de sistema de archivos preferido</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="928"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Para %1, puede optar por formatear las particiones como ext2, ext3, ext4, f2fs, jfs, xfs o btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="929"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Hay opciones adicionales de compresión disponibles para unidades que utilizan btrfs. Lzo es rápido, pero la compresión es menor. Zlib es más lento, con mayor compresión.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="931"/>
        <source>System partition management tool</source>
        <translation>Herramienta de gestión de particiones del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="932"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Para tener más control sobre los diseños de la unidad (como modificar el diseño existente en un disco), haga clic en el botón de administración de particiones (% 1). Esto ejecutará la herramienta de administración de particiones del sistema operativo, lo que le permitirá crear el diseño exacto que necesita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="938"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Para conservar una partición cifrada, haga clic derecho sobre ella y seleccione &lt;b&gt;Desbloquear&lt;/b&gt;. En el cuadro de diálogo que aparece, ingrese un nombre para el dispositivo virtual y la contraseña. Cuando el dispositivo está desbloqueado, el nombre que elija aparecerá en &lt;i&gt;Dispositivos virtuales&lt;/i&gt;, con opciones similares a las de una partición normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="940"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Para que la partición cifrada se desbloquee en el arranque, debe agregarse al archivo crypttab. Utilice la acción del menú &lt;b&gt;Agregar a crypttab&lt;/b&gt; para hacer esto.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="941"/>
        <source>Other partitions</source>
        <translation>Otras particiones</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="942"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>El instalador permite que se creen o utilicen otras particiones para otros fines; sin embargo, tenga en cuenta que los sistemas más antiguos no pueden manejar unidades con más de 4 particiones.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="943"/>
        <source>Subvolumes</source>
        <translation>Subvolúmenes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="944"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Algunos sistemas de archivos, como Btrfs, admiten varios subvolúmenes en una sola partición. Estas no son subdivisiones físicas, por lo que su orden no importa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="946"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Utilice la acción del menú &lt;b&gt;Escanear subvolúmenes&lt;/b&gt; para buscar subvolúmenes en una partición Btrfs existente. Para crear un nuevo subvolumen, use la acción de menú &lt;b&gt;Nuevo subvolumen&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="948"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Los subvolúmenes existentes se pueden conservar, sin embargo, el nombre debe seguir siendo el mismo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="949"/>
        <source>Virtual Devices</source>
        <translation>Dispositivos virtuales</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="950"/>
        <source>If the installer detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Si el instalador detecta cualquier dispositivo virtual como particiones LUKS abiertas, volúmenes lógicos LVM o volúmenes RAID basados en software, pueden ser utilizados para la instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="951"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>El uso de dispositivos virtuales (más allá de preservar los sistemas de archivos cifrados) es una característica avanzada. Puede que tenga que editar algunos archivos (por ejemplo, initramfs, crypttab, fstab) para asegurarse de que los dispositivos virtuales utilizados se creen al arrancar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="956"/>
        <source>You have chosen to encrypt at least one volume, and more information is required before continuing.</source>
        <translation>Ha elegido cifrar al menos un volumen y se necesita más información antes de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="961"/>
        <source>Final Review and Confirmation</source>
        <translation>Revisión y confirmación final</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="962"/>
        <source>Please review this list carefully. This is the last opportunity to check, review and confirm the actions of the installation process before proceeding.</source>
        <translation>Por favor, revise esta lista cuidadosamente. Esta es la última oportunidad para comprobar, revisar y confirmar las acciones del proceso de instalación antes de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="972"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalar GRUB para Linux y Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="973"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1 utiliza el gestor de arranque GRUB para arrancar %1 y Microsoft Windows.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="974"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Por defecto GRUB se instala en el Registro Maestro de Arranque (MBR) o ESP (Partición del Sistema EFI para sistemas de arranque UEFI de 64 bits) de su unidad de arranque y reemplaza al gestor de arranque que estaba utilizando antes. Esto es lo normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="975"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Si elige instalar GRUB en Partition Boot Record (PBR) en su lugar, entonces GRUB se instalará al principio de la partición especificada. Esta opción es sólo para expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="976"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Si desmarca la casilla Instalar GRUB, GRUB no se instalará en este momento. Esta opción es sólo para expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="977"/>
        <source>Generate host-specific initramfs will try to create an initramfs tailored for the particular device rather than a generic all-purpose initramfs. This option is for experts only.</source>
        <translation>Generar initramfs específico para el host intentará crear un initramfs adaptado al dispositivo concreto en lugar de un initramfs genérico para todo uso. Esta opción es solo para expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="985"/>
        <source>Zram swap is a method of putting swap space in RAM.  A compressed swap device is placed in RAM.  It may be used in conjunction with other forms of swap, or on its own.</source>
        <translation>El intercambio Zram es un método para colocar espacio de intercambio en la RAM. Se coloca un dispositivo de intercambio comprimido en la RAM. Se puede utilizar junto con otras formas de intercambio o por sí solo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1404"/>
        <source>Welcome to %1 Installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1418"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Reiniciar automáticamente el sistema cuando el instalador este cerrado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1519"/>
        <location filename="../minstall.cpp" line="1529"/>
        <source> %:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1611"/>
        <source>Installation Confirmation</source>
        <translation>Confirmación de la instalación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1617"/>
        <source>Please review the installation settings.

This is the last opportunity to check and confirm
the actions of the installation process.

Press ENTER to begin installation or Backspace to go back.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1642"/>
        <source>Enter computer name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1657"/>
        <source>Enter domain name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>Workgroup</source>
        <translation>Equipo de trabajo:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Localization Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>Locale:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Time Area:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Time Zone:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>System services will be configured with default settings.
You can modify service settings after installation
using your system's service manager.

Press ENTER to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>Replace Existing Installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1881"/>
        <source>Attempt to upgrade packages</source>
        <translation>Intentando actualizar paquetes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1899"/>
        <source>Custom Partitioning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1914"/>
        <source>Swap File Configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1927"/>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1938"/>
        <source>Size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1952"/>
        <source>R: reset size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1958"/>
        <source>Enable hibernation support</source>
        <translation>Activar el soporte de hibernación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1964"/>
        <source>Zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1969"/>
        <source>Enable zram swap</source>
        <translation>Habilitar swap zram</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1976"/>
        <source>Allocate based on RAM (%):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1991"/>
        <source>Allocate fixed size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2138"/>
        <source>Encryption options</source>
        <translation>Opciones de cifrado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2143"/>
        <source>Encryption password:</source>
        <translation>Contraseña de cifrado:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2154"/>
        <source>Confirm password:</source>
        <translation>Confirmar contraseña:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2192"/>
        <source>Enter username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2206"/>
        <source>Enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2219"/>
        <source>Re-enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2285"/>
        <source>A home directory already exists for this user name.
Choose what to do with it:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2329"/>
        <source>The system is being installed.
This may take several minutes.

Press ENTER to continue to completion screen.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3641"/>
        <source>Passwords must match and not be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3969"/>
        <source>Please enter a computer name.</source>
        <translation>Por favor ingrese un nombre de computadora.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3972"/>
        <source>The computer name contains invalid characters.</source>
        <translation>El nombre del ordenador contiene caracteres no válidos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3975"/>
        <source>Please enter a domain name.</source>
        <translation>Por favor ingrese un nombre de dominio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3978"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>El domino del ordenador contiene caracteres no válidos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3981"/>
        <source>Please enter a workgroup.</source>
        <translation>Por favor ingrese un grupo de trabajo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4267"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>El nombre de usuario no puede contener caracteres especiales ni espacios.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4270"/>
        <location filename="../minstall.cpp" line="4273"/>
        <source>Please ensure the passwords match.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4288"/>
        <source>The chosen user name is in use.</source>
        <translation>El nombre de usuario elegido ya está en uso.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4292"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>No ha proporcionado una frase de contraseña para %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4300"/>
        <source>You did not provide a password for the root account.</source>
        <translation>No ha proporcionado una contraseña para la cuenta root.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4387"/>
        <source>Please select an option to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="982"/>
        <location filename="../minstall.cpp" line="1919"/>
        <source>Create a swap file</source>
        <translation>Crear un archivo para la swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="278"/>
        <source>Experimental</source>
        <comment>As In feature is not polished and may not work properly</comment>
        <translation>Experimental</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="983"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Un archivo de intercambio es más flexible que una partición de intercambio; es considerablemente más fácil redimensionar un archivo de intercambio para adaptarse a los cambios en el uso del sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="984"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Por defecto, está marcada si no se han establecido particiones swap, y desmarcada si se han establecido particiones swap. Esta opción debe dejarse sin tocar, y es sólo para expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="990"/>
        <source>Common Services to Enable</source>
        <translation>Servicios comunes para habilitar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="991"/>
        <source>Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.</source>
        <translation>Seleccione cualquiera de estos servicios comunes que pueda necesitar con la configuración de su sistema y los servicios se iniciarán automáticamente cuando inicie %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="996"/>
        <source>Computer Identity</source>
        <translation>Nombre del ordenador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="997"/>
        <source>The computer name is a common unique name which will identify your computer if it is on a network.</source>
        <translation>El nombre del ordenador es un nombre único común que identificará su ordenador si está conectado a una red.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="998"/>
        <source>The computer domain is unlikely to be used unless your ISP or local network requires it.</source>
        <translation>Es poco probable que se utilice el dominio del ordenador, a menos que su ISP o red local lo requieran.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="999"/>
        <source>The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens.</source>
        <translation>Los nombres de ordenador y de dominio solo pueden contener caracteres alfanuméricos, puntos y guiones. No pueden contener espacios en blanco ni comenzar o terminar con guiones.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1001"/>
        <source>The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.</source>
        <translation>El servidor SaMBa debe activarse si desea utilizarlo para compartir algunos de sus directorios o impresoras con un ordenador local que ejecute MS-Windows o Mac OSX.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1006"/>
        <source>Localization Defaults</source>
        <translation>Localización por Defecto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1007"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Establezca la configuración regional predeterminada. Esto se aplicará a menos que el usuario las anule más adelante.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1008"/>
        <source>Configure Clock</source>
        <translation>Configurar el Reloj</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1009"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Si tiene una computadora Apple o Unix puro, el reloj del sistema está configurado de forma predeterminada en la hora del meridiano de Greenwich (GMT) o en la hora universal coordinada (UTC). Para cambiar esto, marque la casilla &quot;&lt;b&gt;El reloj del sistema usa la hora local&lt;/b&gt;&quot;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1011"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>El sistema arranca con la zona horaria preestablecida en GMT/UTC. Para cambiar la zona horaria, después de reiniciar en la nueva instalación, haga clic derecho en el reloj en el Panel y seleccione Propiedades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1013"/>
        <source>Service Settings</source>
        <translation>Configuración de servicio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1014"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>La mayoría de los usuarios no deberían cambiar los valores predeterminados. Los usuarios con computadoras de bajos recursos a veces desean deshabilitar los servicios innecesarios para mantener el uso de RAM lo más bajo posible. ¡Asegúrate de saber lo que estás haciendo!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1021"/>
        <source>Default User Login</source>
        <translation>Inicio de sesión de usuario predeterminado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1022"/>
        <source>Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Introduzca el nombre de una nueva cuenta de usuario ( predeterminada) que utilizará a diario. Si es necesario, puede añadir otras cuentas de usuario más adelante con %1 User Manager.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1024"/>
        <source>Root (administrator) account</source>
        <translation>Cuenta root (administrador)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1025"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account.</source>
        <translation>El usuario root es similar al usuario Administrador en algunos otros sistemas operativos. No debe utilizar el usuario root como cuenta de usuario diaria.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1027"/>
        <source>The root account is disabled on MX Linux, as administrative tasks are performed with an elevation prompt for the default user.</source>
        <translation>La cuenta root está deshabilitada en MX Linux, ya que las tareas administrativas se realizan con un prompt de elevación para el usuario por defecto.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1028"/>
        <source>Enabling the root account is strongly recommended for antiX Linux.</source>
        <translation>Se recomienda encarecidamente habilitar la cuenta root para antiX Linux.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1029"/>
        <source>Passwords</source>
        <translation>Contraseñas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1030"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Ingrese una nueva contraseña para su cuenta de usuario predeterminada y para la cuenta root. Cada contraseña debe ingresarse dos veces.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1032"/>
        <source>No passwords</source>
        <translation>Sin contraseñas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1033"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Si desea que la cuenta de usuario predeterminada no tenga contraseña, deje los campos de contraseña vacíos. Esto le permite iniciar sesión sin necesidad de una contraseña.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1035"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Obviamente, esto solo debe hacerse en situaciones en las que la cuenta de usuario no necesita ser segura, como una terminal pública.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1044"/>
        <location filename="../minstall.cpp" line="2279"/>
        <source>Old Home Directory</source>
        <translation>Directorio Home Antiguo</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1045"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Ya existe un directorio home para el nombre de usuario que ha elegido. Esta pantalla le permite elegir lo que le sucede a este directorio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1047"/>
        <location filename="../minstall.cpp" line="2291"/>
        <source>Re-use it for this installation</source>
        <translation>Reutilizarlo para esta instalación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1048"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>El directorio home antiguo será utilizado para esta cuenta de usuario. Esta es una buena opción cuando se actualiza, y sus archivos y configuraciones estarán fácilmente disponibles.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1050"/>
        <location filename="../minstall.cpp" line="2298"/>
        <source>Rename it and create a new directory</source>
        <translation>Renombrar y crear un nuevo directorio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1051"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Se creará un nuevo directorio home para el usuario, pero el antiguo directorio home será renombrado. Sus archivos y configuraciones no serán visibles inmediatamente en la nueva instalación, pero se puede acceder a ellos usando el directorio renombrado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1053"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>El directorio antiguo tendrá un número al final, dependiendo de cuántas veces el directorio ha sido renombrado antes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1054"/>
        <location filename="../minstall.cpp" line="2305"/>
        <source>Delete it and create a new directory</source>
        <translation>Borrar y crear un nuevo directorio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1055"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>El antiguo directorio de home se eliminará y se creará uno nuevo desde cero.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="853"/>
        <location filename="../minstall.cpp" line="1056"/>
        <source>Warning</source>
        <translation>Advertencia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1057"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Todos los archivos y configuraciones se eliminarán permanentemente si se selecciona esta opción. Sus posibilidades de recuperarlos son bajas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1069"/>
        <location filename="../minstall.cpp" line="2323"/>
        <source>Installation in Progress</source>
        <translation>Instalación en Progreso</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1070"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 se está instalando. Para una instalación nueva, esto probablemente tomará de 3-20 minutos, dependiendo de la velocidad de su sistema y del tamaño de cualquier partición que esté reformateando.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1072"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Si hace clic en el botón Abortar, la instalación se detendrá tan pronto como sea posible.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1074"/>
        <source>Change settings while you wait</source>
        <translation>Cambia la configuración mientras esperas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1075"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Mientras se instala %1, puede hacer clic en los botones &lt;b&gt;Siguiente&lt;/b&gt; o &lt;b&gt;Atrás&lt;/b&gt; para ingresar otra información requerida para la instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1077"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Complete estos pasos a su propio ritmo. El instalador esperará su aporte si es necesario.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1084"/>
        <source>Congratulations!</source>
        <translation>¡Felicidades!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1085"/>
        <source>You have completed the installation of %1.</source>
        <translation>Ha completado la instalación de %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1086"/>
        <source>Finding Applications</source>
        <translation>Búsqueda de aplicaciones</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1087"/>
        <source>There are hundreds of excellent applications installed with %1. The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus.</source>
        <translation>Hay cientos de aplicaciones excelentes instaladas con %1. La mejor manera de conocerlas es navegar por el menú y probarlas. Muchas de las aplicaciones se desarrollaron específicamente para el proyecto %1. Estas se muestran en los menús principales.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1091"/>
        <source>In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.</source>
        <translation>Además, %1 incluye muchas aplicaciones estándar de Linux que solo se ejecutan desde la línea de comandos y, por lo tanto, no aparecen en el menú.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1093"/>
        <source>Enjoy using %1</source>
        <translation>Disfrute usando %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1126"/>
        <source>Finish</source>
        <translation>Terminar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>Start</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1132"/>
        <source>OK</source>
        <translation>Está bien</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1134"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1259"/>
        <source>The installation and configuration is incomplete.</source>
        <translation>La instalación y la configuración están incompletas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1260"/>
        <source>Do you really want to stop now?</source>
        <translation>¿De verdad quiere detenerse ahora?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1337"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Buscar Ayuda&lt;/b&gt;&lt;br/&gt;La información Básica acerca de %1 está en %2.&lt;/p&gt;&lt;p&gt;Hay voluntarios que pueden asistirlo en el foro %3, %4&lt;/p&gt;&lt;p&gt;Si solicita ayuda, por favor recuerde describir su problema y su computador en detalle. Declaraciones como &apos;tal cosa no funciona&apos; normalmente no nos ayudan para determinar una solución a su problema.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparando su instalación&lt;/b&gt;&lt;br/&gt;Si %1 deja de funcionar desde el disco duro, a veces es posible arreglar el problema al iniciar con el LiveDVD o LiveUSB y al ejecutar una de las utilidades incluidas en %1 o por medio de las herramientas incluidas en Linux para reparar el sistema.&lt;/p&gt;&lt;p&gt;¡Además, puede utilizar el %1 LiveDVD o LiveUSB para recuperar datos de sistemas de MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1351"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ajustando el Mezclador de Sonido&lt;/b&gt;&lt;br/&gt; %1 intenta configurar el mezclador de sonido pero a veces será necesario que usted ajuste el volumen y/o desactive el silenciador de canales para poder escuchar el sonido.&lt;/p&gt; &lt;p&gt;El atajo del mezclador está ubicado en el menú. Haga clic en él para abrirlo. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1359"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mantenga su copia de %1 actualizada&lt;/b&gt;&lt;br/&gt;Para más información y actualizaciones, por favor visite &lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Agradecimientos Especiales&lt;/b&gt;&lt;br/&gt;Gracias a todos quienes han decidido apoyar %1 con su tiempo, recursos económicos, sugerencias, trabajo, elogios, ideas, promoción y/o estímulo.&lt;/p&gt;&lt;p&gt;Sin ustedes, no existia %1.&lt;/p&gt;&lt;p&gt;%2 Equipo de Desarolladores&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ayuda</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Registro live</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Anterior</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="78"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="85"/>
        <source>Next</source>
        <translation>Siguiente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="91"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="114"/>
        <source>Installation in progress</source>
        <translation>Instalación en progreso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="129"/>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="132"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="168"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Recopilación de información, por favor, espere.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="200"/>
        <source>Terms of Use</source>
        <translation>Condiciones de uso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="232"/>
        <source>Keyboard Settings</source>
        <translation>Configuración del teclado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="247"/>
        <source>Model:</source>
        <translation>Modelo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="262"/>
        <source>Variant:</source>
        <translation>Variante:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>Change Keyboard Settings</source>
        <translation>Cambiar Configuración del Teclado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="294"/>
        <source>Layout:</source>
        <translation>Distribución:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="341"/>
        <source>Select type of installation</source>
        <translation>Seleccione el tipo de instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="414"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="499"/>
        <location filename="../meinstall.ui" line="521"/>
        <location filename="../meinstall.ui" line="1153"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="534"/>
        <source>Encrypt</source>
        <translation>Cifrar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1121"/>
        <source>Enable hibernation support</source>
        <translation>Activar el soporte de hibernación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="353"/>
        <source>Regular install using the entire disk</source>
        <translation>Instalación regular usando todo el disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Dual drive</source>
        <translation>Doble unidad</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="370"/>
        <source>System drive:</source>
        <translation>Unidad del sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="380"/>
        <source>Home drive:</source>
        <translation>Unidad de home:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="544"/>
        <source>Customize the disk layout</source>
        <translation>Personaliza el diseño del disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="551"/>
        <source>Replace existing installation</source>
        <translation>Sustituir la instalación existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="590"/>
        <source>Replace an existing installation</source>
        <translation>Sustituye una instalación existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="612"/>
        <source>Device</source>
        <translation>Medio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="617"/>
        <source>Installation</source>
        <translation>Instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="625"/>
        <source>Scan for existing installations</source>
        <translation>Buscar instalaciones existentes</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="646"/>
        <source>Replacement options</source>
        <translation>Opciones de sustitución</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Attempt to upgrade packages</source>
        <translation>Intentando actualizar paquetes</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="663"/>
        <source>Choose partitions</source>
        <translation>Elija las particiones</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="672"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Marque la unidad seleccionada para borrarla para un nuevo diseño.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="683"/>
        <source>Show Grid</source>
        <translation>Mostrar cuadrícula</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="703"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Ejecute la aplicación de gestión de particiones de este sistema operativo.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="714"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Remover una entrada existente del diseño. Esto solo funciona con entradas a un nuevo diseño.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="725"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Consulte el sistema operativo y vuelva a cargar los diseños de todas las unidades.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="750"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Agregue una nueva entrada de partición. Esto solo funciona con un nuevo diseño.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="761"/>
        <source>Show advanced fields.</source>
        <translation>Mostrar campos avanzados.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="791"/>
        <source>Encryption options</source>
        <translation>Opciones de cifrado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="797"/>
        <source>Encryption password:</source>
        <translation>Contraseña de cifrado:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="814"/>
        <source>Confirm password:</source>
        <translation>Confirmar contraseña:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="842"/>
        <source>Installation Confirmation</source>
        <translation>Confirmación de la instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="885"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalar GRUB para Linux y Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="900"/>
        <source>System boot disk:</source>
        <translation>Disco de arranque del sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="942"/>
        <source>EFI System Partition</source>
        <translation>Sistema de partición EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="945"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="964"/>
        <source>Partition Boot Record</source>
        <translation>Registro de Arranque de Partición</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="967"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="989"/>
        <source>Master Boot Record</source>
        <translation>Registro de Inicialización del Disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="995"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="998"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1011"/>
        <source>Location to install on:</source>
        <translation>Ubicación de la instalación:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1018"/>
        <source>Generate host-specific initramfs image</source>
        <translation>Generar imagen initramfs específica del host</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1051"/>
        <source>Create a swap file</source>
        <translation>Crear un archivo para la swap</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <location filename="../meinstall.ui" line="1192"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1091"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1114"/>
        <source>Location:</source>
        <translation>Ubicación:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1131"/>
        <source>Enable zram swap</source>
        <translation>Habilitar swap zram</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1143"/>
        <source>Allocate based on RAM:</source>
        <translation>Asignar en función de la RAM:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1172"/>
        <source>Recommended maximum: 100%</source>
        <translation>Máximo recomendado: 100 %</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1179"/>
        <source>Allocate fixed size:</source>
        <translation>Asignar tamaño fijo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1223"/>
        <source>Common Services to Enable</source>
        <translation>Servicios comunes para habilitar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1233"/>
        <source>Service</source>
        <translation>Servicio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1238"/>
        <source>Description</source>
        <translation>Descripción</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1268"/>
        <source>Computer Network Names</source>
        <translation>Nombres de la Redes de Computadoras</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1295"/>
        <source>Workgroup</source>
        <translation>Equipo de trabajo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1308"/>
        <source>Workgroup:</source>
        <translation>Equipo de trabajo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1321"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Servidor SaMBa para redes de MS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>example.dom</source>
        <translation>ejemplo.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1350"/>
        <source>Computer domain:</source>
        <translation>Dominio del ordenador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1373"/>
        <source>Computer name:</source>
        <translation>Nombre del ordenador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1416"/>
        <source>Localization Defaults</source>
        <translation>Localización por Defecto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1437"/>
        <source>Locale:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1456"/>
        <source>Configure Clock</source>
        <translation>Configurar el Reloj</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1491"/>
        <source>Format:</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Timezone:</source>
        <translation>Zona horaria:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1558"/>
        <source>System clock uses local time</source>
        <translation>El reloj del sistema usa la hora local</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1580"/>
        <source>Service Settings (advanced)</source>
        <translation>Configuración de Servicios (avanzado)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1598"/>
        <source>Adjust which services should run at startup</source>
        <translation>Ajustar cuáles servicios se ejecutarán al inicio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1601"/>
        <source>View</source>
        <translation>Ver</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1650"/>
        <source>Default User Account</source>
        <translation>Cuenta de Usuario Predeterminada</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1662"/>
        <source>Default user login name:</source>
        <translation>Nombre de inicio de sesión del usuario principal:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1678"/>
        <source>username</source>
        <translation>nombre del usuario</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1691"/>
        <source>Default user password:</source>
        <translation>Contraseña del usuario principal:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Confirm user password:</source>
        <translation>Confirmar contraseña de usuario:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1746"/>
        <source>Root (administrator) Account</source>
        <translation>Cuenta root (administrador)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1764"/>
        <source>Root password:</source>
        <translation>Contraseña de root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1790"/>
        <source>Confirm root password:</source>
        <translation>Confirmar la contraseña de root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1819"/>
        <source>Autologin</source>
        <translation>Autoingreso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1826"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Las modificaciones al escritorio del LiveDVD o LiveUSB, serán llevadas a la instalación del SO. </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1829"/>
        <source>Save live desktop changes</source>
        <translation>Guardar los cambios del escritorio live</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1859"/>
        <source>Existing Home Directory</source>
        <translation>Directorio Home Existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1868"/>
        <source>What would you like to do with the old directory?</source>
        <translation>¿Que le gustaría hacer con el directorio antiguo?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1875"/>
        <source>Re-use it for this installation</source>
        <translation>Reutilizarlo para esta instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1882"/>
        <source>Rename it and create a new directory</source>
        <translation>Renombrar y crear un nuevo directorio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1889"/>
        <source>Delete it and create a new directory</source>
        <translation>Borrar y crear un nuevo directorio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1907"/>
        <source>Tips</source>
        <translation>Consejos</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1939"/>
        <source>Installation complete</source>
        <translation>Instalación completa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1945"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Reiniciar automáticamente el sistema cuando el instalador este cerrado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1964"/>
        <source>Reminders</source>
        <translation>Recordatorios</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="359"/>
        <source>Please enter a computer name.</source>
        <translation>Por favor ingrese un nombre de computadora.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="363"/>
        <source>The computer name contains invalid characters.</source>
        <translation>El nombre del ordenador contiene caracteres no válidos.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="364"/>
        <location filename="../oobe.cpp" line="375"/>
        <location filename="../oobe.cpp" line="595"/>
        <source>Please choose a different name before proceeding.</source>
        <translation>Elija otro nombre antes de continuar.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="370"/>
        <source>Please enter a domain name.</source>
        <translation>Por favor ingrese un nombre de dominio.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="374"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>El domino del ordenador contiene caracteres no válidos.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="383"/>
        <source>Please enter a workgroup.</source>
        <translation>Por favor ingrese un grupo de trabajo.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="600"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>El nombre de usuario no puede contener caracteres especiales ni espacios.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="610"/>
        <source>The chosen user name is in use.</source>
        <translation>El nombre de usuario elegido ya está en uso.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="619"/>
        <source>Are you sure you want to continue?</source>
        <translation>¿Estás seguro que quieres continuar?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="624"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>No ha proporcionado una frase de contraseña para %1.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="629"/>
        <source>You did not provide a password for the root account.</source>
        <translation>No ha proporcionado una contraseña para la cuenta root.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="642"/>
        <source>Failed to set user account passwords.</source>
        <translation>Fallo al establecer las contraseñas de la cuenta del usuario. </translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="674"/>
        <source>Failed to save old home directory.</source>
        <translation>Fallo al guardar el antiguo directorio home.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="683"/>
        <source>Failed to delete old home directory.</source>
        <translation>Fallo al eliminar el antiguo directorio home.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="704"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Lo siento, fallo al crear directorio de usuario.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="707"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Fallo al nombrar directorio de usuario.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="745"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Error al establecer la propiedad o los permisos del directorio de usuario.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="257"/>
        <location filename="../partman.cpp" line="883"/>
        <source>Virtual Devices</source>
        <translation>Dispositivos virtuales</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="533"/>
        <location filename="../partman.cpp" line="584"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Añadir partición</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="535"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Remover partición</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="544"/>
        <source>&amp;Lock</source>
        <translation>&amp;Bloquear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="548"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Desbloquear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="552"/>
        <location filename="../partman.cpp" line="727"/>
        <source>Add to crypttab</source>
        <translation>Agregar a crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="559"/>
        <source>New subvolume</source>
        <translation>Nuevo subvolumen</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="560"/>
        <source>Scan subvolumes</source>
        <translation>Escanear subvolúmenes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="587"/>
        <source>New &amp;layout</source>
        <translation>Nuevo &amp;diseño</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Restablecer diseño</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="590"/>
        <source>Layout &amp;Builder...</source>
        <translation>&amp;Generador de diseños...</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="617"/>
        <source>Remove subvolume</source>
        <translation>Remover subvolumen</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="721"/>
        <source>Unlock Drive</source>
        <translation>Desbloquear unidad</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="725"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="757"/>
        <source>Could not unlock device.</source>
        <translation>No se pudo desbloquear el dispositivo.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="787"/>
        <source>Failed to close %1</source>
        <translation>Fallo al cerrar %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="811"/>
        <source>Invalid subvolume label</source>
        <translation>Etiqueta de subvolumen inválida</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="821"/>
        <source>Duplicate subvolume label</source>
        <translation>Etiqueta de subvolumen duplicada</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="832"/>
        <source>Invalid use for %1: %2</source>
        <translation>Uso no válido para %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="840"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 ya está seleccionado para: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="853"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Se requiere una partición root de al menos %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="872"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>No se puede conservar /home dentro de root (/) si también está montada una partición /home separada.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="887"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Preparar la tabla de partición %1 en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="885"/>
        <source>Re-use partition table on %1</source>
        <translation>Reutilizar tabla de partición en %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="758"/>
        <source>Possible incorrect password.</source>
        <translation>Posible contraseña incorrecta.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="894"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Reutilizar (sin reformatear) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="897"/>
        <source>Format %1</source>
        <translation>Formatear %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="898"/>
        <source>Format %1 to use for %2</source>
        <translation>Formatear %1 para usar con %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="899"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Reutilizar (sin reformatear) %1 como %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="900"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Eliminar los datos en %1 excepto /home, para usarlos en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="903"/>
        <source>Create %1 without formatting</source>
        <translation>Crear %1 sin formatear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="904"/>
        <source>Create %1, format to use for %2</source>
        <translation>Crear %1, formato para usar en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>Reutilizar subvolumen %1 como %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="921"/>
        <source>Delete subvolume %1</source>
        <translation>Borrar subvolumen %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="924"/>
        <source>Overwrite subvolume %1</source>
        <translation>Sobrescribir subvolumen %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="925"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>Sobrescribir subvolumen %1 para usarlo en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="927"/>
        <source>Create subvolume %1</source>
        <translation>Crear subvolumen %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="928"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>Crear subvolumen %1 para usarlo en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="944"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Debe elegir una partición de inicio separada al cifrar root.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="982"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) requiere %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1008"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>La instalación puede fallar porque los siguientes volúmenes son demasiado pequeños:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1010"/>
        <source>Are you sure you want to continue?</source>
        <translation>¿Estás seguro que quieres continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1021"/>
        <source>This setup may produce an unbootable system. Do you want to continue?</source>
        <translation>Esta configuración puede provocar que el sistema no arranque. ¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1027"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Este sistema utiliza EFI, pero no se ha asignado ninguna partición de sistema EFI válida para /boot/efi por separado.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1030"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>El volumen asignado a /boot/efi no es una partición de sistema EFI válida.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1057"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Las siguientes unidades están, o estarán, configuradas con GPT, pero no tienen una partición BIOS-GRUB:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1059"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Este sistema no puede arrancar desde unidades GPT sin una partición BIOS-GRUB.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1098"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Los discos con las particiones seleccionadas están fallando:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1102"/>
        <source>Smartmon tool output:</source>
        <translation>Resultados de Smartmon tool:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1103"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Los discos con las particiones que seleccionó para la instalación pasaron la prueba para monitores SMART (smartctl), pero las pruebas indican que tendrá una tasa de fallas más alta que el promedio en el futuro cercano.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1110"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Si no está seguro, por favor salga del instalador y ejecute GSmartControl para obtener más información.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1114"/>
        <source>Do you want to abort the installation?</source>
        <translation>¿Desea interrumpir la instalación?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1120"/>
        <source>Do you want to continue?</source>
        <translation>¿Desea continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1189"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Fallo al preparar las particiones requeridas.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1233"/>
        <source>Preparing partition tables</source>
        <translation>Preparando tablas de particiones</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1261"/>
        <source>Preparing required partitions</source>
        <translation>Preparando particiones requeridas</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1325"/>
        <source>Failed to format partition.</source>
        <translation>Fallo al formatear la partición.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1332"/>
        <source>Formatting: %1</source>
        <translation>Formateo: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1410"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Fallo al preparar los subvolúmenes.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1411"/>
        <source>Preparing subvolumes</source>
        <translation>Preparando subvolúmenes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1538"/>
        <source>Failed to mount partition.</source>
        <translation>Fallo al montar la partición.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1551"/>
        <source>Mounting: %1</source>
        <translation>Montaje: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1735"/>
        <source>Model: %1</source>
        <translation>Modelo: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1743"/>
        <source>Free space: %1</source>
        <translation>Espacio libre: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1843"/>
        <source>Device</source>
        <translation>Medio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1844"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1845"/>
        <source>Active</source>
        <translation>Activa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1846"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1847"/>
        <source>Use For</source>
        <translation>Usar para</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1848"/>
        <source>Label</source>
        <translation>Etiqueta</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1849"/>
        <source>Encrypt</source>
        <translation>Cifrar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1850"/>
        <source>Format</source>
        <translation>Formatear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1851"/>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1852"/>
        <source>Options</source>
        <translation>Opciones</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1853"/>
        <source>Dump</source>
        <translation>Volcado</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1854"/>
        <source>Pass</source>
        <translation>Pasadas</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1862"/>
        <source>Active partition</source>
        <translation>Partición activa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1863"/>
        <source>EFI System Partition</source>
        <translation>Sistema de partición EFI</translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2681"/>
        <source>&amp;Templates</source>
        <translation>&amp;Plantillas</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2688"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Compresión (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2690"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Compresión (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2692"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Compresión (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Negligible</source>
        <translation>Insignificante</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Very weak</source>
        <translation>Muy débil</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Weak</source>
        <translation>Débil</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Moderate</source>
        <translation>Moderado</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Strong</source>
        <translation>Fuerte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Very strong</source>
        <translation>Muy fuerte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="156"/>
        <source>Password strength: %1</source>
        <translation>Fuerza de la contraseña: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Hide the password</source>
        <translation>Ocultar la contraseña</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Show the password</source>
        <translation>Mostrar la contraseña</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="99"/>
        <source>Gazelle Installer</source>
        <translation>Instalador Gazelle</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="102"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Instalador GUI personalizable para MX Linux y antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="105"/>
        <source>Enable advanced settings, even in regular installation mode.</source>
        <translation>Habilita la configuración avanzada, incluso en el modo de instalación normal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="106"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Se instala automáticamente usando el archivo de configuración (más información a continuación).
-- ADVERTENCIA: opción potencialmente peligrosa, borrará la(s) particion(es) automáticamente.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="108"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Anula las comprobaciones de sanidad en particiones y unidades, lo que hace que se muestren.
-- ADVERTENCIA: esto puede romper cosas, utilícelo solo si no le importan los datos en el disco.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="110"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Carga un archivo de configuración según lo especificado por &lt;config-file&gt;.
Por defecto, se usa /etc/minstall.conf.
Esta configuración se puede utilizar con --auto para una instalación desatendida.
El instalador crea (o sobrescribe) /mnt/antiX/etc/minstall.conf y guarda una copia en /etc/minstalled.conf para uso futuro.
El instalador no escribirá contraseñas ni configuraciones ignoradas en el nuevo archivo de configuración.
Tenga en cuenta que esto es experimental. Las versiones futuras del instalador pueden romper la compatibilidad con los archivos de configuración existentes.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="116"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Se apagará automáticamente cuando finalice la instalación.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="117"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>No desmontar /mnt/antiX ni cerrar ninguno de los contenedores LUKS asociados cuando haya terminado.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="118"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Instale el sistema operativo, retrasando las solicitudes de opciones específicas del usuario hasta el primer reinicio.
Al reiniciar, el instalador se ejecutará con --oobe para que el usuario pueda proporcionar estos detalles.
Esto es útil para instalaciones OEM, vender o regalar una computadora con un sistema operativo precargado.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="121"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Opción de experiencia oobe (Out Of the Box ).
Esto se iniciará automáticamente si se instala con la opción --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Modo de prueba para GUI, puede avanzar a diferentes pantallas sin realmente instalar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="124"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Reiniciar automáticamente cuando termine de instalar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="125"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Instalación con rsync en lugar de cp en particiones personalizadas.
-- no formatea /root y no funciona con cifrado.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Verificar siempre los medios de instalación al iniciar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>No verificar los medios de instalación al iniciar.
No se recomienda a menos que se garantice que los medios de instalación están libres de errores.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Force TUI (Text User Interface) mode instead of GUI.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="131"/>
        <source>Jump directly to a specific page for testing (use with --pretend).
Page names: splash, terms, installation, partitions, confirm, boot, services, user, end</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>&lt;page-name&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="133"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Carga un archivo de configuración según lo especificado por &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="143"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Demasiados argumentos. Verifique el formato del comando ejecutando el programa con --help</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="153"/>
        <source>%1 Installer</source>
        <translation>Instalador %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="163"/>
        <source>The installer appears to be running already.</source>
        <translation>El instalador parece estar ya en ejecución.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="164"/>
        <source>Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Si es posible, ciérrelo o ejecute «pkill minstall» en la terminal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="169"/>
        <location filename="../app.cpp" line="184"/>
        <location filename="../app.cpp" line="209"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="170"/>
        <source>The installer appears to be running already.
Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="179"/>
        <location filename="../app.cpp" line="185"/>
        <source>This operation requires root access.</source>
        <translation>Esta operación requiere acceso de root.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="205"/>
        <location filename="../app.cpp" line="210"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Archivo de configuración (%1) no encontrado.</translation>
    </message>
</context>
<context>
    <name>Replacer</name>
    <message>
        <location filename="../replacer.cpp" line="141"/>
        <source>Could not open any of the locked encrypted containers.</source>
        <translation>No se pudo abrir ninguno de los contenedores cifrados bloqueados.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="142"/>
        <source>Possible incorrect password. Press the &apos;Scan&apos; button to try again with a different password.</source>
        <translation>Es posible que la contraseña sea incorrecta. Pulse el botón “Escanear” para volver a intentarlo con otra contraseña.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="158"/>
        <source>Volume %1 on drive %2</source>
        <translation>Volumen %1 en unidad %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="197"/>
        <source>No existing installation selected.</source>
        <translation>No hay ninguna instalación seleccionada.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="274"/>
        <source>Replace the installation in %1: %2</source>
        <translation>Reemplazar la instalación en %1: %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="283"/>
        <source>Unlock encrypted volumes</source>
        <translation>Desbloquear volúmenes cifrados</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="287"/>
        <source>Password:</source>
        <translation>Contraseña:</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="289"/>
        <source>Ignore encrypted volumes</source>
        <translation>Ignorar volúmenes cifrados</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="354"/>
        <source>Cannot unlock encrypted partition: %1</source>
        <translation>No se puede desbloquear la partición cifrada: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="361"/>
        <source>Cannot find partition listed in crypttab: %1</source>
        <translation>No se encuentra la partición en crypttab: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="382"/>
        <source>Could not re-lock encrypted device(s): %1</source>
        <translation>No se pudo volver a bloquear el/los dispositivo(s) cifrados: %1</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="57"/>
        <source>Recommended maximum: %1 MB</source>
        <translation>Máximo recomendado: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="60"/>
        <source>Unable to query RAM size.</source>
        <translation>No se pudo consultar el tamaño de la RAM.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="89"/>
        <source>Invalid location</source>
        <translation>Ubicación no válida</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="92"/>
        <source>Maximum: %1 MB</source>
        <translation>Máximo: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="109"/>
        <source>Failed to configure zram swap.</source>
        <translation>No se pudo configurar la swap zram.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="119"/>
        <source>Failed to create or install swap file.</source>
        <translation>Error al crear o instalar el archivo para la swap.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="125"/>
        <source>Creating swap file</source>
        <translation>Creando un archivo para la swap</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="138"/>
        <source>Configuring swap file</source>
        <translation>Configurando el archivo swap</translation>
    </message>
</context>
</TS>