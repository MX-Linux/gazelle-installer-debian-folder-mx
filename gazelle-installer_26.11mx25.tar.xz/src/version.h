inline const QString VERSION {"26.11mx25"};
