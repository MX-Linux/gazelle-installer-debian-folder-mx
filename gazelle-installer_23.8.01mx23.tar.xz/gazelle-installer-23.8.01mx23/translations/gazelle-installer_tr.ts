<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="tr">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="58"/>
        <source>Root</source>
        <translation>Kök</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="59"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="140"/>
        <location filename="../autopart.cpp" line="142"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>Önerilen: %1 
En az: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="179"/>
        <source>Layout Builder</source>
        <translation>Yerleşim Oluşturucu</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="323"/>
        <source>%1% root
%2% home</source>
        <translation>%1% root
%2% home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="325"/>
        <source>Combined root and home</source>
        <translation>Birleştirilmiş root ve home</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="55"/>
        <source>Cannot access installation media.</source>
        <translation>Kurulum ortamına erişilemiyor.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="155"/>
        <source>Deleting old system</source>
        <translation>Eski sistem siliniyor</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="165"/>
        <source>Failed to set the system configuration.</source>
        <translation>Sistem yapılandırması ayarlanamadı.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="167"/>
        <source>Setting system configuration</source>
        <translation>Sistem yapılandırma ayarları</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="152"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Hedefdeki eski sistem silinemedi.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="245"/>
        <source>Copying new system</source>
        <translation>Yeni sistem kopyalanıyor</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="275"/>
        <source>Failed to copy the new system.</source>
        <translation>Yeni sistem kopyalanamadı.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="277"/>
        <source>Updating initramfs</source>
        <translation>initramfs güncelleniyor </translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="128"/>
        <source>Installing GRUB</source>
        <translation>GRUB Kurulumu</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="106"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>GRUB kurulumu başarısız oldu. Kurulumu onarmak için canlı ortamı yeniden başlatabilir ve GRUB Kurtarma menüsünü kullanabilirsiniz.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="278"/>
        <source>Failed to update initramfs.</source>
        <translation>initramfs güncellenemedi.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="303"/>
        <source>System boot disk:</source>
        <translation>Sistem Önyükleme Diski:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="322"/>
        <location filename="../bootman.cpp" line="332"/>
        <source>Partition to use:</source>
        <translation>Kullanılacak bölüm:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="35"/>
        <source>Checking installation media.</source>
        <translation>Kurulum ortamı kontrol ediliyor.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="36"/>
        <source>Press ESC to skip.</source>
        <translation>Atlamak için ESC tuşuna basın.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="53"/>
        <source>The installation media is corrupt.</source>
        <translation>Kurulum ortamı bozuk.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="117"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>Kurulum ortamını kontrol etmeyi atlamak istediğinizden emin misiniz?</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="87"/>
        <source>Shutdown</source>
        <translation>Bilgisayarı Kapat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="142"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>64 bit UEFI modunda başlatılan 32 bit işletim sistemini çalıştırıyorsunuz. Yeniden başlatma sırasında Legacy Boot veya benzerini seçmediğiniz sürece sistem önyükleme yapamayacaktır.
Şimdi çıkmanızı ve Legacy Boot’da yeniden başlatmanızı öneririz.

Kuruluma devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="186"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 Desteği

%1 sizin gibi kişiler tarafından destekleniyor. Bazıları destek forumunda diğerlerine yardım ediyor -% 2 veya yardım dosyalarını farklı dillere çeviriyor, önerilerde bulunuyor, belgelendirme yazıyor veya yeni yazılımın denenmesine yardımcı oluyor.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="226"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1, Debian Kararlı tabanlı bağımsız bir Linux dağıtımıdır.

%1, Apache özgür lisans altında dağıtılan MEPİS Linux’un bazı bileşenlerini kullanıyor. Bazı MEPİS bileşenleri %1 için değiştirildi.

%1’in keyfini çıkarın</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="439"/>
        <source>Pretending to install %1</source>
        <translation>%1 kuruluma hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="353"/>
        <source>Preparing to install %1</source>
        <translation>%1 kuruluma hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="368"/>
        <source>Paused for required operator input</source>
        <translation>Gerekli operatör girişi için duraklatıldı</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="380"/>
        <source>Setting system configuration</source>
        <translation>Sistem yapılandırma ayarları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="390"/>
        <source>Cleaning up</source>
        <translation>Temizleniyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="394"/>
        <source>Finished</source>
        <translation>Bitti</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="415"/>
        <source>The installation was aborted.</source>
        <translation>Kurulum iptal edildi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="515"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation> (% 1) Yapılandırma dosyasında geçersiz ayarlar bulundu. Lütfen işaretli alanları karşılaştıkça inceleyin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="535"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>% 2 için tüm diski (% 1) biçimlendirilip kullanılacak. Tamam mı?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="539"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>UYARI: Seçilen sürücü en az 2TB kapasiteye sahip ve GPT kullanılarak formatlanması gerekiyor. Bazı sistemlerde GPT biçimli bir disk önyükleme yapamaz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="568"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Gerekli bilgiler elde edilemediği için /home içindeki veriler korunamaz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="595"/>
        <source>The home directory for %1 already exists.</source>
        <translation>%1 için ev dizini zaten mevcut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="631"/>
        <source>General Instructions</source>
        <translation>Genel Yönergeler</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="632"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>DEVAM ETMEDEN ÖNCE, DİĞER UYGULAMALARIN TÜMÜNÜ KAPATIN.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="633"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Lütfen her sayfadaki yönergeleri okuyun, seçimlerinizi yapın ve devam etmeye hazır olduğunuzda İleri’yi tıklayın. Herhangi bir yıkıcı eylem gerçekleştirilmeden önce sizden onay istenecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="635"/>
        <source>Limitations</source>
        <translation>Sınırlamalar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="636"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Unutmayın, bu yazılım herhangi bir garanti olmaksızın OLDUĞU GİBİ sağlanır. Devam etmeden önce verilerinizi yedeklemek yalnızca sizin sorumluluğunuzdadır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="641"/>
        <source>Installation Options</source>
        <translation>Kurulum Seçenekleri</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="642"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Mac veya Windows işletim sistemi kullanıyorsanız (Vista’dan itibaren), yüklemeden önce, bölümleri ve Önyükleme Yöneticisini kurmak için bu sistemin yazılımını kullanmanız gerekebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="643"/>
        <source>Using the root-home space slider</source>
        <translation>Kök-home boşluk kaydırıcı kullanılıyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="644"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>Sürücü, kaydırma çubuğu kullanılarak ayrı sistem (root) ve kullanıcı verileri (home) bölümlerine ayrılabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="645"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>&lt;b&gt;root&lt;/b&gt; bölümü, işletim sistemini ve uygulamaları içerecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="646"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>&lt;b&gt;home&lt;/b&gt; bölümü ayarları, dosyaları, belgeleri, resimleri, müzikleri, videoları vb. gibi tüm kullanıcıların verilerini içerecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="647"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>&lt;b&gt;kök&lt;/b&gt;alanını artırmak için kaydırıcıyı sağa doğru hareket ettirin. &lt;b&gt;home&lt;/b&gt; alanını artırmak için sola doğru hareket ettirin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="648"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Aynı bölümde hem kök hem de home istiyorsanız, kaydırıcıyı en sağa kaydırın. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="649"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Giriş dizinini ayrı bir bölümde tutmak, işletim sistemi yükseltmelerinin güvenilirliğini artırır. Ayrıca yedekleme ve kurtarma işlemini kolaylaştırır. Bu, sistem dosyalarını sürücünün tanımlanmış bir bölümüyle sınırlayarak genel performansı da iyileştirebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <location filename="../minstall.cpp" line="735"/>
        <source>Encryption</source>
        <translation>Şifreleme</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="652"/>
        <location filename="../minstall.cpp" line="736"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Şifreleme LUKS ile mümkündür. Bir parola gereklidir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="653"/>
        <location filename="../minstall.cpp" line="737"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Ayrı bir şifrelenmemiş önyükleme bölümü gerekir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="654"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Otomatik kurulum ile şifreleme kullanılırsa, ayrı bir önyükleme bölümü otomatik olarak oluşturulacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="655"/>
        <source>Using a custom disk layout</source>
        <translation>Özel bir disk düzeni kullanılıyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="656"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>%1’in nereye kurulacağı üzerinde daha fazla bilgiye gereksinim duyuyorsanız, &quot;&lt;b&gt;%2&lt;/b&gt;&quot; yi seçin ve İleri’yi tıklayın. Sonraki sayfada, size gereken depolama aygıtlarını ve bölümleri seçip yapılandırabileceksiniz. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="663"/>
        <source>Choose Partitions</source>
        <translation>Bölüm Seçimi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="664"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Bölüm listesi, bu kurulum için hangi bölümlerin kullanılacağını seçmenize izin verir. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="665"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Aygıt&lt;/i&gt; - Bu, oluşturulan bölüme atanan veya atanacak olan yığın aygıtı adıdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="666"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Boyut&lt;/i&gt; - Bölümün boyutu. Bu yalnızca yeni bir düzende değiştirilebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="667"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Kullanım İçin&lt;/i&gt; - Bu bölümü bir yüklemede kullanmak için burada seçime yapmalısınız.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="682"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Yukarıdakilere ek olarak, kendi bağlama noktanızı da yazabilirsiniz. Özel bağlama noktaları eğik çizgi (&quot;/&quot;) ile başlamalıdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etiket&lt;/i&gt; - Biçimlendirildikten sonra bölüme atanan etiket.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="684"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Şifrele&lt;/i&gt; - Bu bölüm için LUKS şifrelemesi kullanın. Parola, şifreleme için seçilen tüm bölümler için geçerlidir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="685"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Biçim&lt;/i&gt; - Bu bölümün biçimidir. Mevcut biçimler bölümün ne için kullanıldığına bağlıdır. Varolan bir düzen ile çalışırken, &lt;b&gt;Koru&lt;/b&gt;’yu seçerek bölümün biçimini koruyabilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="689"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>ext2, ext3, ext4, jfs, xfs ve btrfs Linux dosya sistemleri desteklenir ve ext4 önerilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="690"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Kontrol Et&lt;/i&gt; - Sürücüdeki bozuk blokları kontrol edin ve düzeltin (tüm formatlar için desteklenmez). Bu çok zaman alıcıdır, bu nedenle sürücünüzde bozuk bloklar olduğundan şüphelenmediğiniz sürece bu adımı atlamak isteyebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="692"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Bağlama Seçenekleri&lt;/i&gt; - Bu bölüm için kullanılacak bağlama seçeneklerini belirtir.   </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="693"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Dump&lt;/i&gt;- Dump yardımcı programına bu bölümü yedeklemeye dahil etmesi talimatını verir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="694"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Geçiş&lt;/i&gt; - Bu dosya sisteminin açılışta kontrol edileceği sayı. Sıfır ise, dosya sistemi kontrol edilmez.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>Menus and actions</source>
        <translation>Menüler ve eylemler</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="696"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Listedeki herhangi bir sürücü veya bölüm öğesine sağ tıklayarak farklı eylemler gerçekleştirilebilir. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="697"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Listenin sağındaki düğmeler, girdileri değiştirmek için de kullanılabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="698"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>Yükleyici sürücüde önceden var olan yerleşimi değiştiremez. Özel bir düzen oluşturmak için, sürücüyü &lt;b&gt;Yeni Düzen&lt;/b&gt; menü eylemi veya düğmesiyle (%1) yeni bir düzen için işaretleyin. Bu, mevcut düzeni temizler.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="701"/>
        <source>Basic layout requirements</source>
        <translation>Temel düzen gereksinimleri </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="702"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 bir kök bölümü gerektirir. Takas bölümü isteğe bağlıdır ancak şiddetle önerilir. %1’in diski askıya alma özelliğini kullanmak istiyorsanız, fiziksel bellek boyutunuzdan daha büyük bir takas alanına gereksiniminiz olacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="704"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Ayrı bir /home bölümü seçerseniz, gelecekte yükseltmeniz daha kolay olacaktır, ancak ayrı bir ev bölümü olmayan bir kurulumdan yükseltiyorsanız bu olanaksızdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="706"/>
        <source>Active partition</source>
        <translation>Faal bölüm</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Kurulu işletim sisteminin önyüklenmesi için uygun bölümün (genellikle önyükleme veya kök bölümü) etkin olarak işaretlenmesi gerekir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="708"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>Bir sürücünün aktif bölümü, &lt;b&gt;Aktif bölüm&lt;/b&gt; kısmı kullanılarak seçilebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="709"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Aygıt adının yanında yıldız işareti (*) bulunan bir bölüm, etkin bölümdür veya öyle olacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="714"/>
        <source>Boot partition</source>
        <translation>Açılış bölümü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="715"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Bu bölüm genellikle yalnızca şifreli, LVM veya yazılım RAID birimleri gibi sanal aygıtlardaki kök bölümler için gereklidir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="716"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Şifrelenmiş diske veya sanal aygıtlara erişmek için kullanılan temel çekirdek ve sürücüler içerir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="717"/>
        <source>BIOS-GRUB partition</source>
        <translation>BIOS-GRUB bölümlemesi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="718"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>EFI olmayan bir sistemde GPT biçimli bir sürücü kullanırken, GRUB kullanırken 1 MB BIOS önyükleme bölümü gerekir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="719"/>
        <source>New drives are formatted in GPT if more than 4 partitions are to be created, or the drive has a capacity greater than 2TB. If the installer is about to format the disk in GPT, and there is no BIOS-GRUB partition, a warning will be displayed before the installation starts.</source>
        <translation>4’ten fazla bölüm oluşturulacaksa veya sürücünün kapasitesi 2 TB’den fazlaysa, yeni sürücüler GPT olarak biçimlendirilir. Yükleyici diski GPT olarak biçimlendirmek üzereyse ve BIOS-GRUB bölümü yoksa yükleme başlamadan önce bir uyarı görüntülenecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="721"/>
        <source>Need help creating a layout?</source>
        <translation>Bir düzen oluşturmak için yardıma mı ihtiyacınız var? </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="722"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Bir sürücüye sağ tıklayın ve menüden &lt;b&gt;Yerleşim Oluşturucu&lt;/b&gt;’yu seçin. Bu, normal yüklemeye benzer bir düzen oluşturabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="756"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Windows ve Linux için GRUB kur</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="757"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1, %1 ve Microsoft Windows’u başlatmak için GRUB önyükleyicisini kullanır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="758"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Varsayılan olarak GRUB, önyükleme sürücünüzün Ana Önyükleme Kaydına (MBR) veya ESP’ye (64 bit UEFI önyükleme sistemleri için EFI Sistem Bölümü) yüklenir ve daha önce kullanmakta olduğunuz önyükleyicinin yerini alır. Bu normaldir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="759"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Bunun yerine GRUB’u Partition Boot Record’a (PBR) kurmayı seçerseniz, GRUB belirtilen bölümün başına kurulacaktır. Bu seçenek yalnızca uzmanlar içindir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="760"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>GRUB’u Yükle kutusunun işaretini kaldırırsanız, GRUB şu anda kurulmayacaktır. Bu seçenek yalnızca uzmanlar içindir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="761"/>
        <source>Create a swap file</source>
        <translation>Takas dosyası oluştur</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="762"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Takas dosyası, takas bölümünden daha esnektir; sistem kullanımındaki değişikliklere uyum sağlamak için bir takas dosyasını yeniden boyutlandırmak çok daha kolaydır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="763"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Varsayılan olarak, herhangi bir takas bölümü ayarlanmamışsa bu işaretlenir ve takas bölümleri ayarlanmışsa işareti kaldırılır. Bu seçeneğe dokunulmamalıdır ve yalnızca uzmanlar içindir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="764"/>
        <source>Setting the size to 0 has the same effect as unchecking this option.</source>
        <translation>Boyutu 0 olarak ayarlamak, bu seçeneğin işaretini kaldırmakla aynı etkiye sahiptir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="871"/>
        <source>Enjoy using %1</source>
        <translation>%1 kullanmanın tadını çıkarın</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="723"/>
        <source>Upgrading</source>
        <translation>Yükseltiliyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="669"/>
        <source>Format without mounting</source>
        <translation>Bağlamadan biçimlendir</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="670"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>GRUB için BIOS GPT Önyükleme bölümü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="671"/>
        <location filename="../minstall.cpp" line="710"/>
        <source>EFI System Partition</source>
        <translation>EFİ Sistem Bölümü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="673"/>
        <source>Boot manager</source>
        <translation>Önyükleme yöneticisi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="674"/>
        <source>System root</source>
        <translation>Sistem kökü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="675"/>
        <source>User data</source>
        <translation>Kullanıcı verisi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="676"/>
        <source>Static data</source>
        <translation>Sabit veri</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="677"/>
        <source>Variable data</source>
        <translation>Değişken veri</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="678"/>
        <source>Temporary files</source>
        <translation>Geçici dosyalar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="679"/>
        <source>Swap files</source>
        <translation>Takas dosyaları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="680"/>
        <source>Swap partition</source>
        <translation>Takas bölümü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="687"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>Kök bölüm için &lt;b&gt;/home’u Koru&lt;/b&gt;’yu seçmek, /home dizininin içeriğini korur ve geri kalan her şeyi siler. Bu seçenek yalnızca /home, kök bölümle aynı bölümde olduğunda kullanılabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Sisteminiz Genişletilebilir Ürün Yazılımı Arabirimi (EFI) kullanıyorsa, sistemin önyüklemesi için EFI Sistem Bölümü (ESP) olarak bilinen bir bölüm gerekir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="712"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Bu sistemler, Aktif olarak işaretlenmiş herhangi bir bölüm gerektirmez, bunun yerine ESP olarak işaretlenmiş bir FAT dosya sistemiyle biçimlendirilmiş bir bölüm gerektirir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="713"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>Son 10 yılda çoğu sistem EFI kullanır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="724"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Mevcut bir Linux kurulumundan yükseltmek için, öncekiyle aynı ev bölümünü seçin ve format olarak &lt;b&gt;Koru&lt;/b&gt;’yu seçin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="725"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Ayrı bir ev bölümü kullanmıyorsanız, kök bölümünüzde bulunan mevcut /home dizinini korumak için kök dosya sistemi girişinde &lt;b&gt;Koru&lt;/b&gt; /home’u seçin. Yükleyici yalnızca /home’u koruyacak ve diğer her şeyi silecektir. Sonuç olarak, kurulum normalden çok daha uzun sürecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="727"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tercih Edilen Dosya Sistemi Türü</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="728"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>%1 için bölümleri ext2, ext3, ext4, f2fs, jfs, xfs veya btrfs olarak biçimlendirmeyi seçebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="729"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Btrfs kullanan sürücüler için ek sıkıştırma seçenekleri mevcuttur. Lzo hızlıdır, ancak sıkıştırma daha düşüktür. Zlib, daha yüksek sıkıştırma ile daha yavaştır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="731"/>
        <source>System partition management tool</source>
        <translation>Sistem bölümlendirme yönetim aracı </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="732"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Sürücü düzenleri üzerinde daha fazla kontrol için (bir diskteki mevcut düzeni değiştirmek gibi), bölüm yönetimi düğmesini (%1) tıklayın. Bu, işletim sisteminin bölüm yönetim aracını çalıştıracak ve bu, tam olarak ihtiyacınız olan düzeni oluşturmanıza olanak sağlayacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="738"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Şifrelenmiş bir bölümü korumak için, üzerine sağ tıklayın ve &lt;b&gt;Kilidi Aç&lt;/b&gt;’ı seçin. Görüntülenen iletişim kutusunda sanal aygıt için bir ad ve parola girin. Aygıtın kilidi açıldığında, seçtiğiniz ad &lt;i&gt;Sanal Aygıtlar&lt;/i&gt; altında, normal bir bölümünkine benzer seçeneklerle görünecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="740"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Şifreli bölümün önyükleme sırasında kilidinin açılması için crypttab dosyasına eklenmesi gerekir. Bunu yapmak için &lt;b&gt;crypttab sekmesine ekle&lt;/b&gt; menü eylemini kullanın.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="741"/>
        <source>Other partitions</source>
        <translation>Diğer bölümler</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="742"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Yükleyici, diğer bölümlerin oluşturulmasına veya başka amaçlar için kullanılmasına izin verir, ancak daha eski sistemlerin 4’ten fazla bölüme sahip sürücüleri işleyemeyeceğine dikkat edin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="743"/>
        <source>Subvolumes</source>
        <translation>Altbirimler</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="744"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Btrfs gibi bazı dosya sistemleri, tek bir bölümde birden çok alt birimi destekler. Bunlar fiziksel alt birimler değildir ve bu nedenle sıraları önemli değildir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="746"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Alt birimler için mevcut bir Btrfs bölümünü aramak için &lt;b&gt;Alt birimleri tara&lt;/b&gt; eylemini kullanın. Yeni bir alt birim oluşturmak için &lt;b&gt;Yeni alt birim&lt;/b&gt; eylemini kullanın.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="748"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Mevcut alt birimler korunabilir, ancak adı aynı kalmalıdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="749"/>
        <source>Virtual Devices</source>
        <translation>Sanal Cihazlar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="750"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Yükleyici, açılmış LUKS bölümleri, LVM mantıksal birimleri veya yazılım tabanlı RAID birimleri gibi herhangi bir sanal aygıt algılarsa, bunlar yükleme için kullanılabilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="751"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>Sanal aygıtların kullanımı (şifreli dosya sistemlerini korumanın ötesinde) gelişmiş bir özelliktir. Kullanılan sanal aygıtların önyükleme sırasında oluşturulmasını sağlamak için bazı dosyaları (örn. initramfs, crypttab, fstab) düzenlemeniz gerekebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="770"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Etkinleştirilecek Genel Hizmetler&lt;/b&gt;&lt;br/&gt;Sistem yapılandırmanızda gereksinim duyabileceğiniz bu genel hizmetlerden herhangi birini seçin. %1’u başlattığınızda hizmetler otomatik olarak başlayacaktır.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="774"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Bilgisayar Kimliği&lt;/b&gt;&lt;br/&gt;Bilgisayar adı, bilgisayarınızı bir ağ üzerindeyse onu tanımlayacak ortak benzersiz bir addır. İSS’nız veya yerel ağınız gerektirmedikçe bilgisayar alan adı olarak kullanılamaz.&lt;/p&gt;&lt;p&gt;Bilgisayar ve  alan adları yalnızca abecesayısal karakterler, noktalar, kısa çizgiler içerebilir. Boşluk, kısa çizgi ile başlangıç veya bitiş içeremezler&lt;/p&gt;&lt;p&gt;Bazı dizinlerinizi veya yazıcınızı MS-Windows veya Mac OSX çalıştıran yerel bir bilgisayarla paylaşarak kullanmak istiyorsanız SaMBa Sunucusunun etkinleştirilmesi gerekir.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="784"/>
        <source>Localization Defaults</source>
        <translation>Yerelleştirme Öntanımlıları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="785"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Varsayılan yerel ayarı belirleyin. Bu, daha sonra kullanıcı tarafından aksi belirtilmediği sürece geçerli olacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="786"/>
        <source>Configure Clock</source>
        <translation>Saati Yapılandır</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="787"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Bir Apple veya salt Unix bilgisayarınız varsa, sistem saati varsayılan olarak Greenwich Meridyen Zamanı’na (GMT) veya Eşgüdümlü Evrensel Saat’e (UTC) ayarlıdır. Bunu değiştirmek için &quot;&lt;b&gt;Sistem saati yerel saati kullanır&lt;/b&gt;&quot; kutusunu işaretleyin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="789"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Sistem, GMT/UTC’ye önceden ayarlanmış zaman dilimi ile önyükleme yapar. Saat dilimini değiştirmek için, yeni kuruluma yeniden başladıktan sonra Panel’deki saate sağ tıklayın ve Özellikler’i seçin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="791"/>
        <source>Service Settings</source>
        <translation>Hizmet Ayarları</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="792"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Çoğu kullanıcı varsayılanları değiştirmemelidir. Düşük kaynaklı bilgisayarlara sahip kullanıcılar, RAM kullanımını mümkün olduğunca düşük tutmak için bazen gereksiz hizmetleri devre dışı bırakmak isterler. Ne yaptığınızı bildiğinizden emin olun!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="798"/>
        <source>Default User Login</source>
        <translation>Öntanımlı Kullanıcı Girişi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="799"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>root kullanıcı, diğer bazı işletim sistemlerinde Yönetici kullanıcıya benzer. root kullanıcıyı günlük kullanıcı hesabınız olarak kullanmamalısınız. Lütfen günlük olarak kullanacağınız yeni (varsayılan) bir kullanıcı hesabının adını girin. Gerekirse, daha sonra %1 Kullanıcı Yöneticisi ile başka kullanıcı hesapları ekleyebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="803"/>
        <source>Passwords</source>
        <translation>Parolalar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="804"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Varsayılan kullanıcı hesabınız ve root hesabı için yeni bir parola girin. Her şifre iki kez girilmelidir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="806"/>
        <source>No passwords</source>
        <translation>Şifre yok</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="807"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Varsayılan kullanıcı hesabının şifresinin olmamasını istiyorsanız, şifre alanlarını boş bırakın. Bu, şifre gerektirmeden giriş yapmanızı sağlar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="809"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Açıkçası, bu yalnızca genel terminal gibi kullanıcı hesabının güvenli olmasının gerekmediği durumlarda yapılmalıdır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>Old Home Directory</source>
        <translation>Eski Ev Dizini</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Seçtiğiniz kullanıcı adı için bir ev dizini zaten var. Bu ekran, bu dizine ne olacağını seçmenize izin verir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="820"/>
        <source>Re-use it for this installation</source>
        <translation>Bu kurulum için yeniden kullanın</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Bu kullanıcı hesabı için eski ev dizini kullanılacak. Bu, yükseltme yaparken iyi bir seçimdir. Çünkü dosyalarınız ve ayarlarınız hazır durumda olacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="823"/>
        <source>Rename it and create a new directory</source>
        <translation>Yeniden adlandır ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Kullanıcı için yeni bir ev dizini oluşturulacak ve eski ev dizini de yeniden adlandırılacaktır. Dosyalarınız ve ayarlarınız yeni kurulumda hemen görünmeyecek, ancak yeniden adlandırılan dizin kullanılarak erişilebilir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="826"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Eski dizinin sonunda, dizinin önceden kaç kez yeniden adlandırıldığını gösteren bir sayı bulunur.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="827"/>
        <source>Delete it and create a new directory</source>
        <translation>Sil ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Eski ev dizini silinecek ve sıfırdan yeni bir dizin oluşturulacaktır.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="829"/>
        <source>Warning</source>
        <translation>Uyarı</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="830"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Bu seçenek belirlenirse tüm dosyalar ve ayarlar kalıcı olarak silinir. Onları kurtarma şansınız düşüktür.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="846"/>
        <source>Installation in Progress</source>
        <translation>Kurulum devam ediyor</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="847"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 kuruluyor. Yeni bir kurulumda, sisteminizin hızına ve yeniden biçimlendirdiğiniz bölümlerin boyutuna bağlı olarak bu işlem muhtemelen 3-20 dakika sürer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="849"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>İptal düğmesine tıklarsanız, kurulum mümkün olan en kısa sürede durdurulacak.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="851"/>
        <source>Change settings while you wait</source>
        <translation>Beklerken ayarları değiştirin</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="852"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>% 1 kurulurken, kurulum için gerekli diğer bilgileri girmek için &lt;b&gt;İleri&lt;/b&gt; veya &lt;b&gt;Geri&lt;/b&gt; düğmelerine tıklayabilirsiniz. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="854"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Bu adımları kendi hızınızda tamamlayın. Yükleyici, gerekirse girişinizi bekleyecektir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="862"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kutlarız!&lt;/b&gt;&lt;br/&gt;%1 kurulumunu tamamladınız&lt;/p&gt;&lt;p&gt;&lt;b&gt;Uygulamaları Bulma&lt;/b&gt;&lt;br/&gt;%1 ile yüklenmiş yüzlerce mükemmel uygulama var. Onlar hakkında bilgi edinmenin en iyi yolu Menüye göz atmak ve onları denemektir. Uygulamaların çoğu, %1 tasarımı için özel olarak geliştirilmiştir. Bunlar ana menülerde gösterilmektedir. &lt;p&gt;Ek olarak, antiX Linux, yalnızca komut satırından çalıştırılan ve bu nedenle Menüde görünmeyen birçok standart Linux uygulamasını içerir.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="872"/>
        <location filename="../minstall.cpp" line="1138"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;b&gt;&lt;p&gt;%1 Desteği&lt;/b&gt;&lt;br/&gt;%1 sizin gibi kişiler tarafından destekleniyor. Bazıları destek forumunda diğerlerine yardım ediyor -% 2 veya yardım dosyalarını farklı dillere çeviriyor, önerilerde bulunuyor, belgelendirme yazıyor veya yeni yazılımın denenmesine yardımcı oluyor.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="902"/>
        <source>Finish</source>
        <translation>Son</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="905"/>
        <source>OK</source>
        <translation>Tamam</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="907"/>
        <source>Next</source>
        <translation>İleri</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="406"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>Sistem yapılandırılıyor. Lütfen bekleyin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="410"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Yapılandırma tamamlandı. Sistem yeniden başlatılıyor. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1060"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Kurulum ve yapılandırma tamamlanmadı.
Gerçekten şimdi durdurmak istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1124"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Yardım Alma&lt;/b&gt;&lt;br/&gt;%1 ile ilgili temel bilgiler %2’dedir.&lt;/p&gt;&lt;p&gt;%4 adresindeki %3 forumda size yardımcı olacak gönüllüler var&lt;/p&gt;&lt;p&gt;Yardım istediğinizde lütfen sorununuzu ve bilgisayarınızı ayrıntılı bir şekilde açıklamayı unutmayın. Genellikle ’işe yaramadı’ gibi ifadeler yardımcı olmaz.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1132"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kurulumunuzu Onarma&lt;/b&gt;&lt;br/&gt;%1 sabit sürücüden çalışmayı durdurursa, bazen CanlıDVD veya CanlıUSB’den önyükleme yaparak ve Sistem %1 yardımcı programlarından birini çalıştırarak veya sistemi onarmak için normal Linux araçlarından birini kullanarak sorunu çözmek mümkündür.&lt;/p&gt;&lt;p&gt;MS-Windows sistemlerinden veri kurtarmak için de %1 CanlıDVD veya CanlıUSB’nizi kullanabilirsiniz!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1146"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ses Kartınızı Ayarlayıcı&lt;/b&gt;&lt;br/&gt; %1, ses karıştırıcısını sizin için yapılandırmaya çalışır, ancak bazen sesi duymak için karıştırıcının ses düzeylerini yükseltmeniz ve kanalların sesini açmanız gerekebilir.&lt;/p&gt; &lt;p&gt;Karıştırıcı kısayolu menüde bulunur. Karıştırıcıyı açmak için üzerine tıklayın. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1154"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%1 Kopyanızı Güncel Tutun&lt;/b&gt;&lt;br/&gt;Daha çok bilgi ve güncellemeler için şurayı ziyaret edin&lt;/p&gt;&lt;p&gt;%2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Teşekkürler&lt;/b&gt;&lt;br/&gt;%1’i zamanı, parası, önerileri, çalışmaları, övgüleri, düşünceleri, tanıtımları ve/veya teşvikleriyle desteklemeyi seçen herkese teşekkürler.&lt;/p&gt;&lt;p&gt;Siz olmadan %1 olamazdı.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="43"/>
        <source>Help</source>
        <translation>Yardım</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Canlı Günlük </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="160"/>
        <source>Close</source>
        <translation>Kapat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="86"/>
        <source>Next</source>
        <translation>İleri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="93"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="177"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Bilgi toplanıyor, lütfen hazır bekleyin.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="209"/>
        <source>Terms of Use</source>
        <translation>Kullanım Koşulları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="297"/>
        <source>Change Keyboard Settings</source>
        <translation>Klavye Ayarlarını Değiştir</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="375"/>
        <source>Select type of installation</source>
        <translation>Kurulum türünü seçin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Regular install using the entire disk</source>
        <translation>Tüm diski kullanarak olağan kurulum </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="400"/>
        <source>Customize the disk layout</source>
        <translation>Disk düzenini özelleştirin </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="413"/>
        <source>Use disk:</source>
        <translation>Şu diski kullan:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="567"/>
        <source>Encrypt</source>
        <translation>Şifrele</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="579"/>
        <location filename="../meinstall.ui" line="782"/>
        <source>Encryption password:</source>
        <translation>Şifreleme parolası:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="596"/>
        <location filename="../meinstall.ui" line="799"/>
        <source>Confirm password:</source>
        <translation>Parolayı onayla:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="447"/>
        <source>Root</source>
        <translation>Kök</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Keyboard Settings</source>
        <translation>Tuş Ayarları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="256"/>
        <source>Model:</source>
        <translation>Model:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="271"/>
        <source>Variant:</source>
        <translation>Varyant:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="309"/>
        <source>Layout:</source>
        <translation>Yerleşim:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="457"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="532"/>
        <location filename="../meinstall.ui" line="554"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="616"/>
        <location filename="../meinstall.ui" line="1057"/>
        <source>Enable hibernation support</source>
        <translation>Hazırda bekletme desteğini etkinleştir</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="654"/>
        <source>Choose partitions</source>
        <translation>Bölümleri seçin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="694"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>İşletim sistemini sorgulayın ve tüm sürücülerin düzenlerini yeniden yükleyin. </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="727"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Var olan bir girişi yerleşimden kaldırın. Bu, yalnızca yeni bir yerleşime yapılan girişlerle çalışır.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Yeni bir bölüm girdisi ekleyin. Bu yalnızca yeni bir düzen ile çalışır. </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="663"/>
        <source>Show Grid</source>
        <translation>Izgarayı Göster</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Yeni bir düzen için temizlenecek sürücüyü seçip işaretleyin. </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Bu işletim sisteminin bölümlendime yönetimi uygulamasını çalıştırın. </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="776"/>
        <source>Encryption options</source>
        <translation>Şifreleme seçenekleri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="835"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Windows ve Linux için GRUB kur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="859"/>
        <source>Master Boot Record</source>
        <translation>Ana Önyükleme Kaydı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="865"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="868"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="890"/>
        <source>EFI System Partition</source>
        <translation>EFİ Sistem Bölümü</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="893"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="925"/>
        <source>Partition Boot Record</source>
        <translation>Bölüm Önyükleme Kaydı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="928"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="941"/>
        <source>System boot disk:</source>
        <translation>Sistem Önyükleme Diski:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="954"/>
        <source>Location to install on:</source>
        <translation>Kurulacak yer:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="990"/>
        <source>Create a swap file</source>
        <translation>Takas dosyası oluştur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1007"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1027"/>
        <source>Size:</source>
        <translation>Boyut:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1050"/>
        <source>Location:</source>
        <translation>Konum:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1089"/>
        <source>Common Services to Enable</source>
        <translation>Etkinleştirilecek Ortak Hizmetler</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1108"/>
        <source>Service</source>
        <translation>Hizmet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1113"/>
        <source>Description</source>
        <translation>Açıklama</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1146"/>
        <source>Computer Network Names</source>
        <translation>Bilgisayar Ağ Adları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1173"/>
        <source>Workgroup</source>
        <translation>Çalışmagrubu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1186"/>
        <source>Workgroup:</source>
        <translation>Çalışma grubu:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1199"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>MS Ağ iletişimi için SaMBa Sunucusu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1215"/>
        <source>example.dom</source>
        <translation>örnek.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1228"/>
        <source>Computer domain:</source>
        <translation>Bilgisayar alan adı:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1254"/>
        <source>Computer name:</source>
        <translation>Bilgisayar adı:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1315"/>
        <source>Configure Clock</source>
        <translation>Saati Yapılandır</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1356"/>
        <source>Format:</source>
        <translation>Biçimlendirme:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1384"/>
        <source>Timezone:</source>
        <translation>Saat dilimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1429"/>
        <source>System clock uses local time</source>
        <translation>Sistem saati yerel saati kullanır </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1461"/>
        <source>Localization Defaults</source>
        <translation>Yerelleştirme Öntanımlıları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1501"/>
        <source>Locale:</source>
        <translation>Bölge</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1523"/>
        <source>Service Settings (advanced)</source>
        <translation>Hizmet Ayarları (gelişmiş)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1541"/>
        <source>Adjust which services should run at startup</source>
        <translation>Hangi hizmetlerin başlangıçta çalışacağını ayarlayın</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1544"/>
        <source>View</source>
        <translation>Görünüm</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1589"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Canlı ortamda yapılan masaüstü değişiklikleri kurulu işletim sistemine taşınır</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1592"/>
        <source>Save live desktop changes</source>
        <translation>Canlı ortamdaki değişiklikleri kaydet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1605"/>
        <source>Default User Account</source>
        <translation>Öntanımlı Kullanıcı Hesabı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1617"/>
        <source>Default user login name:</source>
        <translation>Öntanımlı kullanıcı giriş adı:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1649"/>
        <source>Default user password:</source>
        <translation>Öntanımlı kullanıcı parolası:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1678"/>
        <source>Confirm user password:</source>
        <translation>Kullanıcı parolasını onayla:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1636"/>
        <source>username</source>
        <translation>kullanıcı adı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1710"/>
        <source>Root (administrator) Account</source>
        <translation>Kök (yönetici) Hesabı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1728"/>
        <source>Root password:</source>
        <translation>Kök parolası:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1757"/>
        <source>Confirm root password:</source>
        <translation>Kök parolasını onayla:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1789"/>
        <source>Autologin</source>
        <translation>Otomatik Oturum Aç</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1825"/>
        <source>Existing Home Directory</source>
        <translation>Mevcut Ev Dizini</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1834"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Eski dizine ne yapmak istersiniz?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1841"/>
        <source>Re-use it for this installation</source>
        <translation>Bu kurulum için yeniden kullanın</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1848"/>
        <source>Rename it and create a new directory</source>
        <translation>Yeniden adlandır ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1855"/>
        <source>Delete it and create a new directory</source>
        <translation>Sil ve yeni bir dizin oluştur</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1900"/>
        <source>Tips</source>
        <translation>İpuçları</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1944"/>
        <source>Installation complete</source>
        <translation>Kurulum tamamlandı</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1950"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Yükleyici kapalıyken sistemi otomatik olarak yeniden başlat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1969"/>
        <source>Reminders</source>
        <translation>Anımsatıcılar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Geri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="79"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="122"/>
        <source>Installation in progress</source>
        <translation>Kurulum devam ediyor</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="137"/>
        <source>Abort</source>
        <translation>Vazgeç</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="140"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="333"/>
        <source>Please enter a computer name.</source>
        <translation>Lütfen bir bilgisayar adı girin.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="337"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Üzgünüm, bilgisayar adınız geçersiz karakterler içeriyor.
Farklı bir seçim yapmanız gerek
İşleme devam etmeden önce ad gerekli.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="342"/>
        <source>Please enter a domain name.</source>
        <translation>Lütfen bir etki alanı adı girin.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="346"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Üzgünüm, bilgisayar alan adınız geçersiz karakterler içeriyor.
Devam etmeden önce
farklı bir alan adı seçmeniz gerekiyor.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="353"/>
        <source>Please enter a workgroup.</source>
        <translation>Lütfen bir çalışma grubu adı girin.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="493"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Kullanıcı adı özel karakterler veya boşluk içeremez.
Lütfen devam etmeden önce başka bir ad seçin.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="504"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Üzgünüm bu ad kullanılıyor.
Farklı bir ad seçin.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="513"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>%1 için parola girmediniz.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="514"/>
        <source>Are you sure you want to continue?</source>
        <translation>Devam etmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="520"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>Kök hesap için bir parola sağlamadınız. Devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="533"/>
        <source>Failed to set user account passwords.</source>
        <translation>Kullanıcı hesabı parolası oluşturma başarısız oldu.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="559"/>
        <source>Failed to save old home directory.</source>
        <translation>Eski ev dizini kaydedilemedi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="568"/>
        <source>Failed to delete old home directory.</source>
        <translation>Eski ev dizini silinemedi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="589"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Üzgünüm,kullanıcı dizini oluşturma başarısız.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="592"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Üzgünüm,kullanıcı dizini adı başarısız.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="628"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Kullanıcı dizininin sahipliği veya izinleri ayarlanamadı.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="219"/>
        <source>Virtual Devices</source>
        <translation>Sanal Cihazlar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="448"/>
        <location filename="../partman.cpp" line="508"/>
        <source>&amp;Add partition</source>
        <translation>Bölüm ekle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="450"/>
        <source>&amp;Remove partition</source>
        <translation>Bölümü kaldır</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="460"/>
        <source>&amp;Lock</source>
        <translation>&amp;Kilitle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="464"/>
        <source>&amp;Unlock</source>
        <translation>Kilidi &amp;Aç</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="468"/>
        <location filename="../partman.cpp" line="620"/>
        <source>Add to crypttab</source>
        <translation>crypttab’a ekle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="473"/>
        <source>Active partition</source>
        <translation>Faal bölüm</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="474"/>
        <source>EFI System Partition</source>
        <translation>EFİ Sistem Bölümü</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="482"/>
        <source>New subvolume</source>
        <translation>Yeni altbirim</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="483"/>
        <source>Scan subvolumes</source>
        <translation>Altbirimleri tara</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="511"/>
        <source>New &amp;layout</source>
        <translation>Yeni &amp;düzen</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="512"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Düzeni sıfırla</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="535"/>
        <source>Default subvolume</source>
        <translation>Varsayılan alt birim</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="536"/>
        <source>Remove subvolume</source>
        <translation>Altbirimi kaldır</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="618"/>
        <source>Unlock Drive</source>
        <translation>Sürücü Kilidini Aç</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="623"/>
        <source>Password:</source>
        <translation>Parola:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="649"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation>Cihazın kilidi açılamadı. Muhtemelen yanlış şifre.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="677"/>
        <source>Failed to close %1</source>
        <translation>%1 kapatılamadı</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="721"/>
        <source>Invalid subvolume label</source>
        <translation>Geçersiz altbirim etiketi</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="730"/>
        <source>Duplicate subvolume label</source>
        <translation>Altbirim etiketini çiftle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="740"/>
        <source>Invalid use for %1: %2</source>
        <translation>%1 için geçersiz kullanım: %2 </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="751"/>
        <source>%1 is already selected for: %2</source>
        <translation>Şunun için %1 zaten seçildi: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="765"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>En az %1’lik bir kök bölüm gereklidir.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="771"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Ayrı bir /home bölümü de takılıysa (/) root içindeki /home korunamaz.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="787"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Yeniden kullan (biçimlendirmeden) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="790"/>
        <source>Format %1</source>
        <translation>%1’i Biçimlendir</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="806"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>%1 alt birimini %2 olarak yeniden kullan</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="808"/>
        <source>Delete subvolume %1</source>
        <translation>%1 alt birimini sil</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="811"/>
        <source>Overwrite subvolume %1</source>
        <translation>%1 alt biriminin üzerine yaz</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="812"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>%2 için kullanmak üzere %1 alt biriminin üzerine yaz</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="814"/>
        <source>Create subvolume %1</source>
        <translation>%1 alt birimi oluştur</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="815"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>%2 için kullanmak üzere %1 alt birimi oluşturun</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="830"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Kök bölümünü şifrelerken ayrı bir önyükleme bölümü seçmelisiniz.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="781"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>%2 üzerinde %1 bölüm tablosu hazırla</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="791"/>
        <source>Format %1 to use for %2</source>
        <translation>%1’i %2 için kullanmak üzere biçimlendir</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="792"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Yeniden kullan (yeniden biçimlendirme yok) %1, %2 olarak </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="793"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>%2 için kullanmak üzere %1 üzerinde olan /home dışındaki verileri silin</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="796"/>
        <source>Create %1 without formatting</source>
        <translation>Biçimlendirmeden %1 oluştur</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="797"/>
        <source>Create %1, format to use for %2</source>
        <translation>%2 biçiminde %1 oluştur</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="946"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Aşağıdaki sürücüler GPT ile kurulu veya kurulacak, ancak BIOS-GRUB bölümü yok:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="948"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Bu sistem, BIOS-GRUB bölümü olmayan GPT sürücülerinden önyükleme yapmayabilir.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="831"/>
        <location filename="../partman.cpp" line="905"/>
        <location filename="../partman.cpp" line="923"/>
        <location filename="../partman.cpp" line="949"/>
        <source>Are you sure you want to continue?</source>
        <translation>Devam etmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="514"/>
        <source>Layout &amp;Builder...</source>
        <translation>Yerleşim &amp;Oluşturucu...</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="877"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) %3 gerektirir</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="903"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>Aşağıdaki birimler çok küçük olduğu için yükleme başarısız olabilir:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="837"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>%1 yükleyici şimdi istenen eylemleri gerçekleştirecek.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="838"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Bu eylemler geri alınamaz. Devam etmek istediğinize emin misiniz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="916"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Bu sistem EFI kullanır, ancak /boot/efi’ye ayrıca geçerli bir EFI sistem bölümü atanmamıştır.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>/boot/efi’ye atanan birim, geçerli bir EFI sistem bölümü değil.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="986"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Kurulum için bölümlerini seçtiğiniz diskler başarısız oluyor:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="990"/>
        <source>Smartmon tool output:</source>
        <translation>Smartmon aracı çıktısı:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="991"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Kurulum için seçtiğiniz bölümlü disk SMART izleme testini (smartctl) geçiyor, ancak testler yakın gelecekte ortalama hata oranından daha yüksek olacağını gösteriyor.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="998"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Emin değilseniz, lütfen kurulumdan çıkın ve daha fazla bilgi için GSmartControl’u çalıştırın</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1002"/>
        <source>Do you want to abort the installation?</source>
        <translation>Kurulumu iptal etmek mi istiyorsunuz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1006"/>
        <source>Do you want to continue?</source>
        <translation>Devam etmek istiyor musunuz?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1211"/>
        <source>Failed to format LUKS container.</source>
        <translation>LUKS kapsayıcısı biçimlendirilemedi.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1225"/>
        <source>Failed to open LUKS container.</source>
        <translation>LUKS kapsayıcısı açılamadı.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1092"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Gerekli bölümler hazırlanamadı.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1131"/>
        <source>Preparing partition tables</source>
        <translation>Bölümleme tablosu hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1148"/>
        <source>Preparing required partitions</source>
        <translation>Gerekli bölümler hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1216"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Şifreli birim oluşturuluyor: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1245"/>
        <source>Formatting: %1</source>
        <translation>Biçimlendiriliyor: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1238"/>
        <source>Failed to format partition.</source>
        <translation>Bölüm biçimlendirilemedi.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1303"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Altbölümler hazırlanamadı.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1304"/>
        <source>Preparing subvolumes</source>
        <translation>Altbirimlerin hazırlanıyor</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1402"/>
        <source>Failed to mount partition.</source>
        <translation>Bölüm bağlanamadı.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1407"/>
        <source>Mounting: %1</source>
        <translation>Bağlanıyor: %1</translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2449"/>
        <source>&amp;Templates</source>
        <translation>&amp;Şablonlar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2457"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Sıkıştırma (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2459"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Sıkıştırma (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2461"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Sıkıştırma (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="143"/>
        <source>Negligible</source>
        <translation>İhmal edilebilir</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="143"/>
        <source>Very weak</source>
        <translation>Çok zayıf</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="143"/>
        <source>Weak</source>
        <translation>Zayıf</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="144"/>
        <source>Moderate</source>
        <translation>Makul</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="144"/>
        <source>Strong</source>
        <translation>Güçlü</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="144"/>
        <source>Very strong</source>
        <translation>Çok güçlü</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="146"/>
        <source>Password strength: %1</source>
        <translation>Şifre gücü: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="179"/>
        <source>Hide the password</source>
        <translation>Şifreyi gizle</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="179"/>
        <source>Show the password</source>
        <translation>Şifreyi göster</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="95"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>MX Linux ve antiX Linux için özelleştirilebilir grafik arayüz yükleyici </translation>
    </message>
    <message>
        <location filename="../app.cpp" line="98"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Yapılandırma dosyasını kullanarak otomatik olarak kurulur (daha fazla bilgi aşağıda).
-- UYARI: potansiyel olarak tehlikeli seçenek, birim(ler)i otomatik olarak siler.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="100"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Bölümler ve sürücüler üzerindeki akıl sağlığı denetimlerini geçersiz kılarak bunların görüntülenmesine neden olur.
-- UYARI: Bu bazı şeyleri bozabilir, yalnızca sürücüdeki verileri umursamıyorsanız kullanın.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="102"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>&lt;config-file&gt; tarafından belirtildiği gibi bir yapılandırma dosyası yükleyin.
Varsayılan olarak /etc/minstall.conf kullanılır.
Bu yapılandırma, katılımsız bir kurulum için --auto ile kullanılabilir.
Yükleyici /mnt/antiX/etc/minstall.conf dosyasını oluşturur (veya üzerine yazar) ve ileride kullanmak üzere /etc/minstalled.conf dosyasına bir kopyasını kaydeder.
Yükleyici, yeni yapılandırma dosyasına herhangi bir parola veya yoksayılan ayar yazmaz.
Lütfen bunun deneysel olduğunu unutmayın. Gelecekteki yükleyici sürümleri, mevcut yapılandırma dosyalarıyla uyumluluğu bozabilir.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="108"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Kurulum bittiğinde otomatik olarak kapanır.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="109"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation>Kapasiteden bağımsız olarak tam sürücü kurulumu yaparken her zaman GPT kullanın.
Bu seçenek olmadan GPT yalnızca en az 2 TB kapasiteli sürücülerde kullanılacaktır.
GPT, bu seçenek olmasa bile, kapasiteden bağımsız olarak UEFI sistemlerindeki tam sürücü kurulumlarında her zaman kullanılır.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="112"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Bittiğinde /mnt/antiX bağlantısını kesmeyin veya ilişkili LUKS kaplarından herhangi birini kapatmayın.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation>Yükleyici için başka bir test modu, bölümler/sürücüler FORMATLANACAK, dosyaları kopyalama atlanacak.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>İşletim sistemini kurun, ilk yeniden başlatmaya kadar kullanıcıya özel seçenekler için istemleri erteleyin.
Yeniden başlatmanın ardından, kullanıcının bu ayrıntıları sağlayabilmesi için yükleyici --oobe ile çalıştırılacaktır.
Bu, işletim sistemi önceden yüklenmiş bir bilgisayarı satan veya başka birine veren OEM kurulumları için kullanışlıdır.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="117"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Kutu Dışı Deneyim seçeneği.
--oem seçeneği ile kurulursa bu otomatik olarak başlayacaktır.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="119"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>(GUI) Grafik Arabirim için test modu, gerçekten yüklemeden farklı ekranlara ilerleyebilirsiniz.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="120"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Yükleme tamamlandığında otomatik olarak yeniden başlatılır.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="121"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Özel bölümlemede cp yerine rsync ile yükleme.
-- /kök biçimlendirmez ve şifreleme çalışmaz.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Her zaman başlangıçtakurulum ortamını kontrol edin.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="124"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>Kurulum ortamını başlangıçta kontrol etmeyin.
Kurulum ortamının hatasız olduğu garanti edilmedikçe önerilmez.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="126"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>&lt;config-file&gt; tarafından belirtildiği gibi bir yapılandırma dosyası yükleyin .</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Çok fazla seçenek belirtildi. Lütfen programı --help ile çalıştırarak komut biçimini kontrol edin.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="135"/>
        <source>%1 Installer</source>
        <translation>%1 Yükleyici</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="143"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Yükleyici, zaten arka planda çalışıyor göründüğü için başlamıyor.

Lütfen mümkünse kapatın veya uçbirimde ’pkill minstall’ komutunu çalıştırın.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="150"/>
        <source>This operation requires root access.</source>
        <translation>Bu işlem kök erişimi gerektirir.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="171"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Yapılandırma dosyası (%1) bulunamadı.</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="85"/>
        <source>Failed to create or install swap file.</source>
        <translation>Takas dosyası oluşturulamadı veya yüklenemedi.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="91"/>
        <source>Creating swap file</source>
        <translation>Takas dosyası oluşturuluyor</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="103"/>
        <source>Configuring swap file</source>
        <translation>Takas dosyası ayarlanıyor</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="67"/>
        <source>Invalid location</source>
        <translation>Geçersiz konum</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="70"/>
        <source>Maximum: %1 MB</source>
        <translation>En fazla: %1 MB</translation>
    </message>
</context>
</TS>
