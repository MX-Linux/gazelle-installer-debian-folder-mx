const QString VERSION {"23.8.01mx23"};
