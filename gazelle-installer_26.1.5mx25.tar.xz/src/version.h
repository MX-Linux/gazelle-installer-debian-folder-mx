inline const QString VERSION {"26.1.5mx25"};
