<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="uk">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="59"/>
        <source>Root</source>
        <translation>Корінь (root)</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Home</source>
        <translation>Домівка (home)</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="137"/>
        <location filename="../autopart.cpp" line="139"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="176"/>
        <source>Layout Builder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="321"/>
        <source>%1% root
%2% home</source>
        <translation>Корінь (root) %1%
Домівка (home) %2%</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="323"/>
        <source>Combined root and home</source>
        <translation>Комбінований корінь і домівка (root/home)</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="67"/>
        <source>Cannot access installation media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base.cpp" line="162"/>
        <source>Deleting old system</source>
        <translation>Видалення старої системи</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="166"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Не вдалося видалити стару систему на місці призначення.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="172"/>
        <source>Creating system directories</source>
        <translation>Створення системних каталогів</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="182"/>
        <source>Fixing configuration</source>
        <translation>Фіксування конфігурації</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="252"/>
        <source>Copying new system</source>
        <translation>Копіювання нової системи</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="283"/>
        <source>Failed to copy the new system.</source>
        <translation>Не вдалося скопіювати нову систему.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="282"/>
        <source>Updating initramfs</source>
        <translation>Оновлення initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="149"/>
        <source>Installing GRUB</source>
        <translation>Установлення GRUB</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="150"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>Помилка встановлення GRUB. Ви можете перезавантажити live-носій і скористатися меню GRUB Rescue, щоб відновити встановлення.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="283"/>
        <source>Failed to update initramfs.</source>
        <translation>Не вдалося оновити initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="309"/>
        <source>System boot disk:</source>
        <translation>Диск завантаження системи:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="328"/>
        <location filename="../bootman.cpp" line="340"/>
        <source>Partition to use:</source>
        <translation>Розділ для використання:</translation>
    </message>
</context>
<context>
    <name>DeviceItem</name>
    <message>
        <location filename="../partman.cpp" line="1878"/>
        <source>EFI System Partition</source>
        <translation>Системний розділ EFI</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1879"/>
        <source>swap space</source>
        <translation>простір свопу</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1880"/>
        <source>format only</source>
        <translation>лише форматування</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">Створити</translation>
    </message>
    <message>
        <source>Preserve</source>
        <translation type="vanished">Зберегти</translation>
    </message>
    <message>
        <source>Preserve (%1)</source>
        <translation type="vanished">Зберегти (%1)</translation>
    </message>
    <message>
        <source>Preserve /home (%1)</source>
        <translation type="vanished">Зберегти /home (%1)</translation>
    </message>
</context>
<context>
    <name>DeviceItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2409"/>
        <source>&amp;Templates</source>
        <translation>&amp;Схеми</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2416"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Стиснення (&amp;ZLIB)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2418"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Стиснення (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2420"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Стиснення (&amp;LZO)</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="83"/>
        <source>Shutdown</source>
        <translation>Вимкнути</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="158"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>Ви використовуєте 32-розрядну ОС, запущену в 64-розрядному режимі UEFI, система не зможе завантажитися, якщо під час перезавантаження ви не виберете Legacy Boot або подібне.
Ми рекомендуємо вам вийти зараз і перезапуститися в Legacy Boot

Бажаєте продовжити встановлення?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="182"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Підтримка %1

%1 підтримують такі люди, як ви. Деякі допомагають іншим на форумі підтримки - %2, або перекладають файли довідки різними мовами, або роблять пропозиції, пишуть документацію чи допомагають тестувати нове програмне забезпечення.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="226"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 — це незалежний дистрибутив Linux на основі Debian Stable.

%1 використовує деякі складники MEPIS Linux, які випускаються під вільною ліцензією Apache. Деякі складники MEPIS були змінені для %1.

Насолоджуйтесь %1!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>Pretending to install %1</source>
        <translation>Удавання встановлення %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="370"/>
        <source>Preparing to install %1</source>
        <translation>Підготування до встановлення %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="396"/>
        <source>Paused for required operator input</source>
        <translation>Призупинено до введення користувачем</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="407"/>
        <source>Setting system configuration</source>
        <translation>Налаштування конфігурації системи</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="420"/>
        <source>Cleaning up</source>
        <translation>Очищення</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="424"/>
        <source>Finished</source>
        <translation>Завершено</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="449"/>
        <source>The installation was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="542"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>У файлі конфігурації (%1) знайдено недійсні налаштування. Будь ласка, перегляньте зазначені поля, щойно ви їх зустрінете.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="558"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Чи можна форматувати та використати весь диск (%1) для %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="562"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>ПОПЕРЕДЖЕННЯ. Вибраний диск повинен мати місткість принаймні 2 ТБ і має бути відформатований за допомогою GPT. У деяких системах диск, відформатований у GPT, не завантажується.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="591"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Дані в /home неможливо зберегти, оскільки не вдалося отримати необхідні відомості.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="614"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Домашній каталог для %1 уже існує.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="650"/>
        <source>General Instructions</source>
        <translation>Загальні вказівки</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ПЕРЕД ПРОДОВЖЕННЯМ ЗАКРИЙТЕ ВСІ ІНШІ ПРОГРАМИ.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="652"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>На кожній сторінці прочитайте вказівки, зробіть вибір і натисніть «Далі», коли будете готові продовжити. Вам буде запропоновано підтвердження перед виконанням будь-яких потенційно руйнівних дій.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="654"/>
        <source>Limitations</source>
        <translation>Обмеження</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="655"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Пам’ятайте, що це програмне забезпечення надається «ЯК Є» без будь-яких гарантій. Перш ніж продовжити, ви повинні створити резервну копію даних.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="660"/>
        <source>Installation Options</source>
        <translation>Опції встановлення</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="661"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Якщо ви використовуєте Mac OS або Windows (починаючи з Vista), можливо, вам доведеться використовувати програмне забезпечення цієї системи для налаштування розділів і диспетчера завантаження перед установленням.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="662"/>
        <source>Using the root-home space slider</source>
        <translation>Використання повзунка кореневий/домашній</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="663"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>Диск можна розділити на окремі системний (кореневий) і призначений для користувача (домашній) розділи за допомогою повзунка.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="664"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>Розділ &lt;b&gt;root&lt;/b&gt; (кореневий) міститиме операційну систему та програми.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="665"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>Розділ &lt;b&gt;home&lt;/b&gt; (домашній) міститиме дані всіх користувачів, наприклад їхні налаштування, файли, документи, зображення, музику, відео тощо.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="666"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Перемістіть повзунок праворуч, щоб збільшити простір для &lt;b&gt;root&lt;/b&gt;. Перемістіть праворуч, щоб збільшити простір для &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="667"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Перемістіть повзунок до упору праворуч, якщо ви хочете, щоб кореневий і домашній розділи були на одному розділі.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Зберігання домашнього каталогу в окремому розділі підвищує надійність оновлень операційної системи. Це також полегшує резервне копіювання та відновлення. Це також може покращити загальну плідність системи, обмеживши системні файли певною частиною диска.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="670"/>
        <location filename="../minstall.cpp" line="745"/>
        <source>Encryption</source>
        <translation>Шифрування</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="671"/>
        <location filename="../minstall.cpp" line="746"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Шифрування можливе через LUKS. Потрібен пароль.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="672"/>
        <location filename="../minstall.cpp" line="747"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Потрібен окремий незашифрований завантажувальний розділ.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="673"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Якщо шифрування використовується з автовстановленням, окремий завантажувальний розділ буде створено автоматично.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="674"/>
        <source>Using a custom disk layout</source>
        <translation>Використання користувацької схеми диска</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="675"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Якщо вам потрібно більше контролювати місце встановлення %1, виберіть &quot;&lt;b&gt;%2&lt;/b&gt;&quot; і натисніть &lt;b&gt;Далі&lt;/b&gt;. На наступній сторінці ви зможете вибрати та налаштувати пристрої зберігання та розділи, які вам потрібні.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>Choose Partitions</source>
        <translation>Виберіть розділи</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="684"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Список розділів дозволяє вибрати, які розділи використовуватимуться для цього встановлення.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="685"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Пристрій (Device)&lt;/i&gt; – це назва пристрою блоку, який призначено або буде призначено створеному розділу.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="686"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Розмір (Size)&lt;/i&gt; - розмір розділу. Його можна змінити лише на новій схемі.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="687"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Викор. для (Use For)&lt;/i&gt; - Щоб використовувати цей розділ під час встановлення, ви повинні вибрати щось тут.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="688"/>
        <source>Format - Format without mounting.</source>
        <translation>Format - Форматувати без монтування.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="689"/>
        <source>BIOS-GRUB - BIOS Boot GPT partition for GRUB.</source>
        <translation>BIOS-GRUB - розділ GPT завантаження BIOS для GRUB.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="690"/>
        <source>EFI - EFI System Partition.</source>
        <translation>EFI - системний розділ EFI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="691"/>
        <source>boot - Boot manager (/boot).</source>
        <translation>boot - менеджер завантаження (/boot).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="692"/>
        <source>root - System root (/).</source>
        <translation>root - Корінь системи (/).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="693"/>
        <source>swap - Swap space.</source>
        <translation>swap - Простір свопу</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="694"/>
        <source>home - User data (/home).</source>
        <translation>home - Дані користувача (/home).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Окрім зазначеного вище, ви також можете ввести власну точку монтування. Налаштовувані точки монтування мають починатися зі скісної риски (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="696"/>
        <source>The installer treats &quot;/boot&quot;, &quot;/&quot;, and &quot;/home&quot; exactly the same as &quot;boot&quot;, &quot;root&quot;, and &quot;home&quot;, respectively.</source>
        <translation>Установлювач обробляє &quot;/boot&quot;, &quot;/&quot; і &quot;/home&quot; точно так само, як &quot;boot&quot;, &quot;root&quot; і &quot;home&quot;, відповідно.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="697"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Мітка (Label)&lt;/i&gt; - Мітка, яка присвоюється розділу після його форматування.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="698"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Шифрування (Encrypt)&lt;/i&gt; - Використовуйте шифрування LUKS для цього розділу. Пароль застосовується до всіх розділів, вибраних для шифрування.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="699"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Формат (Format)&lt;/i&gt; - Це формат розділу. Доступні формати залежать від того, для чого використовується розділ. Працюючи з наявною схемою, ви можете зберегти формат розділу, вибравши &lt;b&gt;Зберегти&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="701"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root.</source>
        <translation>Вибір &lt;b&gt;Зберегти /home&lt;/b&gt;для кореневого розділу зберігає вміст каталогу /home, видаляючи все інше. Цю опцію можна використовувати, лише якщо /home знаходиться на тому самому розділі, що й кореневий.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="703"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Підтримуються файлові системи Linux ext2, ext3, ext4, jfs, xfs і btrfs, а рекомендується ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="704"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Перевірка (Check)&lt;/i&gt; - Перевірка та виправлення пошкоджених блоків на диску (підтримується не для всіх форматів). Це забирає багато часу, тому ви можете пропустити цей крок, якщо не підозрюєте, що ваш диск має пошкоджені блоки.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="706"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Опції монтування (Mount Options)&lt;/i&gt; -  визначає опції монтування, які використовуватимуться для цього розділу.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Дамп (Dump)&lt;/i&gt; - Вказує утиліті створення дампа включити цей розділ до резервної копії.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="708"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Пропуск (Pass)&lt;/i&gt; - Послідовність, у якій цю файлову систему слід перевіряти під час завантаження. Якщо нуль, файлова система не перевіряється.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="709"/>
        <source>Menus and actions</source>
        <translation>Меню та дії</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="710"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Різноманітні дії доступні, клацнувши правою кнопкою миші будь-який диск або розділ у списку.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Кнопки праворуч від списку також можна використовувати для маніпулювання записами.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="712"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>Установлювач не може змінити схему, яка вже є на диску. Щоб створити власну схему, позначте диск для нової схеми за допомогою дії меню &lt;b&gt;Нова схема&lt;/b&gt;або кнопки (%1). Це очищає наявну схему.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="715"/>
        <source>Basic layout requirements</source>
        <translation>Основні вимоги до схем</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="716"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>Для %1 потрібен кореневий розділ. Розділ свопу необов’язковий, але настійно рекомендований. Якщо ви хочете використовувати функцію «Призупинення на диск» %1, вам знадобиться розділ свопу, розмір якого перевищує розмір фізичної пам’яті.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="718"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Якщо ви виберете окремий розділ /home, вам буде легше виконати оновлення в майбутньому, але це буде неможливо, якщо ви оновлюєтеся з установлення, яке не має окремого домашнього розділу.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="720"/>
        <source>Active partition</source>
        <translation>Активний розділ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="721"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Для завантаження встановленої операційної системи відповідний розділ (зазвичай завантажувальний або кореневий) має бути позначений як активний.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="722"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>Активний розділ диска можна вибрати за допомогою дії меню &lt;b&gt;Активний розділ&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="723"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Розділ із зірочкою (*) біля назви пристрою є або стане активним розділом.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="724"/>
        <source>Boot partition</source>
        <translation>Завантажувальний розділ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="725"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Цей розділ зазвичай потрібен лише для кореневих розділів на віртуальних пристроях, таких як зашифровані томи, томи LVM або програмні розділи RAID.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="726"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Він містить основне ядро ​​та драйвери, які використовуються для доступу до зашифрованого диска або віртуальних пристроїв.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="727"/>
        <source>BIOS-GRUB partition</source>
        <translation>Розділ BIOS-GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="728"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>У разі використання диска, відформатованого GPT, у системі без EFI, під час використання GRUB потрібен завантажувальний розділ BIOS розміром 1 МБ.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="729"/>
        <source>New drives are formatted in GPT if more than 4 partitions are to be created, or the drive has a capacity greater than 2TB. If the installer is about to format the disk in GPT, and there is no BIOS-GRUB partition, a warning will be displayed before the installation starts.</source>
        <translation>Нові диски форматуються в GPT, якщо потрібно створити більше ніж 4 розділи або диск має місткість понад 2 ТБ. Якщо встановлювач збирається відформатувати диск у GPT, а розділ BIOS-GRUB відсутній, перед початком встановлення з’явиться попередження.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="731"/>
        <source>Need help creating a layout?</source>
        <translation>Потрібна допомога у створенні схеми?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="732"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="766"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Установити GRUB для Linux та Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="767"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="768"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="769"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="770"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="771"/>
        <source>Create a swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="772"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="773"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="774"/>
        <source>Setting the size to 0 has the same effect as unchecking this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="880"/>
        <source>Enjoy using %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="733"/>
        <source>Upgrading</source>
        <translation>Оновлення</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="734"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Щоб оновити наявне встановлення Linux, виберіть той самий домашній розділ, що й раніше, і виберіть &lt;b&gt;Зберегти&lt;/b&gt; як формат.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="735"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Якщо ви не використовуєте окремий домашній розділ, виберіть &lt;b&gt;Зберегти /home&lt;/b&gt; у записі кореневої файлової системи, щоб зберегти наявний каталог /home, розташований у вашому кореневому розділі. Установлювач збереже лише /home, а все інше видалить. У результаті встановлення триватиме набагато довше, ніж зазвичай.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Preferred Filesystem Type</source>
        <translation>Бажаний тип файлової системи</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="738"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Для %1 ви можете відформатувати розділи як ext2, ext3, ext4, f2fs, jfs, xfs або btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="739"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Додаткові опції стиснення доступні для дисків, які використовують btrfs. Lzo швидкий, але стиснення нижче. Zlib повільніший, а проте із вищим стисненням.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="741"/>
        <source>System partition management tool</source>
        <translation>Засіб управління системними розділами</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="742"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Для більшого контролю над макетами дисків (наприклад, змінення наявного макета на диску), натисніть кнопку управління розділами (%1). Це запустить засіб управління розділами операційної системи, який дозволить вам створити точний макет, який вам потрібен.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="748"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Щоб зберегти зашифрований розділ, клацніть на ньому правою кнопкою миші та виберіть &lt;b&gt;Розблокувати&lt;/b&gt;. У діалоговому вікні, що з’явиться, введіть назву віртуального пристрою та пароль. Коли пристрій розблоковано, вибрана вами назва з’явиться в розділі &lt;i&gt;Віртуальні пристрої&lt;/i&gt; з опціями, подібними до опцій звичайного розділу.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="750"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Щоб зашифрований розділ було розблоковано під час завантаження, його потрібно додати до файлу crypttab. Для цього скористайтеся пунктом меню &lt;b&gt;Додати до crypttab&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="751"/>
        <source>Other partitions</source>
        <translation>Інші розділі</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="752"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Установлювач дозволяє створювати інші розділи або використовувати їх для інших цілей, однак майте на увазі, що старіші системи не можуть обробляти диски з більш ніж 4 розділами.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="753"/>
        <source>Subvolumes</source>
        <translation>Підтоми</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="754"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Деякі файлові системи, такі як Btrfs, підтримують кілька підтомів в одному розділі. Це не фізичні підрозділи, тому їх порядок не має значення.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="756"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Використовуйте дію меню &lt;/b&gt;Сканувати підтоми&lt;/b&gt; для пошуку підтомів в наявному розділі Btrfs. Щоб створити новий підтом, скористайтеся пунктом меню &lt;b&gt;Новий підтом&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="758"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Наявні підтоми можна зберегти, але назва має залишитися незмінною.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="759"/>
        <source>Virtual Devices</source>
        <translation>Віртуальні пристрої</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="760"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Якщо встановлювач виявить будь-які віртуальні пристрої, такі як відкриті розділи LUKS, логічні томи LVM або програмні томи RAID, їх можна використовувати для встановлення.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="761"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>Використання віртуальних пристроїв (крім збереження зашифрованих файлових систем) є розширеною функцією. Можливо, вам доведеться відредагувати деякі файли (наприклад, initramfs, crypttab, fstab), щоб забезпечити створення віртуальних пристроїв під час завантаження.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="780"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Загальні служби для увімкнення&lt;/b&gt;&lt;br/&gt;Виберіть будь-яку з цих загальних служб, які можуть знадобитися для конфігурації вашої системи, і служби будуть запущені автоматично, коли ви запустите %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="784"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ідентифікація комп&apos;ютера&lt;/b&gt;&lt;br/&gt;Назва комп&apos;ютера — це унікальна назва, яка позначає ваш комп&apos;ютер в мережі. Назва домену, навряд чи буде використовуватись для цього, хіба що цього вимагає провайдер або умови локальної мережі.&lt;/p&gt;&lt;p&gt;Імена комп&apos;ютерів і доменів можуть містити тільки букви і цифри, точки, тире. Вони не можуть містити пробіли, починатися або закінчуватися дефісом.&lt;/p&gt;&lt;p&gt;Вам потрібно активувати сервер SaMBa, щоб спільно використовувати свої каталоги та друкувати документи з локального комп&apos;ютера під керуванням MS-Windows або Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="794"/>
        <source>Localization Defaults</source>
        <translation>Типова мова</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="795"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Установіть типову мову. Це застосовуватиметься, якщо користувач не змінить їх пізніше.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="796"/>
        <source>Configure Clock</source>
        <translation>Налаштувати годинник</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="797"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Якщо у вас комп’ютер Apple або чистий Unix, типово системний годинник установлено на час за Гринвічем (GMT) або всесвітній координований час (UTC). Щоб змінити це, перевірте поле &quot;&lt;b&gt;Системний годинник використовує місцевий час&lt;/b&gt;&quot;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="799"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Система завантажується з часовим поясом, попередньо встановленим GMT/UTC. Щоб змінити часовий пояс, після перезавантаження нового встановлення клацніть правою кнопкою миші годинник на панелі та виберіть «Властивості».</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="801"/>
        <source>Service Settings</source>
        <translation>Налаштування служб</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="802"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Більшість користувачів не повинні змінювати типові налаштування. Користувачі з комп’ютерами з низьким ресурсом іноді хочуть вимкнути непотрібні служби, щоб зберегти використання оперативної пам’яті якомога меншим. Переконайтеся, що ви знаєте, що робите!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="808"/>
        <source>Default User Login</source>
        <translation>Типовий логін користувача</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="809"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Користувач root схожий на користувача адміністратора в деяких інших операційних системах. Ви не повинні використовувати користувача root як щоденний обліковий запис. Будь ласка, введіть ім’я для нового (типового) облікового запису користувача, яким ви будете користуватися щодня. За потреби ви можете пізніше додати інші облікові записи користувачів за допомогою Менеджера користувачів %1 .</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="813"/>
        <source>Passwords</source>
        <translation>Паролі</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="814"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Введіть новий пароль для типового облікового запису користувача і для облікового запису root. Кожен пароль необхідно вводити двічі.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="816"/>
        <source>No passwords</source>
        <translation>Без паролів</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Якщо ви хочете, щоб типовий обліковий запис користувача не мав пароля, залиште його поля порожніми. Це дозволяє входити в систему, не вимагаючи пароля.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="819"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Очевидно, що це слід робити лише в ситуаціях, коли обліковий запис користувача не потрібно захищати, наприклад, прилюдний термінал.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="826"/>
        <source>Old Home Directory</source>
        <translation>Старий домашній каталог</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="827"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Для вибраного вами імені користувача вже існує домашній каталог. Цей екран дозволяє вибрати, що станеться з цим каталогом.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="829"/>
        <source>Re-use it for this installation</source>
        <translation>Повторно використати для цього встановлення</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="830"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Для цього облікового запису користувача буде використано старий домашній каталог. Це хороший вибір під час оновлення, і ваші файли та налаштування будуть легкодоступними.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>Rename it and create a new directory</source>
        <translation>Перейменувати та створити новий каталог</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="833"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Для користувача буде створено новий домашній каталог, але старий домашній каталог буде перейменовано. Ваші файли та налаштування не будуть одразу видимі в новому встановленні, але доступ до них можна отримати за допомогою перейменованого каталогу.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Старий каталог матиме номер у кінці, залежно від того, скільки разів каталог було перейменовано раніше.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="836"/>
        <source>Delete it and create a new directory</source>
        <translation>Видалити та створити новий каталог</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="837"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Старий домашній каталог буде видалено, а новий буде створено з нуля.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="838"/>
        <source>Warning</source>
        <translation>Попередження</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="839"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Якщо вибрано цей параметр, усі файли та налаштування буде видалено назавжди. Ваші шанси відновити їх низькі.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="855"/>
        <source>Installation in Progress</source>
        <translation>Виконується встановлення</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="856"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 встановлюється. Для нового встановлення це, ймовірно, займе 3-20 хвилин, залежно від швидкості вашої системи та розміру будь-яких розділів, які ви переформатуєте.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="858"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Якщо натиснути кнопку «Скасувати», встановлення буде зупинено якомога швидше.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="860"/>
        <source>Change settings while you wait</source>
        <translation>Змініть налаштування, поки чекаєте</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="861"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Під час встановлення %1 ви можете натиснути кнопки &lt;b&gt;Далі&lt;/b&gt; або &lt;b&gt;Назад&lt;/b&gt;, щоб вказати інші дані для встановлення.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="863"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Виконайте ці кроки у зручному для вас темпі. Установлювач за потреби очікуватиме на ваші дані.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="871"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Вітаємо!&lt;/b&gt;&lt;br/&gt;Ви завершили встановлення %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Пошук програм&lt;/b&gt;&lt;br/&gt;Існують сотні чудових програм, встановлених за допомогою %1. Найкращий спосіб дізнатися про них — переглянути меню та спробувати їх. Багато програм було розроблено спеціально для проєкту %1. Вони показані в головних меню. &lt;p&gt;Крім того, %1 містить багато стандартних програм Linux, які запускаються лише з командного рядка і тому не показані в меню.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="881"/>
        <location filename="../minstall.cpp" line="1137"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Підтримка %1&lt;/b&gt;&lt;br/&gt;%1 підтримують такі люди, як ви. Деякі допомагають іншим на форумі підтримки - %2 - або перекладають файли довідки різними мовами, чи роблять пропозиції, пишуть документацію або допомагають тестувати нове програмне забезпечення.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="911"/>
        <source>Finish</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="914"/>
        <source>OK</source>
        <translation>Гаразд</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="916"/>
        <source>Next</source>
        <translation>Далі</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="437"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>Налаштування системи. Зачекайте.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="444"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Налаштування завершено. Перезапускання системи.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1071"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Установлення та налаштування не завершено.\n
Ви дійсно хочете все зупинити зараз?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1123"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Отримання допомоги&lt;/b&gt;&lt;br/&gt;Основні відомості про %1 містяться за адресою %2.&lt;/p&gt;&lt;p&gt;Є добровольці, які допоможуть вам на форумі %3, %4&lt;/p&gt;&lt;p&gt;Якщо ви звертаєтесь по допомогу, не забудьте докладно описати свою проблему та свій комп’ютер. Зазвичай такі заяви, як «це не спрацювало», не допомагають.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1131"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Відновлення системи&lt;/b&gt;&lt;br/&gt;Якщо %1 припиняє роботу з жорстокого диска, іноді можна виправити проблему завантаживши систему з CD та запустивши одну з утиліт в меню «Налаштування системи» або через один зі звичайних засобів Linux для відновлення системи.&lt;/p&gt;&lt;p&gt;Також через antiX Linux CD можна відновити дані з операційних систем MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1145"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Налаштування звукового мікшера&lt;/b&gt;&lt;br/&gt; %1 намагається налаштувати звуковий мікшер для вас, але іноді вам потрібно буде збільшити гучність і ввімкнути канали в мікшері, щоб почути звук.&lt;/p&gt; &lt;p&gt;Ярлик мікшера розташований у меню. Натисніть на нього, щоб відкрити. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Підтримуйте свою копію %1 в актуальному стані&lt;/b&gt;&lt;br/&gt;Для отримання подробиць та оновлень відвідайте сторінку &lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1158"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Особливі подяки&lt;/b&gt;&lt;br/&gt;Дякуємо всім, хто вирішив підтримати %1 своїм часом, грошима, пропозиціями, роботою, похвалою, ідеями, просуванням та/або заохоченням.&lt;/p&gt;&lt;p&gt;Без вас не було б %1.&lt;/p&gt;&lt;p&gt;Команда розробників %2&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MPassEdit</name>
    <message>
        <source>Use password</source>
        <translation type="vanished">Використовувати пароль</translation>
    </message>
    <message>
        <source>Hide the password</source>
        <translation type="vanished">Сховати пароль</translation>
    </message>
    <message>
        <source>Show the password</source>
        <translation type="vanished">Показати пароль</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="43"/>
        <source>Help</source>
        <translation>Довідка</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="69"/>
        <source>Live Log</source>
        <translation>Live-журнал</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="195"/>
        <source>Close</source>
        <translation>Закрити</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="121"/>
        <source>Next</source>
        <translation>Далі</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="128"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="215"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Збір відомостей, будь ласка, зачекайте.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="250"/>
        <source>Terms of Use</source>
        <translation>Умови використання</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="338"/>
        <source>Change Keyboard Settings</source>
        <translation>Змінити налаштування клавіатури</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="416"/>
        <source>Select type of installation</source>
        <translation>Вибір типу встановлення</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="428"/>
        <source>Regular install using the entire disk</source>
        <translation>Загальне встановлення з використанням всього диска</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="441"/>
        <source>Customize the disk layout</source>
        <translation>Налаштувати макет диска</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="454"/>
        <source>Use disk:</source>
        <translation>Використовувати диск:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="608"/>
        <source>Encrypt</source>
        <translation>Шифрування</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="620"/>
        <location filename="../meinstall.ui" line="793"/>
        <source>Encryption password:</source>
        <translation>Пароль шифрування:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="637"/>
        <location filename="../meinstall.ui" line="810"/>
        <source>Confirm password:</source>
        <translation>Підтвердьте пароль:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="488"/>
        <source>Root</source>
        <translation>Корінь (root)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>Keyboard Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="297"/>
        <source>Model:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>Variant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="350"/>
        <source>Layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="498"/>
        <source>Home</source>
        <translation>Домівка (home)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="573"/>
        <location filename="../meinstall.ui" line="595"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="657"/>
        <location filename="../meinstall.ui" line="1068"/>
        <source>Enable hibernation support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="695"/>
        <source>Choose partitions</source>
        <translation>Вибір розділів</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="704"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Запит операційної системи та перезавантаження макетів усіх дисків.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Вилучити наявний запис із макета. Це працює лише з записами до нового макета.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="726"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Додання нового запису розділу. Це працює лише з новим макетом.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="737"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Позначити вибраний диск, який потрібно очистити для нового макета.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="764"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Запустити засіб управління розділами цієї операційної системи.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="787"/>
        <source>Encryption options</source>
        <translation>Опції шифрування</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="846"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Установити GRUB для Linux та Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="870"/>
        <source>Master Boot Record</source>
        <translation>Головний завантажувальний запис</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="876"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="879"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="901"/>
        <source>EFI System Partition</source>
        <translation>Системний розділ EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="904"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="936"/>
        <source>Partition Boot Record</source>
        <translation>Завантажувальний запис розділу</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="939"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="952"/>
        <source>System boot disk:</source>
        <translation>Диск завантаження системи:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="965"/>
        <source>Location to install on:</source>
        <translation>Розташування для встановлення:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1001"/>
        <source>Create a swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1018"/>
        <source> MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1038"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1061"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1100"/>
        <source>Common Services to Enable</source>
        <translation>Загальні служби для увімкнення</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1119"/>
        <source>Service</source>
        <translation>Служба</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1124"/>
        <source>Description</source>
        <translation>Опис</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1157"/>
        <source>Computer Network Names</source>
        <translation>Назви комп’ютерних мереж</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1184"/>
        <source>Workgroup</source>
        <translation>Робоча група:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1197"/>
        <source>Workgroup:</source>
        <translation>Робоча група:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1210"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Сервер SaMBa для мережі MS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1226"/>
        <source>example.dom</source>
        <translation>example.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1239"/>
        <source>Computer domain:</source>
        <translation>Домен комп&apos;ютера:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1265"/>
        <source>Computer name:</source>
        <translation>Назва комп&apos;ютера:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1326"/>
        <source>Configure Clock</source>
        <translation>Налаштувати годинник</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1367"/>
        <source>Format:</source>
        <translation>Формат:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1395"/>
        <source>Timezone:</source>
        <translation>Часовий пояс:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1440"/>
        <source>System clock uses local time</source>
        <translation>Системний годинник використовує місцевий час</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1472"/>
        <source>Localization Defaults</source>
        <translation>Типова мова</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1512"/>
        <source>Locale:</source>
        <translation>Мова:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1534"/>
        <source>Service Settings (advanced)</source>
        <translation>Налаштування служб (розширені)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1552"/>
        <source>Adjust which services should run at startup</source>
        <translation>Налаштуйте, які служби мають запускатися під час запуску системи</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1555"/>
        <source>View</source>
        <translation>Вигляд</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1600"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Зміни стільниці, зроблені в live-середовищі, будуть перенесені на встановлену ОС</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1603"/>
        <source>Save live desktop changes</source>
        <translation>Зберегти поточні зміни стільниці</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1616"/>
        <source>Default User Account</source>
        <translation>Типовий обліковий запис користувача</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1628"/>
        <source>Default user login name:</source>
        <translation>Типове ім&apos;я користувача для входу:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1660"/>
        <source>Default user password:</source>
        <translation>Типовий пароль користувача:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1689"/>
        <source>Confirm user password:</source>
        <translation>Підтвердити пароль користувача:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1647"/>
        <source>username</source>
        <translation>ім&apos;я користувача</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1721"/>
        <source>Root (administrator) Account</source>
        <translation>Обліковий запис root (адміністратора).</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1739"/>
        <source>Root password:</source>
        <translation>Пароль root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1768"/>
        <source>Confirm root password:</source>
        <translation>Підтвердити пароль root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1800"/>
        <source>Autologin</source>
        <translation>Автовхід</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1836"/>
        <source>Existing Home Directory</source>
        <translation>Наявний домашній каталог</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1845"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Що б ви хотіли зробити зі старим каталогом?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1852"/>
        <source>Re-use it for this installation</source>
        <translation>Повторно використати для цього встановлення</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1859"/>
        <source>Rename it and create a new directory</source>
        <translation>Перейменувати та створити новий каталог</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1866"/>
        <source>Delete it and create a new directory</source>
        <translation>Видалити та створити новий каталог</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1911"/>
        <source>Tips</source>
        <translation>Поради</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1955"/>
        <source>Installation complete</source>
        <translation>Установлення завершено</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1961"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Автоматично перезавантажити систему після закриття встановлювача</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1980"/>
        <source>Reminders</source>
        <translation>Нагадування</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="107"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="114"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Installation in progress</source>
        <translation>Установлення триває</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="172"/>
        <source>Abort</source>
        <translation>Перервати</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="175"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="326"/>
        <source>Please enter a computer name.</source>
        <translation>Введіть назву комп&apos;ютера.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="330"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>На жаль, ім&apos;я вашого комп&apos;ютера містить недійсні символи.
Вам доведеться вибрати інше
перш ніж продовжити.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="335"/>
        <source>Please enter a domain name.</source>
        <translation>Введіть доменне ім&apos;я.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="339"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Вибачте, домен вашого комп’ютера містить недійсні символи.
Вам доведеться вибрати інший
перш ніж продовжити.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="346"/>
        <source>Please enter a workgroup.</source>
        <translation>Введіть робочу групу.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="486"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Ім&apos;я користувача не може містити спеціальні символи або пробіли.
Перш ніж продовжити, виберіть інше ім’я.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="497"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Вибачте, це вже використовується.
Виберіть інше.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="506"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>Ви не вказали пароль для облікового запису root. Ви хочете продовжити?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="535"/>
        <source>Failed to set user account passwords.</source>
        <translation>Не вдалося встановити паролі облікових записів користувачів.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="554"/>
        <source>Failed to save old home directory.</source>
        <translation>Не вдалося зберегти старий домашній каталог.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="558"/>
        <source>Failed to delete old home directory.</source>
        <translation>Не вдалося видалити старий домашній каталог.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="579"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>На жаль, не вдалось створити каталог користувача.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="583"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>На жаль, не вдалось назвати каталог користувача.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="625"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="225"/>
        <source>Virtual Devices</source>
        <translation>Віртуальні пристрої</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="450"/>
        <location filename="../partman.cpp" line="505"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Додати розділ</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="452"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Вилучити розділ</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="462"/>
        <source>&amp;Lock</source>
        <translation>&amp;Заблокувати</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="466"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Розблокувати</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="471"/>
        <location filename="../partman.cpp" line="605"/>
        <source>Add to crypttab</source>
        <translation>Додати до crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="477"/>
        <source>Active partition</source>
        <translation>Активний розділ</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="484"/>
        <source>New subvolume</source>
        <translation>Новий підтом</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="485"/>
        <source>Scan subvolumes</source>
        <translation>Сканувати підтоми</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="508"/>
        <source>New &amp;layout</source>
        <translation>Новий &amp;макет</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="509"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Скинути макет</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="532"/>
        <source>Remove subvolume</source>
        <translation>Вилучити підтом</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="602"/>
        <source>Unlock Drive</source>
        <translation>Розблокувати диск</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="608"/>
        <source>Virtual Device:</source>
        <translation>Віртуальний пристрій:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="609"/>
        <source>Password:</source>
        <translation>Пароль:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="638"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation>Не вдалося розблокувати пристрій. Можливо неправильний пароль.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="667"/>
        <source>Failed to close %1</source>
        <translation>Не вдалося закрити %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="712"/>
        <source>Invalid subvolume label</source>
        <translation>Недійсна мітка підтому</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="723"/>
        <source>Duplicate subvolume label</source>
        <translation>Дубльована мітка підтому</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="732"/>
        <source>Invalid use for %1: %2</source>
        <translation>Недійсне використання для %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="743"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 вже обрано для: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="770"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Потрібен кореневий (root) розділ принаймні для %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="778"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Неможливо зберегти /home в корені (/), якщо також змонтовано окремий розділ /home.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="774"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Ви повинні вибрати окремий завантажувальний розділ під час шифрування root.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="792"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Підготувати таблицю розділів %1 на %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="805"/>
        <source>Format %1 to use for %2</source>
        <translation>Форматувати %1 для використання для %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="806"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Повторне використати (без переформатування) %1 як %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="807"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Видалити дані на %1, за винятком /home, для використання для %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="810"/>
        <source>Create %1 without formatting</source>
        <translation>Створити %1 без форматування</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="811"/>
        <source>Create %1, format to use for %2</source>
        <translation>Створити %1, форматувати для %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="866"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Наступні диски налаштовані або будуть налаштовані за допомогою GPT, але не мають розділу BIOS-GRUB:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="868"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Ця система може не завантажуватися з дисків GPT без розділу BIOS-GRUB.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="862"/>
        <location filename="../partman.cpp" line="869"/>
        <source>Are you sure you want to continue?</source>
        <translation>Ви впевнені, що бажаєте продовжити?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="511"/>
        <source>Layout &amp;Builder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="786"/>
        <source>%1 (%2) requires %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="802"/>
        <source>Reuse %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="823"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="825"/>
        <source>Delete subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="828"/>
        <source>Overwrite subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="829"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="831"/>
        <source>Create subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="832"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="859"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="873"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>Установлювач %1 тепер виконає необхідні дії.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="874"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Ці дії не можна скасувати. Ви хочете продовжити?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="921"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Диски з розділами, які ви вибрали для встановлення, несправні:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="925"/>
        <source>Smartmon tool output:</source>
        <translation>Підсумок засобу Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="926"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Диски з розділами, які ви вибрали для встановлення, пройшли перевірку монітора SMART (smartctl), але перевірки вказують на те, що найближчим часом частота відмов буде вищою за середню.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="931"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Якщо ви не впевнені, вийдіть з установлювача та запустіть GSmartControl, щоб отримати подробиці.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="933"/>
        <source>Do you want to abort the installation?</source>
        <translation>Ви хочете перервати встановлення? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="938"/>
        <source>Do you want to continue?</source>
        <translation>Бажаєте продовжити? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="953"/>
        <source>Failed to format LUKS container.</source>
        <translation>Не вдалося відформатувати контейнер LUKS.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="962"/>
        <source>Failed to open LUKS container.</source>
        <translation>Не вдалося відкрити контейнер LUKS.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1032"/>
        <source>Failed to finalize encryption setup.</source>
        <translation>Не вдалося завершити налаштування шифрування.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1039"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Не вдалося підготувати необхідні розділи.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1070"/>
        <source>Preparing partition tables</source>
        <translation>Підготування таблиць розділів</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1086"/>
        <source>Preparing required partitions</source>
        <translation>Підготування потрібних розділів</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1152"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Створення зашифрованого тому: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1157"/>
        <source>Formatting: %1</source>
        <translation>Форматування: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1160"/>
        <source>Failed to format partition.</source>
        <translation>Не вдалося відформатувати розділ.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1218"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Не вдалося підготувати підтоми.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1219"/>
        <source>Preparing subvolumes</source>
        <translation>Підготування підтомів</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1391"/>
        <source>Failed to mount partition.</source>
        <translation>Не вдалося змонтувати розділ.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1396"/>
        <source>Mounting: %1</source>
        <translation>Монтування: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1568"/>
        <source>Model: %1</source>
        <translation>Модель: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1576"/>
        <source>Free space: %1</source>
        <translation>Вільний простір: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1663"/>
        <source>Device</source>
        <translation>Пристрій</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1664"/>
        <source>Size</source>
        <translation>Розмір</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1665"/>
        <source>Use For</source>
        <translation>Викор. для (Use for)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1666"/>
        <source>Label</source>
        <translation>Мітка</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1667"/>
        <source>Encrypt</source>
        <translation>Шифрування</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1668"/>
        <source>Format</source>
        <translation>Формат</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1669"/>
        <source>Check</source>
        <translation>Перевірка</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1670"/>
        <source>Options</source>
        <translation>Опції</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1671"/>
        <source>Dump</source>
        <translation>Дамп</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1672"/>
        <source>Pass</source>
        <translation>Пропуск (pass)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="102"/>
        <source>Use password</source>
        <translation type="unfinished">Використовувати пароль</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="138"/>
        <source>Negligible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="138"/>
        <source>Very weak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="138"/>
        <source>Weak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="139"/>
        <source>Moderate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="139"/>
        <source>Strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="139"/>
        <source>Very strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="141"/>
        <source>Password strength: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="174"/>
        <source>Hide the password</source>
        <translation type="unfinished">Сховати пароль</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="174"/>
        <source>Show the password</source>
        <translation type="unfinished">Показати пароль</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="63"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Установлювач користувацького графічного інтерфейсу для MX Linux і antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="66"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Установлюється автоматично за допомогою файлу конфігурації (більше відомостей нижче).
-- ПОПЕРЕДЖЕННЯ: потенційно небезпечний варіант, він автоматично стирає розділ(и).</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Скасовує перевірку працездатності розділів і дисків, спричиняючи їх показ.
-- ПОПЕРЕДЖЕННЯ: це може порушити роботу, використовуйте, лише якщо вам байдужі дані на диску.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="70"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Вантаження файлу конфігурації, як зазначено в &lt;config-file&gt;.
Типово використовується /etc/minstall.conf.
Цю конфігурацію можна використовувати з --auto для автоматичного встановлення.
Установлювач створює (або перезаписує) /mnt/antiX/etc/minstall.conf і зберігає копію в /etc/minstalled.conf для подальшого використання.
Установлювач не записуватиме жодних паролів чи знехтуваних налаштувань у новий файл конфігурації.
Зверніть увагу, що це експериментально. Майбутні версії встановлювача можуть порушити сумісність із наявними конфігураційними файлами.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Shutdowns automatically when done installing.</source>
        <translation>Автоматично вимикається після завершення встановлення.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation>Завжди використовує GPT, коли встановлюється весь диск, незалежно від місткості.
Без цієї опції GPT використовуватиметься лише на дисках місткістю принаймні 2 ТБ.
GPT завжди використовується для встановлення повного диска в системах UEFI незалежно від місткості, навіть без цієї опції.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="80"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Не відмонтовуйте /mnt/antiX і не закривайте жодного з пов’язаних контейнерів LUKS після завершення.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="81"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation>Інший режим тестування для встановлювача, розділи/диски буде ФОРМАТОВАНО, копіювання файлів буде пропущено.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="82"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Установити операційну систему, відклавши підказки щодо опцій користувача до першого перезавантаження.
Після перезавантаження встановлювач буде запущено з --oobe, щоб користувач міг надати ці дані.
Це корисно для встановлення OEM, продажу чи роздачі комп’ютера з попередньо завантаженою ОС.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="85"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Опція Out Of Box Experience.
Вона запуститься автоматично, якщо встановлено з опцією --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="87"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Тестовий режим для GUI, ви можете переходити до різних екранів без фактичного встановлення.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="88"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Після встановлення автоматично перезавантажується.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="89"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Встановлення за допомогою rsync замість cp на спеціальному розділі.
-- не форматує /root і не працює з шифруванням.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="91"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Вантаження файлу конфігурації, як зазначено в &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="95"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Забагато аргументів. Перевірте формат команди, запустивши програму за допомогою --help</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="100"/>
        <source>%1 Installer</source>
        <translation>Установлювач %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="108"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Установлювач не запускається, оскільки, здається, він уже працює у фоновому режимі.

Закрийте його, якщо можливо, або запустіть «pkill minstall» у консолі.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="115"/>
        <source>This operation requires root access.</source>
        <translation>Для цієї операції потрібен доступ root.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="136"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Файл конфігурації (%1) не знайдено.</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="63"/>
        <source>Failed to create or install swap file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="70"/>
        <source>Creating swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="80"/>
        <source>Configuring swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="122"/>
        <source>Invalid location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="125"/>
        <source>Maximum: %1 MB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
