inline const QString VERSION {"26.1mx25"};
