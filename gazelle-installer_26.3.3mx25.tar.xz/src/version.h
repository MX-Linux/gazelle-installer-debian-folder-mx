inline const QString VERSION {"26.3.3mx25"};
