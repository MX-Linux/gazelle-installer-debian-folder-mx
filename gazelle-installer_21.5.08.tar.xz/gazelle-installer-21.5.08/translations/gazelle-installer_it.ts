<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Arresta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation>%1 Installer</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Sostieni %1

%1 è sostenuta da persone come te. Alcuni aiutano altri nel forum di supporto - %2, o traducono guide in lingue diverse, danno consigli, scrivono documentazione, o aiutano a testare nuovo software.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Il programma di installazione non parte perché risulta essere già avviato in background.

Si prega di chiuderlo, se possibile, o eseguire &apos;pkill minstall&apos; nel terminale.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation>Non si riesce ad accedere alla sorgente dell&apos;installazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>Stai usando un OS a 32 bit avviato in modalità UEFI a 64 bit, il sistema non sarà in grado di fare il boot a meno che non si vada a scegliere nel Bios la modalità Legacy Boot, o simile, al riavvio.
Noi ti raccomandiamo di chiudere ora e riavviare in Legacy Boot

Vuoi continuare l&apos;installazione ? </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 è una distribuzione Linux independente basata su Debian Stabile.

%1 usa alcuni componenti da MEPIS Linux che sono rilasciati con una licenza libera Apache. Alcuni componenti MEPIS sono stati modificati per %1.

Prova il piacere di usare %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation>Simulazione di installazione di %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="532"/>
        <source>Preparing to install %1</source>
        <translation>Preparazione all&apos;installazione di %1</translation>
    </message>
    <message>
        <source>Failed to format required partitions.</source>
        <translation type="vanished">Non si è riusciti a formattare le partizioni richieste.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="558"/>
        <source>Paused for required operator input</source>
        <translation>In pausa per informazioni richieste all&apos;operatore</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="569"/>
        <source>Setting system configuration</source>
        <translation>Impostazioni di configurazione del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="588"/>
        <source>Cleaning up</source>
        <translation>Fase di pulizia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="590"/>
        <source>Finished</source>
        <translation>Finito</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="754"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>Sono state riscontrate impostazioni non corrette nel file di configurazione (%1). Per cortesia ricontrolla i campi contrassegnati che ti verranno presentati.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="810"/>
        <source>Deleting old system</source>
        <translation>Eliminazione del vecchio sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="814"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Fallita eliminizione del vecchio %1 dalla sua posizione.
Torna allo Step 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>Creating system directories</source>
        <translation>Creazione delle cartelle di sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>Fixing configuration</source>
        <translation>Riparazione della configurazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="888"/>
        <source>Copying new system</source>
        <translation>Copia del nuovo sistema in corso</translation>
    </message>
    <message>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="vanished">Progressione della copiatura non determinabile. Nessuna statistica del filesystem</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="911"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Fallita scrittura di %1 nella sua destinazione.
Torna allo Step 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="955"/>
        <location filename="../minstall.cpp" line="1070"/>
        <source>Updating initramfs</source>
        <translation>Aggiornamento di initramfs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="965"/>
        <source>Installing GRUB</source>
        <translation>Installazione di GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1000"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>L&apos;installazione di GRUB non è riuscita. Ad ogni modo è possibile riparare l&apos;installazione riavviando l&apos;unità live e poi utilizzare Ripara GRUB per riparare l&apos;installazione.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">Errore nell&apos;aggiornamento della variabile di boot NVRAM. Il sistema potrebbe non avviarsi, ma può essere riparato grazie alle voci contenute nello strumento Ripara Boot.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1122"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Il nome utente non può contenere caratteri speciali o spazi.
Prego, scegli un altro nome prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1133"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Spiacente, quel nome è già in uso.
Per favore, scegli un nome differente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1143"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>Non hai fornito una password per l&apos;account root. Vuoi continuare?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1152"/>
        <source>The home directory for %1 already exists.</source>
        <translation>La directory home per %1 esiste già.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>Failed to set user account passwords.</source>
        <translation>Non si è riusciti ad impostare le password dell&apos;account utente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1198"/>
        <source>Failed to save old home directory.</source>
        <translation>Non si è riusciti a salvare la vecchia directory home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1203"/>
        <source>Failed to delete old home directory.</source>
        <translation>Non si è riusciti ad eliminare la vecchia directory home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1221"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Spiacente, la creazione della cartella utente è fallita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1226"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Spiacente, la denominazione della cartella utente è fallita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1247"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Spiacente, l&apos;impostazione della proprietà della cartella utente è fallita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1293"/>
        <source>Please enter a computer name.</source>
        <translation>Inserisci un nome per il computer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1297"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Il nome del tuo computer contiene caratteri non validi.
Devi scegliere un nome differente
prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1303"/>
        <source>Please enter a domain name.</source>
        <translation>Inserisci un nome di dominio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1307"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Il dominio del tuo computer contiene caratteri non validi.
Devi scegliere un nome differente
 prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1314"/>
        <source>Please enter a workgroup.</source>
        <translation>Inserisci un nome di gruppo di lavoro.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1557"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>OK per formattare e usare l&apos;intero disco (%1) per %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1561"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>ATTENZIONE: l&apos;unità selezionata ha una capacità di almeno 2 TB e deve essere formattata usando GPT. Su alcuni sistemi, un disco con formattazione GPT non si avvia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1587"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>I dati in /home non possono essere preservati perchè non è stato possibile ottenere le informazioni richieste.</translation>
    </message>
    <message>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="vanished">Se la partizione contenente /home è crittografata, assicurarsi che sia selezionata correttamente la casella &quot;Crittografare&quot; e che la password inserita sia corretta.</translation>
    </message>
    <message>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="vanished">L&apos;installer non può crittografare una directory o partizione /home già esistente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1649"/>
        <source>General Instructions</source>
        <translation>Istruzioni Generali</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1650"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>PRIMA DI PROCEDERE, CHIUDI TUTTE LE ALTRE APPLICAZIONI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1651"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Si prega di leggere le istruzioni di ogni pagina, effettuate le vostre scelte, quindi cliccate su Avanti quando si è pronti a procedere. Vi verrà richiesta una conferma prima di qualsiasi azione distruttiva.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1653"/>
        <source>Limitations</source>
        <translation>Limitazioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1654"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Ricorda, questo software viene fornito così com&apos;è senza alcuna garanzia. È esclusiva responsabilità dell&apos;utente eseguire il backup dei dati prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1659"/>
        <source>Installation Options</source>
        <translation>Opzioni d&apos;Installazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1660"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation>L&apos;installazione richiede circa %1 di spazio. %2 o più è preferibile.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1661"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Se stai usando Mac OS o Windows OS (da Vista in avanti), puoi usare il software di quei sistemi per creare le partizioni e impostare il boot manager prima dell’installazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1662"/>
        <source>Using the root-home space slider</source>
        <translation>Utilizzare il cursore dello spazio home-root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1663"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation>Su unità di grandi dimensioni, l&apos;installazione regolare predefinita prevede le partizioni root e home separate. Il cursore consente di controllare la quantità di spazio a disposizione di ciascuna partizione. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1665"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Muovi il cursore a destra per incrementare lo spazio per &lt;b&gt;root&lt;/b&gt;. Muovilo a sinistra per incrementare lo spazio per la &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1666"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Muovi il cursore tutto a destra se vuoi sia root che home nella stessa partizione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1667"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation> Se prevedi di installare molte applicazioni o applicazioni di grandi dimensioni come pacchetti di editing di grafica, audio e video, probabilmente ti servirà una partizione &lt;b&gt;root&lt;/b&gt; più grande.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1669"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation>Se intendi memorizzare una grande quantità di dati, o questo computer è utilizzato da molti utenti, potresti volere una partizione &lt;b&gt;home&lt;/b&gt; più grande.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Mantenere la directory home in una partizione separata migliora l&apos;affidabilità degli aggiornamenti del sistema operativo. Inoltre, facilita il backup e il ripristino. Ciò può anche migliorare le prestazioni complessive vincolando i file di sistema ad una parte definita del disco. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1673"/>
        <location filename="../minstall.cpp" line="1740"/>
        <source>Encryption</source>
        <translation>Crittografia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <location filename="../minstall.cpp" line="1741"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>La crittografia è possibile attraverso LUKS. Si richiede una password.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <location filename="../minstall.cpp" line="1742"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>È necessaria una partizione di boot separata non crittografata. Per impostazioni aggiuntive tra cui la scelta della cifratura, usa il pulsante &lt;b&gt;Impostazioni avanzate di crittografia&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1677"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Quando si compie la scelta per l&apos;installazione automatica insieme alla crittografia, verrà creata automaticamente una partizione di boot separata .</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>Using a custom disk layout</source>
        <translation>Impostare una configurazione personalizzata del disco</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Nella pagina successiva, sarai quindi in grado di selezionare e configurare i dispositivi di archiviazione e le partizioni di cui hai bisogno. 
Se hai bisogno di un maggior controllo riguardo la posizione di installazione di  %1 seleziona  &quot;&lt;b&gt;%2&lt;/b&gt;&quot; e clicca &lt;b&gt;Avanti&lt;/b&gt;. Nella pagina successiva, sarai quindi in grado di selezionare e configurare i dispositivi di archiviazione e le partizioni che ti servono. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>Choose Partitions</source>
        <translation>Scegli le partizioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1695"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>L&apos;elenco delle partizioni ti consente di scegliere quali partizioni verranno utilizzate per questa installazione. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1696"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Dispositivo&lt;/i&gt; - Questo è il nome del dispositivo che è, o sarà assegnato, alla partizione creata.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Dimensione&lt;/i&gt; - La dimensione della partizione. Questa può essere cambiata solo in una nuova configurazione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1698"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etichetta&lt;/i&gt; - L&apos;etichetta che viene assegnata a una partizione una volta che questa sia stata formattata.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1699"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation>&lt;i&gt;Usa Per&lt;/i&gt; - Per utilizzare questa partizione in un&apos;installazione, devi selezionare qualcosa qui. Puoi anche digitare il tuo punto di montaggio, che deve iniziare con una slash (&quot;/&quot;). </translation>
    </message>
    <message>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption. To preserve the format of an existing encrypted partition, you must use the same passphrase that it was originally encrypted with.</source>
        <translation type="vanished">&lt;i&gt;Crittografia&lt;/i&gt; - La password si applica a tutte le partizioni selezionate per la crittografia. Per preservare il formato di una partizione crittografata esistente, è necessario utilizzare la stessa pass-phrase con cui era stata originariamente crittografata. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Formato&lt;/i&gt; - Questo è il formato della partizione. I formati disponibili dipendono dallo scopo per cui viene utilizzata la partizione. Quando si lavora con una configurazione esistente, è possibile mantenere il formato della partizione selezionando &lt;b&gt;Preserva&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>I filesystem linux ext2, ext3, ext4, jfs, xfs, btrfs e reiserfs sono tutti supportati ma è raccomandato ext4.


</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Opzioni di montaggio&lt;/i&gt; - Specifica le opzioni di montaggio che saranno usate per questa partizione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1706"/>
        <source>Menus and actions</source>
        <translation>Menu e azioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Sono disponibili numerose azioni cliccando col destro del mouse su una qualsiasi unità, o partizione, presenti nell&apos;elenco. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>I pulsanti a destra dell&apos;elenco possono essere utilizzati anche per manipolare le varie voci. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1709"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation> Il programma di installazione non può modificare la configurazione già presente sull&apos;unità. Per creare una configurazione personalizzata, contrassegnare l&apos;unità per una nuova configurazione con l&apos;azione del menu &lt;b&gt;Nuova configurazione&lt;/b&gt; o il pulsante (%1). Questi elimineranno la configurazione esistente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1712"/>
        <source>Basic layout requirements</source>
        <translation>Requisiti basilari di configurazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 richiede una partizione di root. La partizione di swap è facoltativa ma altamente consigliata. Se si desidera utilizzare la funzionalità di sospensione di %1, è necessario disporre di una partizione di swap con una dimensione più grande di quella della memoria fisica (RAM).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Se scegliete una partizione /home separata sarà più facile fare l&apos;aggiornamento in futuro, ma questo non sarà possibile se avete fatto l&apos;aggiornamento da un&apos;installazione che non ha una partizione home separata.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Need help creating a layout?</source>
        <translation>Ti serve aiuto per creare una configurazione?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation>Basta cliccare col destro su un&apos;unità per visualizzare un menu e selezionare un modello di configurazione. Queste configurazioni sono simili a quelle dell&apos;installazione normale. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation>&lt;i&gt;Installazione Standard&lt;/i&gt; Adatta alla maggior parte delle configurazioni. Questo modello non aggiunge una partizione di avvio separata, quindi non è adatto per l&apos;uso con un sistema operativo criptato. -</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation>&lt;i&gt;Sistema Crittografato&lt;/i&gt; - Contiene la partizione di avvio richiesta per caricare un sistema operativo criptato. Questo modello può anche essere utilizzato come base per un sistema ad avvio multiplo. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1725"/>
        <source>Upgrading</source>
        <translation>Aggiornare</translation>
    </message>
    <message>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="vanished">Per eseguire l&apos;aggiornamento da un&apos;installazione Linux esistente, selezionare la stessa partizione home precedente e selezionare &lt;b&gt;mantieni&lt;/b&gt; come tipo di file system.</translation>
    </message>
    <message>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="vanished">Se volete conservare una directory /home esistente situata nella vostra partizione di root, l&apos;installer non riformatterà la partizione root. Come risultato, l&apos;installazione richiederà molto più tempo del previsto.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <source>Failed to prepare required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <location filename="../minstall.cpp" line="2522"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1701"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>Partition boot flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1718"/>
        <source>For the installed operating system to boot, the boot flag must be set on the appropriate partition. This is usually the boot or root partition. The flag can be changed using the &lt;b&gt;Set boot flag&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>A partition whose boot flag will be set is shown with its device name in &lt;i&gt;italic&lt;/i&gt; type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipo di Filesystem Preferito</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Per %1, potete scegliere di formattare le partizioni come ext2, ext3, ext4, f2fs, jfs, xfs. btrfs o reiser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1731"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Un&apos;ulteriore opzione di compressione è disponibile per i dischi che usano btrfs. Lzo è veloce, ma la compressione è bassa. Zlib è lento, con una maggiore compressione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>Bad Blocks</source>
        <translation>Settori danneggiati</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Se scegliete ext2, ext3 o ext4 come tipo di formato, avete l&apos;opzione di testare e correggere i bad blocks o settori danneggiati del disco. Il test dei bad blocks richiede parecchio tempo, quindi vi conviene saltare questo passaggio se non sospettate che il vostro disco abbia dei blocchi danneggiati.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1736"/>
        <source>System partition management tool</source>
        <translation>Strumento di gestione delle partizioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Per un maggiore controllo sulla configurazione delle unità (come la modifica della configurazione esistente su un disco), cliccare sul pulsante di gestione delle partizioni (%1). Questo avvierà lo strumento di gestione delle partizioni del sistema operativo, che ti consentirà di creare l&apos;esatta configurazione di cui hai bisogno. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>Other partitions</source>
        <translation>Altre partizioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Il programma di installazione consente la creazione o l&apos;utilizzo di altre partizioni per scopi diversi, tuttavia tieni presente che i sistemi meno recenti non possono gestire unità con più di 4 partizioni. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>Subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1755"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1763"/>
        <source>Advanced Encryption Settings</source>
        <translation>Impostazioni Avanzate di Crittografia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1763"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Questa pagina consente una regolazione precisa delle partizioni crittografate LUKS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Nella maggior parte dei casi, i valori predefiniti forniscono un pratico equilibrio tra sicurezza e prestazioni, che è una buona scelta per le applicazioni sensibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Questo testo affronta gli aspetti basilari dei parametri utilizzati con LUKS, il che non significa che sia una guida completa alla crittografia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>La modifica di una qualsiasi di queste impostazioni senza una buona conoscenza della crittografia può determinare l&apos;uso di una crittografia debole.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>La modifica di un campo spesso influisce sulle opzioni disponibili sotto di esso. I campi sottostanti possono essere automaticamente modificati con i valori consigliati.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1769"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Dove si ritiene di ottenere migliori prestazioni o maggiore sicurezza modificando le impostazioni dai valori raccomandati, lo si fa a proprio rischio e pericolo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Puoi usare il pulsante &lt;b&gt;Benchmark&lt;/b&gt; (che avvia la  &lt;i&gt;valutazione impostazioni di crittografia&lt;/i&gt; in un&apos;apposita finestra di terminale) per confrontare le prestazioni delle comuni combinazioni di hash, cifrari e modalità a catena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1772"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Si noti che &lt;i&gt;valutazione impostazioni di crittografia&lt;/i&gt; non considera tutte le combinazioni o selezioni possibili, e generalmente affronta le selezioni più comunemente utilizzate.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>Cipher</source>
        <translation>Cifrario</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>A variety of ciphers are available.</source>
        <translation>Sono disponibili una varietà di cifrari</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1775"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>è stato uno dei cinque migliori algoritmi AES. Si ritiene abbia un margine di sicurezza più elevato di Rijndael e di tutti gli altri finalisti per AES. Funziona meglio su alcune CPU a 64 bit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1776"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(anche conosciuto come &lt;i&gt;Rijndael&lt;/i&gt;) è un codice molto comune e molte CPU moderne includono istruzioni specifiche per AES, per via della sua ubiquità. Sebbene Rijndael sia stato designato come superiore a Serpent per le sue prestazioni, non ci si aspetta che siano praticabili attacchi attualmente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>è il successore di Blowfish. È diventato uno dei cinque algoritmi finalisti per l&apos;AES, sebbene non sia stato scelto come standard.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) era un candidato al concorso per l&apos;AES, tuttavia non è diventato un finalista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1779"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>è un codice a blocchi a 64 bit creato da Bruce Schneier. Non è raccomandato per le applicazioni sensibili in quanto sono supportate solo le modalità CBC ed ECB. Blowfish supporta chiavi, multiple di 8, di dimensioni comprese tra 32 e 448 bit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1781"/>
        <source>Chain mode</source>
        <translation>Modalità a catena</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1781"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Se i blocchi sono stati tutti crittografati utilizzando la stessa chiave, potrebbe emergere un modello e per riuscire a codificare il testo in chiaro.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>XEX-based Tweaked codebook with ciphertext Stealing) è una moderna modalità a catena, che supera CBC e EBC. E&apos; la modalità a catena di default (e raccomandata). Usando ESSIV su Plain64 si peggioreranno le prestazioni, con un guadagno in sicurezza trascurabile.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Cipher Block Chaining) è più semplice di XTS, ma vulnerabile ad un attacco padding oracle (in parte mitigato da ESSIV) e non è raccomandato per applicazioni sensibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1784"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic CodeBook) è meno sicuro di CBC e non dovrebbe essere usato per applicazioni sensibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>IV generator</source>
        <translation>generatore di IV</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>Per XTS e CBC, questo seleziona come l&apos;&lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector viene generato. &lt;b&gt;ESSIV&lt;/b&gt; richiede una funzione di hash e perciò sarà disponibile un secondo menu a discesa se questo viene selezionato. Gli hash disponibili dipendono dal cifrario selezionato.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1787"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>La modalità ECB non utilizza un IV, per cui questi campi saranno tutti disabilitati se ECB è selezionata per la modalità a catena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>Key size</source>
        <translation>Dimensione chiave</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Imposta la dimensione della chiave in bit. Le dimensioni delle chiavi disponibili sono limitate dalle modalità a catena e cifratura.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>La modalità di cifratura a catena XTS divide la chiave a metà (per esempio, AES-256 in modalità XTS richiede una dimensione della chiave di 512-bit).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>LUKS key hash</source>
        <translation>hash della chiave LUKS</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>l&apos;hash usata per PBKDF2 e per AF splitter.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 e RIPEMD-160 non sono più raccomandati per applicazioni sensibili in quanto si è riscontrato che possono essere rotti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Kernel RNG</source>
        <translation>Kernel RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Imposta quale generatore di numeri casuali del kernel verrà utilizzato per creare la chiave master del volume (che è una chiave a lungo termine).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Due opzioni sono disponibili: /dev/&lt;b&gt;random&lt;/b&gt; che blocca fino a quando si ottiene un&apos;entropia sufficiente (può impiegare molto tempo in situazioni di bassa entropia), e /dev/&lt;b&gt;urandom&lt;/b&gt; che non bloccherà anche se l&apos;entropia è insufficiente (è possibile che si abbiano chiavi più deboli).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF round time&lt;/b&gt;&lt;br/&gt;La quantità di tempo (in millisecondi) da impiegare con PBKDF2 passphrase processing.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Un valore di 0 seleziona il valore precompilato di default (esegui &lt;i&gt;cryptsetup --help&lt;/i&gt; per dettagli).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Se hai una macchina lenta, potresti voler aumentare questo valore per maggiore sicurezza, in cambio del tempo impiegato per sbloccare un volume dopo che è stata inserita una passphrase.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1805"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Seleziona Sistema di Boot&lt;/b&gt;&lt;br/&gt; %1 usa GRUB come caricatore del boot per l&apos;avvio sia di %1 che di MS-Windows. &lt;p&gt;Di default GRUB2 viene installato nell&apos;apposito Master Boot Record (MBR) o in ESP (EFI System Partition for 64-bit UEFI boot systems) presente nell&apos;Hard Disk o comunque nell&apos;unità che usi per il boot e va a rimpiazzare il caricatore del boot che stavi usando prima. Questa è la norma.&lt;/p&gt;&lt;p&gt;Se invece tu scegli di installare GRUB2 nel PBR (Partition Boot Record),  allora GRUB2 sarà installato all&apos;inizio della specifica partizione. Questa opzione è solo per gli esperti.&lt;/p&gt;&lt;p&gt;Se tu deselezioni la casella per l&apos;installazione di GRUB, allora GRUB non verrà installato in questo momento. Questa opzione è solo per esperti.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1820"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Servizi da Avviare in Automatico&lt;/b&gt;&lt;br/&gt;Seleziona quali tra questi servizi, che ritieni importanti per la configurazione del tuo sistema, vuoi che siano attivati automaticamente all&apos;avvio di %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1824"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identità del Computer&lt;/b&gt;&lt;br/&gt;Il nome del computer è un normale nome che identificherà il computer quando sarà all&apos;interno di un network di rete. Il dominio del computer è improbabile che sia usato a meno che non venga richiesto dal tuo ISP o network locale.&lt;/p&gt;&lt;p&gt;I nomi del computer e del dominio possono contenere solo caratteri alfanumerici, punti e trattini.  Non possono contenere spazi bianchi, iniziare o finire con trattini&lt;/p&gt;&lt;p&gt;Il server SaMBa deve essere attivato se vuoi condividere cartelle o stampanti con un computer locale che usa MS-Windows o Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1837"/>
        <source>Localization Defaults</source>
        <translation>Impostazioni di Localizzazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Inserisci le impostazioni predefinite della localizzazione.  Verranno mantenute a meno che non vengano sostituite successivamente dall&apos;utente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1839"/>
        <source>Configure Clock</source>
        <translation>Configura l&apos;Ora</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation> Se si dispone di un computer Unix o Apple, per impostazione predefinita l&apos;orologio di sistema è impostato su Greenwich Meridian Time (GMT) o su Coordinated Universal Time (UTC). Per modificare questa impostazione, seleziona la casella &quot;&lt;b&gt;Usa l&apos;ora locale per l&apos;orologio di sistema &lt;/b&gt;&quot; .</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1842"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Il sistema si avvia con il fuso orario preimpostato su GMT/UTC. Per modificare il fuso orario, dopo il riavvio nella nuova installazione, cliccare col destro del mouse sull&apos;orologio nel pannello e selezionare Proprietà. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1844"/>
        <source>Service Settings</source>
        <translation>Impostazioni Servizi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1845"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>La maggior parte degli utenti non dovrebbe cambiare le impostazioni predefinite. Gli utenti con computer con poche risorse a volte vogliono disabilitare i servizi non necessari per mantenere l&apos;uso della RAM più basso possibile. Assicuratevi di sapere cosa si sta facendo!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1851"/>
        <source>Default User Login</source>
        <translation>Login Utente Predefinito</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>L&apos;utente root corrisponde all&apos;utente Amministratore di altri noti sistemi operativi. Non dovresti usare l&apos;utente root-amministratore come utente per il normale uso giornaliero. Prego, inserisci il nome di un nuovo account utente (utente di default) che userai per le normali attività giornaliere. Se necessario, potrai aggiungere altri account utente più tardi con gestione degli utenti con  %1 Manager Utenti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1856"/>
        <source>Passwords</source>
        <translation>Passwords</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1857"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Inserisci una nuova password per l&apos;account dell&apos;utente di default  e per l&apos;account root. Ogni password deve essere inserita due volte. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>No passwords</source>
        <translation>Nessuna password</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1860"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Se si vuole che l&apos;account dell&apos;utente di default non abbia password, lasciare vuoti i campi della password. Ciò consente di accedere senza che venga richiesta una password. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1862"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Ovviamente, questo dovrebbe essere fatto solo in situazioni in cui non è necessario che l&apos;account utente sia sicuro, come ad es. in un terminale pubblico. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>Old Home Directory</source>
        <translation>Vecchia Home Directory</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1872"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Per il nome-utente scelto esiste già una directory home. Questa schermata permette di decidere cosa fare con questa directory.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>Re-use it for this installation</source>
        <translation>Riusa per questa installazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>La vecchia home directory verrà utilizzata per questo account utente. Questa è una buona scelta nel caso di un aggiornamento perchè i tuoi file e le tue impostazioni saranno immediatamente disponibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1877"/>
        <source>Rename it and create a new directory</source>
        <translation>Rinomina e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1878"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Verrà creata una nuova home directory per l&apos;utente, mentre la vecchia home directory verrà rinominata. I file e le impostazioni, della vecchia home, non saranno immediatamente visibili nella nuova installazione, ma ci si potrà accedere andando alla directory rinominata</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>La vecchia directory avrà un numero alla fine, in funzione di quante volte la directory è stata rinominata in precedenza.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1881"/>
        <source>Delete it and create a new directory</source>
        <translation>Cancella e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1882"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>La vecchia directory home verrà eliminata e ne verrà creata una nuova da zero.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1883"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1884"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Se questa opzione è selezionata, tutti i file e impostazioni verranno eliminati in modo permanente. Dopodichè la possibilità di recuperarli saranno molto scarse.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1900"/>
        <source>Installation in Progress</source>
        <translation>Installazione in avanzamento</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1901"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 è in corso di installazione. Una nuova installazione richiederà probabilmente da 3 a 20 minuti, a seconda della velocità del tuo sistema e della dimensione di ciascuna partizione che stai riformattando.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1903"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Se clicchi il pulsante Interrompi, l&apos;installazione verrà arrestata prima possibile.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1905"/>
        <source>Change settings while you wait</source>
        <translation>Modifica impostazioni durante l&apos;attesa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1906"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Mentre %1 è in corso d&apos;installazione, puoi cliccare sui pulsanti &lt;b&gt;Avanti&lt;/b&gt; o &lt;b&gt;Indietro&lt;/b&gt; per inserire ulteriori informazioni necessarie all&apos;installazione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1908"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Completa questi passaggi senza fretta. Se necessario, l&apos;installer aspetterà i tuoi inserimenti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1917"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Congratulazioni!&lt;/b&gt;&lt;br/&gt;Hai completato l&apos;installazione di %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Trovare Applicazioni&lt;/b&gt;&lt;br/&gt;Ci sono centinaia di eccellenti applicazioni installate con %1 Il miglior modo di iniziare a conoscerle è di scorrere il Menu e cercarle. Molte applicazioni sono sviluppate specificatamente per il progetto %1. Queste sono visibili nei menu principali. &lt;p&gt;In aggiunta %1 include molte applicazioni standard di Linux che sono avviabili solo da riga di comando e quindi non appaiono nei menu.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1926"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Prova il piacere di usare %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1927"/>
        <location filename="../minstall.cpp" line="2342"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Sostieni %1&lt;/b&gt;&lt;br/&gt;%1 è sostenuta da persone come te. Alcuni aiutano altri nel forum di supporto - %2 - o traducono guide in lingue diverse, danno consigli, scrivono documentazione, o aiutano a testare nuovo software.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1958"/>
        <source>Finish</source>
        <translation>Finito</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1962"/>
        <source>OK</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1964"/>
        <source>Next</source>
        <translation>Avanti</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1999"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>Configuro il sistema. Prego attendere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2002"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Configurazione completa. Riavvio il sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2006"/>
        <source>Could not complete configuration.</source>
        <translation>Non posso completare la configurazione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2024"/>
        <source>Loading...</source>
        <translation>Caricamento...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2066"/>
        <location filename="../minstall.cpp" line="2457"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2068"/>
        <location filename="../minstall.cpp" line="2465"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2267"/>
        <source>Confirmation</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2267"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>L&apos;intallazione e configurazione non è ultimata.
Vuoi davvero chiudere ora?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2328"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ricevere Assistenza&lt;/b&gt;&lt;br/&gt;Informazioni di base su %1 puoi trovarle in %2.&lt;/p&gt;&lt;p&gt;Ci sono volontari che ti possono aiutare nel Forum di %3 , %4&lt;/p&gt;&lt;p&gt;Se chiedi aiuto, per favore ricordati di fornire sufficienti dettagli per descrivere il tuo problema e il tuo computer. Di solito con richieste del tipo &apos;non funziona&apos; non si riceve aiuto.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2336"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Riparare la tua Installazione&lt;/b&gt;&lt;br/&gt;Se %1, installato sul disco, per qualche motivo non dovesse funzionare, talvolta è possibile riparare il danno avviando il DVD-Live o l&apos;USB-Live e facendo uso delle utility presenti negli specifici strumenti d&apos;aiuto contenuti in %1 o usando i normali strumenti Linux per riparare il sistema.&lt;/p&gt;&lt;p&gt;Puoi usare il DVD-Live o l&apos;USB-Live di  %1 anche per recuperare dati da un sistema MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2350"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Regolare il Mixer del Suono&lt;/b&gt;&lt;br/&gt; %1 cerca di configurare il mixer del suono per te, ma talvolta dopo l&apos;installazione sarà necessario alzare i volumi e attivare i canali per riuscire ad udire il suono.&lt;/p&gt; &lt;p&gt;L&apos;icona del mixer si trova nel pannello. Cliccaci col destro per aprire il mixer. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2358"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mantenere %1 aggiornato&lt;/b&gt;&lt;br/&gt;Per informazioni e aggiornamenti, prego visita&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2363"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ringraziamenti&lt;/b&gt;&lt;br/&gt;Grazie a tutti coloro che hanno deciso di supportare %1 con il loro tempo, denaro, promozione, consigli, lavoro, idee, lodi, e/o incoraggiamento.&lt;/p&gt;&lt;p&gt;Senza di voi non ci sarebbe %1.&lt;/p&gt;&lt;p&gt;%2 Team Sviluppatori&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2415"/>
        <source>%1% root</source>
        <translation>%1% root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2415"/>
        <source>%2% home</source>
        <translation>%2% home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2462"/>
        <source>----</source>
        <translation>----</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2510"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2521"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2651"/>
        <source>System boot disk:</source>
        <translation>Disco di avvio del sistema:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2665"/>
        <location filename="../minstall.cpp" line="2674"/>
        <source>Partition to use:</source>
        <translation>Partizione da usare:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation>Utilizza la password</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation>Log Live</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>Avanti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Fase di elaborazione delle informazioni, si prega di attendere.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Termini d&apos;Uso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Impostazione Tastiera&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modello:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variante:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation>Cambia Impostazioni Tastiera </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Seleziona il tipo d&apos;installazione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Installazione normale usando l&apos;intero disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation>Personalizzare l&apos;aspetto del disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="403"/>
        <location filename="../meinstall.ui" line="784"/>
        <source>Confirm password:</source>
        <translation>Conferma password:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <location filename="../meinstall.ui" line="801"/>
        <source>Encryption password:</source>
        <translation>Password di crittografia:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="426"/>
        <location filename="../meinstall.ui" line="824"/>
        <location filename="../meinstall.ui" line="856"/>
        <source>Advanced encryption settings</source>
        <translation>Impostazioni avanzate di crittografia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="442"/>
        <source>Use disk:</source>
        <translation>Usare il disco:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="468"/>
        <location filename="../meinstall.ui" line="705"/>
        <source>Encrypt</source>
        <translation>Crittografare</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="525"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="560"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="624"/>
        <source>Choose partitions</source>
        <translation>Scegli le partizioni</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Aggiungi un nuovo nome di partizione. Questo funziona solo con un nuovo aspetto.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Size</source>
        <translation>Dimensione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="695"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="700"/>
        <source>Use For</source>
        <translation>Usa Per</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="710"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mount Options</source>
        <translation>Opzioni di Montaggio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="673"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Interroga il sistema operativo e ricarica l&apos;aspetto di tutti i dischi.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="642"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation>Ricerca settori danneggiati (richiede più tempo)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="649"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Rimuovi una voce esistente dalla configurazione. Funziona solo con le voci di una nuova configurazione. </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="734"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Contrassegna l&apos;unità selezionata da pulire per una nuova configurazione.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="745"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Avvia il programma di gestione delle partizioni di questo sistema operativo.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="768"/>
        <source>Encryption options</source>
        <translation>Opzioni di crittografia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1138"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1143"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1148"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1153"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1158"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="884"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1178"/>
        <source> mS</source>
        <translation> mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="868"/>
        <source>LUKS key hash:</source>
        <translation>hash della chiave LUKS:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="998"/>
        <source>Key size:</source>
        <translation>Dimensione Chiave:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1108"/>
        <source>KDF round time:</source>
        <translation>KDF round time:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1095"/>
        <source>Cipher:</source>
        <translation>Cifrario:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="938"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="943"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="948"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="953"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="958"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="985"/>
        <source>Benchmark...</source>
        <translation>Benchmark...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1054"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1064"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1069"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1074"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1011"/>
        <source>IV generator:</source>
        <translation>IV generatore:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1037"/>
        <source>Chain mode:</source>
        <translation>Modalita  a catena:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="904"/>
        <source>Kernel RNG:</source>
        <translation>Kernel RNG:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="912"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="917"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1082"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1213"/>
        <source>Select Boot Method</source>
        <translation>Selezionare il modo di avvio Boot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>EFI System Partition</source>
        <translation>EFI System Partition</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1253"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1272"/>
        <source>Partition Boot Record</source>
        <translation>Partition Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation>Posizione su cui installare:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1301"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Installare GRUB per Linux e Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1304"/>
        <location filename="../meinstall.ui" line="2414"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1320"/>
        <source>System boot disk:</source>
        <translation>Disco di avvio del sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1342"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1348"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1351"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1422"/>
        <source>Common Services to Enable</source>
        <translation>Servizi da avviare in automatico</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1441"/>
        <source>Service</source>
        <translation>Servizio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1446"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1479"/>
        <source>Computer Network Names</source>
        <translation>Nome Computer in Rete</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1506"/>
        <source>Workgroup</source>
        <translation>Gruppolavoro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Workgroup:</source>
        <translation>Gruppo di lavoro:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1532"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Server SaMBa per Network MS Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1548"/>
        <source>example.dom</source>
        <translation>example.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1561"/>
        <source>Computer domain:</source>
        <translation>Dominio computer:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1587"/>
        <source>Computer name:</source>
        <translation>Nome computer:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1648"/>
        <source>Configure Clock</source>
        <translation>Configura l&apos;Ora</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1689"/>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Timezone:</source>
        <translation>Fuso orario:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1762"/>
        <source>System clock uses local time</source>
        <translation>Usa l&apos;ora locale per l&apos;orologio di sistema</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1794"/>
        <source>Localization Defaults</source>
        <translation>Impostazioni di Localizzazione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1834"/>
        <source>Locale:</source>
        <translation>Lingua locale:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1856"/>
        <source>Service Settings (advanced)</source>
        <translation>Impostazione Servizi (utenti avanzati)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1874"/>
        <source>Adjust which services should run at startup</source>
        <translation>Imposta quali servizi dovrebbero partire all&apos;avvio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1877"/>
        <source>View</source>
        <translation>Mostra </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Root (administrator) Account</source>
        <translation>Account di root (amministratore)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1947"/>
        <source>Root password:</source>
        <translation>Password amministratore:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>Confirm root password:</source>
        <translation>Conferma la password amministratore</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2021"/>
        <source>Default User Account</source>
        <translation>Account dell&apos;utente predefinito</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2033"/>
        <source>Default user login name:</source>
        <translation>Login dell&apos;utente predefinito:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2049"/>
        <source>Default user password:</source>
        <translation>Password dell&apos;utente predefinito:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2062"/>
        <source>Confirm user password:</source>
        <translation>Conferma la password utente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2123"/>
        <source>username</source>
        <translation>nome utente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2139"/>
        <source>Autologin</source>
        <translation>Login automatico</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2152"/>
        <source>Show passwords</source>
        <translation>Mostra le password</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2165"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Le modifiche del desktop, fatte in modalità &quot;live&quot;, verranno trasferite sul sistema una volta installato</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2168"/>
        <source>Save live desktop changes</source>
        <translation>Salva modifiche del desktop &quot;live&quot;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2191"/>
        <source>Existing Home Directory</source>
        <translation>Home Directory Esistente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Cosa ne vorresti fare della vecchia directory ?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Re-use it for this installation</source>
        <translation>Riusa per questa installazione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2214"/>
        <source>Rename it and create a new directory</source>
        <translation>Rinomina e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2221"/>
        <source>Delete it and create a new directory</source>
        <translation>Cancella e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2266"/>
        <source>Tips</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2310"/>
        <source>Installation complete</source>
        <translation>Installazione completata</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2316"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Riavvia automaticamente il sistema quando l&apos;installer si chiude</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2335"/>
        <source>Reminders</source>
        <translation>Promemoria</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2376"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2383"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Installation in progress</source>
        <translation>Installazione in avanzamento</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2411"/>
        <source>Abort</source>
        <translation>Interrompi</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="397"/>
        <source>EFI System Partition</source>
        <translation>EFI System Partition</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="398"/>
        <source>swap space</source>
        <translation>Spazio swap</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="399"/>
        <source>swap space #%1</source>
        <translation>Spazio swap #%1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="512"/>
        <source>Preserve (%1)</source>
        <translation>Preserva (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="702"/>
        <location filename="../partman.cpp" line="760"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Aggiungi partizione</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="704"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Rimuovi partizione</translation>
    </message>
    <message>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation type="vanished">Compressione BTRFS (&amp;ZLIB)</translation>
    </message>
    <message>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation type="vanished">Compressione BTRFS (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="138"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="400"/>
        <source>format only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="512"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="555"/>
        <location filename="../partman.cpp" line="970"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="714"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="718"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="725"/>
        <location filename="../partman.cpp" line="857"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="731"/>
        <source>Set boot flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="738"/>
        <source>New subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="739"/>
        <source>Scan subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="763"/>
        <source>New &amp;layout</source>
        <translation>Nuovo &amp;configurazione</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="764"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Ripristina configurazione</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="765"/>
        <location filename="../partman.cpp" line="799"/>
        <source>&amp;Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="766"/>
        <source>&amp;Standard install</source>
        <translation>&amp;Installazione standard</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>&amp;Encrypted system</source>
        <translation>&amp;Sistema criptato</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="785"/>
        <source>Remove subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="802"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="804"/>
        <source>Compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="854"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="860"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="861"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="896"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="932"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1004"/>
        <source>Preserve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1050"/>
        <source>Invalid subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1058"/>
        <source>Invalid use for %1: %2</source>
        <translation>Uso non valido per %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1070"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 è già selezionato per: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1105"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Non è possibile preservare la /home all&apos;interno di root (/) se è montata anche una partizione /home separata.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1114"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Devi scegliere una partizione root.
La partizione root deve essere come minimo di %1 .</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1120"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Devi scegliere una partizione boot separata quando cripti root.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1132"/>
        <source>Delete the data on %1 except for /home</source>
        <translation>Cancellare i dati su %1 ad eccezione della /home</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1135"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Riusa (non riformatta) %1 come %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1141"/>
        <source>%1, to be used for %2</source>
        <translation>%1, da usare per %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1144"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Le partizioni seguenti, che hai selezionato, non sono partizioni Linux:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1152"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Sei sicuro di voler riformattare queste partizioni?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1160"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>%1 installer ora andrà a formattare e a distruggere i dati delle partizioni seguenti:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1168"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>%1 installer ora eseguirà le seguenti azioni:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1172"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Queste azioni non possono essere annullate. Sei sicuro di voler continuare?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1270"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>I dischi con le partizioni che hai selezionato per l&apos;installazione non rispondono:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1274"/>
        <source>Smartmon tool output:</source>
        <translation>Output dello strumento Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1275"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>I dischi con le partizioni che hai selezionato per l&apos;installazione hanno superato il test S.M.A.R.T. (smartctl), ma i test riferiscono che ci sono alte probabilità che nel prossimo futuro si possano presentare un numero di non conformità superiori alla media.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1280"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Se non sei sicuro, per favore esci dall&apos;Installer e avvia GSmartControl per avere più informazioni.

</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1282"/>
        <source>Do you want to abort the installation?</source>
        <translation>Vuoi annullare l&apos;installazione?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1287"/>
        <source>Do you want to continue?</source>
        <translation>Vuoi continuare?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1434"/>
        <source>Preparing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Clearing existing partition tables</source>
        <translation type="vanished">Pulizia della tavola delle partizioni esistenti</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1455"/>
        <source>Preparing required partitions</source>
        <translation> Preparazione delle partizioni richieste</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1523"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>Configurazione dei contenitori criptati LUKS</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1543"/>
        <source>Formatting: %1</source>
        <translation>Formattando: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1629"/>
        <source>Preparing subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1775"/>
        <source>Mounting: %1</source>
        <translation>Montando: %1</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Installer grafico personalizzabile per MX e antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Si installa automaticamente usando il file di configurazione (maggiori informazioni di seguito).
-- ATTENZIONE: opzione potenzialmente pericolosa, cancellerà automaticamente la/e partizione/i.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Sovraintende i test di integrità su partizioni e unità, facendoli visualizzare. - ATTENZIONE: questo può danneggiare i dati, usalo solo se non ti interessano i dati sull&apos;unità. </translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Carica un file di configurazione come specificato da &lt;config-file&gt;.
Di default viene usato /etc/minstall.conf.
Questa configurazione può essere usata con --auto per un&apos;installazione non assistita.
L&apos;installer crea (o sovrascrive) /mnt/antiX/etc/minstall.conf e ne salva una copia in /etc/minstalled.conf per uso futuro.
Il programma di installazione non scriverà alcuna password, ne impostazioni che non siano state settate, nel nuovo file di configurazione.
Si tenga conto che queste funzioni sono sperimentali. Le future versioni dell&apos;installer potrebbero rompere la compatibilità con i file di configurazione esistenti.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation>Usate sempre GPT quando fate l&apos;installazione su tutto il disco, indipendentemente dalla sua capacità.
Senza questa opzione, GPT sarà usato solo su dischi con almeno 2TB di capacità.
GPT è sempre usato nelle installazioni sull&apos;intero disco su sistemi UEFI indipendentemente dalla capacità, anche senza questa opzione.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation>Un&apos;altra modalità in fase test per l&apos;installer, le partizioni/unità verranno FORMATTATE, salterà la copia dei file. </translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Installa il sistema operativo, rimandando al primo riavvio le richieste per le opzioni specifiche dell&apos;utente.
Al riavvio, il programma di installazione verrà eseguito con --oobe in modo che l&apos;utente possa fornire questi dettagli.
Questo è utile per installazioni OEM, qualora si venda o si regali un computer con un sistema operativo precaricato all&apos;interno.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Opzione Esperienza immediata.
Si avvierà automaticamente se installato con l&apos;opzione --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Modalità in fase test per l&apos;interfaccia grafica, è possibile avanzare a diverse schermate senza installare attivamente.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Installare con rsync invece di cp (copy) su partizionamento personalizzato.
-- non formatta /root e non funziona con la crittografia.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Carica un file di configurazione come specificato da &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation>Questa operazione richiede l&apos;accesso come root.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Non si è riusciti a trovare il file di configurazione (%1).</translation>
    </message>
</context>
</TS>
