<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sl">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Izklop</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation>%1 Namestitev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Podpora za %1

%1 je podprt s strani ljudi, kot ste vi. Nekateri nudijo pomoč v podpornem forumu - %2 ali prevajajo pomoč v različne jezike, predlagajo, pišejo dokumentacijo ali pomagajo pri testiranju novih programov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Namestitveni program se ne more zagnati, ker je zaznal, da se že izvaja v ozadju.

Prosimo, zaprite ga, če je to mogoče, ali v terminalu zaženite &apos;pkill minstall&apos;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation>Ne morem dostopati do vira za namestitev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>Zagnan je 32bitni OS, ki je bil zagnan v 64 bitnem UEFI modusu. Sistem se ne bo mogel zagnati, če ob ponovnem zagonu ne izberete Legacy zagona ali nekaj podobnega.
Priporočamo, da zdaj končate in sistem ponovno zaženete z Legacy zagonom

Ali želite nadaljevati z namestitvijo?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 je neodvisna distribucija Linuxa, ki temelji na stabilnem Debianu.

%1 uporablja neketere komponente MEPIS Linuxa, ki so izdane pod prosto Apache licenco. Nekatere MEPIS komponente so bile prilagojene za %1.

Uživajte v sistemu %1!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation>Pretvarjam se, da nameščam %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="530"/>
        <source>Preparing to install %1</source>
        <translation>Pripavljanje na namestitev %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="542"/>
        <source>Failed to format required partitions.</source>
        <translation>Neuspelo formatiranje izbranih razdelkov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="553"/>
        <source>Paused for required operator input</source>
        <translation>Čakam na zahtevan vnos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="563"/>
        <source>Setting system configuration</source>
        <translation>Nastavitev konfiguracije sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="581"/>
        <source>Cleaning up</source>
        <translation>Čiščenje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="583"/>
        <source>Finished</source>
        <translation>Končano</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="644"/>
        <location filename="../minstall.cpp" line="2542"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="747"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>V konfiguracijski datoteki (%1) so bile najdene napačne nastavitve. Prosimo, preverite označena polja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="803"/>
        <source>Deleting old system</source>
        <translation>Brisanje starega sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="807"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Neuspešno brisanje starega %1 na destinaciji.
Vračam se na prvi korak.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="814"/>
        <source>Creating system directories</source>
        <translation>Ustvarjanje sistemskih direktorijev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>Fixing configuration</source>
        <translation>Popravljanje konfiguracije</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="866"/>
        <source>Copying new system</source>
        <translation>Kopiranje novega sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="906"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Napredek pri kopiranju ni znan. Ni statistike datotečnega sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="915"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Neuspešno zapisovanje na destinacijo %1.
Vračam se na prvi korak.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="958"/>
        <source>Updating initramfs</source>
        <translation>Posodabljam initramfs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="968"/>
        <source>Installing GRUB</source>
        <translation>Nameščam GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1036"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>Namesitev GRUB ni uspela. Lahko zaženete živ nosilec in uporabite GRUB reševalni meni, da bi popravili namestitev.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">Osveževanje NVRAM zagonske spremenljivke ni bilo uspešno. Sistem se morda ne bo zagnal, a ga je možno popraviti s pomočjo GRUB reševalne menija.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Uporabniško ime ne more vsebovati posebnih znakov ali presledkov.
Prosimo, izberite drugo ime pred nadaljevanjem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Oprostite, to ime je že v rabi.
Prosimo, izberite drugo ime.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1180"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>Niste podali gesla za korenski dostop. Želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1189"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Imenik /home za %1 že obstaja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1218"/>
        <source>Failed to set user account passwords.</source>
        <translation>Neuspela nastavitev gesla za uporabniški račun</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1235"/>
        <source>Failed to save old home directory.</source>
        <translation>Neuspešno shranjevanje starega /home imenika</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1240"/>
        <source>Failed to delete old home directory.</source>
        <translation>Neuspešno brisanje starega /home imenika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1258"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Ustvarjanje uporabnikovega imenika ni uspelo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1263"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Poimenovanje uporabnikovega imenika ni bilo uspešno.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1284"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Določitev lastništva za uporabnikov imenik ni bilo uspešno.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1330"/>
        <source>Please enter a computer name.</source>
        <translation>Vnesite ime računalnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1334"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Oprostite, ime vašega računalnika vsebuje nedovoljene znake.
Morali boste izbrati
drugo ime, preden lahko nadaljujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1340"/>
        <source>Please enter a domain name.</source>
        <translation>Prosiom vnesite ime domene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1344"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Oprostite, ime vašeračunalniške domene vsebuje nedovoljene znake.
Morali boste izbrati
drugo ime, preden lahko nadaljujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1351"/>
        <source>Please enter a workgroup.</source>
        <translation>Vnesite ime delovne skupine</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1594"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Ali naj formatiram in uporabim celoten disk (%1) za %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1598"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>OPOZORILO: Izbrani pogon ima zmogljivost vsaj 2TB in mora biti formatiran z uporabo GPT. Na nekaterih sistemih diski, ki so formatirani z GPT, ne morejo izvesti zagona.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1624"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Podatki v /home ne morejo biti ohranjeni, ker ni bilo mogoče pridobiti potrebnih podatkov.</translation>
    </message>
    <message>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="vanished">Če je razdelek, ki vsebuje /home, šifriran je nujno, da so označene pravilne opcije za &quot;Šifriranje&quot; in da je vnešeno pravilno geslo.</translation>
    </message>
    <message>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="vanished">Namestitveni program ne more šifrirati obstoječega /home imenika ali razdelka.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1680"/>
        <source>General Instructions</source>
        <translation>Splošna navodila</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1681"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>PRED NADALJEVANJEM ZAPRITE VSE OSTALE APLIKACIJE.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1682"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Prosimo, da na vsaki strani preberete navodila, naredite izbor in potem kliknete Naprej, ko ste pripravljeni za nadaljevanje. Pozvani boste k potrditvi izbire, preden se izvedejo kakšne destruktivne akcije.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>Limitations</source>
        <translation>Omejitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Pomnite, da je ta programska oprema na voljo TAKO KOT JE, brez kakršnekoli garancije. Zgolj vaša odgovornost je, da poskrbite za ustrezno varnostno kopiranje vaših podatkov, preden nadaljujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>Installation Options</source>
        <translation>Možnosti namestitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1691"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation>Namestitev potrtebuje okoli %1 prostora. Priporočeno je %2 ali več.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Če poganjate Mac OS ali Windows OS (od različice Vista naprej), boste morda morali pred namestitvijo uporabiti orodja teh sistemov za ustvarjanje razdelkov in zagonskega upravljalnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1693"/>
        <source>Using the root-home space slider</source>
        <translation>Raba drsnika za prostor na root-home razdelku</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation>Na večjih diskih je privzeta razdelitev na ločeni korenski (root) in domači (home) razdelek. Drsnik omogoča nadzor nad količino prostora za vsakega od teh razdelkov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1696"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Premaknite drsnik na desno, če želite povečasti prosgtor za korenski &lt;b&gt;root&lt;/b&gt;. Pfremaknite ga na levo, če želite povečati prostor za  domači &lt;/b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Premaknite drsnik popolnoma na desno, če želite imeti root in home na istem razdelku.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1698"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation>Če nameravate namestiti veliko ali velike programe, kot so grafični, zvočni ali paketi za urejanje videa, je priporočljivo imeti većji korenski &lt;b&gt;root&lt;/b&gt; razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1700"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation>Če delate z velikimi količinami podatkov ali če ta računalnik uporablja veliko število uproabnikov, je priporočljivo imeti večji domači &lt;b&gt;home&lt;/b&gt; razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Ločena domača (home) mapa izboljša zanesljivost nadgrajevanja operacijskega sistema. Poleg tega poenostavlja varnostno kopiranje in obnavljanje. Poleg tega je mogoče z določitvijo sistemskih datotek na točno določen del diska izboljšati zmogljivost delovanja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <location filename="../minstall.cpp" line="1767"/>
        <source>Encryption</source>
        <translation>Šifriranje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <location filename="../minstall.cpp" line="1768"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Šifriranje je možno preko LUKS. Zahtevano je geslo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1706"/>
        <location filename="../minstall.cpp" line="1769"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Potreben je ločen in nešifriran zagonski razdelek. Za dodatne nastavitve, vključno z izbiro šifrirnika, uporabite gumb &lt;b&gt;Urejanje naprednih nastavitev šifriranja&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Če se šifriranje uporablja skupaj z opcijo za samodejno namestitev, bo samodejno ustvarjen ločen zagonski razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1709"/>
        <source>Using a custom disk layout</source>
        <translation>Uporaba lastnega razporeda razdelkov</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1710"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1725"/>
        <source>Choose Partitions</source>
        <translation>Izberite razdelke</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1735"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Podprti so Linux datotečni sistemi ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs, priporočena je raba ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1736"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1739"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 potrebuje korenski /root razdelek. Izmenjevalni swap razdelek je opcijski, a je zelo priporočljiv. Če želite uporabljati funkcijo Hiberniraj na disku, ki jo ponuja %1, boste potrebovali swap razdelek, ki je večji od velikosti fizičnega pomnilnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Če izberete ločen /home razdelek, bo v prihodnje lažje nadgraditi vaš računalnik, vendar le v primeru, da ne gre za nadgrajevanje namestitve, ki nima ločenega /home razdelka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>Upgrading</source>
        <translation>Nadgrajujem</translation>
    </message>
    <message>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="vanished">Če ohranjate imenik /home, ki se nahaja na vašem korenskem razdelku, namestitveni program ne bo ponovno formatiral razdelka. Posledica je mnogo daljša namestitev, kot sicer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>Preferred Filesystem Type</source>
        <translation>Zaželjen datotečni sistem</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Za %1 lahko izberete formatiranje kot ext2, ext3, ext4, f2fs, jfs, xfs, btrfs ali reiser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Dodatne možnosti za stiskanje podatkov so na voljo za pogone, ki uproabljajo btrfs, vendar je stopnja kompresije manjša. Zlib je počasnejši, a ima večjo stopnjo stiskanja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>Bad Blocks</source>
        <translation>Napake na disku</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Če kot vrsto formata izberete ext2, ext3 ali ext4, imate možnost preverjanja in popravljanja napak na disku, ki so posledica okvar blokov. Preverjanje napak na disku zahteva veliko časa. zato boste morda raje preskočili ta korak, razen če ne sumite, da so na vašem disku napake.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1763"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1772"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1775"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1776"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>Advanced Encryption Settings</source>
        <translation>Napredne nastavitve šifriranja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Ta stran omogoča spreminjanje finih nastavitev za particije, ki so šifrirane z LUKS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1784"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>V večini primerov privzete nastavitve predstavljajo praktični kompromis med varnostjo in hitrostjo, ki je primeren za občutljive programe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Ta tekst pokriva osnove parametrov, ki se uporabljajo z LUKS, vendar ne predstavlja poglobljenega vodiča za kriptografijo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1787"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Spreminjanje katerih koli od teh nastavitev brez vednosti o kriptografiji, lahko ima za posledico, da bo šifriranje šibko.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Urejanje nekega polja pogosto vpliva na možnosti, ki so na voljo pod njim. Te se lahko samodejno nastavijo na priporočene vrednosti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>S spreminjanjem priporočenih vrednosti je sicer mogoče doseči večjo varnost ali zmogljivost, vendar to počnete na lastno odgovornost.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Za primerjanje zmogljivosti delovanja najbolj pogostih kombinacij razpršitev, šifriranj in načinov veriženja lahko uporabite gumb &lt;b&gt;Meritev hitrosti&lt;/b&gt; (ta zažene &lt;i&gt; cryptsetup benchmark&lt;/i&gt; v svojem terminalu).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Upoštevajte, da &lt;i&gt;cryptsetup benchmark&lt;/i&gt; ne pokriva vseh kombinacij ali možnih izbir, temveč le najbolj pogosto uporabljene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1794"/>
        <source>Cipher</source>
        <translation>Šifriranje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1794"/>
        <source>A variety of ciphers are available.</source>
        <translation>Na voljo so različne šifriranja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>je bil eden od petih AES finalistov. Smatra se, da ima večjo stopnjo varnosti kot Rijndael in ostali AES finalisti. Deluje bolj na nekaterih 64-bitnih procesorijh.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(tudi poznan kot &lt;i&gt;Rijndael&lt;/i&gt;) je zelo znan šifrirnik in mnogo modernih procesorjev vsebuje instrukcije, ki so namenjene posebej za AES. Čeprav je bil Rijndael izbran namesto Serpenta zaradi svoje zmogljivosti, trenutno ni pričakovati praktičnih napadov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>je naslednik Blowfisha. Postal je eden od petih AES finalistov, kljub temu pa ni bil izbran kot standard.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) je bil kandidat v AES tekmovanju, vendar se ni uvrstil v finale.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>je 64 bitno šifriranje, ki ga je ustvaril Bruce Schneier. Ni primeren za občutljive programe, ker podpira le CBC in ECB načina. Blowfish podpira ključe velikosti med 32 in 448 bitov, ki so večkratniki števila 8.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>Chain mode</source>
        <translation>Verižni način</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Če so vsi bloki šifrirani z istim ključem, se lahko ustvari vzorec, ki omogoča prepoznavanje teksta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1802"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>Spremenjena kodirna knjiga, ki temelji na XEX, s šifrantom Stealing) je moderen verižni način, ki je boljši od CBC in EBC. Je privzeti (in priporočeni) način veriženja. Uporaba ESSIV preko Plain64 bo povzročila upad zmogljivosti, ob nejasnih varnostnih pridobitvah.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Cipher Block Chaining) je bolj preprost od XTS, vendar je ranljiv na oddaljeni oracle napad (kar je prevzel od ESSIV), zato ni priporočen za občutljivo rabo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic CodeBook) je manj varen kot CBC in naj ne bi bil uporaben za občutljive stvari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>IV generator</source>
        <translation>IV generator</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>To določa način generiranja &lt;b&gt;i&lt;/b&gt;nicializacijskega &lt;b&gt;v&lt;/b&gt;ektorja za XTS in CBC. &lt;b&gt;ESSIV&lt;/b&gt; potrebuje razpršitveno funkcijo in zaradi tega se ob njegovi izbiri pojavi še en izbirni seznam. Katere razpršitve so na voljo, je odvisno od izbranega šifrirnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>ECB način ne upirablja IV, zato bodo, kadar je izbran za način veriženja, vsa ta polja onemogočena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Key size</source>
        <translation>Velikost ključa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Določi velikost ključa v bitih. Velikosti ključa, ki so na voljo, so omejeni z načinom šifriranja in veriženja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>XTS šifrirni verižni način razdeli ključ na pol (na primer AES-256 in XTS načina rabita 512-bitni ključ).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>LUKS key hash</source>
        <translation>LUKS razpršilni ključ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>Razpršilnik uporabljen za PBKDF2 in za AF razdelilnik</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 in RIPMED-160 nista več priporočena za občutljive aplikacije, ker je bilo ugotovljeno, da sta opkvarjena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>Kernel RNG</source>
        <translation>Jedro RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Določi kateri generator naključnih števil jedra bo uporabljen za ustvarjanje glavnega ključa od ključa pogona (to je dolgoročen ključ)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Na voljo sta dve opciji: /dev/&lt;b&gt;random&lt;/b&gt;, ki blokira tolko časa, da ni dovolj entropije (to lahko traja dolgo časa, ko je stopnja entropije majhna) in /dev/&lt;b&gt;urandom&lt;/b&gt;, ki ne bo blokirala, pa četudi ni dovolj entropije (posledica so lahko šibkejši ključi).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF zaokrožen čas&lt;/b&gt;&lt;br/&gt;Čas (v milisekundah), ki se porabi za procesiranje PBKDF2 gesla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Vrednost 0 izbere privzete nastavitve compiled-in (zaženi &lt;i&gt;cryptsetup --help za podrobnosti).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1820"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Če imate počasen računalnik, boste nemara žeželi povečati to vrednost za več varnosti, a na račun časa za odklepanje, potem ko se vnese geslo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1825"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Izberite način zaganjana&lt;/b&gt;&lt;br/&gt;%1 uporablja zaganjalnik GRUB za zagon boot %1 in MS-Windows. &lt;p&gt;Privzeto se namesti GRUB2 v Master Boot Record ali ESP (EFI sistemska particija za 64-bitni sisteme z UEFI zagonom) vašega zagonskega diska, ki nadomesti zaganjalnik, ki ste ga uporabljali do tedaj. To je normalno.&lt;/p&gt;&lt;p&gt;Če želite namestiti GRUB2 v koren oz. root, bo GRUB2 nameščen na začetku korenske root particije. Ta možnost je pimerna le za strokovnjake.&lt;/p&gt;&lt;p&gt;Če odznačite Namesti GRUB, se GRUB ne bo namestil. Ta možnost je primerna le za strokovnjake.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Omogočene pogoste storitve&lt;/b&gt;&lt;br/&gt; Izberite poljubno od teh storitev, ki bi jih lahko potrebovali s svojo konfiguracijo sistema in storitve se bodo samodejno zagnale, ko zaženete %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1844"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identiteta računalnika&lt;/b&gt;&lt;br/&gt;Ime računalnika je unikatno ime, ki identificira vaš računalnik, kadar se nahaja v mreži. Domena računalnika se uporablja le, kadar to zahteva vaš ponudnik interneta ali vaše lokalno omrežje. &lt;/p&gt;&lt;p&gt;Ime računalnika ali domene lahko vsebuje le alfanumerične znake, pike in vezaje. Ne more vsebovati presledkov ali se začeti oziroma končati z vezajem. &lt;/p&gt;&lt;p&gt;Če želite deliti katerega od direktorijev ali tiskalnikov za rabo z lokalnim računalnikom, ki poganja MS-Windows ali Mac OSX, je potrebno aktivirati SaMBa strežnik. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1857"/>
        <source>Localization Defaults</source>
        <translation>Privzete lokalne nastavitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>Configure Clock</source>
        <translation>Nastavitve časa:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1860"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1862"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1864"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1865"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1872"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>Passwords</source>
        <translation>Gesla</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1877"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1879"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1882"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Old Home Directory</source>
        <translation>Stari /home imenik</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Za izbrano uporabniško ime že obstaja /home imenik. Ta zaslon vam omogoča, da določite, kaj se zgodi s tem imenikom.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>Re-use it for this installation</source>
        <translation>Ponovno uporabi za to namestitev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Za ta uporabniški račun bo uporabljen stari imenik /home. To je dobra izbira za nadgradnjo, saj bodo datoteke in nastavitve ostale nedotaknjene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Rename it and create a new directory</source>
        <translation>Preimenuj in ustvari nov imenik</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1898"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Za uporabnika bo ustvarjen nov /home imenik, stari pa bo preimenovan. Vaše datoteke in nastavitve v novi namestitvi ne bodo takoj vidne, a se lahko do njih dostopa v preimenovanem imeniku.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1900"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Star imenik bo imel na koncu številko, ki je odvisna od tega, kolikokrat poprej je bil imenik že preimenovan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1901"/>
        <source>Delete it and create a new directory</source>
        <translation>Izbriši in ustvari nov imenik</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1902"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Stari imenik /home bo izbrisan in ustvarjena bo povsem nov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1903"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1904"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Vse datoteke in nastavitve bodo za stalno izbrisane, če je izbrana ta možnost. Vaše možnosti za njihovo obnovitev bodo majhne.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1920"/>
        <source>Installation in Progress</source>
        <translation>Namestitev poteka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1921"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 se namešča. Sveža namestitev bo vzela med 3-20 minut, odvisno od hitrosti sistema in velikosti razdelkov, ki jih ponovno formatirate.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1923"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Če pritisnete tipko Prekini, se bo namestitev zaustavila, takoj ko bo to mogoče.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1925"/>
        <source>Change settings while you wait</source>
        <translation>Med nameščanjem spremenite nastavitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1926"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Medtem, ko se %1 namešča, lahko kliknete na tipki &lt;b&gt;Naprej&lt;/b&gt; ali &lt;b&gt;Nazaj&lt;/b&gt; in vnesete druge informacije za namestitev.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1928"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Te korake opravite v svojem ritmu. Namestitveni program vas bo počakal, če je to potrebno.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1937"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Čestitke!&lt;/b&gt;&lt;br/&gt;Uspešno ste zaključili namestitev za %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Iskanje programov&lt;/b&gt;&lt;br/&gt;Skupaj z %1 je nameščenih na stotine odličnih programov. Najbolje je, da jih spoznavate tako, da jih poiščete v menuju in preizkusite. Mnogo aplikacij je bilo razvitih posebej za %1 projekt. Te so prikazane v glavnem menuju.&lt;p&gt;Poleg tega %1 vsebuje mnogo standardnih Linux programov, ki jih je mogoče zagnati le iz terminala in zato niso prikazani v menuju.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1946"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Naj vam bo %1 v užitek&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1947"/>
        <location filename="../minstall.cpp" line="2362"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Podpora za %1&lt;/b&gt;&lt;br/&gt;%1 je podprt s strani ljudi, kakršnih ste vi. Nekateri pomagajo drugim preko podpornega foruma -%2 - drugi s prevajanjem pomoči v druge jezike, podajanjem predlgovo, pisanjem dokumentacije ali preizkusanjem novih programov.&lt;/p&gt; </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Finish</source>
        <translation>Zaključi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1982"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1984"/>
        <source>Next</source>
        <translation>Naslednji</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2019"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2022"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2026"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2044"/>
        <source>Loading...</source>
        <translation>Nalaganje...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2086"/>
        <location filename="../minstall.cpp" line="2477"/>
        <source>Root</source>
        <translation>Koren</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2088"/>
        <location filename="../minstall.cpp" line="2485"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2287"/>
        <source>Confirmation</source>
        <translation>Potrditev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2287"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Namestitev in konfiguracija nista končani.
Ali bi jo res radi zaustavili?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2348"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kam po pomoč?&lt;/b&gt;&lt;br/&gt;Osnovne inoformacije o sistemu %1 se nahajajo na %2. &lt;/p&gt;&lt;p&gt;Prostovoljci, ki lahko nudijo pomoč se najdejo na %3 forumu, %4.&lt;/p&gt;&lt;p&gt;Če iščete pomoč, opišite svojo težavo in svoj računalnik čim bolj podrobno. Ponavadi stavki tipa &apos;ne deluje&apos; niso dovolj.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2356"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Popravilo namestitve&lt;/b&gt;&lt;br/&gt;Če %1 na vašem disku preneha delovati, je včasih mogoče težavo odpraviti z zagonom iz živega DVD ali USB pogona in zagonom katerega od vključenih orodji, ki jih %1 vsebuje ali z uporabo katerega od standardnih Linux orodji za popravljanje sistema.&lt;/p&gt;&lt;p&gt;Živi DVD ali SUSB lahko uporabite tudi za reševanje podatkov iz sistemov z MS-Windows!&lt;/p&gt; </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2370"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%1 bo samodejno poskusil&lt;/b&gt;&lt;br/&gt;nastaviti zvočni mikser, vendar je včasih potrebno, da uporabnik nastavi glasnost in vklopi kanale na miskerju, da bi se zvok slišal.&lt;/p&gt; &lt;p&gt;Bljižnica do mikserja se nahaja v menuju. Kliknite nanjo, da bi ga odprli. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2378"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Poskrbite, da bo vaš %1 ažuriran&lt;/b&gt;&lt;br/&gt;Za več informacij in posodobitve obiščite&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2383"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Posebna zahvala&lt;/b&gt;&lt;br/&gt;Hvala vsem, ki se odločili podpreti %1 s svojim časom, denarjem, predlogi, delom, pohvalami, idejami, promoviranjem in/ali spodbujanjem.&lt;/p&gt;&lt;p&gt;Brez vas %1 ne bi obstajal.&lt;/p&gt;&lt;p&gt;%2 ravojna skupina&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2435"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2435"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2482"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2530"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2541"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2671"/>
        <source>System boot disk:</source>
        <translation>Zagonski disk sistema:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2685"/>
        <location filename="../minstall.cpp" line="2694"/>
        <source>Partition to use:</source>
        <translation>Razdelek za uporabo:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>Naslednji</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Zbiram podatke, prosimo počakajte.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Pogoji uporabe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Nastavitve tipkovnice&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Različica:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation>Spremeni nastavitve tipkovnice</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Razpored:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Izberi vrsto namestitve</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="403"/>
        <location filename="../meinstall.ui" line="784"/>
        <source>Confirm password:</source>
        <translation>Potrdite geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <location filename="../meinstall.ui" line="801"/>
        <source>Encryption password:</source>
        <translation>Šifrirno geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="426"/>
        <location filename="../meinstall.ui" line="824"/>
        <location filename="../meinstall.ui" line="856"/>
        <source>Advanced encryption settings</source>
        <translation>Napredne nastavitve šifriranja</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="442"/>
        <source>Use disk:</source>
        <translation>Uporabi disk:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="468"/>
        <location filename="../meinstall.ui" line="705"/>
        <source>Encrypt</source>
        <translation>Šifriranje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="525"/>
        <source>Root</source>
        <translation>Koren</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="560"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="624"/>
        <source>Choose partitions</source>
        <translation>Izberite razdelke</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Device</source>
        <translation>Naprava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="695"/>
        <source>Label</source>
        <translation>Vrsta</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="700"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="710"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="673"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="642"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="649"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="734"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="745"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="768"/>
        <source>Encryption options</source>
        <translation>Možnosti šifriranja</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1138"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1143"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1148"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1153"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1158"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="884"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1178"/>
        <source> mS</source>
        <translation> mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="868"/>
        <source>LUKS key hash:</source>
        <translation>LUKS razpršitveni ključ:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="998"/>
        <source>Key size:</source>
        <translation>Velikost ključa:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1108"/>
        <source>KDF round time:</source>
        <translation>KDF zaokrožen čas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1095"/>
        <source>Cipher:</source>
        <translation>Šifrirnik:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="938"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="943"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="948"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="953"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="958"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="985"/>
        <source>Benchmark...</source>
        <translation>Merjenje hitrosti...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1054"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1064"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1069"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1074"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1011"/>
        <source>IV generator:</source>
        <translation>IV generator:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1037"/>
        <source>Chain mode:</source>
        <translation>Način veriženja:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="904"/>
        <source>Kernel RNG:</source>
        <translation>RNG (generator naključnih števil) jedra:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="912"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="917"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1082"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1213"/>
        <source>Select Boot Method</source>
        <translation>Določi zagonski način</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>EFI System Partition</source>
        <translation>EFI sistemski razdelek</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1253"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1272"/>
        <source>Partition Boot Record</source>
        <translation>Partition Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation>Lokacija za namestitev:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1301"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Namesti GRUB za Linux in Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1304"/>
        <location filename="../meinstall.ui" line="2414"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1320"/>
        <source>System boot disk:</source>
        <translation>Zagonski disk sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1342"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1348"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1351"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1422"/>
        <source>Common Services to Enable</source>
        <translation>Omogoči pogoste storitve:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1441"/>
        <source>Service</source>
        <translation>Storitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1446"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1479"/>
        <source>Computer Network Names</source>
        <translation>Imena računalnikov v mreži</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1506"/>
        <source>Workgroup</source>
        <translation>Delovna skupina</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Workgroup:</source>
        <translation>Delovna skupina:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1532"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa strežnik za MS Networking</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1548"/>
        <source>example.dom</source>
        <translation>primer.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1561"/>
        <source>Computer domain:</source>
        <translation>Domena računalnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1587"/>
        <source>Computer name:</source>
        <translation>Ime računalnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1648"/>
        <source>Configure Clock</source>
        <translation>Nastavitve časa:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1689"/>
        <source>Format:</source>
        <translation>Format:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Timezone:</source>
        <translation>Časovni pas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1762"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1794"/>
        <source>Localization Defaults</source>
        <translation>Privzete lokalne nastavitve</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1834"/>
        <source>Locale:</source>
        <translation>Lokalizacija:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1856"/>
        <source>Service Settings (advanced)</source>
        <translation>Nastavitve storitev (napredno)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1874"/>
        <source>Adjust which services should run at startup</source>
        <translation>Določi, katere storitve naj se zaženejo ob zagonu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1877"/>
        <source>View</source>
        <translation>Ogled</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Root (administrator) Account</source>
        <translation>Korenski (administratorski) račun</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1947"/>
        <source>Root password:</source>
        <translation>Korensko geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>Confirm root password:</source>
        <translation>Potrdite korensko geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2021"/>
        <source>Default User Account</source>
        <translation>Privzeti uporabniški račun</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2033"/>
        <source>Default user login name:</source>
        <translation>Ime privzetega uporabnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2049"/>
        <source>Default user password:</source>
        <translation>Geslo privzetega uporabnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2062"/>
        <source>Confirm user password:</source>
        <translation>Potrdi geslo uporabnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2123"/>
        <source>username</source>
        <translation>uporabniško ime</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2139"/>
        <source>Autologin</source>
        <translation>Samodejna prijava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2152"/>
        <source>Show passwords</source>
        <translation>Pokaži gesla</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2165"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Modifikacije namizja, ki so bile opravljene v živem okolju, bodo prenešene na nameščen OS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2168"/>
        <source>Save live desktop changes</source>
        <translation>Shrani spremembe iz živega namizja</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2191"/>
        <source>Existing Home Directory</source>
        <translation>Obstoječi /home imenik</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Kaj bi radi storili s starim imenikom?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Re-use it for this installation</source>
        <translation>Ponovno uporabi za to namestitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2214"/>
        <source>Rename it and create a new directory</source>
        <translation>Preimenuj in ustvari nov imenik</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2221"/>
        <source>Delete it and create a new directory</source>
        <translation>Izbriši in ustvari nov imenik</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2266"/>
        <source>Tips</source>
        <translation>Namigi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2310"/>
        <source>Installation complete</source>
        <translation>Namestitev je dokončana</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2316"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Samodejni ponovni zagon po tem, ko se namestitveni program zapre</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2335"/>
        <source>Reminders</source>
        <translation>Opomniki</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2376"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2383"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Installation in progress</source>
        <translation>Namestitev poteka</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2411"/>
        <source>Abort</source>
        <translation>Prekini</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="397"/>
        <source>EFI System Partition</source>
        <translation>EFI sistemski razdelek</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="398"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="399"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="508"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="694"/>
        <location filename="../partman.cpp" line="745"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="696"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="138"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="400"/>
        <source>format only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="508"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="551"/>
        <location filename="../partman.cpp" line="955"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="705"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="709"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="716"/>
        <location filename="../partman.cpp" line="842"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="725"/>
        <source>New subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="726"/>
        <source>Scan subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="748"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="749"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="750"/>
        <location filename="../partman.cpp" line="784"/>
        <source>&amp;Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="751"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="752"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="770"/>
        <source>Remove subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="787"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="789"/>
        <source>Compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="839"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="845"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="846"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="881"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="917"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="989"/>
        <source>Preserve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1036"/>
        <source>Invalid subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1044"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1056"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1095"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1102"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Izbrati morate korenski oz. root razdelek.
Korenski razdelek mora imeti vsaj %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1108"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Za šifriranje korena oz. root, je potrebno ustvariti ločen zagonski razdelek.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1120"/>
        <source>Delete the data on %1 except for /home</source>
        <translation>Izbriši podatke na %1, razen za /home</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1123"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1129"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1132"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Naslednji izbrani razdelki niso Linux razdelki:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1140"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Ste prepričani, da želite ponovno formatirati te razdelke?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1148"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>Namestitveni program %1 bo sedaj formatiral in uničil podatke na naslednjih razdelkih:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1156"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>Program za namestitev %1 bo sedaj izvedel naslednja dejanja:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1160"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Teh dejanj ni mogoče razveljaviti. Ali bi radi nadaljevali?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1258"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Diski z razdelki, ki ste jih izbrali, odpovedujejo:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1262"/>
        <source>Smartmon tool output:</source>
        <translation>Izpis za Smarton orodje:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1263"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Diski z izbranimi razdelki za namestitev so sicer prestali SMART monitor test (smartctl), a je test pokazal, da bodo v bližnji prihodnosti imeli večjo možnost za napake.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1268"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Če niste prepričani, zaprite namestitveni program in zaženite GSmartControl za več informacij.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1270"/>
        <source>Do you want to abort the installation?</source>
        <translation>Želite prekiniti namestitev?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1275"/>
        <source>Do you want to continue?</source>
        <translation>Želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1444"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1452"/>
        <source>Preparing required partitions</source>
        <translation>Pripravljanje zahtevanih razdelkov</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1507"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>Ustvarjanje šifriranih zabojnikov LUKS</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1527"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1608"/>
        <source>Preparing subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1753"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Kongiracijska datoteka (%1) ni bila najdena.</translation>
    </message>
</context>
</TS>
