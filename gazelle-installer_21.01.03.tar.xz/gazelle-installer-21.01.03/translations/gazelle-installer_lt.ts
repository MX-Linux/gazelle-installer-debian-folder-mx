<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="lt">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="94"/>
        <source>%1 Installer</source>
        <translation>%1 diegimo programa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="54"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="111"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Palaikykite %1

%1 yra palaikoma tokių žmonių kaip jūs. Vieni padeda kitiems palaikymo forume - %2, arba verčia žinyno failus į skirtingas kalbas, arba pateikia pasiūlymus, rašo dokumentaciją, arba padeda išbandyti naują programinę įrangą.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="188"/>
        <source>Cannot access source medium.
Activating pretend installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="326"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 yra nepriklausoma Linux distribucija, kuri yra pagrįsta Debian Stable

%1 naudoja kai kuriuos komponentus iš MEPIS Linux, kuri yra išleista pagal Apache nemokamą licenciją. Kai kurie MEPIS komponentai buvo modifikuoti naudojimui %1.

Mėgaukitės, naudodami %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="439"/>
        <source>Pretending to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="576"/>
        <source>target drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="595"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Diskai su skaidiniais, kuriuos pasirinkote diegimui, patiria nesėkmę:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="599"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="600"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="605"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="607"/>
        <source>Do you want to abort the installation?</source>
        <translation>Ar norite nutraukti diegimą?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="612"/>
        <source>Do you want to continue?</source>
        <translation>Ar norite tęsti?</translation>
    </message>
    <message>
        <source>The password needs to be at least
%1 characters long. Please select
a longer password before proceeding.</source>
        <translation type="vanished">Slaptažodis turi būti bent
%1 simbolių ilgio. Prieš tęsdami,
pasirinkite ilgesnį slaptažodį.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="631"/>
        <source>Preparing to install %1</source>
        <translation>Ruošiamasi įdiegti %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="643"/>
        <source>Failed to format required partitions.</source>
        <translation>Nepavyko formatuoti reikiamų skaidinių.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="654"/>
        <source>Paused for required operator input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="664"/>
        <source>Setting system configuration</source>
        <translation>Nustatoma sistemos konfigūracija</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="682"/>
        <source>Cleaning up</source>
        <translation>Išvaloma</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="852"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="891"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>Nustatomi LUKS šifruoti konteineriai</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="922"/>
        <source>Formatting swap partition</source>
        <translation>Formatuojamas sukeitimų skaidinys</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="931"/>
        <source>Formatting the / (root) partition</source>
        <translation>Formatuojamas / (šaknies) skaidinys</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="941"/>
        <source>Formatting boot partition</source>
        <translation>Formatuojamas paleidimo skaidinys</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="947"/>
        <source>Formatting EFI System Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="954"/>
        <source>Formatting the /home partition</source>
        <translation>Formatuojamas /home skaidinys</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="964"/>
        <source>Mounting the /home partition</source>
        <translation>Prijungiamas /home skaidinys</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1062"/>
        <source>Sorry, could not create %1 LUKS partition</source>
        <translation>Atleiskite, nepavyko sukurti %1 LUKS skaidinio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1079"/>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation>Atleiskite, nepavyko sukurti %1 LUKS konteinerio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1094"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1108"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Privalote pasirinkti šaknies skaidinį.
Šaknies skaidinys privalo būti bent %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1134"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1144"/>
        <source>Reuse (no reformat) %1 as the /home partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>Configure %1 as swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1180"/>
        <source>The partition you selected for /boot is larger than expected.</source>
        <translation>Skaidinys, kurį pasirinkote kaip skirtą /boot, yra didesnis nei tikėtasi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1185"/>
        <source>%1 for the %2 partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Šie jūsų pasirinkti skaidiniai nėra Linux skaidiniai:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1196"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Ar tikrai norite iš naujo formatuoti šiuos skaidinius?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1206"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>%1 diegimo programa netrukus formatuos ir sunaikins duomenis šiuose skaidiniuose:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1214"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>%1 diegimo programa dabar atliks šiuos veiksmus:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1218"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Šių veiksmų neįmanoma bus atšaukti. Ar norite tęsti?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1414"/>
        <source>Creating required partitions</source>
        <translation>Kuriami reikalingi skaidiniai</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1420"/>
        <source>Preparing required partitions</source>
        <translation>Ruošiami reikalingi skaidiniai</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1490"/>
        <source>Mounting the / (root) partition</source>
        <translation>Prijungiamas / (šaknies) skaidinys</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1493"/>
        <source>Deleting old system</source>
        <translation>Ištrinama senoji sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1497"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1504"/>
        <source>Creating system directories</source>
        <translation>Kuriami sistemos katalogai</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1524"/>
        <source>Fixing configuration</source>
        <translation>Pataisoma konfigūracija</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1653"/>
        <source>Copying new system</source>
        <translation>Kopijuojama naujoji sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1695"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Kopijavimo eiga nežinoma. Nėra failų sistemos statistikos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>Installing GRUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a user name.</source>
        <translation type="vanished">Įveskite naudotojo vardą.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1936"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1947"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter the user password.</source>
        <translation type="vanished">Įveskite naudotojo slaptažodį.</translation>
    </message>
    <message>
        <source>The user password entries do not match.
Please try again.</source>
        <translation type="vanished">Naudotojo slaptažodžio įrašai nesutampa.
Bandykite dar kartą.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1957"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1966"/>
        <source>The home directory for %1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1997"/>
        <source>Failed to set user account passwords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2017"/>
        <source>Failed to save old home directory.</source>
        <translation>Nepavyko įrašyti senojo namų katalogo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2024"/>
        <source>Failed to delete old home directory.</source>
        <translation>Nepavyko ištrinti senojo namų katalogo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2044"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Atleiskite, nepavyko sukurti naudotojo katalogą.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2052"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Atleiskite, nepavyko suteikti pavadinimą naudotojo katalogui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2073"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Atleiskite, nepavyko nustatyti naudotojo katalogo nuosavybės teisių.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2111"/>
        <source>Please enter a computer name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2115"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2121"/>
        <source>Please enter a domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2125"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2132"/>
        <source>Please enter a workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2349"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Galima formatuoti ir naudoti visą diską (%1), skirtą %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2353"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2373"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2374"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2375"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation>Diegimo programa negali šifruoti esamo /home katalogo ar skaidinio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2431"/>
        <source>General Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2432"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2433"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2435"/>
        <source>Installation requires about %1 of space. %2 or more is preferred. You can use the entire disk or you can put the installation on existing partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2437"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2438"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2439"/>
        <source>Autoinstall will place home on the root partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2440"/>
        <location filename="../minstall.cpp" line="2474"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2441"/>
        <location filename="../minstall.cpp" line="2475"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2442"/>
        <location filename="../minstall.cpp" line="2476"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2444"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2456"/>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2457"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2459"/>
        <source>Choose Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2460"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2462"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2463"/>
        <source>Upgrading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2464"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and check the preference to preserve data in /home.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2465"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2467"/>
        <source>Preferred Filesystem Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2468"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2469"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2471"/>
        <source>Bad Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2472"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2481"/>
        <source>Advanced Encryption Settings</source>
        <translation>Išplėstiniai šifravimo nustatymai</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2481"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Šis puslapis leidžia derinti LUKS šifruotus skaidinius.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2482"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2484"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2485"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2486"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2487"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2489"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2490"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2492"/>
        <source>Cipher</source>
        <translation>Šifras</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2492"/>
        <source>A variety of ciphers are available.</source>
        <translation>Yra prieinami įvairūs šifrai.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2493"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2494"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2495"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2496"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2497"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2499"/>
        <source>Chain mode</source>
        <translation>Grandinės veiksena</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2499"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2500"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2501"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2502"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2504"/>
        <source>IV generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2504"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2505"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2507"/>
        <source>Key size</source>
        <translation>Rakto dydis</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2507"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Nustato rakto dydį, bitais. Prieinami rakto dydžiai yra apriboti šifru ir grandinės veiksena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2508"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2510"/>
        <source>LUKS key hash</source>
        <translation>LUKS rakto maiša</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2510"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2511"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2513"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2513"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2514"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2516"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2517"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2518"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2523"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2538"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2542"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2555"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2556"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2557"/>
        <source>Configure Clock</source>
        <translation type="unfinished">Konfigūruoti laikrodį</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2558"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2560"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2562"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2563"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2569"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2570"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2574"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2575"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2577"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2578"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2580"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2589"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2590"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2592"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2593"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2595"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2596"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2598"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2599"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2600"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2601"/>
        <source>Warning</source>
        <translation>Įspėjimas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2602"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2618"/>
        <source>Installation in Progress</source>
        <translation>Vyksta diegimas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2619"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2621"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2623"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2624"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2626"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2635"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2645"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Mėgaukitės, naudodami %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2646"/>
        <location filename="../minstall.cpp" line="3098"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2677"/>
        <source>Finish</source>
        <translation>Užbaigti</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2681"/>
        <source>OK</source>
        <translation>Gerai</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2683"/>
        <source>Next</source>
        <translation>Kitas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2718"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2721"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2725"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2742"/>
        <source>Loading...</source>
        <translation>Įkeliama...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2789"/>
        <source>Select target root partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3018"/>
        <source>Confirmation</source>
        <translation>Patvirtinimas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3018"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Įdiegimas ir konfigūravimas nėra užbaigti.
Ar tikrai, norite sustabdyti dabar?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3084"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3092"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3106"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3114"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3119"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ypatingos padėkos&lt;/b&gt;&lt;br/&gt;Dėkojame visiems, kas nusprendė palaikyti %1 savo laiku, pinigais, pasiūlymais, darbu, pagyrimais, idėjomis, reklama ir/arba padrąsinimu.&lt;/p&gt;&lt;p&gt;Be jūsų nebūtų jokios %1.&lt;/p&gt;&lt;p&gt;%2 plėtojimo komanda&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3358"/>
        <source>System boot disk:</source>
        <translation>Sistemos paleidimo diskas:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3372"/>
        <location filename="../minstall.cpp" line="3381"/>
        <source>Partition to use:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="94"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="39"/>
        <source>Help</source>
        <translation>Žinynas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="147"/>
        <source>Next</source>
        <translation>Kitas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="154"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2670"/>
        <source>Back</source>
        <translation>Atgal</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2677"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2690"/>
        <source>Installation in progress</source>
        <translation>Vyksta diegimas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2705"/>
        <source>Abort</source>
        <translation>Nutraukti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1652"/>
        <location filename="../meinstall.ui" line="2708"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="96"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="136"/>
        <source>Close</source>
        <translation>Užverti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="195"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="230"/>
        <source>Terms of Use</source>
        <translation>Naudojimo sąlygos</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="257"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Klaviatūros nustatymai&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="264"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modelis:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="271"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variantas:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="288"/>
        <source>Change Keyboard Settings</source>
        <translation>Keisti klaviatūros nustatymus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="295"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Išdėstymas:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="339"/>
        <source>Rearrange disk partitions (optional)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="366"/>
        <source>Modify partitions:</source>
        <translation>Modifikuoti skaidinius:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="382"/>
        <source>Run partition tool...</source>
        <translation>Paleisti skaidymo įrankį...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="398"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="616"/>
        <source>Auto-install using entire disk </source>
        <translation>Automatiškai įdiegti, naudojant visą diską </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="434"/>
        <location filename="../meinstall.ui" line="1155"/>
        <source>Encryption password:</source>
        <translation>Šifravimo slaptažodis:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="521"/>
        <source>MB </source>
        <translation>MB </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="531"/>
        <location filename="../meinstall.ui" line="1138"/>
        <source>Confirm password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="560"/>
        <source>Leave free space up to:</source>
        <translation>Palikti laisvą vietą iki:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="483"/>
        <source>Custom install on existing partitions</source>
        <translation>Tinkintas įdiegimas esamuose skaidiniuose</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="579"/>
        <location filename="../meinstall.ui" line="1178"/>
        <location filename="../meinstall.ui" line="1223"/>
        <source>Advanced encryption settings</source>
        <translation>Išplėstiniai šifravimo nustatymai</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="420"/>
        <location filename="../meinstall.ui" line="1081"/>
        <source>Encrypt</source>
        <translation>Šifruoti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="460"/>
        <source>Use disk:</source>
        <translation>Naudoti diską:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="668"/>
        <source>Preferences</source>
        <translation>Nuostatos</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Preserve data in /home (if upgrading)</source>
        <translation>Išsaugoti duomenis /home kataloge (jeigu naujinama)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="693"/>
        <source>Check for badblocks (takes longer)</source>
        <translation>Tikrinti blogus blokus (užtrunka ilgiau)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="709"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="747"/>
        <location filename="../meinstall.ui" line="936"/>
        <source>ext4</source>
        <translation>ext4</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="752"/>
        <location filename="../meinstall.ui" line="941"/>
        <source>ext3</source>
        <translation>ext3</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="757"/>
        <location filename="../meinstall.ui" line="946"/>
        <source>ext2</source>
        <translation>ext2</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="762"/>
        <location filename="../meinstall.ui" line="951"/>
        <source>f2fs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="767"/>
        <location filename="../meinstall.ui" line="956"/>
        <source>jfs</source>
        <translation>jfs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="772"/>
        <location filename="../meinstall.ui" line="961"/>
        <source>xfs</source>
        <translation>xfs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="777"/>
        <location filename="../meinstall.ui" line="966"/>
        <source>btrfs</source>
        <translation>btrfs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="782"/>
        <location filename="../meinstall.ui" line="971"/>
        <source>btrfs-zlib</source>
        <translation>btrfs-zlib</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="787"/>
        <location filename="../meinstall.ui" line="976"/>
        <source>btrfs-lzo</source>
        <translation>btrfs-lzo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="792"/>
        <location filename="../meinstall.ui" line="981"/>
        <source>reiserfs</source>
        <translation>reiserfs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="797"/>
        <location filename="../meinstall.ui" line="986"/>
        <source>reiser4</source>
        <translation>reiser4</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="815"/>
        <source>boot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="840"/>
        <source>Label</source>
        <translation>Etiketė</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="859"/>
        <source>root:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="872"/>
        <source>swap:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="921"/>
        <location filename="../meinstall.ui" line="1092"/>
        <source>root</source>
        <translation>šaknis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1000"/>
        <source>Type</source>
        <translation>Tipas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1016"/>
        <source>home:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1106"/>
        <source>Location</source>
        <translation>Vieta</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1122"/>
        <source>Encryption options</source>
        <translation>Šifravimo parametrai</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1239"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1244"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1249"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1254"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1259"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1276"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1295"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1317"/>
        <source>LUKS key hash:</source>
        <translation>LUKS rakto maiša:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1330"/>
        <source>Key size:</source>
        <translation>Rakto dydis:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1350"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1373"/>
        <source>Cipher:</source>
        <translation>Šifras:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1393"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1398"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1403"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1408"/>
        <source>CAST6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1413"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1430"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1460"/>
        <source>ESSIV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1465"/>
        <source>Plain64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1470"/>
        <source>Plain64BE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1475"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1480"/>
        <source>BENBI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1494"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1507"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1521"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1529"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1534"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1561"/>
        <source>Select Boot Method</source>
        <translation>Pasirinkite OS paleidimo metodą</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1598"/>
        <source>EFI System Partition</source>
        <translation>EFI sistemos skaidinys</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1601"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1620"/>
        <source>Partition Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1623"/>
        <source>PBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1636"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1649"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1668"/>
        <source>System boot disk:</source>
        <translation>Sistemos paleidimo diskas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1690"/>
        <source>Master Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1696"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1699"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1758"/>
        <source>Common Services to Enable</source>
        <translation>Bendrosios tarnybos, kurias įjungti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1777"/>
        <source>Service</source>
        <translation>Tarnyba</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1782"/>
        <source>Description</source>
        <translation>Aprašas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1815"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1842"/>
        <source>Workgroup</source>
        <translation>Darbo_grupė</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1855"/>
        <source>Workgroup:</source>
        <translation>Darbo grupė:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1868"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa serveris, skirtas MS darbui tinkle</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1884"/>
        <source>example.dom</source>
        <translation>pavyzdys.sri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1897"/>
        <source>Computer domain:</source>
        <translation>Kompiuterio sritis:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1923"/>
        <source>Computer name:</source>
        <translation>Kompiuterio pavadinimas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1978"/>
        <source>Configure Clock</source>
        <translation>Konfigūruoti laikrodį</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2013"/>
        <source>Format:</source>
        <translation>Formatas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2041"/>
        <source>Timezone:</source>
        <translation>Laiko juosta:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2080"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2106"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2146"/>
        <source>Locale:</source>
        <translation>Lokalė:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2168"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2186"/>
        <source>Adjust which services should run at startup</source>
        <translation>Reguliuoti, kurios tarnybos turėtų būti paleidžiamos kompiuterio paleidimo metu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2189"/>
        <source>View</source>
        <translation>Rodyti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2235"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2292"/>
        <source>Confirm root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2247"/>
        <source>Root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2321"/>
        <source>Default User Account</source>
        <translation>Numatytojo naudotojo paskyra</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2423"/>
        <source>username</source>
        <translation>naudotojo_vardas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2362"/>
        <source>Confirm user password:</source>
        <translation>Patvirtinkite naudotojo slaptažodį:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2349"/>
        <source>Default user password:</source>
        <translation>Numatytojo naudotojo slaptažodis:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2333"/>
        <source>Default user login name:</source>
        <translation>Numatytojo naudotojo prisijungimo vardas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2439"/>
        <source>Autologin</source>
        <translation>Automatiškai prisijungti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2452"/>
        <source>Show passwords</source>
        <translation>Rodyti slaptažodžius</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2465"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Pristatymo aplinkoje atliktos darbalaukio modifikacijos bus perkeltos į įdiegtą OS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2468"/>
        <source>Save live desktop changes</source>
        <translation>Įrašyti pristatomojo darbalaukio pakeitimus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2491"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2500"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Ką norėtumėte daryti su senu katalogu?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2507"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2514"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2521"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2560"/>
        <source>Tips</source>
        <translation>Patarimai</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2604"/>
        <source>Installation complete</source>
        <translation>Įdiegimas baigtas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2610"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2629"/>
        <source>Reminders</source>
        <translation>Priminimai</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="49"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="52"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="62"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="65"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="66"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="110"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Diegimo programa nepasileidžia dėl to, jog atrodo, kad ji jau yra vykdoma fone.

Prašome, jeigu įmanoma, ją užverti arba paleisti terminale &quot;pkill minstall&quot;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="118"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="131"/>
        <source>You must run this app as root.</source>
        <translation>Privalote paleisti šią programą kaip pagrindinis (root) naudotojas.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="150"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
