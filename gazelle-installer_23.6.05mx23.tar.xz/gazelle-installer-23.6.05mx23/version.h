const QString VERSION {"23.6.05mx23"};
