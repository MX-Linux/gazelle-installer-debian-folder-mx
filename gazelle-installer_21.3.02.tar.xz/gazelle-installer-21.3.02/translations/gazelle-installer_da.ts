<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="da">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="95"/>
        <source>%1 Installer</source>
        <translation>Installationsprogrammet for %1</translation>
    </message>
    <message>
        <source>Gathering Information, please stand by.</source>
        <translation type="vanished">Indsamler information, vent venligst.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="55"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="112"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Støt %1

%1 støttes af folk som dig. Nogen hjælper andre i supportforummet - %2, eller oversætter hjælpefiler til forskellige sprog, eller kommer med forslag, skriver dokumentation, eller hjælper med at teste ny software.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="338"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 er en uafhængig Linux-distribution baseret på Debian stable.

%1 bruger nogle komponenter fra MEPIS Linux som er udgivet under en Apache fri-licens. Nogle MEPIS-komponenter er blevet ændret til %1.

God fornøjelse med %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="451"/>
        <source>Pretending to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to abort the installation?</source>
        <translation type="vanished">Vil du afbryde installationen?</translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="vanished">Vil du fortsætte?</translation>
    </message>
    <message>
        <source>The password needs to be at least
%1 characters long. Please select
a longer password before proceeding.</source>
        <translation type="vanished">Adgangskoden skal være mindst
%1 tegn langt. Vælg venligst
en længere adgangskode inden du fortsætter.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="507"/>
        <source>Preparing to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="519"/>
        <source>Failed to format required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="530"/>
        <source>Paused for required operator input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="540"/>
        <source>Setting system configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="558"/>
        <source>Cleaning up</source>
        <translation>Rydder op</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="718"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="vanished">Opsætter LUKS-krypterede beholdere</translation>
    </message>
    <message>
        <source>Formatting swap partition</source>
        <translation type="vanished">Formaterer swap-partition</translation>
    </message>
    <message>
        <source>Formatting the / (root) partition</source>
        <translation type="vanished">Formaterer /-partitionen (rod)</translation>
    </message>
    <message>
        <source>Formatting boot partition</source>
        <translation type="vanished">Formaterer opstartspartition</translation>
    </message>
    <message>
        <source>Formatting the /home partition</source>
        <translation type="vanished">Formaterer /home-partitionen</translation>
    </message>
    <message>
        <source>Mounting the /home partition</source>
        <translation type="vanished">Monterer /home-partitionen</translation>
    </message>
    <message>
        <source>Sorry, could not create %1 LUKS partition</source>
        <translation type="vanished">Beklager, kunne ikke oprette %1 LUKS-partition</translation>
    </message>
    <message>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation type="vanished">Beklager, kunne ikke åben %1 LUKS-beholder</translation>
    </message>
    <message>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="vanished">Du skal vælge en separat opstartspartition når roden krypteres.</translation>
    </message>
    <message>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="vanished">Du skal vælge en rodpartition.
Rodpartitionen skal være mindst %1.</translation>
    </message>
    <message>
        <source>Creating required partitions</source>
        <translation type="vanished">Opretter krævede partitioner</translation>
    </message>
    <message>
        <source>Preparing required partitions</source>
        <translation type="vanished">Forbereder krævede partitioner</translation>
    </message>
    <message>
        <source>Mounting the / (root) partition</source>
        <translation type="vanished">Monterer /-partitionen (rod)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="807"/>
        <source>Deleting old system</source>
        <translation>Sletter gammelt system</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="811"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Kunne ikke slette den gamle %1 på destinationen.
Vender tilbage til trin 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Creating system directories</source>
        <translation>Opretter systemmapper</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Fixing configuration</source>
        <translation>Retter konfiguration</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="870"/>
        <source>Copying new system</source>
        <translation>Kopierer nyt system</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="910"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="919"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Kunne ikke skrive %1 til destinationen.
Vender tilbage til trin 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="937"/>
        <source>Installing GRUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1022"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1038"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>The home directory for %1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>Failed to set user account passwords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1232"/>
        <source>Failed to save old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1239"/>
        <source>Failed to delete old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1259"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Beklager, kunne ikke oprette brugermappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1267"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Beklager, kunne ikke navngive brugermappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1288"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Beklager, kunne ikke indstille ejerskab af brugermappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1335"/>
        <source>Please enter a computer name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1339"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>Please enter a domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1356"/>
        <source>Please enter a workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1573"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Er det ok at formatere og bruge hele disken (%1) til %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1577"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1603"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1604"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1605"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1661"/>
        <source>General Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1662"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1663"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1666"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1667"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <location filename="../minstall.cpp" line="1720"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1677"/>
        <location filename="../minstall.cpp" line="1722"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1695"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>Choose Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1698"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1700"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1706"/>
        <source>Upgrading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1174"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="133"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished">Installationsprogrammet startes ikke da det ser ud til allerede at køre i baggrunden.

Luk det venligst hvis det er muligt, eller kør &apos;pkill minstall&apos; i terminalen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="158"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="209"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished">Du kører et 32 bit styresystem startet i 64 bit UEFI-tilstand, systemet kan ikke starte med mindre du vælger udgået opstart eller lignende ved genstart.
Vi anbefaler at du afslutter nu og genstarter i udgået opstart

Vil du fortsætte installationen?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="560"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1665"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1668"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1669"/>
        <source>By default, the automatic install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>Move the slider to the left to increase the space for &lt;b&gt;home&lt;/b&gt;. Move it to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move the slider all the way to the right if you want both root and home on the same partition; &lt;b&gt;this is not recommended.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1673"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1680"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1681"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1710"/>
        <source>Preferred Filesystem Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1711"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1712"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>Bad Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>System drive management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1718"/>
        <source>If you want more control over the drive layouts than what can be provided on this page, click the button to the bottom-right of the list. This will run the drive management tool provided with the operating system, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>Advanced Encryption Settings</source>
        <translation>Avancerede krypteringsindstillinger</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1735"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>A variety of ciphers are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1741"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Chain mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>IV generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1755"/>
        <source>Key size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1755"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>LUKS key hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1765"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Vælg opstartsmetode&lt;/b&gt;&lt;br/&gt; %1 bruger GRUB-opstartsindlæseren til at starte %1 og MS-Windows. &lt;p&gt;GRUB2 er som standard installeret i Master Boot Record&apos;en (MBR) eller ESP&apos;en (EFI-systempartition til 64-bit UEFI-opstartssystemer) i dit opstartsdrev og erstatter den opstartsindlæser du tidligere brugte. Det er normalt.&lt;/p&gt;&lt;p&gt;Hvis du i stedet vælger at installere GRUB2 i Partition Boot Record (PBR), så installeres GRUB2 i begyndelsen af den valgte partition. Valgmuligheden er kun til eksperter.&lt;/p&gt;&lt;p&gt;Hvis du fravælger Installer GRUB-boksen, så installeres GRUB ikke denne gang. Valgmuligheden er kun for eksperter.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Fælles tjenester som skal aktiveres&lt;/b&gt;&lt;br/&gt;Vælg de fælles tjenester som du kan have brug for til dit systemkonfiguration og tjenesterne startes automatisk når du starter %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Computeridentitet&lt;/b&gt;&lt;br/&gt;Computernavnet er et fælles unikt navn som identificerer din computer hvis den er på et netværk. Computerdomænet bruges sandsynligvis ikke, med mindre din internetudbyder eller lokale netværk kræver det.&lt;/p&gt;&lt;p&gt;Computeren og domænenavnene må kun indeholde alfanumeriske tegn, prikker, bindestreger. De må ikke indeholde blanktegn, begynde eller slutte med bindestreger&lt;/p&gt;&lt;p&gt;SaMBa-serveren skal være aktiveret hvis du vil bruge den til at dele nogle af dine mapper eller printer med en lokal computer som kører MS-Windows eller Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1805"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1808"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1811"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1817"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1822"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1823"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1825"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1826"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2033"/>
        <location filename="../minstall.cpp" line="2399"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2034"/>
        <location filename="../minstall.cpp" line="2405"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2401"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Localization Defaults&lt;/b&gt;&lt;br/&gt;Set the default keyboard and locale. These will apply unless they are overridden later by the user.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Configure Clock&lt;/b&gt;&lt;br/&gt;If you have an Apple or a pure Unix computer, by default the system clock is set to GMT or Universal Time. To change, check the box for &apos;System clock uses LOCAL.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timezone Settings&lt;/b&gt;&lt;br/&gt;The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Service Settings&lt;/b&gt;&lt;br/&gt;Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing! </source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Lokaliseringsstandarder&lt;/b&gt;&lt;br/&gt;Indstil standardtastaturet og -lokaliteten. Disse anvendes med mindre de tilsidesættes af brugeren senere.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Konfigurer ur&lt;/b&gt;&lt;br/&gt;Hvis du har en Apple- eller en ren Unix-computer, så indstilles systemets ur til GMT eller universel tid. Tilvælg boksen &apos;Systemets ur bruger LOKAL&apos;, for at ændre det.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Tidszoneindstillinger&lt;/b&gt;&lt;br/&gt;Systemet starter med tidszonen forudindstillet til GMT/UTC. Når du har genstartet i den nye installation kan du skifte tidszonen ved at højreklikke på uret i panelet og vælge egenskaber.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Tjenesteindstillinger&lt;/b&gt;&lt;br/&gt;De fleste brugere ændre ikke standarderne. Brugere med computere som har få ressourcer vil nogle gange deaktivere unødvendige tjenester for at holde RAM-forbruget så lavt som muligt. Sørg for at du ved hvad du gør! </translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Default User Login&lt;/b&gt;&lt;br/&gt;The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Passwords&lt;/b&gt;&lt;br/&gt;Enter a new password for your default user account and for the root account. Each password must be entered twice.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Indlogning af standardbruger&lt;/b&gt;&lt;br/&gt;I nogle andre styresystemer er root-brugeren i stil som Administrator-brugeren. Du bør ikke bruge root-brugeren som din daglige brugerkonto. Indtast venligst navnet til en ny (standard) brugerkonto som du bruger på daglig basis. Hvis det er nødvendigt kan du tilføje andre brugerkonti senere med %1 Brugerhåndtering. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Adgangskoder&lt;/b&gt;&lt;br/&gt;Indtast en ny adgangskode til din standardbrugerkonto og til root-kontoen. Hver adgangskode skal indtastes to gange.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1837"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1841"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1843"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1844"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1846"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1847"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1848"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1849"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1850"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1866"/>
        <source>Installation in Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1867"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1869"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1872"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1883"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Tillykke!&lt;/b&gt;&lt;br/&gt;Du har fuldført installationen af %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Find programmer&lt;/b&gt;&lt;br/&gt;Der er installeret hundredvis af fremragende programmer i %1. Den bedst måde at lære dem at kende på, er ved at gennemse menuen og prøve dem. Mange af programmerne blev udviklet specielt til %1-projektet. De vises i hovedmenuerne. &lt;p&gt;Derudover inkluderer %1 mange standard Linux-programmer som kun kan køres fra kommandolinjen og derfor ikke vises i menuen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1893"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>God fornøjelse med %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <location filename="../minstall.cpp" line="2309"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Støt %1&lt;/b&gt;&lt;br/&gt;%1 støttes af folk som dig. Nogen hjælper andre i supportforummet - %2 - eller oversætter hjælpefiler til forskellige sprog, eller kommer med forslag, skriver dokumentation, eller hjælper med at teste ny software.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1925"/>
        <source>Finish</source>
        <translation>Færdig</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1931"/>
        <source>Next</source>
        <translation>Næste</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1966"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1969"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1973"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1990"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2234"/>
        <source>Confirmation</source>
        <translation>Bekræftelse</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2234"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Installationen og konfigurationen er ikke færdig.
Vil du virkelig stoppe nu?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2295"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Få hjælp&lt;/b&gt;&lt;br/&gt;Grundlæggende information om %1 findes på %2.&lt;/p&gt;&lt;p&gt;Der er frivillige som kan hjælpe dig i %3-forummet, %4&lt;/p&gt;&lt;p&gt;Hvis du spørger om hjælp, så husk venligst at beskrive dit problem og give noget informationer om din computer. At skrive &apos;det virker ikke&apos; hjælper ikke meget.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2303"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparation af din installation&lt;/b&gt;&lt;br/&gt;Hvis %1 holder op med at virke fra harddisken, så er det nogle gange muligt at rette problemet ved at opstarte fra LiveDVD eller LiveUSB og køre et af de inkluderede redskaber i %1 eller ved at bruge en af de almindelige Linux-værktøjer til at reparere systemet.&lt;/p&gt;&lt;p&gt;Du kan også bruge din %1-LiveDVD eller -LiveUSB til at gendanne data fra MS-Windows-systemer!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2317"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Justerer din lydmixer&lt;/b&gt;&lt;br/&gt; %1 forsøger at konfigurere lydmixeren for dig men nogle gange er det nødvendigt for dig at skrue op for lydstyrken og slå lyden til for kanaler i mixeren, for at kunne høre lyden..&lt;/p&gt; &lt;p&gt;Genvejen til mixeren findes i menuen. Klik på den for at åbne mixeren. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2325"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Hold din kopi af %1 opdateret&lt;/b&gt;&lt;br/&gt;For information og opdateringer besøg venligst&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2330"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Særlig tak&lt;/b&gt;&lt;br/&gt;Tak til alle dem der har valgt at støtte %1 med deres tid, penge, forslag, arbejde, ros, ideer, promovering og/eller støtte.&lt;/p&gt;&lt;p&gt;Uden dig ville der ikke være noget %1.&lt;/p&gt;&lt;p&gt;%2-udviklerteam&lt;/p&gt;</translation>
    </message>
    <message>
        <source>This option also encrypts swap partition if selected, which will render the swap partition unable to be shared with other installed operating systems.</source>
        <translation type="vanished">Valgmuligheden krypterer også swap-partitionen hvis det er valgt, hvilket gør at swap-partitionen ikke kan deles med andre installerede styresystemer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2553"/>
        <source>System boot disk:</source>
        <translation>Systemets bootdisk:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2567"/>
        <location filename="../minstall.cpp" line="2576"/>
        <source>Partition to use:</source>
        <translation>Partition som skal bruges:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="94"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="43"/>
        <source>Help</source>
        <translation>Hjælp</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="149"/>
        <source>Next</source>
        <translation>Næste</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="156"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="371"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2425"/>
        <source>Back</source>
        <translation>Tilbage</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2432"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2445"/>
        <source>Installation in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2460"/>
        <source>Abort</source>
        <translation>Afbryd</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1353"/>
        <location filename="../meinstall.ui" line="2463"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="100"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="138"/>
        <source>Close</source>
        <translation>Luk</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="203"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished">Indsamler information, vent venligst.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="238"/>
        <source>Terms of Use</source>
        <translation>Vilkår for anvendelse</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="265"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tastaturindstillinger&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="272"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="279"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="302"/>
        <source>Change Keyboard Settings</source>
        <translation>Skift tastaturindstillinger</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="309"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Rearrange disk partitions (optional)</source>
        <translation type="vanished">Omarranger diskpartitioner (valgfrit)</translation>
    </message>
    <message>
        <source>Modify partitions:</source>
        <translation type="vanished">Rediger partitioner:</translation>
    </message>
    <message>
        <source>Run partition tool...</source>
        <translation type="vanished">Kør partitionsværktøj...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="359"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-install using entire disk </source>
        <translation type="vanished">Automatisk installation med hele disken </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="565"/>
        <location filename="../meinstall.ui" line="857"/>
        <source>Encryption password:</source>
        <translation>Adgangskode for kryptering:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="558"/>
        <source>MB </source>
        <translation>MB </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="400"/>
        <location filename="../meinstall.ui" line="840"/>
        <source>Confirm password:</source>
        <translation>Bekræft adgangskode:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="503"/>
        <source>Leave free space up to:</source>
        <translation>Efterlad ledig plads op til:</translation>
    </message>
    <message>
        <source>Custom install on existing partitions</source>
        <translation type="vanished">Tilpasset installation på eksisterende partitioner</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <location filename="../meinstall.ui" line="880"/>
        <location filename="../meinstall.ui" line="912"/>
        <source>Advanced encryption settings</source>
        <translation>Avancerede krypteringsindstillinger</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="542"/>
        <location filename="../meinstall.ui" line="741"/>
        <source>Encrypt</source>
        <translation>Kryptér</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="416"/>
        <source>Use disk:</source>
        <translation>Brug disk:</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Præferencer</translation>
    </message>
    <message>
        <source>Preserve data in /home (if upgrading)</source>
        <translation type="vanished">Bevar data i /home (hvis der kan opgraderes)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="775"/>
        <source>Check for badblocks (takes longer)</source>
        <translation>Søg efter dårlige blokke (tager længere tid)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="688"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ext4</source>
        <translation type="vanished">ext4</translation>
    </message>
    <message>
        <source>ext3</source>
        <translation type="vanished">ext3</translation>
    </message>
    <message>
        <source>ext2</source>
        <translation type="vanished">ext2</translation>
    </message>
    <message>
        <source>jfs</source>
        <translation type="vanished">jfs</translation>
    </message>
    <message>
        <source>xfs</source>
        <translation type="vanished">xfs</translation>
    </message>
    <message>
        <source>btrfs</source>
        <translation type="vanished">btrfs</translation>
    </message>
    <message>
        <source>btrfs-zlib</source>
        <translation type="vanished">btrfs-zlib</translation>
    </message>
    <message>
        <source>btrfs-lzo</source>
        <translation type="vanished">btrfs-lzo</translation>
    </message>
    <message>
        <source>reiserfs</source>
        <translation type="vanished">reiserfs</translation>
    </message>
    <message>
        <source>reiser4</source>
        <translation type="vanished">reiser4</translation>
    </message>
    <message>
        <source>boot:</source>
        <translation type="vanished">opstart:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="731"/>
        <source>Label</source>
        <translation>Etiket</translation>
    </message>
    <message>
        <source>root:</source>
        <translation type="vanished">rod:</translation>
    </message>
    <message>
        <source>swap:</source>
        <translation type="vanished">swap:</translation>
    </message>
    <message>
        <source>root</source>
        <translation type="vanished">rod</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="746"/>
        <source>Type</source>
        <translation>Type</translation>
    </message>
    <message>
        <source>home:</source>
        <translation type="vanished">hjem:</translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="vanished">Placering</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="824"/>
        <source>Encryption options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="928"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="933"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="938"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="943"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="948"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="965"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="984"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1006"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1019"/>
        <source>Key size:</source>
        <translation>Nøglestørrelse:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1045"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <source>Cipher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1088"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1093"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1098"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1103"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1108"/>
        <source>Blowfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1125"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1155"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1160"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1165"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1170"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1175"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1189"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1202"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1222"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1230"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1235"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1262"/>
        <source>Select Boot Method</source>
        <translation>Vælg opstartsmetode</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1299"/>
        <source>EFI System Partition</source>
        <translation>EFI-systempartition</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1302"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1321"/>
        <source>Partition Boot Record</source>
        <translation>Partition Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1324"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1350"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Installer GRUB til Linux og Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1369"/>
        <source>System boot disk:</source>
        <translation>Systemets bootdisk:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1391"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1397"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1400"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1471"/>
        <source>Common Services to Enable</source>
        <translation>Fælles tjenester som skal aktiveres</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1490"/>
        <source>Service</source>
        <translation>Tjeneste</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1495"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1528"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1555"/>
        <source>Workgroup</source>
        <translation>Arbejdsgruppe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1568"/>
        <source>Workgroup:</source>
        <translation>Arbejdsgruppe:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1581"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa-server til MS-netværk</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1597"/>
        <source>example.dom</source>
        <translation>eksempel.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1610"/>
        <source>Computer domain:</source>
        <translation>Computerdomæne:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1636"/>
        <source>Computer name:</source>
        <translation>Computernavn:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1697"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System clock uses LOCAL</source>
        <translation type="vanished">Systemets ur bruger LOKAL</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1738"/>
        <source>Format:</source>
        <translation>Format:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1766"/>
        <source>Timezone:</source>
        <translation>Tidszone:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1811"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1843"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1883"/>
        <source>Locale:</source>
        <translation>Lokalitet:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1905"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1923"/>
        <source>Adjust which services should run at startup</source>
        <translation>Juster hvilke tjenester som skal køre ved opstart</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1926"/>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1984"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2041"/>
        <source>Confirm root password:</source>
        <translation>Bekræft root-adgangskode:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1996"/>
        <source>Root password:</source>
        <translation>Root-adgangskode:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2070"/>
        <source>Default User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2172"/>
        <source>username</source>
        <translation>brugernavn</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2111"/>
        <source>Confirm user password:</source>
        <translation>Bekræft brugerens adgangskode:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2098"/>
        <source>Default user password:</source>
        <translation>Brugerens standardadgangskode:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2082"/>
        <source>Default user login name:</source>
        <translation>Brugerens standardloginnavn:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="384"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="599"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="634"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="710"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="721"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="726"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="751"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="759"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="782"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="792"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="802"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2188"/>
        <source>Autologin</source>
        <translation>Automatisk indlogning</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2201"/>
        <source>Show passwords</source>
        <translation>Vis adgangskoder</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2214"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Ændringer som er foretaget skrivebordet i livemiljøet videreføres til det installerede styresystem</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2217"/>
        <source>Save live desktop changes</source>
        <translation>Gem ændringer til liveskrivebord</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2240"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2249"/>
        <source>What would you like to do with the old directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2256"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2263"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2270"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2315"/>
        <source>Tips</source>
        <translation>Tips</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2359"/>
        <source>Installation complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2365"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2384"/>
        <source>Reminders</source>
        <translation>Påmindelser</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="441"/>
        <source>&amp;Reset to on-disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="329"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="433"/>
        <source>Template: BTRFS compression (ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="434"/>
        <source>Template: BTRFS compression (LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="443"/>
        <source>Template: &amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="444"/>
        <source>Template: &amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="508"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="518"/>
        <location filename="../partman.cpp" line="587"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="519"/>
        <source>EFI System Partition</source>
        <translation type="unfinished">EFI-systempartition</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="526"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="564"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="571"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished">Du skal vælge en rodpartition.
Rodpartitionen skal være mindst %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="577"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished">Du skal vælge en separat opstartspartition når roden krypteres.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>Configure %1 as swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="595"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="598"/>
        <source>Reuse (no reformat) %1 as the %2 partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="604"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="607"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="615"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="623"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="631"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="635"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="732"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="736"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="737"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="742"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="744"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished">Vil du afbryde installationen?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="749"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished">Vil du fortsætte?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="939"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="947"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished">Forbereder krævede partitioner</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1001"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished">Opsætter LUKS-krypterede beholdere</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1029"/>
        <source>Formatting swap partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1040"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1044"/>
        <source>Formatting EFI System Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1215"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="vanished">Installationsprogrammet startes ikke da det ser ud til allerede at køre i baggrunden.

Luk det venligst hvis det er muligt, eller kør &apos;pkill minstall&apos; i terminalen.</translation>
    </message>
    <message>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="vanished">Du kører et 32 bit styresystem startet i 64 bit UEFI-tilstand, systemet kan ikke starte med mindre du vælger udgået opstart eller lignende ved genstart.
Vi anbefaler at du afslutter nu og genstarter i udgået opstart

Vil du fortsætte installationen?</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must run this app as root.</source>
        <translation type="vanished">Du skal køre programmet som root.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
