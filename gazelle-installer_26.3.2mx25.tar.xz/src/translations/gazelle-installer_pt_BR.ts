<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="pt_BR">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Home</source>
        <translation>Início</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="175"/>
        <source>The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>A unidade de armazenamento que foi selecionada tem a capacidade mínima de 2 TB e deve ser formatada utilizando o GPT. Em alguns computadores, uma  de armazenamento (disco rígido Sata, SSD, NVMe, etc.) quando é formatado com o GPT o sistema operacional não consegue inicializar.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="177"/>
        <source>Are you sure you want to continue?</source>
        <translation>Você tem certeza de que quer continuar?</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="183"/>
        <source>The system and home drives cannot be the same for this type of installation.</source>
        <translation>Para este tipo de instalação, a unidade de armazenamento do sistema operacional e a unidade de armazenamento da pasta pessoal não podem ser os mesmos</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="187"/>
        <source>Format and use drives entirely for %1</source>
        <translation>Formatar e utilizar a unidades de armazenamento exclusivamente para %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="189"/>
        <source>System drive: %1</source>
        <translation>Unidade de armazenamento do sistema operacional %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="191"/>
        <source>Home drive: %1</source>
        <translation>Unidade de armazenamento da pasta pessoal %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="194"/>
        <source>Format and use the entire drive for %1: %2</source>
        <translation>Formatar e utilizar toda a unidade de armazenamento para %1 de %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="224"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>É recomendado %1
E no mínimo %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="226"/>
        <source>Minimum for hibernation support: %1</source>
        <translation>O mínimo para ativar o suporte à hibernação é %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="268"/>
        <source>Layout Builder</source>
        <translation>Criador de Leiautes</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="468"/>
        <source>%1% root
%2% home</source>
        <translation>%1% root
%2% home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="470"/>
        <source>Combined root and home</source>
        <translation>O ‘root’ e a ‘home’ combinados</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="89"/>
        <source>Cannot access installation media.</source>
        <translation>Não foi possível acessar o dispositivo de instalação.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="253"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Ocorreu uma falha ao apagar o sistema operacional antigo no destino.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="256"/>
        <source>Deleting old system</source>
        <translation>Apagando o sistema operacional antigo</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="280"/>
        <source>Failed to set the system configuration.</source>
        <translation>Ocorreu uma falha ao definir as configurações do sistema operacional.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="282"/>
        <source>Setting system configuration</source>
        <translation>Definir as configurações do sistema operacional.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="437"/>
        <source>Copying new system</source>
        <translation>Copiando o novo sistema operacional</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="609"/>
        <source>Failed to copy the new system.</source>
        <translation>Ocorreu uma falha ao copiar o novo sistema operacional.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="117"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>A instalação do GRUB (GNU GRand Unified Bootloader ou Carregador de Inicialização Unificado GRand) falhou. Você pode reparar a instalação do GRUB reiniciando o computador com o USB/DVD/CD executável e utilizar o programa ‘Reparador de Inicialização’ (Boot Repair).</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="191"/>
        <source>Installing GRUB</source>
        <translation>Instalando o GRUB</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="438"/>
        <source>Updating initramfs</source>
        <translation>Atualizando o initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="439"/>
        <source>Failed to update initramfs.</source>
        <translation>Ocorreu uma falha ao atualizar o initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="497"/>
        <source>System boot disk:</source>
        <translation>Disco de inicialização do sistema operacional:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="512"/>
        <location filename="../bootman.cpp" line="522"/>
        <source>Partition to use:</source>
        <translation>Partição para ser utilizada:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="67"/>
        <source>The installation media is corrupt.</source>
        <translation>O dispositivo de instalação está danificado.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="76"/>
        <source>The installation media is still being checked.</source>
        <translation>O dispositivo de instalação ainda está sendo verificado.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="77"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>Você tem certeza que quer interromper a verificação do dispositivo de instalação?</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="231"/>
        <source>Checking installation media.</source>
        <translation>Verificando o dispositivo de instalação.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="232"/>
        <source>Press ESC to skip.</source>
        <translation>Pressione a tecla ESC para não continuar com a verificação da mídia de instalação.</translation>
    </message>
</context>
<context>
    <name>Crypto</name>
    <message>
        <location filename="../crypto.cpp" line="63"/>
        <source>Failed to format LUKS container.</source>
        <translation>Ocorreu uma falha ao formatar o contêiner LUKS.</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="67"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Criando o volume criptografado/encriptado: %1</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="72"/>
        <source>Failed to open LUKS container.</source>
        <translation>Ocorreu uma falha ao abrir o contêiner LUKS.</translation>
    </message>
</context>
<context>
    <name>Device</name>
    <message>
        <location filename="../partman.cpp" line="2261"/>
        <source>Overwrite</source>
        <translation>Substituir</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2261"/>
        <source>Create</source>
        <translation>Criar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2262"/>
        <source>Delete</source>
        <translation>Excluir</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2265"/>
        <source>Preserve</source>
        <translation>Preservar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2266"/>
        <source>Preserve (%1)</source>
        <translation>Preservar (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2267"/>
        <source>Preserve /home (%1)</source>
        <translation>Preservar a pasta /home do (%1)</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="408"/>
        <source>Unknown release</source>
        <translation>A versão não é conhecida</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="114"/>
        <source>Shutdown</source>
        <translation>Desligar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="235"/>
        <source>You are running 32-bit OS started in 64-bit UEFI mode.</source>
        <translation>Você está executando neste exato momento um sistema operacional de 32 bits que foi iniciado no modo UEFI de 64 bits.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="236"/>
        <source>The system will not be able to boot unless you restart the system in Legacy Boot (or similar mode) before proceeding.</source>
        <translation>O sistema operacional não poderá inicializar a menos que você reinicie o computador e ative o modo ‘Legacy Boot’ (BIOS Legado ou BIOS Antigo) ou em um modo similar antes de continuar com o processo de instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="238"/>
        <source>Do you want to continue the installation?</source>
        <translation>Você quer continuar com o processo de instalação?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="280"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>O instalador do %1 agora executará as ações solicitadas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="281"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Estas ações não poderão ser desfeitas. Você quer continuar?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="293"/>
        <source>Support %1</source>
        <translation>Apoie o %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="294"/>
        <source>%1 is supported by people like you. Some help others at the support forum, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>O %1 conta com o apoio e a ajuda de pessoas como você. Algumas pessoas ajudam as outras pessoas com suporte técnico no fórum do antiX. Outras pessoas traduzem os arquivos de ajuda, o sistema operacional antiX e os programas que estão no antiX para diferentes idiomas. Outras pessoas fazem sugestões, escrevem a documentação do antiX, ajudam a testar os novos programas, etc. Você também pode ajudar de alguma maneira.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="339"/>
        <location filename="../minstall.cpp" line="1442"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>O %1 é uma distribuição GNU/Linux independente baseada na distribuição Debian Estável (Stable).

O %1 utiliza alguns componentes do MEPIS Linux que foram publicados sob a licença livre do Apache (Apache free license). Alguns componentes do MEPIS foram modificados para serem utilizados no %1.

Divirta-se utilizando o %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="440"/>
        <source>Preparing to install %1</source>
        <translation>Preparando para instalar o %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="457"/>
        <source>Paused for required operator input</source>
        <translation>O sistema operacional está aguardando o usuário inserir as informações que foram solicitadas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="469"/>
        <source>Setting system configuration</source>
        <translation>Definir as configurações do sistema operacional</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="481"/>
        <source>Cleaning up</source>
        <translation>Limpando</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="485"/>
        <source>Finished</source>
        <translation>Finalizado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="497"/>
        <source>Configuring system. Please wait.</source>
        <translation>O sistema operacional está sendo configurado. Por favor, aguarde a finalização.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="501"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>As configurações foram concluídas. Reiniciando o sistema operacional.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="508"/>
        <source>The installation was aborted.</source>
        <translation>A instalação foi interrompida.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="532"/>
        <source>Pretending to install %1</source>
        <translation>Simulando a instalação do %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="571"/>
        <source>Invalid settings found in configuration file (%1).</source>
        <translation>As configurações que foram encontradas no arquivo de configurações %1 não são válidas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="572"/>
        <source>Please review marked fields as you encounter them.</source>
        <translation>Por favor, revise os campos que estão selecionados ou marcados conforme você os encontrar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="665"/>
        <location filename="../minstall.cpp" line="693"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Os dados na ‘/home’ não podem ser preservados porque as informações solicitadas para este processo não puderam ser obtidas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="725"/>
        <source>Cannot find selected drive.</source>
        <translation>Não foi possível encontrar a unidade de armazenamento selecionada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="774"/>
        <source>The home directory for %1 already exists.</source>
        <translation>A pasta ‘home’ para %1 já existe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="815"/>
        <source>General Instructions</source>
        <translation>Instruções Gerais</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="816"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ANTES DE PROSSEGUIR, FECHE TODOS OS OUTROS PROGRAMAS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Em cada página, leia as instruções atentamente, faça as suas escolhas e clique no botão «Próximo». Será solicitado a sua confirmação, antes de continuar quaisquer ações destrutivas (ações que apagam ou excluem os seus dados do seu dispositivo de armazenamento) a serem executadas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="819"/>
        <source>Limitations</source>
        <translation>Limitações</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="820"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Lembre-se de que este sistema operacional (software) é disponibilizado COMO ESTÁ, sem qualquer tipo de garantia. É de sua exclusiva responsabilidade fazer a cópia de segurança (backup) dos seus dados que estejam no dispositivo de armazenamento do computador, antes de continuar com o processo de instalação do sistema operacional.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>Installation Options</source>
        <translation>Opções de Instalação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="825"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Se você estiver executando um sistema operacional Mac OS ou Windows (Vista ou posterior), pode ser necessário utilizar o programa (software) do sistema existente para configurar as partições e instalar o gerenciador de inicialização (boot manager) antes de prosseguir com esta instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="826"/>
        <source>Dual drive</source>
        <translation>Duas ou mais unidades de armazenamento</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="827"/>
        <source>If your system has multiple storage drives, this option allows you to have the system files on one drive (the System drive), while keeping the data of all users on a separate drive (the Home drive).</source>
        <translation>Se você tiver várias unidades de armazenamento, esta opção permite que você tenha os arquivos do sistema operacional em uma unidade de armazenamento (a unidade do sistema operacional), enquanto mantém os dados de todos os usuários em uma unidade de armazenamento separada (a unidade de armazenamento pessoal).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="829"/>
        <source>Using the root-home space slider</source>
        <translation>Utilizando o controle deslizante para definir o espaço do ‘root’ e da ‘home’.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="830"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>O dispositivo de armazenamento pode ser dividido em partições separadas, sendo uma partição para a instalação do sistema operacional (root) e outra partição para o armazenamento de dados da pasta pessoal do usuário (home). Para isto, utilize o controle deslizante.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="831"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>A partição ‘&lt;b&gt;root&lt;/b&gt;’ (raiz) conterá o sistema operacional e os programas (tanto os programas pré-instalados no antiX, quanto os programas que vierem a ser instalados pelo usuário).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>A partição ‘&lt;b&gt;home&lt;/b&gt;’ conterá os dados de todos os usuários (pasta pessoal ou pasta do usuário), como suas configurações, arquivos, documentos, imagens, músicas, vídeos, etc.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="833"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Mova o controle deslizante para a direita para aumentar o espaço para ‘&lt;b&gt;root&lt;/b&gt;’. Mova o controle deslizante para a esquerda para aumentar o espaço para ‘&lt;b&gt;home&lt;/b&gt;’.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="834"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Mova o controle deslizante totalmente para a direita se você quiser ‘root’ e ‘home’ na mesma partição.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Manter a pasta ‘home’ em uma partição separada aumenta a confiabilidade nas atualizações do sistema operacional. Também torna a cópia de segurança e a recuperação dos dados mais fáceis. Este recurso também pode melhorar o desempenho geral, restringindo os arquivos do sistema operacional em uma partição definida no dispositivo de armazenamento.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="837"/>
        <location filename="../minstall.cpp" line="935"/>
        <location filename="../minstall.cpp" line="955"/>
        <source>Encryption</source>
        <translation>Criptografia ou Encriptação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="838"/>
        <location filename="../minstall.cpp" line="936"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>A criptografia/encriptação é possível via LUKS. É necessária uma senha.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="839"/>
        <location filename="../minstall.cpp" line="937"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>É necessária uma partição de inicialização separada e não criptografada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="840"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Quando a criptografia/encriptação é utilizada com uma instalação automática, será automaticamente criada uma partição de inicialização (boot partition) separada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="841"/>
        <source>Using a custom disk layout</source>
        <translation>Utilizando um leiaute de disco personalizado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="842"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Se você precisar de mais controle sobre onde %1 será instalado, selecione “&lt;b&gt;%2&lt;/b&gt;” e clique em &lt;b&gt;Próximo&lt;/b&gt;. Na próxima página, você poderá selecionar e configurar os dispositivos de armazenamento e as partições que você precisa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <location filename="../minstall.cpp" line="850"/>
        <source>Replace existing installation</source>
        <translation>Substituir a Instalação Existente</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <source>Replace existing installation option will attempt to replace an existing installation with the same disk configuration as the existing installation.  Home directories are preserved.</source>
        <translation>A opção ‘Substituir a Instalação Existente’ tentará substituir uma instalação existente com a mesma configuração do disco da instalação atual. As pastas pessoais ou diretórios pessoais são preservados.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="851"/>
        <source>If you have an existing installation, you can use this function to replace it with a fresh installation.</source>
        <translation>Se você tiver uma instalação existente, poderá utilizar esta funcionalidade para substituí-la por uma nova instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="852"/>
        <source>This is particularly useful if you are upgrading from a previous version and want to preserve your data.</source>
        <translation>Esta funcionalidade é particularmente útil se você estiver atualizando de uma edição ou versão anterior e quiser preservar os seus dados na sua pasta pessoal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="854"/>
        <source>There is no guarantee of this working successfully. Ensure you have a good working backup of all important data before continuing.</source>
        <translation>Como não há garantia de que tudo funcione corretamente. Certifique-se de ter uma cópia de segurança de todos os seus dados antes de continuar com o processo de instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="855"/>
        <source>This feature is designed to replace an installation performed using the regular install method, and may fail to replace an installation with a complex layout or storage scheme. Corruption or data loss may occur.</source>
        <translation>Este recurso foi projetado para substituir uma instalação que utilizou o método de instalação regular e pode não conseguir substituir uma instalação com um leiaute ou um esquema de armazenamento complexo. Pode corromper os dados ou ocorrer a perda dos dados na unidade de armazenamento.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="857"/>
        <source>To replace an installation with a complex layout or storage scheme, it is recommended to use the custom layout option instead.</source>
        <translation>Para substituir uma instalação com um leiaute ou um esquema de armazenamento complexo, recomenda-se utilizar a opção do leiaute personalizado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="865"/>
        <source>Choose Partitions</source>
        <translation>Escolher as Partições</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="866"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>A lista de partições permite que você escolha quais partições são utilizadas para esta instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="867"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Dispositivo&lt;/i&gt; - Este é o nome do dispositivo de bloco (dispositivo de armazenamento) que é, ou que será, atribuído à partição criada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="868"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Tamanho&lt;/i&gt; - O tamanho da partição só pode ser alterado em um novo leiaute.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="869"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Utilizar Para&lt;/i&gt; - Você tem que selecionar esta partição para utilizar em uma instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="871"/>
        <source>Format without mounting</source>
        <translation>Formatar sem montar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="872"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>Partição GPT de inicialização do BIOS para o GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="873"/>
        <location filename="../minstall.cpp" line="912"/>
        <source>EFI System Partition</source>
        <translation>Partição do Sistema EFI</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="875"/>
        <source>Boot manager</source>
        <translation>Gerenciador de inicialização</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="876"/>
        <source>System root</source>
        <translation>Raiz do sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="877"/>
        <source>User data</source>
        <translation>Dados do usuário</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="878"/>
        <source>Static data</source>
        <translation>Dados estáticos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="879"/>
        <source>Variable data</source>
        <translation>Dados variáveis</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="880"/>
        <source>Temporary files</source>
        <translation>Arquivos temporários</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="881"/>
        <source>Swap files</source>
        <translation>Arquivos de trocas (swap)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="882"/>
        <source>Swap partition</source>
        <translation>Partição de trocas (swap)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="884"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Além do que foi referido acima, você também pode digitar o seu próprio ponto de montagem. Os pontos de montagem personalizados devem começar com uma barra (“/”).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="885"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>Rótulo - O rótulo que é atribuído à partição depois de ter sido formatado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="886"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Criptografar&lt;/i&gt; ou &lt;i&gt;Encriptar&lt;/i&gt; - Utilizar a criptografia/encriptação LUKS para esta partição. A senha se aplica a todas as partições selecionadas para criptografia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="887"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Formato&lt;/i&gt; - Este é o formato da partição. Os formatos disponíveis dependem para o que a partição será utilizada. Ao trabalhar com um leiaute existente, você pode ser capaz de preservar o formato da partição, selecionando a opção &lt;b&gt;Preservar&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="889"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>Selecione a opção &lt;b&gt;Preservar a ‘/home’&lt;/b&gt; para a partição de ‘root’ (raiz) preservar o conteúdo do diretório ‘/home’, excluindo todo o resto. Esta opção só pode ser utilizada quando a ‘/home’ estiver na mesma partição que a partição raiz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="891"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Os sistemas de arquivos do GNU/Linux do tipo ext2, ext3, ext4, jfs, xfs e btrfs são suportados e o ext4 é o formato recomendado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="892"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Verificar (Check)&lt;/i&gt; - Verifica e corrige os blocos defeituosos no dispositivo (não é compatível com todos os formatos). Esta opção consome muito tempo, então você pode querer pular esta etapa, a menos que suspeite que o seu dispositivo possui blocos defeituosos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="894"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Opções de Montagem&lt;/i&gt; - Especifica as opções de montagem que serão utilizadas para esta partição.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="895"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Despejar&lt;/i&gt; - Transmite ao utilitário ‘dump’ instruções para incluir esta partição na cópia de segurança.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="896"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Passar&lt;/i&gt; - A sequência na qual este sistema de arquivos deve ser verificado na inicialização. Se for zero, o sistema de arquivos não será verificado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="897"/>
        <source>Menus and actions</source>
        <translation>Menus e ações</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="898"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Uma variedade de ações estão disponíveis clicando com o botão direito em cima de qualquer unidade de armazenamento ou em um item de uma partição da lista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="899"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Os botões à direita da lista também podem ser utilizados para manipular as entradas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="900"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>O instalador não pode modificar o leiaute já existente em uma unidade de armazenamento. Para criar um leiaute personalizado, marque ou selecione a unidade de armazenamento para um novo leiaute com a ação de menu &lt;b&gt;Novo Leiaute&lt;/b&gt; ou com o botão (%1). Isto limpará o leiaute existente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="903"/>
        <source>Basic layout requirements</source>
        <translation>Requisitos básicos do leiaute</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="904"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>O %1 requer uma partição raiz ( / ou root). A partição de trocas (swap) é opcional, mas é altamente recomendada. Se você quiser utilizar o recurso Hibernar (Suspender para o Disco) do %1, você precisará de uma partição de trocas (swap) maior do que a memória RAM física disponível no seu computador.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="906"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Se você escolher uma partição ‘/home’ separada facilitará no futuro a substituição do sistema atual por uma nova versão. Mas se o sistema instalado não tiver em uma partição ‘/home’ separada, não será possível criá-la posteriormente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="908"/>
        <source>Active partition</source>
        <translation>Partição Ativa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="909"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Para que o sistema operacional instalado seja inicializado, a partição apropriada tem que ser marcada ou selecionada como ativa. Geralmente, a partição de inicialização é a raiz ( / ou root).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="910"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>A partição ativa de uma unidade de armazenamento pode ser escolhida utilizando a ação do menu &lt;b&gt;Partição Ativa&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="911"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Uma partição com um asterisco (*) ao lado do nome do dispositivo é, ou se tornará, a partição ativa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="913"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Se o seu computador utiliza EFI (Extensible Firmware Interface ou Interface Extensível do Conjunto de Instruções Operacionais), uma partição conhecida como ESP (EFI System Partition ou Partição do Sistema EFI) é necessária para a inicialização do sistema operacional.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="914"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Este sistema não requer nenhuma partição marcada como ‘Ativa’, mas requer uma partição formatada com um sistema de arquivos FAT (File Allocation Table ou Tabela de Alocação de Arquivos), marcada como ESP (EFI System Partition ou Partição do Sistema EFI).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="915"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>A maioria dos sistemas construídos nos últimos 10 anos utiliza o EFI (Extensible Firmware Interface ou Interface Extensível do Conjunto de Instruções Operacionais).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="916"/>
        <source>Boot partition</source>
        <translation>Partição de inicialização</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="917"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Esta partição é geralmente necessária apenas para partições de ‘root’ (raiz) em dispositivos virtuais como volumes criptografados/encriptados por programas LVM (Logical Volume Manager) ou RAID (Redundant Array of Inexpensive Drives).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="918"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Ele contém um núcleo (kernel) básico e controladores (drivers) utilizados para acessar o disco criptografado/encriptado ou dispositivos virtuais.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="919"/>
        <source>BIOS-GRUB partition</source>
        <translation>Partição BIOS-GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="920"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>Ao utilizar uma unidade de armazenamento com formato GPT (GUID Partition Table ou Tabela de Partição GUID) em um sistema não ESP (EFI System Partition ou Partição do Sistema EFI), uma partição de inicialização do BIOS de 1 MB é necessária ao utilizar o GRUB (GNU GRand Unified Bootloader ou Carregador de Inicialização Unificado GRand).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="921"/>
        <source>Need help creating a layout?</source>
        <translation>Você precisa de ajuda para criar um leiaute?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="922"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Basta clicar com o botão direito em uma unidade de armazenamento e selecionar &lt;b&gt;Criador de Leiautes&lt;/b&gt; no menu. Esta opção pode criar um leiaute semelhante ao da instalação normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="923"/>
        <source>Upgrading</source>
        <translation>Atualizando</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="924"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Para atualizar a partir de uma instalação GNU/Linux existente, selecione a mesma partição ‘home’ de antes e selecione a opção &lt;b&gt;Preservar&lt;/b&gt; com o mesmo formato.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="925"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Se você não utilizar uma partição ‘home’ separada, selecione &lt;b&gt;Preservar a ‘/home’&lt;/b&gt; na entrada do sistema de arquivos ‘root’ (raiz) para preservar o diretório ‘/home’ existente localizado em sua partição ‘root’. O instalador preservará apenas ‘/home’ e excluirá ou apagará todo o restante. Como resultado, a instalação irá demorar muito mais do que o habitual.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="927"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipo do Sistema de Arquivos Preferido</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="928"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Para %1, você pode optar por formatar as partições como ext2, ext3, ext4, f2fs, jfs, xfs ou btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="929"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>A partições formatadas como btrfs podem utilizar opções adicionais de compressão. O sistema lzo proporciona rapidez de compressão, mas a taxa de compressão é menor. O sistema zlib proporciona maior compressão, mas menor rapidez.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="931"/>
        <source>System partition management tool</source>
        <translation>Ferramenta de gerenciamento de partições do sistema operacional</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="932"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Para obter mais controle sobre os leiautes da unidade de armazenamento (como modificar o leiaute existente em um dispositivo de armazenamento), clique no botão do gerenciador de partições (%1). Esta opção executará a ferramenta de gerenciamento de partições do sistema operacional, que permitirá que você crie o leiaute exato de que precisa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="938"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Para preservar uma partição criptografada, clique com o botão direito do rato/mouse sobre ela e selecione &lt;b&gt;Desbloquear&lt;/b&gt;. Na caixa de diálogo que aparece, insira um nome e a senha para o dispositivo virtual. Quando o dispositivo está desbloqueado, o nome que você escolheu será exibido nos &lt;i&gt;Dispositivos Virtuais&lt;/i&gt;, com opções similares às de uma partição normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="940"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Para que a partição criptografada/encriptada seja desbloqueada na inicialização, ela precisa ser adicionada ao arquivo ‘crypttab’. Utilize a ação do menu &lt;b&gt;Adicionar ao crypttab&lt;/b&gt; para fazer isto.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="941"/>
        <source>Other partitions</source>
        <translation>Outras partições</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="942"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>O instalador permite que outras partições sejam criadas ou utilizadas para outros fins, no entanto, esteja ciente de que os computadores mais antigos não podem lidar com acionamentos de unidades de armazenamento com mais de 4 partições.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="943"/>
        <source>Subvolumes</source>
        <translation>Subvolumes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="944"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Alguns sistemas de arquivos, como Btrfs, oferecem suporte a vários subvolumes em uma única partição. Estas não são subdivisões físicas e, portanto, sua ordem não importa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="946"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Utilize a ação do menu &lt;b&gt;Verificar os subvolumes&lt;/b&gt; para pesquisar os subvolumes em uma partição Btrfs existente. Para criar um novo subvolume, utilize a ação do menu &lt;b&gt;Novo subvolume&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="948"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Os subvolumes existentes podem ser preservados, mas o nome tem que permanecer o mesmo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="949"/>
        <source>Virtual Devices</source>
        <translation>Dispositivos Virtuais</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="950"/>
        <source>If the installer detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Se o instalador do antiX detectar dispositivos virtuais, por exemplo, partições abertas do tipo LUKS, volumes lógicos do tipo LVM ou volumes do tipo RAID baseados em programas de máquinas virtuais. Estes dispositivos virtuais poderão ser utilizados para a instalação do antiX.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="951"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>A utilização de dispositivos virtuais (além de preservar sistemas de arquivos criptografados) é um recurso avançado. Você pode ter que editar alguns arquivos (por exemplo: initramfs, crypttab e fstab) para garantir que os dispositivos virtuais utilizados sejam criados na inicialização.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="956"/>
        <source>You have chosen to encrypt at least one volume, and more information is required before continuing.</source>
        <translation>Você escolheu criptografar/encriptar pelo menos um volume (partição ou disco), contudo, são necessárias mais informações antes de continuar com o processo de instalação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="961"/>
        <source>Final Review and Confirmation</source>
        <translation>Revisão Final e Confirmação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="962"/>
        <source>Please review this list carefully. This is the last opportunity to check, review and confirm the actions of the installation process before proceeding.</source>
        <translation>Por favor, revise esta lista com atenção. Esta é a sua última oportunidade para verificar, revisar e confirmar as ações do processo de instalação antes de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="972"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalar o GRUB para o GNU/Linux e o Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="973"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>O %1 utiliza o gerenciador/carregador de inicialização (bootloader) GRUB para inicializar o sistema operacional %1, Windows ou outro instalado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="974"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Por padrão, o GRUB (GNU GRand Unified Bootloader ou Carregador de Inicialização Unificado GRand) será instalado no MBR (Master Boot Record ou Registro Mestre de Inicialização) ou na ESP (EFI System Partition ou Partição do Sistema EFI), no caso de sistemas de 64 bits com UEFI, do seu dispositivo de armazenamento (do disco de inicialização se o computador tiver mais do que um disco) e substituirá o gerenciador/carregador de inicialização que estava instalado antes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="975"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Se você optar por instalar o GRUB (GNU GRand Unified Bootloader ou Carregador de Inicialização Unificado GRand) na PBR (Partition Boot Record ou Registro de Inicialização da Partição) ou na raiz do dispositivo de armazenamento, ele será instalado no início da partição escolhida. Esta opção não deve ser utilizada pelos usuários inexperientes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="976"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Se você desmarcar a opção ‘Instalar o GRUB para o GNU/Linux e Windows’, o GRUB (GNU GRand Unified Bootloader ou Carregador de Inicialização Unificado GRand) não será instalado neste momento. Os usuários inexperientes não devem desmarcar esta opção.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="977"/>
        <source>Generate host-specific initramfs will try to create an initramfs tailored for the particular device rather than a generic all-purpose initramfs. This option is for experts only.</source>
        <translation>Gerar o ‘initramfs’ específico do hospedeiro (host) e tentar criar um ‘initramfs’ personalizado para o dispositivo em questão, em vez de um ‘initramfs’ genérico para todos os fins. Esta opção é apenas para os usuários especialistas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="985"/>
        <source>Zram swap is a method of putting swap space in RAM.  A compressed swap device is placed in RAM.  It may be used in conjunction with other forms of swap, or on its own.</source>
        <translation>A memória de trocas ZRAM é um método que permite ‘criar’ espaço na memória RAM física compactando os dados que são armazenados na memória RAM, este método pode ser utilizado em conjunto com outras formas de trocas (swap) ou sozinho.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1404"/>
        <source>Welcome to %1 Installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1418"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Reinicializar automaticamente o sistema operacional quando o instalador for fechado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1519"/>
        <location filename="../minstall.cpp" line="1529"/>
        <source> %:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1611"/>
        <source>Installation Confirmation</source>
        <translation>Confirmação da Instalação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1617"/>
        <source>Please review the installation settings.

This is the last opportunity to check and confirm
the actions of the installation process.

Press ENTER to begin installation or Backspace to go back.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1642"/>
        <source>Enter computer name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1657"/>
        <source>Enter domain name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>Workgroup</source>
        <translation>Grupo de Trabalho</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Localization Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>Locale:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Time Area:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Time Zone:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>System services will be configured with default settings.
You can modify service settings after installation
using your system's service manager.

Press ENTER to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>Replace Existing Installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1881"/>
        <source>Attempt to upgrade packages</source>
        <translation>Tentar atualizar os pacotes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1899"/>
        <source>Custom Partitioning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1914"/>
        <source>Swap File Configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1927"/>
        <source>Location:</source>
        <translation>Local:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1938"/>
        <source>Size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1952"/>
        <source>R: reset size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1958"/>
        <source>Enable hibernation support</source>
        <translation>Ativar a compatibilidade de hibernação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1964"/>
        <source>Zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1969"/>
        <source>Enable zram swap</source>
        <translation>Ativar a memória de trocas ZRAM</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1976"/>
        <source>Allocate based on RAM (%):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1991"/>
        <source>Allocate fixed size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2138"/>
        <source>Encryption options</source>
        <translation>Opções de criptografia/encriptação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2143"/>
        <source>Encryption password:</source>
        <translation>Senha de criptografia/encriptação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2154"/>
        <source>Confirm password:</source>
        <translation>Confirmar a senha:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2192"/>
        <source>Enter username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2206"/>
        <source>Enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2219"/>
        <source>Re-enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2285"/>
        <source>A home directory already exists for this user name.
Choose what to do with it:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2329"/>
        <source>The system is being installed.
This may take several minutes.

Press ENTER to continue to completion screen.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3641"/>
        <source>Passwords must match and not be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3969"/>
        <source>Please enter a computer name.</source>
        <translation>Por favor, insira o nome do computador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3972"/>
        <source>The computer name contains invalid characters.</source>
        <translation>O nome do computador contém caracteres que não são válidos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3975"/>
        <source>Please enter a domain name.</source>
        <translation>Por favor, insira um nome de domínio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3978"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>O nome do domínio do computador contém caracteres que não são válidos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="3981"/>
        <source>Please enter a workgroup.</source>
        <translation>Por favor, insira um grupo de trabalho</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4267"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>O nome do usuário não pode conter caracteres especiais ou espaços.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4270"/>
        <location filename="../minstall.cpp" line="4273"/>
        <source>Please ensure the passwords match.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4288"/>
        <source>The chosen user name is in use.</source>
        <translation>O nome do usuário que foi inserido está sendo utilizado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4292"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Você não forneceu uma senha para %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4300"/>
        <source>You did not provide a password for the root account.</source>
        <translation>Você não forneceu uma senha para a conta de ‘root’ (administrador).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4387"/>
        <source>Please select an option to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="982"/>
        <location filename="../minstall.cpp" line="1919"/>
        <source>Create a swap file</source>
        <translation>Criar um arquivo de trocas (swap)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="278"/>
        <source>Experimental</source>
        <comment>As In feature is not polished and may not work properly</comment>
        <translation>Este é um recurso experimental</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="983"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Um arquivo de trocas ou arquivo de ‘swap’ é mais fácil de ser ajustado do que uma partição de trocas. É consideravelmente mais fácil redimensionar um arquivo de trocas para adaptá-lo às modificações na utilização do sistema operacional do que de uma partição de trocas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="984"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Por padrão, esta opção é verificada se nenhuma partição de trocas foi definida e tenha sido desmarcada se as partições de trocas foram definidas. Esta opção deve ser deixada intacta e é apenas para os especialistas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="990"/>
        <source>Common Services to Enable</source>
        <translation>Ativar os Serviços Comuns</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="991"/>
        <source>Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.</source>
        <translation>Selecione qualquer um destes serviços comuns que você pode precisar com as configurações do seu sistema e os serviços que serão iniciados automaticamente quando você iniciar o %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="996"/>
        <source>Computer Identity</source>
        <translation>Identidade do Computador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="997"/>
        <source>The computer name is a common unique name which will identify your computer if it is on a network.</source>
        <translation>O nome do computador é um nome único e comum que identificará o seu computador se ele estiver em uma rede.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="998"/>
        <source>The computer domain is unlikely to be used unless your ISP or local network requires it.</source>
        <translation>É improvável que o domínio do computador seja utilizado, a menos que o seu provedor de serviços de internet ou se a sua rede local exijam esta informação.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="999"/>
        <source>The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens.</source>
        <translation>O nome do computador e o nome do domínio podem conter somente caracteres alfanuméricos, pontos e hifens. Mas não podem conter espaços em branco e nem começar ou terminar com hifens.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1001"/>
        <source>The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.</source>
        <translation>O servidor SaMBa precisa ser ativado se você quiser utilizá-lo para compartilhar algumas das suas pastas ou impressoras com um computador local que esteja executando o sistema operacional Windows ou o MacOS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1006"/>
        <source>Localization Defaults</source>
        <translation>Padrões de Localização</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1007"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Defina o local padrão. Isto se aplicará a menos que sejam substituídos posteriormente pelo usuário.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1008"/>
        <source>Configure Clock</source>
        <translation>Configurar o Relógio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1009"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Se você tiver um computador Apple ou um Unix puro, por padrão, o relógio do sistema é definido para o Horário do Meridiano de Greenwich (Greenwich Meridian Time - GMT) ou Tempo Universal Coordenado (Coordinated Universal Time - UTC). Para alterar esta opção, marque a caixa “&lt;b&gt;O relógio do sistema utiliza a hora local&lt;/b&gt;”.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1011"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>O sistema inicializa com o fuso horário predefinido para GMT/UTC. Para alterar o fuso horário, após reiniciar na nova instalação, clique com o botão direito do rato/mouse sobre o relógio no Painel e selecione Propriedades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1013"/>
        <source>Service Settings</source>
        <translation>Configurações de Serviços</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1014"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>A maioria dos usuários não devem alterar os padrões. Os usuários com computadores que possuem poucos recursos (processamento e memória RAM), podem querer desativar alguns serviços desnecessários para manter o uso da memória RAM o mais baixo possível. Certifique-se de que você sabe o que está fazendo!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1021"/>
        <source>Default User Login</source>
        <translation>Acesso (Login) do Usuário Padrão</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1022"/>
        <source>Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Por favor, insira o nome para uma nova conta de usuário (padrão) que você utilizará diariamente. Se for necessário, você poderá adicionar outras contas de usuários mais tarde com o programa Gerenciador de Usuários do %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1024"/>
        <source>Root (administrator) account</source>
        <translation>Conta de Root (Administrador)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1025"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account.</source>
        <translation>O usuário ‘root’ ou a conta de ‘root’ é similar ao usuário ‘Administrator’ em outros sistemas operacionais. Você não deve utilizar o usuário ‘root’ como sua conta de usuário diária.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1027"/>
        <source>The root account is disabled on MX Linux, as administrative tasks are performed with an elevation prompt for the default user.</source>
        <translation>A conta de ‘root’ é desativada no MX Linux, pois as tarefas administrativas são executadas com um ‘prompt’ na linha de comandos de elevação para o usuário padrão.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1028"/>
        <source>Enabling the root account is strongly recommended for antiX Linux.</source>
        <translation>É altamente recomendável ativar a conta de ‘root’ no antiX Linux.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1029"/>
        <source>Passwords</source>
        <translation>Senhas </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1030"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Insira uma nova senha para sua conta de usuário padrão e para a conta de ‘root’. Cada senha deve ser inserida duas vezes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1032"/>
        <source>No passwords</source>
        <translation>Nenhuma senha</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1033"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Se você quiser que a conta de usuário padrão não tenha senha, deixe os campos de senha em branco. Isso permite que você faça o acesso (login) sem exigir uma senha.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1035"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Obviamente, isto só deve ser feito em situações onde a conta do usuário não precisa ser segura, como por exemplo, em um terminal público.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1044"/>
        <location filename="../minstall.cpp" line="2279"/>
        <source>Old Home Directory</source>
        <translation>Pasta ‘Home’ Antiga</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1045"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Já existe uma pasta pessoal (diretório pessoal) para o nome de usuário que você escolheu. Esta tela permite que você escolha o que fazer com esta pasta ou diretório.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1047"/>
        <location filename="../minstall.cpp" line="2291"/>
        <source>Re-use it for this installation</source>
        <translation>Reutilize-a para esta instalação</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1048"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>A pasta (diretório) ‘home’ antiga será utilizada para esta conta de usuário. Esta é uma boa opção no caso de atualização do sistema operacional, pois os arquivos e configurações do usuário estarão imediatamente disponíveis.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1050"/>
        <location filename="../minstall.cpp" line="2298"/>
        <source>Rename it and create a new directory</source>
        <translation>Renomear e criar uma nova pasta (diretório)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1051"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Será criada uma nova pasta pessoal (diretório pessoal) para o usuário e a pasta antiga será renomeada. Os arquivos e as configurações do usuário não ficarão imediatamente visíveis na nova instalação, mas podem ser acessados utilizando a pasta renomeada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1053"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>A pasta pessoal (diretório pessoal) antiga receberá um número no final do nome, que dependerá da quantidade de vezes que a pasta tenha sido renomeada antes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1054"/>
        <location filename="../minstall.cpp" line="2305"/>
        <source>Delete it and create a new directory</source>
        <translation>Apagar e criar uma nova pasta (diretório)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1055"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>A pasta pessoal (diretório pessoal) antiga será apagada e será criada um nova.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="853"/>
        <location filename="../minstall.cpp" line="1056"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1057"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Se esta opção for selecionada, todos os arquivos e configurações serão excluídos/apagados permanentemente. A probabilidade de virem a ser recuperados é baixa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1069"/>
        <location filename="../minstall.cpp" line="2323"/>
        <source>Installation in Progress</source>
        <translation>A instalação está em andamento</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1070"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>O %1 está sendo instalado. Para uma nova instalação, provavelmente irá demorar de 3 a 20 minutos, dependendo da velocidade do seu equipamento e do tamanho das partições que estão sendo reformatadas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1072"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Se você clicar no botão ‘Abortar’, a instalação será interrompida assim que for possível.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1074"/>
        <source>Change settings while you wait</source>
        <translation>Altere as configurações enquanto você espera</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1075"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Enquanto o %1 está sendo instalado, é possível inserir as outras informações que são solicitadas clicando nos botões &lt;b&gt;Próximo&lt;/b&gt; ou &lt;b&gt;Voltar&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1077"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Complete estas etapas sem pressa. O instalador aguardará estas informações se for necessário.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1084"/>
        <source>Congratulations!</source>
        <translation>Meus parabéns!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1085"/>
        <source>You have completed the installation of %1.</source>
        <translation>Você concluiu com sucesso a instalação do %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1086"/>
        <source>Finding Applications</source>
        <translation>Encontrando os Programas</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1087"/>
        <source>There are hundreds of excellent applications installed with %1. The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus.</source>
        <translation>Existem centenas de programas excelentes que estão instalados no %1. A melhor maneira de conhecê-los é navegando pelo menu e experimentá-los. Muitos dos programas foram desenvolvidos especificamente para o projeto do %1. Eles são exibidos nos menus principais.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1091"/>
        <source>In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.</source>
        <translation>Além disso, o %1 inclui vários programas do GNU/Linux que são executados somente por meio da linha de comandos ou interface de texto e, portanto, não são exibido no menu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1093"/>
        <source>Enjoy using %1</source>
        <translation>Divirta-se ao utilizar o %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1126"/>
        <source>Finish</source>
        <translation>Finalizar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1132"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1134"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1259"/>
        <source>The installation and configuration is incomplete.</source>
        <translation>A instalação e as configurações não estão completas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1260"/>
        <source>Do you really want to stop now?</source>
        <translation>Você realmente quer parar agora?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1337"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Obtenha Ajuda&lt;/b&gt;&lt;br/&gt;Informações básicas sobre o %1 estão disponíveis em %2.&lt;/p&gt;&lt;p&gt;Há voluntários que prestam ajuda no fórum do %3, %4 (maioritariamente em idioma inglês)&lt;/p&gt;&lt;p&gt;Ao solicitar ajuda, lembre-se de descrever o seu problema e o seu computador com detalhes. Normalmente, afirmações como ‘(algo) não funcionou’ não ajudam a proporcionar uma boa ajuda.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparando o Sistema Operacional&lt;/b&gt;&lt;br/&gt;Se o %1 parar de funcionar no disco rígido, SSD, NVMe, etc., às vezes é possível corrigir o problema inicializando a partir de um dispositivo externo executável CD/DVD ou USB, executando um dos utilitários que estão incluídos no %1 ou utilizando uma das ferramentas do GNU/Linux para reparar o sistema operacional.&lt;/p&gt;&lt;p&gt;O %1 em CD/DVD executável ou em um dispositivo USB executável (Live USB), pode ser utilizado para recuperar os dados nos sistemas operacionais Windows da Microsoft!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1351"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ajustando o Misturador de Som&lt;/b&gt;&lt;br/&gt;O %1 tenta configurar o misturador de som (sound mixer), mas por vezes é necessário aumentar o volume ou desativar a função ‘mute’ (mudo) nos canais do misturador para que se possa ouvir o som. &lt;/p&gt;&lt;p&gt;O atalho para o misturador está localizado no menu. Clique para abrir o misturador.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1359"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mantenha o Seu %1 Atualizado&lt;/b&gt;&lt;br/&gt;Para mais informações e atualizações do %1, por favor, visite&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Agradecimentos Especiais&lt;/b&gt;&lt;br/&gt;Agradecemos a todos os que decidiram apoiar o %1 com o seu tempo, os seus donativos, com as suas sugestões, o seu trabalho, os seus elogios, as suas ideias, promovendo-o e/ou encorajando-nos.&lt;/p&gt;&lt;p&gt;Sem vocês o %1 não existiria.&lt;/p&gt;&lt;p&gt;A equipe de desenvolvimento do %2&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ajuda</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Arquivo de Registro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Voltar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="78"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="85"/>
        <source>Next</source>
        <translation>Próximo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="91"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="114"/>
        <source>Installation in progress</source>
        <translation>A instalação está em andamento</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="129"/>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="132"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Close</source>
        <translation>Fechar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="168"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Por favor, aguarde a coleta de informações.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="200"/>
        <source>Terms of Use</source>
        <translation>Termos de Utilização</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="232"/>
        <source>Keyboard Settings</source>
        <translation>Configurações do Teclado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="247"/>
        <source>Model:</source>
        <translation>Modelo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="262"/>
        <source>Variant:</source>
        <translation>Variante:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>Change Keyboard Settings</source>
        <translation>Alterar as Configurações do Teclado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="294"/>
        <source>Layout:</source>
        <translation>Leiaute:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="341"/>
        <source>Select type of installation</source>
        <translation>Selecionar o tipo de instalação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="414"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <source>Home</source>
        <translation>Início</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="499"/>
        <location filename="../meinstall.ui" line="521"/>
        <location filename="../meinstall.ui" line="1153"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="534"/>
        <source>Encrypt</source>
        <translation>Criptografar/Encriptar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1121"/>
        <source>Enable hibernation support</source>
        <translation>Ativar a compatibilidade de hibernação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="353"/>
        <source>Regular install using the entire disk</source>
        <translation>Instalação regular utilizando todo o disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Dual drive</source>
        <translation>Acionamento duplo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="370"/>
        <source>System drive:</source>
        <translation>Unidade de armazenamento do sistema operacional:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="380"/>
        <source>Home drive:</source>
        <translation>Unidade de armazenamento da pasta pessoal:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="544"/>
        <source>Customize the disk layout</source>
        <translation>Personalizar o leiaute do disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="551"/>
        <source>Replace existing installation</source>
        <translation>Substituir a instalação existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="590"/>
        <source>Replace an existing installation</source>
        <translation>Substituir uma instalação existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="612"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="617"/>
        <source>Installation</source>
        <translation>Instalação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="625"/>
        <source>Scan for existing installations</source>
        <translation>Pesquisar por instalações existentes</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="646"/>
        <source>Replacement options</source>
        <translation>Opções de substituição</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Attempt to upgrade packages</source>
        <translation>Tentar atualizar os pacotes</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="663"/>
        <source>Choose partitions</source>
        <translation>Escolher as partições</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="672"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Marque ou selecione a unidade de armazenamento para ser limpa e para ser criado um novo leiaute.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="683"/>
        <source>Show Grid</source>
        <translation>Exibir as Grades</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="703"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Executar o programa gerenciador de partições GParted do sistema operacional.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="714"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Remover uma entrada existente do leiaute. Isto só funciona com entradas para um novo leiaute.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="725"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Consulte o sistema operacional e recarregue os leiautes de todas as unidades de armazenamento.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="750"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Adicione uma nova entrada de partição. Isto só funciona com um novo leiaute.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="761"/>
        <source>Show advanced fields.</source>
        <translation>Exibir os campos das opções avançadas.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="791"/>
        <source>Encryption options</source>
        <translation>Opções de criptografia/encriptação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="797"/>
        <source>Encryption password:</source>
        <translation>Senha de criptografia/encriptação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="814"/>
        <source>Confirm password:</source>
        <translation>Confirmar a senha:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="842"/>
        <source>Installation Confirmation</source>
        <translation>Confirmação da Instalação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="885"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalar o GRUB para o GNU/Linux e o Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="900"/>
        <source>System boot disk:</source>
        <translation>Disco de inicialização do sistema operacional:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="942"/>
        <source>EFI System Partition</source>
        <translation>Partição de Sistema EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="945"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="964"/>
        <source>Partition Boot Record</source>
        <translation>Partition Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="967"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="989"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="995"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="998"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1011"/>
        <source>Location to install on:</source>
        <translation>Local para instalar:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1018"/>
        <source>Generate host-specific initramfs image</source>
        <translation>Gerar a imagem do ‘initramfs’ específica do hospedeiro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1051"/>
        <source>Create a swap file</source>
        <translation>Criar um arquivo de trocas (swap)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <location filename="../meinstall.ui" line="1192"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1091"/>
        <source>Size:</source>
        <translation>Tamanho:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1114"/>
        <source>Location:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1131"/>
        <source>Enable zram swap</source>
        <translation>Ativar a memória de trocas ZRAM</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1143"/>
        <source>Allocate based on RAM:</source>
        <translation>Alocar com base na memória RAM:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1172"/>
        <source>Recommended maximum: 100%</source>
        <translation>O valor máximo recomendado é 100%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1179"/>
        <source>Allocate fixed size:</source>
        <translation>Alocar com o tamanho fixado em:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1223"/>
        <source>Common Services to Enable</source>
        <translation>Ativar os Serviços Comuns</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1233"/>
        <source>Service</source>
        <translation>Serviço</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1238"/>
        <source>Description</source>
        <translation>Descrição</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1268"/>
        <source>Computer Network Names</source>
        <translation>Nomes dos Computadores na Rede</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1295"/>
        <source>Workgroup</source>
        <translation>Grupo de trabalho</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1308"/>
        <source>Workgroup:</source>
        <translation>Grupo de trabalho:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1321"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Servidor de arquivos SaMBa para interação em rede com sistemas MS Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>example.dom</source>
        <translation>exemplo.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1350"/>
        <source>Computer domain:</source>
        <translation>Domínio do computador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1373"/>
        <source>Computer name:</source>
        <translation>Nome do computador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1416"/>
        <source>Localization Defaults</source>
        <translation>Padrões de Localização</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1437"/>
        <source>Locale:</source>
        <translation>Localização:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1456"/>
        <source>Configure Clock</source>
        <translation>Configurar o Relógio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1491"/>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Timezone:</source>
        <translation>Fuso Horário:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1558"/>
        <source>System clock uses local time</source>
        <translation>O relógio do sistema operacional utiliza a hora local</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1580"/>
        <source>Service Settings (advanced)</source>
        <translation>Configurações de Serviços (avançados)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1598"/>
        <source>Adjust which services should run at startup</source>
        <translation>Definir quais serviços devem ser executados na inicialização</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1601"/>
        <source>View</source>
        <translation>Exibir</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1650"/>
        <source>Default User Account</source>
        <translation>Conta de Usuário Padrão</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1662"/>
        <source>Default user login name:</source>
        <translation>Nome de acesso (login) do usuário padrão:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1678"/>
        <source>username</source>
        <translation>nomedeusuario</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1691"/>
        <source>Default user password:</source>
        <translation>Senha de usuário padrão:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Confirm user password:</source>
        <translation>Confirmar a senha de usuário:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1746"/>
        <source>Root (administrator) Account</source>
        <translation>Conta de Root (Administrador)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1764"/>
        <source>Root password:</source>
        <translation>Senha de Root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1790"/>
        <source>Confirm root password:</source>
        <translation>Confirmar a senha de ‘root’:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1819"/>
        <source>Autologin</source>
        <translation>Iniciar a sessão sem autenticar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1826"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>As alterações da área de trabalho que foram feitas na sessão da instalação externa serão transpostas para o sistema instalado no disco rígido, SSD, NVMe, etc.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1829"/>
        <source>Save live desktop changes</source>
        <translation>Salvar as alterações feitas na área de trabalho da sessão da instalação externa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1859"/>
        <source>Existing Home Directory</source>
        <translation>Pasta ‘Home’ Existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1868"/>
        <source>What would you like to do with the old directory?</source>
        <translation>O que você quer fazer com a pasta pessoal (diretório pessoal) antiga?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1875"/>
        <source>Re-use it for this installation</source>
        <translation>Reutilizar para esta instalação</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1882"/>
        <source>Rename it and create a new directory</source>
        <translation>Renomear e criar uma nova pasta pessoal (diretório pessoal)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1889"/>
        <source>Delete it and create a new directory</source>
        <translation>Apagar e criar uma nova pasta pessoal (diretório pessoal)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1907"/>
        <source>Tips</source>
        <translation>Dicas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1939"/>
        <source>Installation complete</source>
        <translation>A instalação foi concluída</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1945"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Reinicializar automaticamente o sistema operacional quando o instalador for fechado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1964"/>
        <source>Reminders</source>
        <translation>Lembretes</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="359"/>
        <source>Please enter a computer name.</source>
        <translation>Por favor, insira o nome do computador</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="363"/>
        <source>The computer name contains invalid characters.</source>
        <translation>O nome do computador contém caracteres que não são válidos.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="364"/>
        <location filename="../oobe.cpp" line="375"/>
        <location filename="../oobe.cpp" line="595"/>
        <source>Please choose a different name before proceeding.</source>
        <translation>Por favor, escolha um outro nome antes de continuar.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="370"/>
        <source>Please enter a domain name.</source>
        <translation>Por favor, insira um nome de domínio</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="374"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>O nome do domínio do computador contém caracteres que não são válidos.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="383"/>
        <source>Please enter a workgroup.</source>
        <translation>Por favor, insira um grupo de trabalho</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="600"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>O nome do usuário não pode conter caracteres especiais ou espaços.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="610"/>
        <source>The chosen user name is in use.</source>
        <translation>O nome do usuário que foi inserido está sendo utilizado.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="619"/>
        <source>Are you sure you want to continue?</source>
        <translation>Você tem certeza de que quer continuar?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="624"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Você não forneceu uma senha para %1.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="629"/>
        <source>You did not provide a password for the root account.</source>
        <translation>Você não forneceu uma senha para a conta de ‘root’ (administrador).</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="642"/>
        <source>Failed to set user account passwords.</source>
        <translation>Ocorreu uma falha ao definir as senhas para a conta do usuário.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="674"/>
        <source>Failed to save old home directory.</source>
        <translation>Ocorreu uma falha ao guardar a pasta ‘home’ antiga.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="683"/>
        <source>Failed to delete old home directory.</source>
        <translation>Ocorreu uma falha ao apagar a pasta ‘home’ antiga.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="704"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Desculpe-me, ocorreu uma falha ao criar a pasta pessoal (diretório pessoal) do usuário</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="707"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Desculpe-me, ocorreu uma falha ao nomear a pasta pessoal (diretório pessoal) do usuário.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="745"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Ocorreu uma falha ao definir a propriedade ou as permissões do diretório dos usuários.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="257"/>
        <location filename="../partman.cpp" line="883"/>
        <source>Virtual Devices</source>
        <translation>Dispositivos Virtuais</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="533"/>
        <location filename="../partman.cpp" line="584"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Adicionar a partição</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="535"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Remover a partição</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="544"/>
        <source>&amp;Lock</source>
        <translation>&amp;Bloquear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="548"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Desbloquear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="552"/>
        <location filename="../partman.cpp" line="727"/>
        <source>Add to crypttab</source>
        <translation>Adicionar o crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="559"/>
        <source>New subvolume</source>
        <translation>Novo subvolume</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="560"/>
        <source>Scan subvolumes</source>
        <translation>Verificar os subvolumes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="587"/>
        <source>New &amp;layout</source>
        <translation>Novo &amp;leiaute</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Redefinir o leiaute</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="590"/>
        <source>Layout &amp;Builder...</source>
        <translation>&amp;Criador de Leiautes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="617"/>
        <source>Remove subvolume</source>
        <translation>Remover o subvolume</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="721"/>
        <source>Unlock Drive</source>
        <translation>Desbloquear o Dispositivo</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="725"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="757"/>
        <source>Could not unlock device.</source>
        <translation>Não foi possível desbloquear o dispositivo.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="787"/>
        <source>Failed to close %1</source>
        <translation>Ocorreu uma falha ao fechar %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="811"/>
        <source>Invalid subvolume label</source>
        <translation>O rótulo do subvolume não é válido</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="821"/>
        <source>Duplicate subvolume label</source>
        <translation>O rótulo do subvolume está duplicado</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="832"/>
        <source>Invalid use for %1: %2</source>
        <translation>Uso inválido para %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="840"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 já está selecionado para: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="853"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>É necessária uma partição de ‘root’ (raiz) de pelo menos %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="872"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Não é possível preservar a ‘/home’ dentro do ‘root’ (/) se uma partição ‘/home’ separada também estiver montada.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="887"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Preparar a tabela de partição %1 em %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="885"/>
        <source>Re-use partition table on %1</source>
        <translation>Reutilizar a tabela de partição em %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="758"/>
        <source>Possible incorrect password.</source>
        <translation>É possível que a senha não esteja correta.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="894"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Reutilizar (sem reformatar) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="897"/>
        <source>Format %1</source>
        <translation>Formatar %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="898"/>
        <source>Format %1 to use for %2</source>
        <translation>Formatar %1 para utilizar %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="899"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Reutilizar (sem reformatar) %1 como %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="900"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Apagar os dados em %1 exceto na ‘/home’, para utilizar em %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="903"/>
        <source>Create %1 without formatting</source>
        <translation>Cria %1 sem formatação</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="904"/>
        <source>Create %1, format to use for %2</source>
        <translation>Criar %1, o formato a ser utilizado para %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>Reutilizar o subvolume %1 como %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="921"/>
        <source>Delete subvolume %1</source>
        <translation>Apagar o subvolume %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="924"/>
        <source>Overwrite subvolume %1</source>
        <translation>Sobrescrever o subvolume %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="925"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>Sobrescrever o subvolume %1 para utilizar em %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="927"/>
        <source>Create subvolume %1</source>
        <translation>Criar o subvolume %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="928"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>Criar o subvolume %1 para utilizar em %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="944"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Você tem que escolher uma partição de inicialização (boot) diferente quando a partição raiz (root) for criptografada/encriptada.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="982"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) requer %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1008"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>A instalação pode falhar porque os seguintes volumes (ou partições) são muito pequenos:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1010"/>
        <source>Are you sure you want to continue?</source>
        <translation>Você tem certeza de que quer continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1021"/>
        <source>This setup may produce an unbootable system. Do you want to continue?</source>
        <translation>Estas configurações podem resultar em um sistema operacional que não seja inicializável. Você tem certeza de que quer continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1027"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Este computador utiliza o EFI, mas nenhuma partição válida do sistema EFI foi atribuída separadamente a &lt;b&gt;/boot/efi&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1030"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>O volume atribuído a &lt;b&gt;/boot/efi&lt;/b&gt; não é uma partição de sistema EFI válida.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1057"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>As seguintes unidades de armazenamento são, ou serão, configuradas com GPT (GUID Partition Table ou Tabela de Partição GUID), mas não têm uma partição do tipo BIOS-GRUB:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1059"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Este sistema não pode inicializar a partir de unidades de armazenamento GPT sem uma partição do tipo BIOS-GRUB.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1098"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Os discos (IDE, Sata, SSD, NVMe, etc.) com as partições selecionadas para a instalação estão falhando:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1102"/>
        <source>Smartmon tool output:</source>
        <translation>Resultados da ferramenta Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1103"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Os discos (IDE, Sata, SSD, NVMe, etc.) com as partições selecionadas para a instalação passaram no teste de monitorização SMART (smartctl), mas os testes indicam que terão uma taxa de falha superior à média em um futuro próximo.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1110"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Se você não tem certeza, saia do instalador e execute o programa ‘GSmartControl’ para obter mais informações.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1114"/>
        <source>Do you want to abort the installation?</source>
        <translation>Você quer abortar a instalação?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1120"/>
        <source>Do you want to continue?</source>
        <translation>Você quer continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1189"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Ocorreu uma falha ao preparar as partições que foram solicitadas.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1233"/>
        <source>Preparing partition tables</source>
        <translation>Preparando as tabelas de partição</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1261"/>
        <source>Preparing required partitions</source>
        <translation>Preparando as partições solicitadas</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1325"/>
        <source>Failed to format partition.</source>
        <translation>Ocorreu uma falha ao formatar a partição.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1332"/>
        <source>Formatting: %1</source>
        <translation>Formatando: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1410"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Ocorreu uma falha ao preparar os subvolumes.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1411"/>
        <source>Preparing subvolumes</source>
        <translation>Preparando os subvolumes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1538"/>
        <source>Failed to mount partition.</source>
        <translation>Ocorreu uma falha ao montar a partição.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1551"/>
        <source>Mounting: %1</source>
        <translation>Montagem: % 1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1735"/>
        <source>Model: %1</source>
        <translation>Modelo: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1743"/>
        <source>Free space: %1</source>
        <translation>Espaço livre: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1843"/>
        <source>Device</source>
        <translation>Dispositivo</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1844"/>
        <source>Size</source>
        <translation>Tamanho</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1845"/>
        <source>Active</source>
        <translation>Ativo</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1846"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1847"/>
        <source>Use For</source>
        <translation>Para a Utilização</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1848"/>
        <source>Label</source>
        <translation>Rótulo</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1849"/>
        <source>Encrypt</source>
        <translation>Criptografar/Encriptar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1850"/>
        <source>Format</source>
        <translation>Formato</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1851"/>
        <source>Check</source>
        <translation>Verificar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1852"/>
        <source>Options</source>
        <translation>Opções</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1853"/>
        <source>Dump</source>
        <translation>Despejar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1854"/>
        <source>Pass</source>
        <translation>Passar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1862"/>
        <source>Active partition</source>
        <translation>Partição Ativa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1863"/>
        <source>EFI System Partition</source>
        <translation>Partição de Sistema EFI</translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2681"/>
        <source>&amp;Templates</source>
        <translation>&amp;Modelos</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2688"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Compressão (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2690"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Compressão (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2692"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Compressão (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Negligible</source>
        <translation>Insignificante</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Very weak</source>
        <translation>Muito fraca</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Weak</source>
        <translation>Fraca</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Moderate</source>
        <translation>Moderada</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Strong</source>
        <translation>Forte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Very strong</source>
        <translation>Muito forte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="156"/>
        <source>Password strength: %1</source>
        <translation>Nível de segurança da senha: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Hide the password</source>
        <translation>Ocultar a senha</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Show the password</source>
        <translation>Exibir a senha</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="99"/>
        <source>Gazelle Installer</source>
        <translation>Instalador Gazelle Installer</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="102"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Instalador personalizável do antiX Linux e do MX Linux por interface gráfica do usuário</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="105"/>
        <source>Enable advanced settings, even in regular installation mode.</source>
        <translation>Ative as configurações avançadas, mesmo no modo de instalação normal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="106"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Instala automaticamente utilizando o arquivo de configurações (obtenha mais informações abaixo) .
- AVISO: esta opção é potencialmente perigosa, limpará (apagará) a(s) partição(ões) automaticamente.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="108"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Anula as verificações de integridade em partições e unidades de armazenamento fazendo com que sejam exibidas.
- ATENÇÃO: esta opção pode danificar os seus dados, utilize-a somente se você não se importar com os dados contidos na unidade de armazenamento.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="110"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Carregue um arquivo de configurações conforme especificado por &lt;config-file&gt;.
Por padrão ‘/etc/minstall.conf’ é utilizado.
Estas configurações podem ser utilizadas com --auto para uma instalação autônoma.
O instalador cria (ou sobrescreve) ‘/mnt/antiX/etc/minstall.conf’ e salva uma cópia em ‘/etc/minstalled.conf’ para a utilização futura.
O instalador não gravará nenhuma senha ou configurações ignoradas no novo arquivo de configurações.
Por favor, observe que isto é experimental. As versões futuras do instalador podem quebrar a compatibilidade com os arquivos de configurações antigos existentes.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="116"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Desligar automaticamente quando terminar a instalação do sistema operacional.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="117"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Não desmonte ‘/mnt/antiX’ ou feche qualquer um dos contêineres ‘LUKS’ associados quando finalizar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="118"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Instale o sistema operacional, atrasando os avisos (prompts) das opções específicas do usuário até a primeira reinicialização.
Após a reinicialização, o instalador será executado com --oobe para que o usuário possa fornecer estas informações.
Isto é útil para as instalações OEM (Original Equipment Manufacturer - Fabricante de Equipamento Original), quando um computador é vendido ou distribuído com um sistema operacional pré-instalado no equipamento.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="121"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Opção de Experiência Fora da Caixa (Out Of the Box).
Isto iniciará automaticamente se for instalado com a opção --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Modo de teste da Interface Gráfica do Usuário - GUI, você pode avançar para telas diferentes sem realmente instalar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="124"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Reiniciar automaticamente o computador quando finalizar a instalação.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="125"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Instalando com o ‘rsync’ em vez do ‘cp’ no particionamento personalizado.
-- não formata o ‘/root’ e não funciona com a criptografia/encriptação.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Sempre verifique o dispositivo de instalação ao iniciar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>Não verifique o dispositivo de instalação ao iniciar. Esta opção não é recomendada, a menos que o dispositivo de instalação esteja livre de erros ou de falhas.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Force TUI (Text User Interface) mode instead of GUI.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="131"/>
        <source>Jump directly to a specific page for testing (use with --pretend).
Page names: splash, terms, installation, partitions, confirm, boot, services, user, end</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>&lt;page-name&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="133"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Carregue um arquivo de configurações conforme especificado por &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="143"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Existem muitos argumentos. Por favor, verifique o formato do comando executando o programa com o parâmetro --help</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="153"/>
        <source>%1 Installer</source>
        <translation>Instalador do %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="163"/>
        <source>The installer appears to be running already.</source>
        <translation>O instalador do antiX parece que já está em execução.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="164"/>
        <source>Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Por favor, feche-o se for possível ou execute o comando ‘pkill minstall’ no emulador de terminal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="169"/>
        <location filename="../app.cpp" line="184"/>
        <location filename="../app.cpp" line="209"/>
        <source>Error</source>
        <translation>Ocorreu um erro</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="170"/>
        <source>The installer appears to be running already.
Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="179"/>
        <location filename="../app.cpp" line="185"/>
        <source>This operation requires root access.</source>
        <translation>Esta operação requer o acesso de ‘root’ (administrador).</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="205"/>
        <location filename="../app.cpp" line="210"/>
        <source>Configuration file (%1) not found.</source>
        <translation>O arquivo de configurações (%1) não foi encontrado.</translation>
    </message>
</context>
<context>
    <name>Replacer</name>
    <message>
        <location filename="../replacer.cpp" line="141"/>
        <source>Could not open any of the locked encrypted containers.</source>
        <translation>Não foi possível abrir nenhum dos contêineres que estão bloqueados por criptografia.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="142"/>
        <source>Possible incorrect password. Press the &apos;Scan&apos; button to try again with a different password.</source>
        <translation>É possível que a senha não esteja correta. Por favor, clique no botão ‘Verificar os subvolumes’ para tentar novamente com uma senha diferente.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="158"/>
        <source>Volume %1 on drive %2</source>
        <translation>Volume %1 na unidade %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="197"/>
        <source>No existing installation selected.</source>
        <translation>Nenhuma instalação existente foi selecionada.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="274"/>
        <source>Replace the installation in %1: %2</source>
        <translation>Substituir a instalação %1 em %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="283"/>
        <source>Unlock encrypted volumes</source>
        <translation>Desbloquear os volumes que estão criptografados</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="287"/>
        <source>Password:</source>
        <translation>Senha:</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="289"/>
        <source>Ignore encrypted volumes</source>
        <translation>Ignorar os volumes que estão criptografados</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="354"/>
        <source>Cannot unlock encrypted partition: %1</source>
        <translation>Não foi possível desbloquear a partição criptografada %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="361"/>
        <source>Cannot find partition listed in crypttab: %1</source>
        <translation>Não foi possível encontrar a partição listada no arquivo ‘crypttab’ (tabela de dispositivos criptografados) %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="382"/>
        <source>Could not re-lock encrypted device(s): %1</source>
        <translation>Não foi possível bloquear novamente o(s) dispositivo(s) criptografado(s) %1</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="57"/>
        <source>Recommended maximum: %1 MB</source>
        <translation>O máximo recomendado é %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="60"/>
        <source>Unable to query RAM size.</source>
        <translation>Não foi possível consultar o tamanho da memória RAM.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="89"/>
        <source>Invalid location</source>
        <translation>A localização não é válida</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="92"/>
        <source>Maximum: %1 MB</source>
        <translation>Máximo: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="109"/>
        <source>Failed to configure zram swap.</source>
        <translation>Ocorreu uma falha ao configurar a memória de trocas (swap) ZRAM.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="119"/>
        <source>Failed to create or install swap file.</source>
        <translation>Ocorreu uma falha ao criar ou instalar o arquivo de trocas.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="125"/>
        <source>Creating swap file</source>
        <translation>Criando o arquivo de trocas</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="138"/>
        <source>Configuring swap file</source>
        <translation>Configurando o arquivo de trocas</translation>
    </message>
</context>
</TS>