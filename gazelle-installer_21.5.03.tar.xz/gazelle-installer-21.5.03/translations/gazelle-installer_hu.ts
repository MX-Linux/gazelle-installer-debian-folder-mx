<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hu">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Leállítás</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="530"/>
        <source>Preparing to install %1</source>
        <translation>%1 telepítésének előkészítése</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="542"/>
        <source>Failed to format required partitions.</source>
        <translation>A szükséges partíciók formázása sikertelen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="553"/>
        <source>Paused for required operator input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="563"/>
        <source>Setting system configuration</source>
        <translation>Rendszerkonfiguráció beállítása</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="581"/>
        <source>Cleaning up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="583"/>
        <source>Finished</source>
        <translation>Kész</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="741"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="797"/>
        <source>Deleting old system</source>
        <translation>Régi rendszer törlése</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="801"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="808"/>
        <source>Creating system directories</source>
        <translation>Rendszer könyvtárak létrehozása</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Fixing configuration</source>
        <translation>Beállítások javítása</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="860"/>
        <source>Copying new system</source>
        <translation>Új rendszer másolása</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="900"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="909"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="952"/>
        <source>Updating initramfs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="962"/>
        <source>Installing GRUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1030"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1174"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>The home directory for %1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>Failed to set user account passwords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1229"/>
        <source>Failed to save old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Failed to delete old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1252"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Bocs, de nem sikerült felhasználói könyvtárat létrehozni.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Bocs, de nem sikerült elnevezni a felhasználói könyvtárat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Bocs, de nem sikerült a felhasználói könyvtár tulajdonjogait beállítani.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1324"/>
        <source>Please enter a computer name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1334"/>
        <source>Please enter a domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1338"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>Please enter a workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1588"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1618"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <source>General Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>Installation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1686"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1687"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1691"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1696"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1698"/>
        <location filename="../minstall.cpp" line="1761"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1699"/>
        <location filename="../minstall.cpp" line="1762"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1700"/>
        <location filename="../minstall.cpp" line="1763"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1719"/>
        <source>Choose Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1731"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>Upgrading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>Preferred Filesystem Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Bad Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1755"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1769"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>Advanced Encryption Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1781"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1785"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>A variety of ciphers are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Chain mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>IV generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Key size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>LUKS key hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Számítógép azonosító&lt;/b&gt;&lt;br/&gt;A számítógépnév egy általános, egyedi név, amely azonosítani fogja számítógéped, ha egy hálózatra van csatlakoztatva. A számítógép domént nem valószínű hogy használni kell, hacsak az internet szolgáltató vagy helyi hálózat nem kívánja..&lt;/p&gt;&lt;p&gt;A számítógép és a domain nevek csak alfanumerikus karaktereket tartalmaz, pontok, kötőjelek. Ezek nem tartalmazhatnak szóközt, elején vagy végén kötőjellel.&lt;/p&gt;&lt;p&gt;A SaMBa Szervert aktiválni kell, ha néhány mappádat vagy nyomtatódat meg szeretnéd osztani egy olyan helyi hálózaton, ahol a gépeken MS-Windows vagy Mac OSX fut.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1851"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1853"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1854"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1856"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1865"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1866"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1870"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1873"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1885"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1886"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1888"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1889"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1896"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Warning</source>
        <translation>Figyelmeztetés</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1898"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1914"/>
        <source>Installation in Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1915"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1917"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1919"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1920"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1922"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1931"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1941"/>
        <location filename="../minstall.cpp" line="2355"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1972"/>
        <source>Finish</source>
        <translation>Befejezés</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1976"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Next</source>
        <translation>Következő</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2013"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2016"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2020"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2037"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2079"/>
        <location filename="../minstall.cpp" line="2470"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2081"/>
        <location filename="../minstall.cpp" line="2478"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2280"/>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2280"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>A telepítés és beállítás még nem teljes.
Biztos meg akarod állítani a folyamatot?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2341"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2349"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2363"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2371"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2376"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2428"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2428"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2475"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2523"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2534"/>
        <source>Load key from file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2535"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2664"/>
        <source>System boot disk:</source>
        <translation>Rendszer boot lemez:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2678"/>
        <location filename="../minstall.cpp" line="2687"/>
        <source>Partition to use:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Súgó</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Bezár</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>Következő</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Használat feltételei</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="403"/>
        <location filename="../meinstall.ui" line="791"/>
        <source>Confirm password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <location filename="../meinstall.ui" line="808"/>
        <source>Encryption password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="426"/>
        <location filename="../meinstall.ui" line="831"/>
        <location filename="../meinstall.ui" line="863"/>
        <source>Advanced encryption settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="442"/>
        <source>Use disk:</source>
        <translation>Ezt a lemezt használd:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="468"/>
        <location filename="../meinstall.ui" line="705"/>
        <source>Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="525"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="560"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="624"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Device</source>
        <translation>Eszköz</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Size</source>
        <translation>Méret</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="695"/>
        <source>Label</source>
        <translation>címke </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="700"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="710"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="673"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="642"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="649"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="734"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="745"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="756"/>
        <source>Load key from file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="775"/>
        <source>Encryption options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="879"/>
        <source>SHA-512</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="884"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="889"/>
        <source>Whirlpool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="894"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="899"/>
        <source>RIPEMD-160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="916"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="935"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="957"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="970"/>
        <source>Key size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="996"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1019"/>
        <source>Cipher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1039"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1044"/>
        <source>AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1049"/>
        <source>Twofish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1054"/>
        <source>CAST6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Blowfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1076"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1106"/>
        <source>ESSIV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1111"/>
        <source>Plain64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1116"/>
        <source>Plain64BE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1121"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1126"/>
        <source>BENBI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1140"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1153"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1173"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1181"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1186"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1213"/>
        <source>Select Boot Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>EFI System Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1253"/>
        <source>ESP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1272"/>
        <source>Partition Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>PBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1301"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1304"/>
        <location filename="../meinstall.ui" line="2414"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1320"/>
        <source>System boot disk:</source>
        <translation>Rendszer boot lemez:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1342"/>
        <source>Master Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1348"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1351"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1422"/>
        <source>Common Services to Enable</source>
        <translation>Általános szolgáltatások elindítása</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1441"/>
        <source>Service</source>
        <translation>Szolgáltatás</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1446"/>
        <source>Description</source>
        <translation>Leírás</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1479"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1506"/>
        <source>Workgroup</source>
        <translation>Munkacsoport:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Workgroup:</source>
        <translation>Munkacsoport:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1532"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa szerver MS hálózatokhoz</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1548"/>
        <source>example.dom</source>
        <translation>pelda.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1561"/>
        <source>Computer domain:</source>
        <translation>Számítógép domén:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1587"/>
        <source>Computer name:</source>
        <translation>Számítógép név:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1648"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1689"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Timezone:</source>
        <translation>Időzóna:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1762"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1794"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1834"/>
        <source>Locale:</source>
        <translation>Hely:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1856"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1874"/>
        <source>Adjust which services should run at startup</source>
        <translation>Állítsa mely szolgáltatások futtatott </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1877"/>
        <source>View</source>
        <translation>kilátás </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1947"/>
        <source>Root password:</source>
        <translation>Root jelszó:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>Confirm root password:</source>
        <translation>Root jelszó megerősítése:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2021"/>
        <source>Default User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2033"/>
        <source>Default user login name:</source>
        <translation>Alapértlemezett felhasználói login név:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2049"/>
        <source>Default user password:</source>
        <translation>Alapértelmezett felhasználói jelszó:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2062"/>
        <source>Confirm user password:</source>
        <translation>felhasználó jelszavának megerősítése:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2123"/>
        <source>username</source>
        <translation>felhasználónév</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2139"/>
        <source>Autologin</source>
        <translation>Autologin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2152"/>
        <source>Show passwords</source>
        <translation>Megjelenítés jelszavak</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2165"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2168"/>
        <source>Save live desktop changes</source>
        <translation>Mentsd élő asztali változások</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2191"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>What would you like to do with the old directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2214"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2221"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2266"/>
        <source>Tips</source>
        <translation>Tippek</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2310"/>
        <source>Installation complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2316"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2335"/>
        <source>Reminders</source>
        <translation>Emlékeztetők</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2376"/>
        <source>Back</source>
        <translation>Vissza</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2383"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Installation in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2411"/>
        <source>Abort</source>
        <translation>Megszakít</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="138"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="369"/>
        <source>EFI System Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="370"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="371"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="372"/>
        <source>format only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="475"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="475"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="516"/>
        <location filename="../partman.cpp" line="883"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="637"/>
        <location filename="../partman.cpp" line="701"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="639"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="648"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="652"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="659"/>
        <location filename="../partman.cpp" line="770"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="666"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="667"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="673"/>
        <source>New subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="674"/>
        <source>Scan subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="704"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="705"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="708"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="709"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="721"/>
        <source>Remove subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="773"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="774"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="809"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="845"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="911"/>
        <source>Preserve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="957"/>
        <source>Invalid subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="965"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="977"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1023"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1029"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1041"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1044"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1050"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1053"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1061"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1069"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1077"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1081"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1179"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1183"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1184"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1189"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1191"/>
        <source>Do you want to abort the installation?</source>
        <translation>Szeretnéd megszakítani a telepítést? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1196"/>
        <source>Do you want to continue?</source>
        <translation>Szeretnéd folytatni? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1365"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1373"/>
        <source>Preparing required partitions</source>
        <translation>Szükséges partíciók előkészítése</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1428"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>LUKS titkosított konténerek beállítása</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1448"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1675"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
