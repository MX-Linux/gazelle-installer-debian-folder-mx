<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="96"/>
        <source>%1 Installer</source>
        <translation>%1 Asennusohjelma</translation>
    </message>
    <message>
        <source>Gathering Information, please stand by.</source>
        <translation type="vanished">Tietoja kerätään, odota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="56"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="113"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Tue %1:ia

%1 on sinunlaistesi ihmisten tukema. Jotkut auttavat toisia tukifoorumilla - %2, tai kääntävät ohjeita eri kielille, tekevät ehdotuksia uusista ominaisuuksista, kirjoittavat dokumentaatiota, tai auttavat kokeilemalla uusia sovelluksia.</translation>
    </message>
    <message>
        <source>Cannot access source medium.
Activating pretend installation.</source>
        <translation type="vanished">Lähde-mediaa ei voitu käsitellä.
Asennusteeskentely aloitetaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="344"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 on itsenäinen Linux jakelu, joka pohjautuu Debianin vakaaseen (Stable) haaraan.

%1 käyttää joitakin MEPIS Linuxin komponentteja jotka on julkaistu Apachen vapaalla lisenssillä. Jotkin MEPIS-komponentit on muokattu %1:ia varten.

Pidä hauskaa käyttäessäsi %1:ia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="466"/>
        <source>Pretending to install %1</source>
        <translation>Asennuksen teeskentely %1</translation>
    </message>
    <message>
        <source>target drive</source>
        <translation type="vanished">kohdeasema</translation>
    </message>
    <message>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="vanished">Levyt ja niiden asennukseen valitut osiot ovat vikautumassa:</translation>
    </message>
    <message>
        <source>Smartmon tool output:</source>
        <translation type="vanished">Smartmon-työkalun ulosanti:</translation>
    </message>
    <message>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="vanished">Asennukseen valitut levyt ja niiden osiot läpäisivät SMART-valvontatestin (smartctl), mutta suoritetut kokeet osoittavat keskimääräistä korkeampaa hajoamisvaaran tasoa lähitulevaisuudessa.  </translation>
    </message>
    <message>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="vanished">Jos olet epävarma, poistu asennusohjelmasta sekä aja GSmartControl-ohjelma saadaksesi enemmän tietoa.</translation>
    </message>
    <message>
        <source>Do you want to abort the installation?</source>
        <translation type="vanished">Haluatko keskeyttää asennuksen?</translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="vanished">Haluatko jatkaa?</translation>
    </message>
    <message>
        <source>The password needs to be at least
%1 characters long. Please select
a longer password before proceeding.</source>
        <translation type="vanished">Salasanan tulee olla vähintään
%1 merkkiä pitkä. Valitse
pidempi salasana jatkaaksesi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="522"/>
        <source>Preparing to install %1</source>
        <translation>Valmistautuu asentamaan %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="534"/>
        <source>Failed to format required partitions.</source>
        <translation>Tarvittavien osioiden alustaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="545"/>
        <source>Paused for required operator input</source>
        <translation>Tauotettu tarvittavaa käyttäjän valintaa odottaen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="555"/>
        <source>Setting system configuration</source>
        <translation>Järjestelmäasetusten täytäntöönpano</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="575"/>
        <source>Cleaning up</source>
        <translation>Puhdistetaan</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="735"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>Epäkelpoja asetuksia on löytynyt asetustiedostossa (%1). Tarkista merkatut kentät sitä mukaa kun kohtaat niitä.</translation>
    </message>
    <message>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="vanished">Asetetaan LUKS-salatut säiliöt</translation>
    </message>
    <message>
        <source>Formatting swap partition</source>
        <translation type="vanished">Alustetaan sivutusosio</translation>
    </message>
    <message>
        <source>Formatting the / (root) partition</source>
        <translation type="vanished">Alustetaan / (root) osiota</translation>
    </message>
    <message>
        <source>Formatting boot partition</source>
        <translation type="vanished">Alustetaan käynnistysosiota</translation>
    </message>
    <message>
        <source>Formatting EFI System Partition</source>
        <translation type="vanished">Alustaa EFI-järjestelmäosiota</translation>
    </message>
    <message>
        <source>Formatting the /home partition</source>
        <translation type="vanished">Alustetaan /home osiota</translation>
    </message>
    <message>
        <source>Mounting the /home partition</source>
        <translation type="vanished">Liitetään /home osiota</translation>
    </message>
    <message>
        <source>Sorry, could not create %1 LUKS partition</source>
        <translation type="vanished">Valitettavasti %1 LUKS osiota ei voitu luoda</translation>
    </message>
    <message>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation type="vanished">Valitettavasti %1 LUKS säiliötä ei voitu avata</translation>
    </message>
    <message>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="vanished">Sinun täytyy valita erillinen käynnistysosio salataksesi juurihakemiston.</translation>
    </message>
    <message>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="vanished">Sinun täytyy valita juuri-osio.
Juuri-osion tulee olla vähintään %1. </translation>
    </message>
    <message>
        <source>Delete the data on %1 except for /home</source>
        <translation type="vanished">Poista %1 kaikki tieto poislukien /home </translation>
    </message>
    <message>
        <source>Reuse (no reformat) %1 as the /home partition</source>
        <translation type="vanished">Uudelleenkäytä (ei uudelleenalustusta) %1 /home osiona</translation>
    </message>
    <message>
        <source>Configure %1 as swap space</source>
        <translation type="vanished">Määrittele %1 heittovaihtotiedostotilana</translation>
    </message>
    <message>
        <source>The partition you selected for /boot is larger than expected.</source>
        <translation type="vanished">Valitsemasi osio /boot lohkolle on suurempi kuin oli odotettu.</translation>
    </message>
    <message>
        <source>%1 for the %2 partition</source>
        <translation type="vanished">%1  %2 osioon</translation>
    </message>
    <message>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="vanished">Valitsemistasi osioista seuraavat eivät ole Linux-osioita:</translation>
    </message>
    <message>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="vanished">Oletko varma että haluat uudelleenalustaa nämä osiot?</translation>
    </message>
    <message>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="vanished">%1 asentaja alustaa ja tuhoaa kaiken tiedon seuraavissa osioissa:</translation>
    </message>
    <message>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="vanished">%1 asentaja suorittaa nyt seuraavat toimenpiteet:</translation>
    </message>
    <message>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="vanished">Näitä toimenpiteitä ei voida kumota. Haluatko jatkaa?</translation>
    </message>
    <message>
        <source>Creating required partitions</source>
        <translation type="vanished">Luodaan vaadittavia osioita</translation>
    </message>
    <message>
        <source>Preparing required partitions</source>
        <translation type="vanished">Valmistellaan vaadittavia osioita</translation>
    </message>
    <message>
        <source>Mounting the / (root) partition</source>
        <translation type="vanished">Liitetään / (root) osiota</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>Deleting old system</source>
        <translation>Poistetaan vanhaa järjestelmää</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Vanhan %1 poistaminen epäonnistui kohteessa.
Palataan vaiheeseen 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>Creating system directories</source>
        <translation>Luodaan järjestelmähakemistoja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <source>Fixing configuration</source>
        <translation>Korjataan rakennetta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="887"/>
        <source>Copying new system</source>
        <translation>Kopioidaan uutta järjestelmää</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="927"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Kopioinnin edistyminen tuntematon. Tiedostojärjestelmän tilastoja ei saatavilla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="936"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Kirjoittaminen epäonnistui %1 kohteeseen.
Palataan vaiheeseen 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="954"/>
        <source>Installing GRUB</source>
        <translation>Asennetaan GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1039"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>GRUB:in asennus epäonnistui. Voit uudelleenkäynnistää live-tilaan ja käyttää GRUB Rescue valikkoa korjataksesi asennuksen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1055"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation>Virhe NVRAM käynnistysmuuttujan päivityksessä. Järjestelmä ei luultavasti käynnisty, mutta se voidaan korjata GRUB Rescue käynnistysvalikon avulla.</translation>
    </message>
    <message>
        <source>Please enter a user name.</source>
        <translation type="vanished">Syötä käyttäjänimi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Käyttäjänimi ei voi sisältää erikoismerkkejä tai välilyöntejä.
Valitse toisenkaltainen nimi jatkaaksesi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Pahoittelut, tuo nimi on jo käytössä.
Valitse eri nimi.</translation>
    </message>
    <message>
        <source>Please enter the user password.</source>
        <translation type="vanished">Syötä käyttäjän salasana.</translation>
    </message>
    <message>
        <source>Please enter the root password.</source>
        <translation type="vanished">Syötä juurikäyttäjän salasana.</translation>
    </message>
    <message>
        <source>The user password entries do not match.
Please try again.</source>
        <translation type="vanished">Käyttäjän salasanasyötteet eivät täsmää.
Yritä uudelleen.</translation>
    </message>
    <message>
        <source>The root password entries do not match.
Please try again.</source>
        <translation type="vanished">Juurikäyttäjän salasanat eivät täsmää.
Yritä uudelleen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Kotihakemisto käyttäjälle %1 on jo olemassa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1229"/>
        <source>Failed to set user account passwords.</source>
        <translation>Käyttäjätilien salasanojen asettaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Failed to save old home directory.</source>
        <translation>Vanhan kotikansion tallentaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>Failed to delete old home directory.</source>
        <translation>Vanhan kotikansion poistaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1276"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Käyttäjähakemistoa ei voitu luoda.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1284"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Valitettavasti käyttäjäkansion nimeäminen ei onnistunut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Valitettavasti omistusoikeuksien asettaminen käyttäjäkansiolle ei onnistunut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Please enter a computer name.</source>
        <translation>Syötä nimi tietokoneelle. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1356"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Pahoittelut, tietokoneesi nimi sisältää epäkelpoja merkkejä.
Sinun tulee valita eri
nimi ennen jatkamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>Please enter a domain name.</source>
        <translation>Syötä verkko-domain nimi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1366"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Pahoittelut, tietokoneesi domain sisältää epäkelpoja merkkejä.
Sinun tulee valita eri
nimi jatkaaksesi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1373"/>
        <source>Please enter a workgroup.</source>
        <translation>Syötä työryhmä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1616"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Hyväksytkö levyn alustamisen ja sen käytön kokonaisuudessaan (%1) näin %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1620"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>VAROITUS: valittu asema omaa vähintään 2TT kapasiteetin ja se pitää alustaa käyttäen GPT:tä. Joissakin järjestelmissä GPT-alustettu levy ei käynnisty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1645"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Tietokokoomaa kohteessa /home ei voida säilöä koska vaadittuja tietoja ei onnistuttu hankkimaan. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1646"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation>Mikäli osio joka sisältää /home alueen on varustettu salauksella, varmista että oikeat &quot;Encrypt&quot; laatikot ovat valitut ja syötetty salasana on oikein.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1647"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation>Asentaja ei kyennyt salaamaan olemassaolevaa /home hakemistoa tai osiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>General Instructions</source>
        <translation>Yleiset ohjeet</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>SULJE KAIKKI MUUT SOVELLUKSET ENNEN JATKAMISTA.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Jokaisella sivulla lue ohjeet, tee valintasi, napsauta sitten aina Seuraava kun olet valmis jatkamaan. Tulet näkemään kehotteen varmistusta varten ennen minkään tuhoisan toiminnon toteuttamista.</translation>
    </message>
    <message>
        <source>Installation requires about %1 of space. %2 or more is preferred. You can use the entire disk or you can put the installation on existing partitions.</source>
        <translation type="vanished">Asentaminen vaatii kokolailla %1 tilaa. %2 tai enemmän on suositus. Voit käyttää levyn kokonaisuudessan tai asentaa jo valmiiksi olemassaoleville osioille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Mikäli ajat Mac- tai Windows-käyttöjärjestelmää (Vista:sta eteenpäin lukien), voi olla että sinun pitää käyttää kyseisen järjestelmän ohjelmia luodaksesi osiot ja käynnistyksen hallinnan ennen asennusta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1716"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Linux-tiedostojärjestelmät ext2, ext3, ext4, jfs, xfs, btrfs ja reiserfs ovat tuetut ja ext4 on suositeltu.</translation>
    </message>
    <message>
        <source>Autoinstall will place home on the root partition.</source>
        <translation type="vanished">Automaatti-asennus asettaa kotihakemiston juuri-osioon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <location filename="../minstall.cpp" line="1789"/>
        <source>Encryption</source>
        <translation>Salaus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <location filename="../minstall.cpp" line="1790"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Kiintolevyn salaus on mahdollista LUKS:in kautta. Salasana vaaditaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <location filename="../minstall.cpp" line="1791"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Erillinen salaamaton käynnistys-osio vaaditaan. Lisäasetuksia varten, sisältäen salauksen valinnat, käytä &lt;b&gt;Edistyneet salausasetukset&lt;/b&gt;painiketta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Kun salausta käytetään automaattisen asennuksen yhteydessä, erillinen käynnistys-osio luodaan automaattisesti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>Limitations</source>
        <translation>Rajoitukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Muistathan, että tämä ohjelmisto toimitetaan SELLAISENAAN ilman mitään takuuta. On yksin sinun omalla vastuullasi tehdä varmuuskopiot tiedostoistasi ennen jatkamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Choose Partitions</source>
        <translation>Valitse Osiot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 vaatii juuri-osion. Swap-heittovaihtotiedosto-osio on valinnainen mutta erittäin suositeltava. Mikäli haluat käyttää Suspend-to-Disk %1 keskeytystilaominaisuutta, tarvitset heittovaihtotiedosto-osion joka on kooltaan suurempi kuin aineellinen keskusmuistisi määrä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Mikäli valitset erillisen /home osion, tarkoittaa se helpompaa siirtymäpäivitystä tulevaisuudessa, mutta ei ole mahdollista päivitettäessä asennuksesta ilman erillistä koti-osiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>Upgrading</source>
        <translation>Päivittäminen</translation>
    </message>
    <message>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and check the preference to preserve data in /home.</source>
        <translation type="vanished">Kun päivität jo valmiiksi olemassaolevasta Linux-asennuksesta, valitse sama koti-osio kuten aikaisemminkin ja ruksaa suositukseksi säilyttää tiedot /home kohteessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="134"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished">Asennusohjelma ei käynnistynyt koska se näyttäisi olevan jo käynnissä.

Jos mahdollista, sulje se tai suorita &apos;pkill minstall&apos; päätteessä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="165"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="216"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished">32-bittinen käyttöjärjestelmä joka aloitettiin 64-bittisessä UEFI-moodissa on käynnissä. Järjestelmää ei voida käynnistää ellet valitse Legacy Boot:ia tai vastaavaa vaihtoehtoa uudelleenkäynnistykseen.
Suosittelemme että lopetat nyt ja käynnistät tilassa Legacy Boot 

Haluatko jatkaa asentamista?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="577"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>Installation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1718"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption. To preserve the format of an existing encrypted partition, you must use the same passphrase that it was originally encrypted with.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1765"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1772"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1775"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1776"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation>Mikäli säilytät olemassaolevan /home kotihakemistopuun joka sijaitsee juuri-osiossasi, asennusohjelma ei uudelleenalusta tuota juuri-osiota. Tämän seurauksena asentaminen vie paljon enemmän aikaa kuin yleensä.   </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>Preferred Filesystem Type</source>
        <translation>Suositeltu Tiedostojärjestelmätyyppi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1779"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Saavuttaaksesi %1, voit alustaa osiot ext2, ext3, ext4, f2fs, jfs, xfs, btrfs tai reiser muodossa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Pakkauksen lisävalinnat ovat tarjolla kiintolevyille jotka käyttävät btrfs-tiedostojärjestelmää. Lzo on nopea, mutta pakkaus on vähäisempi. Zlib on hitaampi, korkeammalla pakkauksella.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Bad Blocks</source>
        <translation>Vikaantuneet lohkot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Mikäli valitset ext2, ext3 tai ext4 alustusmuodon, sinulla on vaihtoehtona tarkistaa ja korjata vikaantuneet kiintolevylohkot. Viallisten lohkojen tarkistaminen vie paljon aikaa, joten halunnet sivuuttaa tuon askeleen ellet epäile kiintolevylläsi todellakin olevan vikaantuneita lohkoja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1785"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>Advanced Encryption Settings</source>
        <translation>Edistyneet Salausasetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Tämä sivu sallii LUKS-osiosalauksen hienosäädön.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Useimmissa tapauksissa, vakioasetukset tarjoavat käytännöllisen tasapainon turvallisuuden ja  suorituskyvyn suhteen joka on sopiva arkaluontoisille sovelluksille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Tämä kirjoitus kattaa LUKS:issa käytettyjen parametrien perusteet, mutta ei ole tarkoitettu kaikenkattavaksi oppaaksi salaustekniikkaan. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1802"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Näiden asetusten muuttaminen ilman selkeää ymmärrystä salaustekniikkaan voi päätyä heikon salauksen käyttämiseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Kentän muokkaaminen vaikuttaa usein saatavilla oleviin vaihtoehtoihin sen alapuolella. Alapuoliset kentät voivat muuttua automaattisesti suositeltuihin arvoihin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Vaikkakin parempi suorituskyky tai korkeampi tietoturva voidaan saavuttaa muuttamalla asetuksia niiden suositelluista arvoista, teet sen kaikkinensa omalla vastuullasi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Voit käyttää &lt;b&gt;Benchmark-mittapuu&lt;/b&gt;painiketta (joka ajaa &lt;i&gt;cryptsetup mittapuun&lt;/i&gt;omassa pääteikkunassaan) vertaillaksesi suorituskykyä yleisissä hash-yhdistelmissä, salauksissa ja ketjutustiloissa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Huomioi että &lt;i&gt;cryptsetup mittapuu&lt;/i&gt;ei kata kaikkia mahdollisia yhdistelmiä tai valintoja ja kattaa yleisesti kaikkein useimmin suositut ratkaisut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Cipher</source>
        <translation>Salaustekniikka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>A variety of ciphers are available.</source>
        <translation>Tarjolla on useita salaustekniikoita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>oli yksi viidestä AES-finalisteista. Se omaa korkeamman tason turvalähtöisyyden kuin Rijndael ja kaikki muut AES-finalistit. Se on suorituskyvyltään parempi joillakin 64-bittisillä suorittimilla. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1811"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(tunnetaan myös nimellä&lt;i&gt;Rijndael&lt;/i&gt;) on erittäin yleinen salaustekniikka, ja monet nykyaikaiset suorittimet sisältävät ohjeet erityisesti AES:lle, sen yleisyyden johdosta. Vaikkakin Rijndael arvotettiin paremmaksi kuin Serpent sen suorituskyvyssä, mitään hyökkäystä ei pidetä tällä hetkellä käytännöllisenä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>on Blowfish:in seuraaja. Siitä tuli yksi niistä viidestä AES-finalistista, vaikkakaan se ei tullut valituksi standardille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) oli AES-kilvassa ehdokkaana, kuitenkaan siitä ei finalistia tullut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>on 64-bittinen lohkosalaustekniikka jonka loi Bruce Schneier. Arkaluontoisia tietoja sisältävään käyttöön sitä ei suositella koska vain CBC ja ECB moodit ovat tuettuja. Blowfish tukee avainkokoja 32 ja 448 bitin välillä jotka ovat monistuksia 8:sta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>Chain mode</source>
        <translation>Ketjutustila</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Jos lohkot olisivat kaikki salattuja käyttäen samaa avainta, voi ilmaantua jatkumo jonka kautta ennakoitavissa perustekstiä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1817"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>XEX-perusteinen Tweaked-koodikirja ciphertext Stealing:illä) on nykyaikainen ketju-moodi, joka ylittää CBC:n ja EBC:n. Se on vakiollinen (ja suositeltu) ketju-moodi. Käyttämällä ESSIV:iä Plain64:n yli verottaa suorituskykyä ilman tiettävää turvaetua.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Cipher Block Chaining) on yksinkertaisempi kuin XTS, mutta haavoittuvainen padding oracle hyökkäykselle (jokseenkin lievennettynä ESSIV:in johdosta) eikä ole suositeltu arkaluontoisia tietoja sisältävään käyttötarkoitukseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic Codebook) on vähemmän turvallinen kuin CBC eikä sitä tule käyttää arkaluontoisia tietoja sisältäviin käyttötarkoituksiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>IV generator</source>
        <translation>IV generaattori</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>XTS:n ja CBC:n suhtee, tämä määrittää kuinka &lt;b&gt;i&lt;/b&gt;nitalisaatio &lt;b&gt;v&lt;/b&gt;ektori tuotetaan. &lt;b&gt;ESSIV&lt;/b&gt;edellyttää hash-toiminnon, ja siitä syystä toinen pudotusvalikko tulee tarjolle mikäli se valitaan. Hash-arvot riippuvat valitusta salaustekniikasta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1822"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>ECB moodi ei käytä IV:tä, joten kaikki nämä kentät poistuvat käytöstä jos ECB on valittu ketju-moodiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1824"/>
        <source>Key size</source>
        <translation>Avainkoko</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1824"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Asettaa avainkoon tavuina. Valittavissa olevat avainkoot ovat rajoitetut liittyen salaustekniikkaan ja ketju-moodiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1825"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>XTS salaustekniikka ketju-moodi puolittaa avaimen (esimerkiksi, AES-256 XTS-moodissa vaatii 512-bittisen avainkoon).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1827"/>
        <source>LUKS key hash</source>
        <translation>LUKS avain-hash</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1827"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>Käytetty hash PBKDF2:ssa ja AF-puolittajassa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 ja RIPEMD-160 eivät ole enää suositeltuja arkaluontoisia tietoja käsittelevään käyttöön koska ne on havaittu rikkinäisiksi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1830"/>
        <source>Kernel RNG</source>
        <translation>Ytimen RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1830"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Asettaa mitä ytimen satunnaista numero-generaattoria käytetään pääavaimen avaimen luomiseksi (joka on pitkäaikainen avain).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1831"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Kaksi vaihtoehtoa on valittavissa: /dev/&lt;b&gt;random&lt;/b&gt;joka estää kunnes riittävä haje on saavutettu (voi kestää pitkään alhaisen hajeen tapauksissa), ja /dev/&lt;b&gt;urandom&lt;/b&gt;joka ei estä silloinkaan kun tarjolla on riittämätön haje (mahdollisesti heikommat avaimet).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1833"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF kiertoaika &lt;/b&gt;&lt;br/&gt;Ajan määrä (millisekunneissa) käytettäväksi PBKDF2:n salauslause prosessoinnissa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Arvo 0 valitsee sisäänkokoomisvakion (aja &lt;i&gt;cryptsetup --help&lt;/i&gt;nähdäksesi yksityiskohdat).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1835"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Jos sinulla on hidas kone, saatat nostaa tätä arvoa lisäturvallisuuden saavuttamiseksi, hyvittääkseen aikaa joka käytetään taltion avaamiseksi sen jälkeen kun salauslause on syötetty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Valitse Käynnistysmenetelmä&lt;/b&gt;&lt;br/&gt;%1 käyttää GRUB-käynnistyslatainta käynnistääkseen %1 ja MS-Windowsin. &lt;p&gt;Oletuksena GRUB2 asennetaan Pääkäynnistystaltioon (MBR) tai ESP:n (EFI-järjestelmäosio 64-bittisissä UEFI-käynnistyvissä järjestelmissä) käynnistysasemassasi ja korvaa käynnistyslataimen jota käytit aiemmin. Tämä on tavanomaista. &lt;/p&gt;&lt;p&gt; Jos valitset asentaa GRUB2 osiokäynnistystaltioon (PBR) sen sijaan, sitten GRUB2 asennetaan määritetyn osion alkuosaan. Tämä vaihtoehto on tarkoitettu vain kokeneille käyttäjille.&lt;/p&gt;&lt;p&gt; Mikäli ruksaat pois GRUB.in asentamisen, GRUB:ia ei tällä erää asenneta. Tämä on tarkoitettu vain kokeneille käyttäjille.&lt;/p&gt;   </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1855"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kytkettävät tavanomaiset toiminnot &lt;/b&gt;&lt;br/&gt; Valitse toiminnot joita tulet tarvitsemaan järjestelmässäsi, sekä ne jotka haluat käynnistettävän automaattisesti kun aloitat %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Tietokoneen identiteetti &lt;/b&gt;&lt;br/&gt; Tietokoneen nimi on yleinen ainutlaatuinen nimi joka tunnistaa tietokoneesi jos se on kytkettynä verkkoon. Tietokoneen verkkoalue, domain, tuskin tulee käyttöön ellei sitten internetyhteyden tarjoajasi, ISP, tai paikallinen verkko vaadi sitä. &lt;/p&gt;&lt;p&gt; Tietokoneen ja verkkoalueen nimi voi sisältää vain aakkosnumeerisia merkkejä, pisteitä, yhdysmerkkejä. Ne eivät voi sisältää tyhjiä välejä eivätkä alkaa yhdysmerkeillä &lt;/p&gt;&lt;p&gt; Samba palvelin täytyy aktivoida jos haluat käyttää sitä jakaaksesi tiettyjä hakemistoja tai tulostimen paikallisen tietokoneen kanssa jonka käyttöjärjestelmänä on MS-Windows tai Mac OSX.&lt;/p&gt; </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1872"/>
        <source>Localization Defaults</source>
        <translation type="unfinished">Kotoistuksen oletukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1873"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>Configure Clock</source>
        <translation type="unfinished">Kellon asetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1877"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1879"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1886"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1887"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2100"/>
        <location filename="../minstall.cpp" line="2484"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2102"/>
        <location filename="../minstall.cpp" line="2489"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2443"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2443"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2486"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Localization Defaults&lt;/b&gt;&lt;br/&gt;Set the default keyboard and locale. These will apply unless they are overridden later by the user.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Configure Clock&lt;/b&gt;&lt;br/&gt;If you have an Apple or a pure Unix computer, by default the system clock is set to GMT or Universal Time. To change, check the box for &apos;System clock uses LOCAL.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timezone Settings&lt;/b&gt;&lt;br/&gt;The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Service Settings&lt;/b&gt;&lt;br/&gt;Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing! </source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Vakiolliset paikallisasetukset&lt;/b&gt;&lt;br/&gt; Määritä vakiollinen näppäimistö ja sen paikallisasetus. Nämä toimeenpannaan ellei käyttäjä muuta niitä myöhemmin.&lt;/p&gt;&lt;p&gt;&lt;b&gt; Määritä kello &lt;/b&gt;&lt;br/&gt; Jos omistat Apple- tai Unix-tietokoneen, järjestelmäkello asetetaan vakiollisesti muotoon GMT tai yleismaailmallinen aika. Muuttaaksesi, merkitse pikkulaatikko &apos;Järjestelmän kello käyttää PAIKALLISTA.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;  Aikavyöhykkeen asetukset &lt;/b&gt;&lt;br/&gt; Järjestelmä käynnistyy vakiolliseen maailmanaikaan GMT/UTC.  Muuttaaksesi aikavyöhykkeen, jälkeen uudelleenkäynnistyksen, klikkaa hiiren oikealla napilla Paneelin kelloa ja valitse Asetukset. &lt;/p&gt;&lt;p&gt;&lt;b&gt; Palveluasetukset &lt;/b&gt;&lt;br/&gt; Useimpien käyttäjien ei tarvitse muuttaa vakioasetuksia. Käyttäjät joilla on matala-resurssiset tietokoneet, haluavat joskus kytkeä tarpeettomat palvelut pois säästääkseen keskusmuistia niin paljon kuin mahdollista. Varmista että tiedät mitä olet tekemässä! </translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Default User Login&lt;/b&gt;&lt;br/&gt;The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Passwords&lt;/b&gt;&lt;br/&gt;Enter a new password for your default user account and for the root account. Each password must be entered twice.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Vakiokäyttäjän sisäänkirjautuminen &lt;/b&gt;&lt;br/&gt; Juuri-käyttäjä on samantyyppinen kuten Järjestelmänvalvoja joissakin muissa käyttöjärjestelmissä. Juuri-käyttäjänä ei tule toimia jokapäiväisesti. Valitse nimi uudelle (vakio) käyttäjätilille jota käytät päivittäin. Mikäli tarve on, voit lisätä muita tilejä myöhemmin %1 käyttäjähallinnan kautta. &lt;/p&gt;&lt;p&gt;&lt;b&gt; Salasanat &lt;/b&gt;&lt;br/&gt;Kirjoita uusi salasana vakiokäyttäjätilillesi sekä myös juurikäyttäjätilille. Kumpainenkin salasana pitää kirjoittaa kahdesti. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1906"/>
        <source>Old Home Directory</source>
        <translation>Vanha Kotihakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1907"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Kotikansio on valmiiksi olemassa valitsemallesi käyttäjänimelle. Tämä ruutu sallii sinun valita mitä tälle hakemistolle tapahtuu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1909"/>
        <source>Re-use it for this installation</source>
        <translation>Käytä se uudelleen tätä asennusta varten</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1910"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Vanhaa kotikansiota tullaan käyttämään tälle käyttäjätilille. Tämä on hyvä valinta päivityksen tullessa kyseeseen, ja tiedostosi kuin myös asetuksesi tulevat olemaan valmiina ennallaan. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1912"/>
        <source>Rename it and create a new directory</source>
        <translation>Uudelleennimeä se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1913"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Käyttäjälle tullaan luomaan uusi kotikansio, mutta vanha kotikansio nimetään uudelleen. Tiedostosi ja asetuksesi eivät tule olemaan välittömästi näkyvillä uudessa asennuksessa, mutta niihin pääsee käsiksi käyttäen uudelleennimettyä kansiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1915"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Vanhan hakemiston nimessä tulee olemaan numero sen lopussa, riippuen siitä kuinka minta kertaa tuo hakemisto on aiemmin uudelleennimetty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1916"/>
        <source>Delete it and create a new directory</source>
        <translation>Poista se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1917"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Vanha hakemisto poistetaan ja luodaan uusi alkutekijöistä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1918"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1919"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Kaikki tiedostot ja asetukset poistetaan pysyvästi jos tämä vaihtoehto on valittuna. Mahdollisuutesi palauttaa ne ovat pienet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1935"/>
        <source>Installation in Progress</source>
        <translation>Asennus Käynnissä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1936"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 asentuu. Puhtaan asennuksen ollessa kyseessä, se luultavasti kestää 3-20 minuuttia, riippuen järjestelmäsi nopeudesta ja uudelleenalustettavien osioiden koosta. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1938"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Jos napsautat Keskeytä painiketta, asennus pysäytetään niin pian kuin mahdollista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Change settings while you wait</source>
        <translation>Muuta asetuksia odottaessasi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1941"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Sillä välin kun %1 asentuu, voit napsauttaa &lt;b&gt;Seuraava&lt;/b&gt;tai &lt;b&gt;Takaisin&lt;/b&gt; painikkeita lukeaksesi muita asennuksen vaatimia tietoja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1943"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Saata nämä askeleet valmiiksi omaan tahtiisi. Asennusohjelma odottaa syötteitäsi tarpeen vaatiessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1952"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Onnittelut! &lt;/b&gt;&lt;br/&gt; Olet suorittanut asennuksen %1 &lt;/p&gt;&lt;p&gt;&lt;b&gt; Ohjelmien löytäminen &lt;/b&gt;&lt;br/&gt; Tarjolla on satoja erinomaisia ohjelmia asennettavaksi %1 Paras tapa oppia niistä on on selata käynnistysvalikkoa ja kokeilla. Monet näistä ohjelmista ovat kehitetyt yksinomaan %1 projektia varten. Nämä löytyvät päävalikoista. &lt;p&gt; Lisäksi %1 sisältää monia vakiollisia Linux-sovelluksia joita ajetaan komentokehotteesta ja täten eivät näy ohjelmien käynnistysvalikossa. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1961"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Pidä hauskaa käyttäessäsi %1:ia&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1962"/>
        <location filename="../minstall.cpp" line="2375"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Tuki %1 &lt;/b&gt;&lt;br/&gt; %1 on ihmisten kuten sinä tukema. Eräät auttavat muita tukifoorumilla - %2 - tai kääntävät aputiedostoja eri kielille, tai antavat ehdotuksia, kirjoittavat dokumentaatiota, tai auttavat uusien ohjelmien testaamisessa. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1993"/>
        <source>Finish</source>
        <translation>Lopeta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1997"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1999"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2034"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2037"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2041"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2058"/>
        <source>Loading...</source>
        <translation>Lataa...</translation>
    </message>
    <message>
        <source>Select target root partition</source>
        <translation type="vanished">Valitse kohde juuri-osio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2300"/>
        <source>Confirmation</source>
        <translation>Vahvistus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2300"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Asennus ja konfigurointi on kesken..
Haluatko varmasti lopettaa nyt?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2361"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Avun hakeminen &lt;/b&gt;&lt;br/&gt; Perustiedot liittyen %1 on %2. &lt;/p&gt;&lt;p&gt; Vapaaehtoiset ovat valmiina auttamaan sinua %3 foorumilla, %4 &lt;/p&gt;&lt;p&gt; Kun pyydät apua, muista kuvailla ongelmasi sekä myös tietokoneesi niin hyvin kuin mahdollista. Yleensä lausunnot kuten &apos;se ei toiminut&apos; eivät ole avullisia.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2369"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Asennuksen korjaaminen&lt;/b&gt;&lt;br/&gt;Jos %1 lakkaa toimimasta kiintolevyllä, joskus ongelma on mahdollista korjata käynnistämällä järjestelmä LiveDVD:n tai LiveUSB:in kautta ja suorittamalla jokin vaihtoehto mukana olevasta %1 tai käyttämällä jotakin yleistä Linux-työkalua järjestelmän korjaamiseen.&lt;/p&gt;&lt;p&gt;Voit myös käyttää %1 LiveDVD:tä tai LiveUSB:ia palauttaaksesi tiedostoja MS-Windows käyttöjärjestelmistä!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2383"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Äänimikserin säätäminen &lt;/b&gt;&lt;br/&gt; %1 pyrkii määrittelemään äänimikserin sinulle valmiiksi mutta joskus on välttämätöntä itse vääntää äänitasoja ylös ja poistaa mykkäasetus kanavilta mikserissä kuullaksesi ääntä. &lt;/p&gt;&lt;p&gt; Mikserin oikopolkulinkki sijaitsee käynnistysvalikossa. Klikkaa sitä avataksesi mikserin. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2391"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Pidä %1-kopiosi ajan tasalla&lt;/b&gt;&lt;br/&gt;Saadaksesi lisätietoja sekä viimeisimmät päivitykset, vieraile osoitteessa&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2396"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Erityiskiitokset&lt;/b&gt;&lt;br/&gt;Kiitokset kaikille jotka ovat valinneet tukevansa %1 omalla ajalla, rahalla, ehdotuksilla, työllä, kehuilla, ideoilla, mainonnalla, ja/tai sitoutumisella.&lt;/p&gt;&lt;p&gt;Ilman teitä %1 ei olisi olemassa.&lt;/p&gt;&lt;p&gt;%2 Kehitystiimi&lt;/p&gt;</translation>
    </message>
    <message>
        <source>This option also encrypts swap partition if selected, which will render the swap partition unable to be shared with other installed operating systems.</source>
        <translation type="vanished">Tämä asetus salaa myös heittovaihto-osion mikäli valittuna, joka saattaa heittovaihto-osion mahdottomaksi jakaa tietokoneen muiden käyttöjärjestelmien kanssa. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2640"/>
        <source>System boot disk:</source>
        <translation>Järjestelmän käynnistyslevy:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2654"/>
        <location filename="../minstall.cpp" line="2663"/>
        <source>Partition to use:</source>
        <translation>Osio jota käytetään:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="151"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="372"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2362"/>
        <source>Back</source>
        <translation>Takaisin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2368"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2381"/>
        <source>Installation in progress</source>
        <translation>Asennus käynnissä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Abort</source>
        <translation>Keskeytä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1290"/>
        <location filename="../meinstall.ui" line="2399"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="204"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished">Tietoja kerätään, odota.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="239"/>
        <source>Terms of Use</source>
        <translation>Käyttöehdot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="266"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Näppäimistön asetukset&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Malli:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="280"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Muunnos:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="303"/>
        <source>Change Keyboard Settings</source>
        <translation>Muuta näppäimistön asetuksia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="310"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Asettelu:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Rearrange disk partitions (optional)</source>
        <translation type="vanished">Uudelleenjärjestä levyosiot (vaihtoehtoinen)</translation>
    </message>
    <message>
        <source>Modify partitions:</source>
        <translation type="vanished">Muokkaa osioita:</translation>
    </message>
    <message>
        <source>Run partition tool...</source>
        <translation type="vanished">Suorita osiotyökalu...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Select type of installation</source>
        <translation>Valitse asennustyyppi</translation>
    </message>
    <message>
        <source>Auto-install using entire disk </source>
        <translation type="vanished">Asenna automaattisesti käyttäen koko levyä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="408"/>
        <location filename="../meinstall.ui" line="794"/>
        <source>Encryption password:</source>
        <translation>Salauksen salasana:</translation>
    </message>
    <message>
        <source>MB </source>
        <translation type="vanished">Mt</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <location filename="../meinstall.ui" line="777"/>
        <source>Confirm password:</source>
        <translation>Salasanan varmistus:</translation>
    </message>
    <message>
        <source>Leave free space up to:</source>
        <translation type="vanished">Jätä vapaata tilaa:</translation>
    </message>
    <message>
        <source>Custom install on existing partitions</source>
        <translation type="vanished">Mukautettu asennus olemassaoleville osioille</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <location filename="../meinstall.ui" line="817"/>
        <location filename="../meinstall.ui" line="849"/>
        <source>Advanced encryption settings</source>
        <translation>Edistyneet salausasetukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="466"/>
        <location filename="../meinstall.ui" line="675"/>
        <source>Encrypt</source>
        <translation>Salaa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="440"/>
        <source>Use disk:</source>
        <translation>Käytä levyä:</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Asetukset</translation>
    </message>
    <message>
        <source>Preserve data in /home (if upgrading)</source>
        <translation type="vanished">Säilytä tiedostot /home-osiossa (jos päivitetään)</translation>
    </message>
    <message>
        <source>Check for badblocks (takes longer)</source>
        <translation type="vanished">Tarkista mahdollisesti huonot lohkot (kestää kauemmin)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="622"/>
        <source>Choose partitions</source>
        <translation>Valitse osiot</translation>
    </message>
    <message>
        <source>ext4</source>
        <translation type="vanished">ext4</translation>
    </message>
    <message>
        <source>ext3</source>
        <translation type="vanished">ext3</translation>
    </message>
    <message>
        <source>ext2</source>
        <translation type="vanished">ext2</translation>
    </message>
    <message>
        <source>f2fs</source>
        <translation type="vanished">f2fs</translation>
    </message>
    <message>
        <source>jfs</source>
        <translation type="vanished">jfs</translation>
    </message>
    <message>
        <source>xfs</source>
        <translation type="vanished">xfs</translation>
    </message>
    <message>
        <source>btrfs</source>
        <translation type="vanished">btrfs</translation>
    </message>
    <message>
        <source>btrfs-zlib</source>
        <translation type="vanished">btrfs-zlib</translation>
    </message>
    <message>
        <source>btrfs-lzo</source>
        <translation type="vanished">btrfs-lzo</translation>
    </message>
    <message>
        <source>reiserfs</source>
        <translation type="vanished">reiserfs</translation>
    </message>
    <message>
        <source>reiser4</source>
        <translation type="vanished">reiser4</translation>
    </message>
    <message>
        <source>boot:</source>
        <translation type="vanished">käynnistys:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="665"/>
        <source>Label</source>
        <translation>Nimilappu</translation>
    </message>
    <message>
        <source>root:</source>
        <translation type="vanished">juuri:</translation>
    </message>
    <message>
        <source>swap:</source>
        <translation type="vanished">heittovaihto:</translation>
    </message>
    <message>
        <source>root</source>
        <translation type="vanished">juuri</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="vanished">Tyyppi</translation>
    </message>
    <message>
        <source>home:</source>
        <translation type="vanished">koti:</translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="vanished">Paikka</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="761"/>
        <source>Encryption options</source>
        <translation>Salauksen valinnat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="865"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="870"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="875"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="880"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="885"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="902"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="921"/>
        <source> mS</source>
        <translation>mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="943"/>
        <source>LUKS key hash:</source>
        <translation>LUKS hash-avain:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="956"/>
        <source>Key size:</source>
        <translation>Avaimen koko:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="982"/>
        <source>KDF round time:</source>
        <translation>KDF ympärysaika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1005"/>
        <source>Cipher:</source>
        <translation>Salaustekniikka:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1025"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1030"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1035"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1040"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1045"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1062"/>
        <source>Benchmark...</source>
        <translation>Mittapuu...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1092"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1097"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1102"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1107"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1112"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1126"/>
        <source>IV generator:</source>
        <translation>IV generaattori:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1139"/>
        <source>Chain mode:</source>
        <translation>Ketju-moodi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1159"/>
        <source>Kernel RNG:</source>
        <translation>Ytimen RNG:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1167"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1172"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1199"/>
        <source>Select Boot Method</source>
        <translation>Valitse käynnistystapa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1236"/>
        <source>EFI System Partition</source>
        <translation>EFI Järjestelmäosio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1239"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1258"/>
        <source>Partition Boot Record</source>
        <translation>Osiokäynnistystaltio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1261"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1274"/>
        <source>Location to install on:</source>
        <translation>Kohde johon asennetaan:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1287"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Asenna GRUB Linuxille ja Windowsille</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1306"/>
        <source>System boot disk:</source>
        <translation>Järjestelmän käynnistyslevy:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1328"/>
        <source>Master Boot Record</source>
        <translation>Pääkäynnistyslohko</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1334"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1408"/>
        <source>Common Services to Enable</source>
        <translation>Yleiset käyttöön otettavat palvelut</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1427"/>
        <source>Service</source>
        <translation>Palvelu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1432"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1465"/>
        <source>Computer Network Names</source>
        <translation>Tietokoneen Verkkonimet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1492"/>
        <source>Workgroup</source>
        <translation>Työryhmä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1505"/>
        <source>Workgroup:</source>
        <translation>Työryhmä:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa-palvelin Microsoftin verkkojakoa varten</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1534"/>
        <source>example.dom</source>
        <translation>esimerkki.fi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1547"/>
        <source>Computer domain:</source>
        <translation>Tietokoneen verkkonimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1573"/>
        <source>Computer name:</source>
        <translation>Tietokoneen nimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1634"/>
        <source>Configure Clock</source>
        <translation>Kellon asetukset</translation>
    </message>
    <message>
        <source>System clock uses LOCAL</source>
        <translation type="vanished">Käytä paikallista aikaa järjestelmän kellonaikana</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1675"/>
        <source>Format:</source>
        <translation>Muoto:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1703"/>
        <source>Timezone:</source>
        <translation>Aikavyöhyke:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1748"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1780"/>
        <source>Localization Defaults</source>
        <translation>Kotoistuksen oletukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1820"/>
        <source>Locale:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1842"/>
        <source>Service Settings (advanced)</source>
        <translation>Palveluasetukset (edistyneille)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>Adjust which services should run at startup</source>
        <translation>Määritä, mitkä palvelut tulisi käynnistää järjestelmän käynnistyessä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1863"/>
        <source>View</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1921"/>
        <source>Root (administrator) Account</source>
        <translation>Juuri-tili (pääkäyttäjä)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1978"/>
        <source>Confirm root password:</source>
        <translation>Vahvista pääkäyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1933"/>
        <source>Root password:</source>
        <translation>Pääkäyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2007"/>
        <source>Default User Account</source>
        <translation>Oletuskäyttäjätili</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2109"/>
        <source>username</source>
        <translation>käyttäjänimi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2048"/>
        <source>Confirm user password:</source>
        <translation>Vahvista käyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2035"/>
        <source>Default user password:</source>
        <translation>Käyttäjän oletussalasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2019"/>
        <source>Default user login name:</source>
        <translation>Käyttäjän oletuskäyttäjätunnus:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="385"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="523"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="558"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="655"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="660"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="693"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="712"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="719"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="729"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="739"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2125"/>
        <source>Autologin</source>
        <translation>Kirjaudu automaattisesti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2138"/>
        <source>Show passwords</source>
        <translation>Näytä salasanat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2151"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Liveympäristössä tehdyt työpöydän muutokset siirtyvät asennettuun käyttöjärjestelmään</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2154"/>
        <source>Save live desktop changes</source>
        <translation>Tallenna livetilan muutokset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2177"/>
        <source>Existing Home Directory</source>
        <translation>Olemassaoleva kotihakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2186"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Mitä haluaisit tehdä vanhan hakemiston suhteen?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2193"/>
        <source>Re-use it for this installation</source>
        <translation>Käytä se uudelleen tätä asennusta varten</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>Rename it and create a new directory</source>
        <translation>Uudelleennimeä se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Delete it and create a new directory</source>
        <translation>Poista se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2252"/>
        <source>Tips</source>
        <translation>Vinkkejä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2296"/>
        <source>Installation complete</source>
        <translation>Asennus on valmis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2302"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Uudelleenkäynnistä järjestelmä automaattiseti kun asennusohjelma suljetaan</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2321"/>
        <source>Reminders</source>
        <translation>Muistutukset</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="343"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="258"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="539"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="257"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="256"/>
        <source>EFI System Partition</source>
        <translation type="unfinished">EFI Järjestelmäosio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="444"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="449"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="453"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="454"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="470"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="473"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="474"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="550"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="595"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished">Sinun täytyy valita juuri-osio.
Juuri-osion tulee olla vähintään %1. </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="601"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished">Sinun täytyy valita erillinen käynnistysosio salataksesi juurihakemiston.</translation>
    </message>
    <message>
        <source>Configure %1 as swap space</source>
        <translation type="obsolete">Määrittele %1 heittovaihtotiedostotilana</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="613"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished">Poista %1 kaikki tieto poislukien /home </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="616"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="622"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="625"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished">Valitsemistasi osioista seuraavat eivät ole Linux-osioita:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="633"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished">Oletko varma että haluat uudelleenalustaa nämä osiot?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="641"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished">%1 asentaja alustaa ja tuhoaa kaiken tiedon seuraavissa osioissa:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="649"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished">%1 asentaja suorittaa nyt seuraavat toimenpiteet:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="653"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished">Näitä toimenpiteitä ei voida kumota. Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="750"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished">Levyt ja niiden asennukseen valitut osiot ovat vikautumassa:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="754"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished">Smartmon-työkalun ulosanti:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="755"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished">Asennukseen valitut levyt ja niiden osiot läpäisivät SMART-valvontatestin (smartctl), mutta suoritetut kokeet osoittavat keskimääräistä korkeampaa hajoamisvaaran tasoa lähitulevaisuudessa.  </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="760"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished">Jos olet epävarma, poistu asennusohjelmasta sekä aja GSmartControl-ohjelma saadaksesi enemmän tietoa.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="762"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished">Haluatko keskeyttää asennuksen?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished">Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="941"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="949"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished">Valmistellaan vaadittavia osioita</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1003"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished">Asetetaan LUKS-salatut säiliöt</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1020"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formatting EFI System Partition</source>
        <translation type="obsolete">Alustaa EFI-järjestelmäosiota</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1186"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="vanished">Asennusohjelma ei käynnistynyt koska se näyttäisi olevan jo käynnissä.

Jos mahdollista, sulje se tai suorita &apos;pkill minstall&apos; päätteessä.</translation>
    </message>
    <message>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="vanished">32-bittinen käyttöjärjestelmä joka aloitettiin 64-bittisessä UEFI-moodissa on käynnissä. Järjestelmää ei voida käynnistää ellet valitse Legacy Boot:ia tai vastaavaa vaihtoehtoa uudelleenkäynnistykseen.
Suosittelemme että lopetat nyt ja käynnistät tilassa Legacy Boot 

Haluatko jatkaa asentamista?</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must run this app as root.</source>
        <translation type="vanished">Sinun täytyy suorittaa tämä sovellus pääkäyttäjänä.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Asetustiedostoa (%1) ei löytynyt.</translation>
    </message>
</context>
</TS>
