<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ru">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="96"/>
        <source>%1 Installer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="56"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="113"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Поддержите %1

%1 поддерживается людьми такими как и Вы. Некоторые оказывают другим поддержку на форуме - %2, или переводят файлы справки на разные языки, или оставляют пожелания, пишут документацию или участвуют в тестировании нового ПО.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="344"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 - это независимый дистрибутив Linux основанный на стабильной версии Debian.

%1 использует компоненты MEPIS Linux, которые опубликованы под открытой лицензией Apache. Некоторые компоненты MEPIS были модицфицированы для %1.

Наслаждайтесь %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="466"/>
        <source>Pretending to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to abort the installation?</source>
        <translation type="vanished">Вы хотите прервать установку?</translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="vanished">Вы хотите продолжить?</translation>
    </message>
    <message>
        <source>The password needs to be at least
%1 characters long. Please select
a longer password before proceeding.</source>
        <translation type="vanished">Пароль должен состоять как минимум
из %1 символов. Пожалуйста выберите
более длинный пароль прежде чем продолжить.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="522"/>
        <source>Preparing to install %1</source>
        <translation>Подготовка к установке %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="534"/>
        <source>Failed to format required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="545"/>
        <source>Paused for required operator input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="555"/>
        <source>Setting system configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="575"/>
        <source>Cleaning up</source>
        <translation>Очистка</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="735"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="vanished">Настройка шифрованных контейнеров LUKS</translation>
    </message>
    <message>
        <source>Formatting swap partition</source>
        <translation type="vanished">Форматирование раздела подкачки</translation>
    </message>
    <message>
        <source>Formatting the / (root) partition</source>
        <translation type="vanished">Форматирование / (корневогo) разделa</translation>
    </message>
    <message>
        <source>Formatting boot partition</source>
        <translation type="vanished">Форматирование загрузочного раздела</translation>
    </message>
    <message>
        <source>Formatting the /home partition</source>
        <translation type="vanished">Форматирование разделa /home</translation>
    </message>
    <message>
        <source>Mounting the /home partition</source>
        <translation type="vanished">Подключение раздела /home</translation>
    </message>
    <message>
        <source>Sorry, could not create %1 LUKS partition</source>
        <translation type="vanished">Простите, не удалось создать раздел LUKS %1</translation>
    </message>
    <message>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation type="vanished">Извините, не получилось открыть контейнер LUKS %1</translation>
    </message>
    <message>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="vanished">Вы должны указать отдельный раздел boot, если используется шифрованный корневой раздел.</translation>
    </message>
    <message>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="vanished">Вы должны выбрать корневой раздел.
Он должен быть не менее %1.</translation>
    </message>
    <message>
        <source>The partition you selected for /boot is larger than expected.</source>
        <translation type="vanished">Раздел, который вы выбрали как /boot больше чем ожидалось.</translation>
    </message>
    <message>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="vanished">Следующие выбранные вами разделы не являются разделами Linux:</translation>
    </message>
    <message>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="vanished">Вы уверены, что хотите переформатировать эти разделы?</translation>
    </message>
    <message>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="vanished">Установщик %1 отфарматирует и разрушит данные на следующих разделах:</translation>
    </message>
    <message>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="vanished">Установщик %1 выполняет следующие действия:</translation>
    </message>
    <message>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="vanished">Действия не закончены. Вы хотите продолжить?</translation>
    </message>
    <message>
        <source>Creating required partitions</source>
        <translation type="vanished">Cоздание необходимых разделов</translation>
    </message>
    <message>
        <source>Preparing required partitions</source>
        <translation type="vanished">Подготовка необходимых разделов </translation>
    </message>
    <message>
        <source>Mounting the / (root) partition</source>
        <translation type="vanished">Подключение / (корневого) разделa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>Deleting old system</source>
        <translation>Удаление старой системы</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Не удалось удалить старый %1 в месте назначения.
Возврат к шагу 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>Creating system directories</source>
        <translation>Создание системных каталогoв</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <source>Fixing configuration</source>
        <translation>Установка конфигурации</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="887"/>
        <source>Copying new system</source>
        <translation>Копирование новой системы</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="927"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="936"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Не удалось записать %1 в место назначения.
Возврат к шагу 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="954"/>
        <source>Installing GRUB</source>
        <translation>Установка GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1039"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1055"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Please enter a user name.</source>
        <translation type="vanished">Введите имя пользователя</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Имя пользователя не должно содержать специальных символов или пробелов. Выберите другое имя перед продолжением.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Извините, это имя используется. Выберите другое.</translation>
    </message>
    <message>
        <source>Please enter the user password.</source>
        <translation type="vanished">Введите пароль пользователя.</translation>
    </message>
    <message>
        <source>Please enter the root password.</source>
        <translation type="vanished">Введите root пароль.</translation>
    </message>
    <message>
        <source>The user password entries do not match.
Please try again.</source>
        <translation type="vanished">Введенные пароли не совпадают. Повторите снова.</translation>
    </message>
    <message>
        <source>The root password entries do not match.
Please try again.</source>
        <translation type="vanished">root пароли не совпадают. Повторите снова.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>The home directory for %1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1229"/>
        <source>Failed to set user account passwords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Failed to save old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>Failed to delete old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1276"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>К сожалению, не удалось создать каталог пользователя.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1284"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>К сожалению, не удалось дать имя каталогу пользователя.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>К сожалению, не удалось установить владельца директории пользователя.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Please enter a computer name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1356"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Извините, имя компьютера содержит недопустимые символы. Для продолжения выберите другое имя.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>Please enter a domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1366"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Извините, имя домена содержит недопустимые символы. Для продолжения выберите другое имя.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1373"/>
        <source>Please enter a workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1616"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>OK  для форматирования и использования диска целиком (%1) для %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1620"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1645"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1646"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1647"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>General Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>Installation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1716"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1718"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <location filename="../minstall.cpp" line="1789"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <location filename="../minstall.cpp" line="1790"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <location filename="../minstall.cpp" line="1791"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Choose Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1772"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>Upgrading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="134"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished">Программа установки не может быть запущена, она уже выполняется в фоновом режиме.

Пожалуйста, по возможности закройте ее, или выполните &apos;pkill minstall&apos; в терминале.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="165"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="216"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished">Вы используете 32-битную ОС, запущенную в режиме UEFI 64 бита, система не сможет загрузиться, если Вы не выберете Legacy Boot или аналогичную при перезагрузке.
Рекомендуем Вам выйти из программы и перезагрузить систему в Legacy Boot

Вы хотите продолжить установку?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="577"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption. To preserve the format of an existing encrypted partition, you must use the same passphrase that it was originally encrypted with.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1765"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1775"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1776"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>Preferred Filesystem Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1779"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Bad Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1785"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>Advanced Encryption Settings</source>
        <translation>Расширенные настройки шифрования</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1802"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>A variety of ciphers are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1811"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>Chain mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1817"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>IV generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1822"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1824"/>
        <source>Key size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1824"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1825"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1827"/>
        <source>LUKS key hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1827"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1830"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1830"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1831"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1833"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1835"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1855"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Общие службы для Включения&lt;/b&gt;&lt;br/&gt;Выберите любые из этих общих служб, которые могут Вам понадобиться в конфигурации Вашей системы, и службы будут запускаться автоматически при запуске %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Идентификация kомпьютерa&lt;/b&gt;&lt;br/&gt;Имя компьютера - уникальное имя, которое будет идентифицировать Ваш компьютер, когда он находится в сети. Домен компьютера вряд ли будет использоваться, только если Ваш провайдер или локальная сеть этого требуют.&lt;/p&gt;&lt;p&gt;Имена компьютера и домена могут содержать только алфавитно-цифровые символы, точки, дефисы. Они не могут содержать пробелов, начинаться или заканчиваться дефисом&lt;/p&gt;&lt;p&gt;Samba-сервер должен быть активирован, если Вы хотите использовать его, чтобы поделиться некоторыми из ваших каталогов или принтерoм с локальным компьютером, на котором запущен MS-Windows или Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1872"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1873"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1877"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1879"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1886"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1887"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2100"/>
        <location filename="../minstall.cpp" line="2484"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2102"/>
        <location filename="../minstall.cpp" line="2489"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2443"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2443"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2486"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Localization Defaults&lt;/b&gt;&lt;br/&gt;Set the default keyboard and locale. These will apply unless they are overridden later by the user.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Configure Clock&lt;/b&gt;&lt;br/&gt;If you have an Apple or a pure Unix computer, by default the system clock is set to GMT or Universal Time. To change, check the box for &apos;System clock uses LOCAL.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timezone Settings&lt;/b&gt;&lt;br/&gt;The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Service Settings&lt;/b&gt;&lt;br/&gt;Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing! </source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Локализация по умолчанию&lt;/b&gt;&lt;br/&gt;Установите раскладку клавиатуры и язык по умолчанию. Они будут применяться, если не будут изменены позже пользователем.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Настройка часов&lt;/b&gt;&lt;br/&gt;Если у Вас Apple или чисто Unix компьютер, по умолчанию системные часы установлены по Гринвичу или всемирному времени. Чтобы изменить, установите флажок для &quot;Системные часы используют местное время&quot;.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Настройки часового пояса&lt;/b&gt;&lt;br/&gt;Система загружается с предустановкой системного времени в GMT/UTC. Чтобы изменить часовой пояс, после перезагрузки в новую установку, щелкните правой кнопкой мыши на часах в панели и выберите Свойства&lt;/p&gt;&lt;p&gt;&lt;b&gt;Настройки служб&lt;/b&gt;&lt;br/&gt;Большинство пользователей не должны изменять значения по умолчанию. Людям с компьютерами с ограниченными ресурсами иногда хочется отключить ненужные службы в целях уменьшения использования оперативной памяти. Убедитесь, что Вы знаете, что Вы делаете! </translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Default User Login&lt;/b&gt;&lt;br/&gt;The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Passwords&lt;/b&gt;&lt;br/&gt;Enter a new password for your default user account and for the root account. Each password must be entered twice.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Пользователь по умолчанию&lt;/b&gt;&lt;br/&gt;Суперпользователь cхож c Администратором в некоторых других операционных системax. Вы не должны использовать суперпользователя в качестве повседневной учетной записи. Пожалуйста, введите имя для новой учетной записи пользователя (по умолчанию), который будет использоваться на постоянной основе. Если необходимо, Вы сможете добавить другие учетные записи пользователей позже с помощью %1 Диспетчера пользователей. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Пароли&lt;/b&gt;&lt;br/&gt;Введите новый пароль для вашей учетной записи пользователя по умолчанию, и для учетной записи суперпользователя. Оба пароля необходимо ввести дважды.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1906"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1907"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1909"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1910"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1912"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1913"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1915"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1916"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1917"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1918"/>
        <source>Warning</source>
        <translation>Предупреждение</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1919"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1935"/>
        <source>Installation in Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1936"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1938"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1941"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1943"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1952"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Поздравляем!&lt;/b&gt;&lt;br/&gt;Вы завершили установку %1.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Поиск приложений&lt;/b&gt;&lt;br/&gt;Есть сотни великолепных приложений, установленных с %1. Лучший способ узнать о них - просмотреть меню и попробовать их. Многие из приложений были разработаны специально для %1. Они показаны в основном меню. &lt;p&gt;Кроме того, %1 включает в себя множество стандартных приложений Linux, которые выполняются только из командной строки, и потому не отображены в меню.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1961"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Приятного использования %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1962"/>
        <location filename="../minstall.cpp" line="2375"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Поддержка %1&lt;/b&gt;&lt;br/&gt;%1 поддерживается такими же людьми, как Вы. Некоторые помогают другим на форуме поддержки - %2, или переводят файлы справки на различные языки, или вносят предложения, пишут документацию, или помогают в тестировании нового программного обеспечения.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1993"/>
        <source>Finish</source>
        <translation>Готово</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1997"/>
        <source>OK</source>
        <translation>Да</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1999"/>
        <source>Next</source>
        <translation>Дальше</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2034"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2037"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2041"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2058"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2300"/>
        <source>Confirmation</source>
        <translation>Подтверждение</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2300"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Установка и конфигурация не завершены.
Вы действительно хотите остановить процесс сейчас?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2361"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Получение помощи&lt;/b&gt;&lt;br/&gt;Основная информация о %1 находится на %2.&lt;/p&gt;&lt;p&gt; Есть добровольцы, которые помогут Вам на  %3 Форуме, %4.&lt;/p&gt;&lt;p&gt;Если обращаетесь за помощью, то не забудьте достаточно подробно описать Вашу проблему и Ваш компьютер. Обращения, подобные &quot;это не работает&quot;, обычно малополезны.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2369"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ремонт установленной системы&lt;/b&gt;&lt;br/&gt;Если %1 перестает работать с жесткого диска, иногда можно исправить эту проблему, загрузившись с DVD-диска или USB носителя и запуская утилиты из %1, или стандартные Linux-инструменты для восстановления системы.&lt;/p&gt;&lt;p&gt;Также загрузочный %1 DVD-диск или USB носитель можно использовать для восстановления данных из компьютеров с MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2383"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Настройка Вашего звуковогo микшерa&lt;/b&gt;&lt;br/&gt;%1 пытается настроить звуковой микшер для Вас, но иногда Вам придется увеличить громкость и включить звуковые каналы в микшере, чтобы услышать звук.&lt;/p&gt; &lt;p&gt;Ярлык микшера находится в меню. Нажмите на него, чтобы открыть микшер. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2391"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Поддерживайте Ваш %1 в актуальном состоянии&lt;/b&gt;&lt;br/&gt;Для получения дополнительной информации и обновлений, пожалуйста, посетите&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2396"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Особая благодарность&lt;/b&gt;&lt;br/&gt;Спасибо всем, кто поддержал %1 времeм, деньгaми, предложениями, работaми, похвалaми, идеями, продвижением в сообществах и/или поощрениями.&lt;/p&gt;&lt;p&gt;Без вас не было бы никакого %1.&lt;/p&gt;&lt;p&gt;Команда разработчкиков %2&lt;/p&gt;</translation>
    </message>
    <message>
        <source>This option also encrypts swap partition if selected, which will render the swap partition unable to be shared with other installed operating systems.</source>
        <translation type="vanished">Эта опция также шифрует раздел подкачки swap, делая невозможным его использование для других установленных операционных систем.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2640"/>
        <source>System boot disk:</source>
        <translation>Системный загрузочный диск:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2654"/>
        <location filename="../minstall.cpp" line="2663"/>
        <source>Partition to use:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Справка</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="151"/>
        <source>Next</source>
        <translation>Дальше</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="372"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2362"/>
        <source>Back</source>
        <translation>Назад</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2368"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2381"/>
        <source>Installation in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Abort</source>
        <translation>Отмена</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1290"/>
        <location filename="../meinstall.ui" line="2399"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Закрыть</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="204"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="239"/>
        <source>Terms of Use</source>
        <translation>Условия использования</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="266"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Настройки клавиатуры&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Модель:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="280"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Вариант:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="303"/>
        <source>Change Keyboard Settings</source>
        <translation>Изменить настройки клавиатуры</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="310"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Раскладка:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Modify partitions:</source>
        <translation type="vanished">Изменить разделы:</translation>
    </message>
    <message>
        <source>Run partition tool...</source>
        <translation type="vanished">Запустить инструмент работы с разделами...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-install using entire disk </source>
        <translation type="vanished">Автоматическая установка с использованием всего диска</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="408"/>
        <location filename="../meinstall.ui" line="794"/>
        <source>Encryption password:</source>
        <translation>Пароль для шифрования:</translation>
    </message>
    <message>
        <source>MB </source>
        <translation type="vanished">MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <location filename="../meinstall.ui" line="777"/>
        <source>Confirm password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leave free space up to:</source>
        <translation type="vanished">Оставьте свободное пространство до:</translation>
    </message>
    <message>
        <source>Custom install on existing partitions</source>
        <translation type="vanished">Выборочная установка на существующих разделах</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <location filename="../meinstall.ui" line="817"/>
        <location filename="../meinstall.ui" line="849"/>
        <source>Advanced encryption settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="466"/>
        <location filename="../meinstall.ui" line="675"/>
        <source>Encrypt</source>
        <translation>Зашифровать</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="440"/>
        <source>Use disk:</source>
        <translation>Использовать диск:</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Предпочтения</translation>
    </message>
    <message>
        <source>Preserve data in /home (if upgrading)</source>
        <translation type="vanished">Сохранить данные в /home (при обновлении)</translation>
    </message>
    <message>
        <source>Check for badblocks (takes longer)</source>
        <translation type="vanished">Проверить &quot;битые блоки&quot; (занимает больше времени)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="622"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ext4</source>
        <translation type="vanished">ext4</translation>
    </message>
    <message>
        <source>ext3</source>
        <translation type="vanished">ext3</translation>
    </message>
    <message>
        <source>ext2</source>
        <translation type="vanished">ext2</translation>
    </message>
    <message>
        <source>jfs</source>
        <translation type="vanished">jfs</translation>
    </message>
    <message>
        <source>xfs</source>
        <translation type="vanished">xfs</translation>
    </message>
    <message>
        <source>btrfs</source>
        <translation type="vanished">btrfs</translation>
    </message>
    <message>
        <source>btrfs-zlib</source>
        <translation type="vanished">btrfs-zlib</translation>
    </message>
    <message>
        <source>btrfs-lzo</source>
        <translation type="vanished">btrfs-lzo</translation>
    </message>
    <message>
        <source>reiserfs</source>
        <translation type="vanished">reiserfs</translation>
    </message>
    <message>
        <source>reiser4</source>
        <translation type="vanished">reiser4</translation>
    </message>
    <message>
        <source>boot:</source>
        <translation type="vanished">загрузка:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="665"/>
        <source>Label</source>
        <translation>Метка</translation>
    </message>
    <message>
        <source>root:</source>
        <translation type="vanished">корневой раздел:</translation>
    </message>
    <message>
        <source>swap:</source>
        <translation type="vanished">подкачка:</translation>
    </message>
    <message>
        <source>root</source>
        <translation type="vanished">корневой раздел</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="vanished">Тип</translation>
    </message>
    <message>
        <source>home:</source>
        <translation type="vanished">домашний раздел:</translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="vanished">Положение</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="761"/>
        <source>Encryption options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="865"/>
        <source>SHA-512</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="870"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="875"/>
        <source>Whirlpool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="880"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="885"/>
        <source>RIPEMD-160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="902"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="921"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="943"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="956"/>
        <source>Key size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="982"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1005"/>
        <source>Cipher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1025"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1030"/>
        <source>AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1035"/>
        <source>Twofish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1040"/>
        <source>CAST6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1045"/>
        <source>Blowfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1062"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1092"/>
        <source>ESSIV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1097"/>
        <source>Plain64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1102"/>
        <source>Plain64BE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1107"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1112"/>
        <source>BENBI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1126"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1139"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1159"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1167"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1172"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1199"/>
        <source>Select Boot Method</source>
        <translation>Выбрать метод загрузки</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1236"/>
        <source>EFI System Partition</source>
        <translation>Системный раздел EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1239"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1258"/>
        <source>Partition Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1261"/>
        <source>PBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1274"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1287"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Установить GRUB для Linux и Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1306"/>
        <source>System boot disk:</source>
        <translation>Системный загрузочный диск:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1328"/>
        <source>Master Boot Record</source>
        <translation>Главная загрузочная запись</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1334"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1408"/>
        <source>Common Services to Enable</source>
        <translation>Включить общие службы</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1427"/>
        <source>Service</source>
        <translation>Служба</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1432"/>
        <source>Description</source>
        <translation>Описание</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1465"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1492"/>
        <source>Workgroup</source>
        <translation>Рабочая группа:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1505"/>
        <source>Workgroup:</source>
        <translation>Рабочая группа:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Samba-сервер для MS сетей</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1534"/>
        <source>example.dom</source>
        <translation>example.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1547"/>
        <source>Computer domain:</source>
        <translation>Компьютерный домен:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1573"/>
        <source>Computer name:</source>
        <translation>Имя компьютера:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1634"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System clock uses LOCAL</source>
        <translation type="vanished">Системные часы используют местное время</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1675"/>
        <source>Format:</source>
        <translation>Формат:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1703"/>
        <source>Timezone:</source>
        <translation>Часовой пояс:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1748"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1780"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1820"/>
        <source>Locale:</source>
        <translation>Языковые установки:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1842"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>Adjust which services should run at startup</source>
        <translation>Отметьте, какие службы должны запускаться при старте</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1863"/>
        <source>View</source>
        <translation>Вид</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1921"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1978"/>
        <source>Confirm root password:</source>
        <translation>Подтвердите пароль суперпользователя:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1933"/>
        <source>Root password:</source>
        <translation>Пароль суперпользователя:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2007"/>
        <source>Default User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2109"/>
        <source>username</source>
        <translation>Имя пользователя</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2048"/>
        <source>Confirm user password:</source>
        <translation>Подтвердите пароль пользователя:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2035"/>
        <source>Default user password:</source>
        <translation>Пароль пользователя по умолчанию:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2019"/>
        <source>Default user login name:</source>
        <translation>Логин пользователя по умолчанию:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="385"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="523"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="558"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="655"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="660"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="693"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="712"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="719"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="729"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="739"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2125"/>
        <source>Autologin</source>
        <translation>Автологин</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2138"/>
        <source>Show passwords</source>
        <translation>Показать пароли</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2151"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Перенести изменения рабочей среды, сделанные в live-режиме, в установленную ОС</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2154"/>
        <source>Save live desktop changes</source>
        <translation>Сохранить изменения рабочей среды</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2177"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2186"/>
        <source>What would you like to do with the old directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2193"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2252"/>
        <source>Tips</source>
        <translation>Подсказки</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2296"/>
        <source>Installation complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2302"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2321"/>
        <source>Reminders</source>
        <translation>Напоминания</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="343"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="258"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="539"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="257"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="256"/>
        <source>EFI System Partition</source>
        <translation type="unfinished">Системный раздел EFI</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="444"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="449"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="453"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="454"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="470"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="473"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="474"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="550"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="595"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished">Вы должны выбрать корневой раздел.
Он должен быть не менее %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="601"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished">Вы должны указать отдельный раздел boot, если используется шифрованный корневой раздел.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="613"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="616"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="622"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="625"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished">Следующие выбранные вами разделы не являются разделами Linux:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="633"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished">Вы уверены, что хотите переформатировать эти разделы?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="641"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished">Установщик %1 отфарматирует и разрушит данные на следующих разделах:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="649"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished">Установщик %1 выполняет следующие действия:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="653"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished">Действия не закончены. Вы хотите продолжить?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="750"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="754"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="755"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="760"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="762"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished">Вы хотите прервать установку?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished">Вы хотите продолжить?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="941"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="949"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished">Подготовка необходимых разделов </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1003"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished">Настройка шифрованных контейнеров LUKS</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1020"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1186"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="vanished">Программа установки не может быть запущена, она уже выполняется в фоновом режиме.

Пожалуйста, по возможности закройте ее, или выполните &apos;pkill minstall&apos; в терминале.</translation>
    </message>
    <message>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="vanished">Вы используете 32-битную ОС, запущенную в режиме UEFI 64 бита, система не сможет загрузиться, если Вы не выберете Legacy Boot или аналогичную при перезагрузке.
Рекомендуем Вам выйти из программы и перезагрузить систему в Legacy Boot

Вы хотите продолжить установку?</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must run this app as root.</source>
        <translation type="vanished">Вы должны запустить это приложение от имени суперпользователя.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
