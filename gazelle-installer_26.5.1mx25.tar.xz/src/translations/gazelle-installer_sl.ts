<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="sl">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Root</source>
        <translation>Koren</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Home</source>
        <translation>Domov</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="175"/>
        <source>The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>Izbrani pogon ima zmogljivost vsaj 2TB in mora biti formatiran z uporabo GPT. Na nekaterih sistemih diski, ki so formatirani z GPT, ne morejo izvesti zagona.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="177"/>
        <source>Are you sure you want to continue?</source>
        <translation>Želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="183"/>
        <source>The system and home drives cannot be the same for this type of installation.</source>
        <translation>Sistemski in domači pogon ne moreta biti ista za tovrstno namestitev.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="187"/>
        <source>Format and use drives entirely for %1</source>
        <translation>Formatiraj in uporabi celotne pogone za %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="189"/>
        <source>System drive: %1</source>
        <translation>Sistemski pogon: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="191"/>
        <source>Home drive: %1</source>
        <translation>Domači pogon: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="194"/>
        <source>Format and use the entire drive for %1: %2</source>
        <translation>Formatiraj in uporabi celoten disk za %1: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="224"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>Priporočeno: %1
Najmanj: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="226"/>
        <source>Minimum for hibernation support: %1</source>
        <translation>Minimum za podporo hibernaciji: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="268"/>
        <source>Layout Builder</source>
        <translation>Razdeljevalnik</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="468"/>
        <source>%1% root
%2% home</source>
        <translation>%1% root
%2% home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="470"/>
        <source>Combined root and home</source>
        <translation>Kombinirani korenski root in domači home</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="90"/>
        <source>Cannot access installation media.</source>
        <translation>Ne moremo dostopati do namestitvenega nosilca.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="260"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Neuspešno brisanje starega sistema.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="263"/>
        <source>Deleting old system</source>
        <translation>Brisanje starega sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="287"/>
        <source>Failed to set the system configuration.</source>
        <translation>Nastavljanje sistemske konfiguracije ni bilo uspešno</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="289"/>
        <source>Setting system configuration</source>
        <translation>Nastavitev konfiguracije sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="451"/>
        <source>Copying new system</source>
        <translation>Kopiranje novega sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="623"/>
        <source>Failed to copy the new system.</source>
        <translation>Kopiranje novega sistema ni bilo uspešno.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="133"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>Namesitev GRUB ni uspela. Lahko zaženete živ nosilec in uporabite GRUB reševalni meni, da bi popravili namestitev.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="207"/>
        <source>Installing GRUB</source>
        <translation>Nameščam GRUB</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="470"/>
        <source>Updating initramfs</source>
        <translation>Posodabljam initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="471"/>
        <source>Failed to update initramfs.</source>
        <translation>Ni bilo mogoče posodopbiti initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="529"/>
        <source>System boot disk:</source>
        <translation>Zagonski disk sistema:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="544"/>
        <location filename="../bootman.cpp" line="554"/>
        <source>Partition to use:</source>
        <translation>Razdelek za uporabo:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="67"/>
        <source>The installation media is corrupt.</source>
        <translation>Namestitveni nosilec je okvarjen.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="76"/>
        <source>The installation media is still being checked.</source>
        <translation>Namestitveni nosilec se še vedno preverja.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="77"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>Ali želite res preskočiti preverjanje namestitvenega nosilca?</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="233"/>
        <source>Checking installation media.</source>
        <translation>Preverjanje namestitvenega nosilca.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="234"/>
        <source>Press ESC to skip.</source>
        <translation>Pritisniti ESC za preskok.</translation>
    </message>
</context>
<context>
    <name>Crypto</name>
    <message>
        <location filename="../crypto.cpp" line="63"/>
        <source>Failed to format LUKS container.</source>
        <translation>LUKS vsebnika ni bilo mogoče oblikovati.</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="67"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Ustvarjanje šifriranega nosilca: %1</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="72"/>
        <source>Failed to open LUKS container.</source>
        <translation>LUKS vsebnika ni bilo mogoče odpreti.</translation>
    </message>
</context>
<context>
    <name>Device</name>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Overwrite</source>
        <translation>Prepišem</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Create</source>
        <translation>Ustvari</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2367"/>
        <source>Delete</source>
        <translation>Izbriši</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2371"/>
        <source>Preserve</source>
        <translation>Ohrani</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2372"/>
        <source>Preserve (%1)</source>
        <translation>Ohrani (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2373"/>
        <source>Preserve /home (%1)</source>
        <translation>Ohrani /home (%1)</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="484"/>
        <source>Unknown release</source>
        <translation>Neznana izdaja</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="149"/>
        <source>Shutdown</source>
        <translation>Izklop</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="442"/>
        <source>You are running 32-bit OS started in 64-bit UEFI mode.</source>
        <translation>Izvaja se 32 bitni OS, ki je bil zagnan v 64 bitnem UEFI načinu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="443"/>
        <source>The system will not be able to boot unless you restart the system in Legacy Boot (or similar mode) before proceeding.</source>
        <translation>Sistem se ne bo mogel zagnati, če ga pred nadaljevanjem znova ne zaženete v &quot;legacy&quot; zagonskem načinu (ali podobnem).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="445"/>
        <source>Do you want to continue the installation?</source>
        <translation>Ali želite nadaljevati namestitev?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="487"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>Program za namestitev %1 bo izvedel zahtevana dejanja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="488"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Teh dejanj ni mogoče razveljaviti. Ali bi radi nadaljevali?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="500"/>
        <source>Support %1</source>
        <translation>Podpora %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="501"/>
        <source>%1 is supported by people like you. Some help others at the support forum, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 je podprt s strani ljudi, kot ste vi. Nekateri nudijo pomoč v podpornem forumu ali prevajajo pomoč v različne jezike, predlagajo, pišejo dokumentacijo ali pomagajo pri testiranju novih programov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <location filename="../minstall.cpp" line="1769"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 je neodvisna distribucija Linuxa, ki temelji na stabilnem Debianu.

%1 uporablja neketere komponente MEPIS Linuxa, ki so izdane pod prosto Apache licenco. Nekatere MEPIS komponente so bile prilagojene za %1.

Uživajte v sistemu %1!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>Preparing to install %1</source>
        <translation>Priprava na namestitev %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>Paused for required operator input</source>
        <translation>Čakam na zahtevan vnos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>Setting system configuration</source>
        <translation>Nastavitev konfiguracije sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>Cleaning up</source>
        <translation>Čiščenje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>Finished</source>
        <translation>Končano</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="733"/>
        <source>Configuring system. Please wait.</source>
        <translation>Nastavljanje sistema. Počakajte.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Konfiguriranje je končasno. Ponovno zaganjam sistem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="744"/>
        <source>The installation was aborted.</source>
        <translation>Namestitev je bila prekinjena</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="768"/>
        <source>Pretending to install %1</source>
        <translation>Pretvarjam se, da nameščam %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="812"/>
        <source>Invalid settings found in configuration file (%1).</source>
        <translation>V nastavitveni datoteki (%1) so napake.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="813"/>
        <source>Please review marked fields as you encounter them.</source>
        <translation>Preverite označena polja, ko naletite na njih.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="239"/>
        <location filename="../minstall.cpp" line="911"/>
        <location filename="../minstall.cpp" line="927"/>
        <location filename="../minstall.cpp" line="956"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Podatki v /home ne morejo biti ohranjeni, ker ni bilo mogoče pridobiti potrebnih podatkov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="238"/>
        <location filename="../minstall.cpp" line="817"/>
        <location filename="../minstall.cpp" line="926"/>
        <location filename="../minstall.cpp" line="983"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Invalid settings found in configuration file (%1).
Please review marked fields as you encounter them.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="984"/>
        <location filename="../minstall.cpp" line="995"/>
        <source>Cannot find selected drive.</source>
        <translation>Izbranega pogona ni mogoče najti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1042"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Domači /home direktorij za %1 že obstaja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1087"/>
        <source>General Instructions</source>
        <translation>Splošna navodila</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1088"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>PRED NADALJEVANJEM ZAPRITE VSE OSTALE APLIKACIJE.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1089"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Prosimo, da na vsaki strani preberete navodila, naredite izbor in potem kliknete Naprej, ko ste pripravljeni za nadaljevanje. Pozvani boste k potrditvi izbire, preden se izvedejo kakšne destruktivne akcije.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1091"/>
        <source>Limitations</source>
        <translation>Omejitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1092"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Pomnite, da je ta programska oprema na voljo TAKO KOT JE, brez kakršnekoli garancije. Zgolj vaša odgovornost je, da poskrbite za ustrezno varnostno kopiranje vaših podatkov, preden nadaljujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1096"/>
        <source>Installation Options</source>
        <translation>Možnosti namestitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1097"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Če poganjate Mac OS ali Windows OS (od različice Vista naprej), boste morda morali pred namestitvijo uporabiti orodja teh sistemov za ustvarjanje razdelkov in zagonskega upravljalnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1098"/>
        <source>Dual drive</source>
        <translation>Dvojni pogon</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1099"/>
        <source>If your system has multiple storage drives, this option allows you to have the system files on one drive (the System drive), while keeping the data of all users on a separate drive (the Home drive).</source>
        <translation>Če ima sistem več podatkovnih pogonov, ta možnost omogoča, da so sistemske datoteke na enem pogonu (sistemski pogon), medtem ko se podatkih vseh uporabnikov nahajajo na drugem pogonu (domači pogon).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1101"/>
        <source>Using the root-home space slider</source>
        <translation>Uporaba drsnika za velikost root-home razdelka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1102"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>Pogon je mogoče razdeliti v ločena razdelka za sistem (root) in uporabniške podatke (home) s pomočjo drsnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1103"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>Korenski razdelek &lt;b&gt;root&lt;/b&gt; bo vseboval operacijski sistem in programe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1104"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>Domači razdelek &lt;b&gt;home&lt;/b&gt; bo vseboval podatke uporabnikov, kot so nastavitve, datoteke, dokumente, slike, glasbo, video posnetke, itd.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1105"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Premaknite drsnik na desno, če želite povečasti prosgtor za korenski &lt;b&gt;root&lt;/b&gt;. Pfremaknite ga na levo, če želite povečati prostor za  domači &lt;/b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1106"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Premaknite drsnik popolnoma na desno, če želite imeti root in home na istem razdelku.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1107"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Ločitev domačega (home) direktorija izboljša zanesljivost nadgrajevanja operacijskega sistema. Poleg tega poenostavi varnostno kopiranje in obnavljanje. Z določitvijo sistemskih datotek na točno določen del diska je mogoče tudi izboljšati zmogljivost delovanja sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1109"/>
        <location filename="../minstall.cpp" line="1207"/>
        <location filename="../minstall.cpp" line="1227"/>
        <source>Encryption</source>
        <translation>Šifriranje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1110"/>
        <location filename="../minstall.cpp" line="1208"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Šifriranje je možno preko LUKS. Zahtevano je geslo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1111"/>
        <location filename="../minstall.cpp" line="1209"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Potreben je ločen nešifriran zagosnki razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1112"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Če se šifriranje uporablja skupaj z opcijo za samodejno namestitev, bo samodejno ustvarjen ločen zagonski razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1113"/>
        <source>Using a custom disk layout</source>
        <translation>Uporaba lastne razdelitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1114"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Če potrebujete več nadzora nad tem, kje bo nameščen %1, izberite &quot;&lt;b&gt;%2&lt;/b&gt;&quot; in kliknite &lt;b&gt;Naprej&lt;/b&gt;. Na naslednji strani boste lahko izbrali nosilec podatkov in razdelke, ki jih potrebujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <location filename="../minstall.cpp" line="1122"/>
        <source>Replace existing installation</source>
        <translation>Nadomesti obstoječo namestitev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <source>Replace existing installation option will attempt to replace an existing installation with the same disk configuration as the existing installation.  Home directories are preserved.</source>
        <translation>Možnost Nadomesti obstoječo namestitev bo poskusila nadomestiti obstoječo namestitev z enako konfiguracijo diskov, kot jo ima trenutna namestitev. Domače mape se ohranijo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1123"/>
        <source>If you have an existing installation, you can use this function to replace it with a fresh installation.</source>
        <translation>Če imate obstoječo namestitev, jo lahko s to funkcijo nadomestite s svežo namestitvijo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1124"/>
        <source>This is particularly useful if you are upgrading from a previous version and want to preserve your data.</source>
        <translation>To je zelo uporabno, če želite nadgradnjo s prejšnje različice in želite ohraniti podatke.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1126"/>
        <source>There is no guarantee of this working successfully. Ensure you have a good working backup of all important data before continuing.</source>
        <translation>Ni zagotovila, da bo to delovalo. Poskrbite za delujočo varnostno kopijo z vsemi pomembnimi podatki še preden nadaljujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1127"/>
        <source>This feature is designed to replace an installation performed using the regular install method, and may fail to replace an installation with a complex layout or storage scheme. Corruption or data loss may occur.</source>
        <translation>Ta funkcionalnost je narejena za nadomestitev namestitve, ki je bila izvedena na običajen način in je lahko neuspešna, če namestitev uporablja zapleteno razporeditev ali shemo razdelkov. Podatki se lahko pokvarijo ali izgubijo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>To replace an installation with a complex layout or storage scheme, it is recommended to use the custom layout option instead.</source>
        <translation>Za nadomestitev namestitve z zahtevno razporeditvijo ali shemo razdelkov je priporočljivo uporabiti možnost ustvarjanja razporedov po meri.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1137"/>
        <source>Choose Partitions</source>
        <translation>Izberite razdelke</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1138"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Seznam razdelkov omogoča izbiro razdelkov, ki bodo uporabljeni za namestitev.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1139"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Naprava&lt;/i&gt; - To je ime bločne naprave, ki je ali bo določena za ustvarjeni razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1140"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Velikost&lt;/i&gt; - Velikost razdelka. To je mogoče spremeniti le v novi razporeditvi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1141"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Uporabi za&lt;/i&gt; - Da bi ta razdelek uporabili pri namestitvi, morate tu nekaj izbrati.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1143"/>
        <source>Format without mounting</source>
        <translation>Formatiraj brez priklapljanja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1144"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>BIOS zagonski GPT razdelek za GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1145"/>
        <location filename="../minstall.cpp" line="1184"/>
        <source>EFI System Partition</source>
        <translation>EFI sistemski razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1147"/>
        <source>Boot manager</source>
        <translation>Upravljalnik zagona</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1148"/>
        <source>System root</source>
        <translation>Sistemski koren (root)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1149"/>
        <source>User data</source>
        <translation>Uporabniški podatki</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1150"/>
        <source>Static data</source>
        <translation>Statični podatki</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1151"/>
        <source>Variable data</source>
        <translation>Spremenljivi podatki</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1152"/>
        <source>Temporary files</source>
        <translation>Začasne datoteke</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>Swap files</source>
        <translation>Swap datoteke</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1154"/>
        <source>Swap partition</source>
        <translation>Swap razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1156"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Poleg naštetih je mogoče ustvariti tudi svojo točko priklopa. Lastne pirklopne točke se morajo začeti s poševnico (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1157"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Label&lt;/i&gt; - Oznaka se pripiše razdelku po formatiranju.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1158"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Šifriranje&lt;/i&gt; - Za ta razdelek uporabi LUKS šifriranje. Geslo se nanaša na vse razdelke, ki so označeni za šifriranje.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Format&lt;/i&gt; - To je format oz. vrsta razdelka. Vrste, ki so na voljo, so odvisne od rabe razdelka. Če delate z obstoječim razporedom, lahko tudi ohranite vrsto razdelka z izbiro &lt;b&gt;Ohrani&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1161"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>Izbira &lt;b&gt;Ohrani /home&lt;/b&gt; za korenski razdelek ohrani vsebino /home mape in izbriše vse drugo. To možnost je mogoče izbrati le, če se /home nahaja na istem razdelku kot root.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1163"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Podprti so Linux datotečni sistemi ext2, ext3, ext4, jfs, xfs in  btrfs, priporočna je raba ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Preveri&lt;/i&gt; - Preveri in popravi okvarjene sektorje na disku (ni podprto za vse formate). To zahteva veliko časa, zato to preskočite, če ne sumite, da ima diska okvarjene sektorje.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1166"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Možnosti priklopa&lt;/i&gt; - Tu določite možnosti priklopa, ki bodo uporabljene za ta razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1167"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Deponiraj&lt;/i&gt; - Ukaže orodju za deponiranje, da v varnostno kopijo vključi tudi ta razdelek.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1168"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Prehod&lt;/i&gt; - Zaporedje preizkusa datotečnega sistema ob zagonu. Če je nič, datotečni sistem ne bo preizkušen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1169"/>
        <source>Menus and actions</source>
        <translation>Meniji in dejanja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Na voljo so različna dejanja, do katerih dostopate z desnim klikom na razdelku v seznamu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1171"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Za spreminjanje vnosov je mogoče uporabiti tudi gumbe desno od seznama.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1172"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>Namestitveni program ne more spreminjati razporeda, ki je že na pogonu. Da bi oblikovali lastno razporeditev, označite pogon kot nov razdelek z izbiro &lt;b&gt;Nova razdelitev&lt;/b&gt;v meniju dejanj ali s pritiksom na  (%1). To bo počistilo obstoječo shemo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1175"/>
        <source>Basic layout requirements</source>
        <translation>Osnovne zahteve pri razdeljevanju</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1176"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 potrebuje korenski /root razdelek. Izmenjevalni swap razdelek je opcijski, a je zelo priporočljiv. Če želite uporabljati funkcijo Hiberniraj na disku, ki jo ponuja %1, boste potrebovali swap razdelek, ki je večji od velikosti fizičnega pomnilnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1178"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Če izberete ločen /home razdelek, bo v prihodnje lažje nadgraditi vaš računalnik, vendar le v primeru, da ne gre za nadgrajevanje namestitve, ki nima ločenega /home razdelka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1180"/>
        <source>Active partition</source>
        <translation>Aktivni razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Da bi se nameščeni operacijski sistem zagnal, mora biti kot aktiven označen ustreen razdelek (ponavadi razdelek boot ali root).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1182"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>Aktivni razdelek pogona je mogoče izbrati preko možnosti menija &lt;b&gt;Aktivni razdelek&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Razdelek z zvezdico (*) ob imenu je ali bo postal aktivni razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1185"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Če sistem uporablja  Extensible Firmware Interface (EFI), je za zagon sistema potreben EFI sistemski razdelek (ESP).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1186"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Ti sistemi ne potrebujejo razdelka, ki je označen za aktivnega. Namesto tega zahtevajo razdelek, ki je formatiran z datotečnim sistemom FAT in je oznažen kot ESP.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1187"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>Večina sistemov narejenih v zadnjih desetih letihuporablja EFI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>Boot partition</source>
        <translation>Zagonski razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1189"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Ta razdelek je na splošno potreben le za korenske razdelke na virtualnih napravah, kot so šifrirani, LVM ali programski RAID nosilci.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1190"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Vsebuje osnovno jedro in gonilnike, ki so potrebni za dostop do šifriranega diska ali virtualnih naprav.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>BIOS-GRUB partition</source>
        <translation>BIOS-GRUB razdelek</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1192"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>Če je uporabljen GPT formatiran disk v ne-EFI sistemu, je potreben 1MB BIOS zagonski razdelek, da bi lahko uproabljali GRUB.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1193"/>
        <source>Need help creating a layout?</source>
        <translation>Potrebujete pomoč pri razdeljevanju?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1194"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Zgolj kliknite na pogon in izberite &lt;b&gt;Razdeljevalnik&lt;/b&gt; iz menija. To lahko ustvari razpored, ki je pododben običajni namestitvi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1195"/>
        <source>Upgrading</source>
        <translation>Nadgrajujem</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1196"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Za nadgradnjo obstoječe Linux namestitve izberite isti domači home razdelek in izberite &lt;b&gt;Ohrani&lt;/b&gt; kot format.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1197"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Če ne uporabljate ločenega domačega razdelka, izberite &lt;b&gt;Ohrani /home&lt;/b&gt; na korenskem datotečnem sistemu, da ohranite direktorij /home na korenskem razdelku. Namestilnik bo ohranil le /home, ostalo pa bo izbrisal. Tovrstna namestitev potrebuje mnogo več časa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1199"/>
        <source>Preferred Filesystem Type</source>
        <translation>Zaželjen datotečni sistem</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Za %1 lahko izberete formatiranje v obliko ext2, ext3, ext4, f2fs, jfs, xfs ali btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1201"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Dodatne možnosti za stiskanje podatkov so na voljo za pogone, ki uproabljajo btrfs, vendar je stopnja kompresije manjša. Zlib je počasnejši, a ima večjo stopnjo stiskanja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1203"/>
        <source>System partition management tool</source>
        <translation>Orodje za upravljanje razdelkov</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1204"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Za več nadzora nad razporeditvami pogonov (kot je denimo spreminjanje obstoječe razporeditve na disku) kliknite na gumb za upravljanje z razdelki (%1). To pa zagnalo upravjlalnik razdelkov operacijskega sistema, ki omogoča ustvarjanje točno takšnega razporeda, kot ga potrebujete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1210"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Za ohranitev šifriranega razdelka nanj desno kliknite in izberite &lt;b&gt;Odklep&lt;/b&gt;. V dialog vnesite ime virtualne naprave in geslo. Ko je naprava odklenjena, se bo izbrano ime pojavilo pod &lt;i&gt;Virtualne naprave&lt;/i&gt; s podobnimi možnostmi, kot jih imajo navadni razdelki.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Za odklepanje šifiriranega razdelka ob zagonu ga je potrebno dodativ crypttab datoteko. Za to uporabite meni &lt;b&gt;Dodaj v crypttab&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1213"/>
        <source>Other partitions</source>
        <translation>Drugi razdelki</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1214"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Namestitveni program omogoča uporabo ali ustvarjanje drugih razdelkov za druge namene, vendar je dobro vedeti, da starejši sistemi ne morejo delati z več kot 4 razdelki.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1215"/>
        <source>Subvolumes</source>
        <translation>Pod-pogoni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1216"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Nekateri datotečni sistemi, kot denimo Btrfs, podpirajo več podpogonov na enem razdelku. Ker ne gre za fizično razdelitev, njihov vrstni red ni pomemben.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1218"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Uporabite meni &lt;b&gt;Pošči podpogone&lt;/b&gt;za iskanje obstoječih Btrfs razdelkov in podpogonov. Nov podpogon ustvarite z menijem &lt;b&gt;Nov podpogon&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1220"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Obstoječe podpogone je mogoče ohraniti, vendar mora ime ostati enako.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1221"/>
        <source>Virtual Devices</source>
        <translation>Virtualne naprave</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1222"/>
        <source>If the installer detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Če namestilnik odkrije virtualno napravo, kot je denimo odprti LUKS razdelek, LVM logični nosilec ali programsko ustvarjeni RAID, se lahko ta uporabi za namestitev.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1223"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>Raba virtualnih naprav (z izjemo ohranjanja šifriranih datotečni sistemov) je napredna funkcija, za katero je mogoče potrebno urediti nekaj datotek (npr.initramfs, crypttab, fstab), ki zagotavljajo, da so virtualne naprave ustvarjene ob zagonu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1228"/>
        <source>You have chosen to encrypt at least one volume, and more information is required before continuing.</source>
        <translation>Izbrali ste šifriranje za vsaj en pogon, kar zahteva več podatkov za nadaljevanje.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1233"/>
        <source>Final Review and Confirmation</source>
        <translation>Zadnje preverjanje in potrditev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Please review this list carefully. This is the last opportunity to check, review and confirm the actions of the installation process before proceeding.</source>
        <translation>Pazljivo preverite ta seznam. To je zadnja priložnost, da pred nadaljevanjem preverite in potrdite dejanja namestitve.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1244"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Namesti GRUB za Linux in Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1245"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1 uporablja GRUB zagonski nalagalnik za zagon %1 in Microsoft Windows.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1246"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Privzeto je GRUB nameščen na Master Boot Record (MBR) ali ESP (EFI System Partition za 64-bitne UEFI zagonske sisteme) razdelku zagonskega nosilca in nadomešča zagonski nalagalnik, ki je bil prej v uporabi. To je normalno.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1247"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Če izberete namesto tega namestitev GRUB v Partition Boot Record (PBR), bo GRUB nameščen na začetku določenega razdelaka. Le za izkušene uporabnike.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1248"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Če ste odznačili namesitev GRUB, ta ne bo nameščen. Le za izkušene uporabnike.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Generate host-specific initramfs will try to create an initramfs tailored for the particular device rather than a generic all-purpose initramfs. This option is for experts only.</source>
        <translation>Stvarjenje specifičnega initramfs za gostitelja, bo skušal ustvariti initramfs, ki bo prilagojen za določeno napravo in ne splošnega za vse namene. Opcija je primerna za strokovnjake.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Zram swap is a method of putting swap space in RAM.  A compressed swap device is placed in RAM.  It may be used in conjunction with other forms of swap, or on its own.</source>
        <translation>Zram swap je metoda, ki izmenjevalni prostor ustvari v pomnilniku RAM. V RAM se namesti kompresirana izmenjevlana naprava. Lahko se jo uporablja ločeno ali v kombinaciji z drugimi načini izmenjave.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Automatically restart when the installation is done</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Welcome to %1 Installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2296"/>
        <source>reset size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2684"/>
        <source>The system is being installed.
This may take several minutes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2690"/>
        <source>Reboot automatically when installation completes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2724"/>
        <source>Installation complete</source>
        <translation>Namestitev je dokončana</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4123"/>
        <source>Installing...</source>
        <translation>Nameščam...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4442"/>
        <source>Could not unlock device. Incorrect password?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>Installation Confirmation</source>
        <translation>Potrditev namestitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1935"/>
        <source>Please review the installation settings.

This is the last opportunity to check and confirm
the actions of the installation process.

Press ENTER to begin installation or Backspace to go back.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1960"/>
        <source>Enter computer name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1975"/>
        <source>Enter domain name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1989"/>
        <source>Workgroup</source>
        <translation>Delovna skupina</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2072"/>
        <source>Localization Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2078"/>
        <source>Locale:</source>
        <translation>Krajevno:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2089"/>
        <source>Time Area:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2100"/>
        <source>Time Zone:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2176"/>
        <source>System services will be configured with default settings.
You can modify service settings after installation
using your system's service manager.

Press ENTER to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2194"/>
        <source>Replace Existing Installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2210"/>
        <source>Custom Partitioning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2224"/>
        <source>Apply</source>
        <translation>Uveljavi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2258"/>
        <source>Swap File Configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2271"/>
        <source>Location:</source>
        <translation>Lokacija:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2282"/>
        <source>Size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2302"/>
        <source>Enable hibernation support</source>
        <translation>Vklopi podporo za spanje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2308"/>
        <source>Zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2313"/>
        <source>Enable zram swap</source>
        <translation>Vklopi zram swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2320"/>
        <source>Allocate based on RAM (%):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2335"/>
        <source>Allocate fixed size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2482"/>
        <source>Encryption options</source>
        <translation>Možnosti šifriranja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2487"/>
        <source>Encryption password:</source>
        <translation>Šifrirno geslo:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2498"/>
        <source>Confirm password:</source>
        <translation>Potrdite geslo:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2540"/>
        <source>Enter username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2554"/>
        <source>Enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2567"/>
        <source>Re-enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2640"/>
        <source>A home directory already exists for this user name.
Choose what to do with it:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4937"/>
        <source>Passwords must match and not be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5274"/>
        <source>Please enter a computer name.</source>
        <translation>Vnesite ime računalnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5277"/>
        <source>The computer name contains invalid characters.</source>
        <translation>Ime računalnika vsebuje neveljavne znake.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5280"/>
        <source>Please enter a domain name.</source>
        <translation>Prosiom vnesite ime domene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5283"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>Domena računalnika vsebuje neveljavne znake.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5286"/>
        <source>Please enter a workgroup.</source>
        <translation>Vnesite ime delovne skupine</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5617"/>
        <source>Please fill in all required fields before continuing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5625"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>Uporabniško ime ne more vsebovati posebnih znakov ali presledkov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5628"/>
        <location filename="../minstall.cpp" line="5631"/>
        <source>Please ensure the passwords match.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5646"/>
        <source>The chosen user name is in use.</source>
        <translation>Izbrano uporabniško ime se že uporablja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5650"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Za %1 niste podali gesla</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5658"/>
        <source>You did not provide a password for the root account.</source>
        <translation>Niste podali gesla za korenski dostop.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5747"/>
        <source>Please select an option to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1254"/>
        <location filename="../minstall.cpp" line="2263"/>
        <source>Create a swap file</source>
        <translation>Ustvari izmenjevalno swap datoteko</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="485"/>
        <source>Experimental</source>
        <comment>As In feature is not polished and may not work properly</comment>
        <translation>Eksperimentalno</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1255"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Izmenjevalna datoteka je bolj fleksibilna kot izmenjevalni razdelek, saj ji je mogoče lažje spreminjati velikost, če se pojavi potreba zaradi rabe sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>To je provzeto označeno, če ni bil določen noben izmenjevalni razdelek. To možnost naj spreminjajo le izkušeni uporabniki.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1262"/>
        <source>Common Services to Enable</source>
        <translation>Omogoči pogoste storitve:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1263"/>
        <source>Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.</source>
        <translation>Izberite katero od teh splošnih storitev, ki bi jo rabili s svojo sistemsko konfiguracijo in te storitve se bodo samodejno zagnale, ko zaženete %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1268"/>
        <source>Computer Identity</source>
        <translation>Identiteta računalnika</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1269"/>
        <source>The computer name is a common unique name which will identify your computer if it is on a network.</source>
        <translation>Ime računalnika je splošno unikatno ime, ki identificira računalnik v omrežju.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1270"/>
        <source>The computer domain is unlikely to be used unless your ISP or local network requires it.</source>
        <translation>Domena računalnika verjetno ne bo uporabljena, razen če to zahteva ISP ali lokalno omrežje.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1271"/>
        <source>The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens.</source>
        <translation>Ime domene lahko vsebuje zgolj alfanumerične znake, pike in pomišljaje. Ne sme vsebovati presledkov in ne sme se začeti ali končati s pomišljajem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1273"/>
        <source>The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.</source>
        <translation>SaMBa strežnik mora biti vklopljen, če želite deliti mape in tiskalnike z lokalnim računalnikom, ki poganja MS Windows ali Mac OSX.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Localization Defaults</source>
        <translation>Privzete krajevne nastavitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1279"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Določi privzete krajevne nastavitve. To bo uporabljno, razen če jih uporabnik kasneje ne zavrže.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1280"/>
        <source>Configure Clock</source>
        <translation>Nastavitve časa:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1281"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Če imate Apple ali čisti Unix računalnik, bo sistemska ura privzeto nastavljena na Greenwichi čas (GMT) ali univerzalni čas (UTC). Za spreminjanje označite polje &quot;&lt;b&gt;Sistemska ura uporablja krajevni čas&lt;/b&gt;&quot;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1283"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Sistem se zažene s prednastavitvijo za časovni pas GMT/UTC. Za spremembo časovnega pasu ob zagonu, po namestitivi kliknite z desno na uro v panoju in izberite Lastnosti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1285"/>
        <source>Service Settings</source>
        <translation>Nastavitve storitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1286"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Večina uporabnikov naj ne bi spreminjala privzetih vrednosti. Uporabniki z manj zmogljivimi računalniki pa si večkrat želijo izklopiti nepotrebne storitve, da bi prihranili čim več pomnilnika. Poskrbite, da veste, kaj delate!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1293"/>
        <source>Default User Login</source>
        <translation>Privzeta prijava uporabnika</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1294"/>
        <source>Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Vnesite ime novega (privzetega) računa, ki ga boste redno uporabljali. Kasneje boste lahko dodali tudi druge račune z uporabo %1 upravljalnika uporabnikov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1296"/>
        <source>Root (administrator) account</source>
        <translation>Korenski (administrativni) račun</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1297"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account.</source>
        <translation>Korenski uporabnik ima podobno skrbniško funkcijo kot administrator nekaterih drugih operacijskih sistemov. Korenskega uporabnika ni priporočljivo uporabljati kot račun za vsakodnevna opravila.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1299"/>
        <source>The root account is disabled on MX Linux, as administrative tasks are performed with an elevation prompt for the default user.</source>
        <translation>V MX Linuxu je korenski uporabnik onemogočen, ker se skrbniška opravila izvajajo preko začasnega povečanja pravic privzetega uporabnika.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1300"/>
        <source>Enabling the root account is strongly recommended for antiX Linux.</source>
        <translation>Vklop korenskega računa je zelo priporočljiv za antiX Linux.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1301"/>
        <source>Passwords</source>
        <translation>Gesla</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1302"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Vnesite novo geslo za svoj privzeti uporabniški račun in za korenski račun. Vsako geslo mora biti vneseno dvakrat,</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1304"/>
        <source>No passwords</source>
        <translation>Ni gesel</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Če želite imeti privzet uporabniški račun brez gesla, pustite polja za geslo prazna. To omogoča prijavo brez vnosa gesla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1307"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Očitno je, da je to smiselno le, le uporabniški račun ni potrebno ščititi, kot npr. kadar gre za javno dostopen terminal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1316"/>
        <location filename="../minstall.cpp" line="2634"/>
        <source>Old Home Directory</source>
        <translation>Stari /home direktorij</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1317"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Za izbrano uporabniško ime že obstaja domači /home direktorij. Ta zaslon vam omogoča, da določite, kaj se zgodi s tem direktorijom.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1319"/>
        <location filename="../minstall.cpp" line="2646"/>
        <source>Re-use it for this installation</source>
        <translation>Ponovno uporabi za to namestitev</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1320"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Za ta uporabniški račun bo uporabljen stari direktorij /home. To je dobra izbira za nadgradnjo, saj bodo datoteke in nastavitve ostale nedotaknjene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1322"/>
        <location filename="../minstall.cpp" line="2653"/>
        <source>Rename it and create a new directory</source>
        <translation>Preimenuj in ustvari nov direktorij</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1323"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Za uporabnika bo ustvarjen nov /home direktorij, stari pa bo preimenovan. Vaše datoteke in nastavitve v novi namestitvi ne bodo takoj vidne, a se lahko do njih dostopa v preimenovanem direktoriju.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1325"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Stari direktorij bo imel na koncu številko, ki je odvisna od tega, kolikokrat poprej je bil direktorij že preimenovan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1326"/>
        <location filename="../minstall.cpp" line="2660"/>
        <source>Delete it and create a new directory</source>
        <translation>Izbriši in ustvari nov direktorij</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1327"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Stari direktorij /home bo izbrisan in ustvarjena bo povsem nov.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1125"/>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1329"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Vse datoteke in nastavitve bodo za stalno izbrisane, če je izbrana ta možnost. Vaše možnosti za njihovo obnovitev bodo majhne.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1341"/>
        <location filename="../minstall.cpp" line="2678"/>
        <source>Installation in Progress</source>
        <translation>Namestitev poteka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1342"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 se namešča. Sveža namestitev bo trajala od 3-20 minut, odvisno od hitrosti sistema in velikosti razdelkov, ki jih ponovno formatirate.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1344"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Če pritisnete tipko Prekini, se bo namestitev zaustavila, takoj ko bo to mogoče.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1346"/>
        <source>Change settings while you wait</source>
        <translation>Med nameščanjem spremenite nastavitve</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1347"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Medtem, ko se %1 namešča, lahko kliknete na tipki &lt;b&gt;Naprej&lt;/b&gt; ali &lt;b&gt;Nazaj&lt;/b&gt; in vnesete druge informacije za namestitev.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Te korake opravite v svojem ritmu. Namestitveni program vas bo počakal, če je to potrebno.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1361"/>
        <source>Congratulations!</source>
        <translation>Čestitke!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>You have completed the installation of %1.</source>
        <translation>Uspešno ste namestili %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1363"/>
        <source>Finding Applications</source>
        <translation>Iskanje programov</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>There are hundreds of excellent applications installed with %1. The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus.</source>
        <translation>%1 ima nameščenih na stotine odličnih programov. Najbolje je, da jih spoznavate tako, da jih poiščete v meniju in preizkusite. Mnogo aplikacij je bilo razvitih posebej za projekt %1. Te so prikazane v glavnem meniju.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1368"/>
        <source>In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.</source>
        <translation>Poleg tega %1 vsebuje mnogo standardnih Linux programov, ki jih je mogoče zagnati le iz terminala in zato niso prikazani v meniju.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1370"/>
        <source>Enjoy using %1</source>
        <translation>Uživajte v uporabi %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1444"/>
        <source>Finish</source>
        <translation>Zaključi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1447"/>
        <source>Start</source>
        <translation>Začni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1450"/>
        <source>OK</source>
        <translation>V redu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1452"/>
        <source>Next</source>
        <translation>Naslednji</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>The installation and configuration is incomplete.</source>
        <translation>Namestitev in nastavitev ni zaključena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1593"/>
        <source>Do you really want to stop now?</source>
        <translation>Bi jo vseeno radi zaustavili?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kam po pomoč?&lt;/b&gt;&lt;br/&gt;Osnovne inoformacije o sistemu %1 se nahajajo na %2. &lt;/p&gt;&lt;p&gt;Prostovoljce, ki nudijo pomoč, je mogoče najti na %3 forumu, %4.&lt;/p&gt;&lt;p&gt;Če iščete pomoč, čim bolj podrobno opišite svojo težavo in računalnik. Ponavadi stavki tipa &apos;ne deluje&apos; niso dovolj.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Popravilo namestitve&lt;/b&gt;&lt;br/&gt;Če %1 na vašem disku preneha delovati, je včasih mogoče težavo odpraviti z zagonom iz živega DVD ali USB pogona in zagonom katerega od orodji, ki jih %1 vsebuje ali z uporabo katerega od standardnih Linux orodji za popravljanje sistema.&lt;/p&gt;&lt;p&gt;Živi DVD ali SUSB lahko uporabite tudi za reševanje podatkov iz sistemov z MS-Windows!&lt;/p&gt; </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%1 bo samodejno poskusil&lt;/b&gt;&lt;br/&gt;nastaviti zvočni mikser, vendar je včasih potrebno, da uporabnik nastavi glasnost in vklopi kanale na miskerju, da bi se zvok slišal.&lt;/p&gt; &lt;p&gt;Bljižnica do mikserja se nahaja v menuju. Kliknite nanjo, da bi ga odprli. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Poskrbite, da bo vaš %1 ažuriran&lt;/b&gt;&lt;br/&gt;Za več informacij in posodobitve obiščite&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Posebna zahvala&lt;/b&gt;&lt;br/&gt;Hvala vsem, ki se odločili podpreti %1 s svojim časom, denarjem, predlogi, delom, pohvalami, idejami, promoviranjem in/ali spodbujanjem.&lt;/p&gt;&lt;p&gt;Brez vas %1 ne bi obstajal.&lt;/p&gt;&lt;p&gt;%2 razvojna skupina&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Pomoč</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Dnevnik</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Nazaj</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="78"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="85"/>
        <source>Next</source>
        <translation>Naslednji</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="91"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="120"/>
        <source>Installation in progress</source>
        <translation>Namestitev poteka</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="135"/>
        <source>Abort</source>
        <translation>Prekini</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="138"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="158"/>
        <source>Close</source>
        <translation>Zapri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="177"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Zbiram podatke, prosimo počakajte.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="209"/>
        <source>Terms of Use</source>
        <translation>Pogoji uporabe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Keyboard Settings</source>
        <translation>Nastavitve tipkovnice</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="256"/>
        <source>Model:</source>
        <translation>Model:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="271"/>
        <source>Variant:</source>
        <translation>Izvedba:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="297"/>
        <source>Change Keyboard Settings</source>
        <translation>Spremeni nastavitve tipkovnice</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="309"/>
        <source>Layout:</source>
        <translation>Razdelitev:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Izberi vrsto namestitve</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <source>Root</source>
        <translation>Koren</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="445"/>
        <source>Home</source>
        <translation>Domov</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="520"/>
        <location filename="../meinstall.ui" line="542"/>
        <location filename="../meinstall.ui" line="1216"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="555"/>
        <source>Encrypt</source>
        <translation>Šifriranje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1184"/>
        <source>Enable hibernation support</source>
        <translation>Vklopi podporo za spanje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Običajna namestitev z uporabo celotnega diska</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="381"/>
        <source>Dual drive</source>
        <translation>Dvojni pogon</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="391"/>
        <source>System drive:</source>
        <translation>Sistemski pogon: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <source>Home drive:</source>
        <translation>Domači pogon: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="565"/>
        <source>Customize the disk layout</source>
        <translation>Lastna razdelitev diskov</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="572"/>
        <source>Replace existing installation</source>
        <translation>Nadomesti obstoječo namestitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="617"/>
        <source>Replace an existing installation</source>
        <translation>Nadomesti obstoječo namestitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="639"/>
        <source>Device</source>
        <translation>Naprava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Installation</source>
        <translation>Namestitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Scan for existing installations</source>
        <translation>Zaznaj obstoječe namestitve</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="679"/>
        <source>Replacement options</source>
        <translation>Možnosti za nadomestilo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Attempt to upgrade packages</source>
        <translation>Poskus nadgradnje paketov</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="696"/>
        <source>Choose partitions</source>
        <translation>Izberite razdelke</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Označi izbrane pogone za brisanje ob ustvarjanju novega razporeda.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Show Grid</source>
        <translation>Prikaži mrežo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Zaženi upravljalnik razdelkov tega operacijskega sistema</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="747"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Odstrani obstoječ zapis iz razporeditve. To deluje le, kadar zapisujemo novo razporeditev.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Izvedi poizvedbo operacijskega sistema in ponovno naloži razporeditev vseh pogonov.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="795"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Dodaj zapis za nov razdelek. To deluje le z novo razporeditvijo.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="806"/>
        <source>Show advanced fields.</source>
        <translation>Prikaži napredna polja.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="836"/>
        <source>Encryption options</source>
        <translation>Možnosti šifriranja</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="842"/>
        <source>Encryption password:</source>
        <translation>Šifrirno geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="859"/>
        <source>Confirm password:</source>
        <translation>Potrdite geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="893"/>
        <source>Installation Confirmation</source>
        <translation>Potrditev namestitve</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="936"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Namesti GRUB za Linux in Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="951"/>
        <source>System boot disk:</source>
        <translation>Zagonski disk sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="999"/>
        <source>EFI System Partition</source>
        <translation>EFI sistemski razdelek</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1021"/>
        <source>Partition Boot Record</source>
        <translation>Partition Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1024"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1046"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1052"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1055"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <source>Location to install on:</source>
        <translation>Lokacija za namestitev:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1075"/>
        <source>Generate host-specific initramfs image</source>
        <translation>Ustvari initramfs slike posebej za gostitelja</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1114"/>
        <source>Create a swap file</source>
        <translation>Ustvari izmenjevalno swap datoteko</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1131"/>
        <location filename="../meinstall.ui" line="1255"/>
        <source> MB</source>
        <translation>MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1154"/>
        <source>Size:</source>
        <translation>Velikost:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1177"/>
        <source>Location:</source>
        <translation>Lokacija:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1194"/>
        <source>Enable zram swap</source>
        <translation>Vklopi zram swap</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1206"/>
        <source>Allocate based on RAM:</source>
        <translation>Rezerviraj glede na pomnilnik RAM:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1235"/>
        <source>Recommended maximum: 100%</source>
        <translation>Priporočeni maksimum: 100%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1242"/>
        <source>Allocate fixed size:</source>
        <translation>Rezerviraj fiksno velikost:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1292"/>
        <source>Common Services to Enable</source>
        <translation>Omogoči pogoste storitve:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1302"/>
        <source>Service</source>
        <translation>Storitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1307"/>
        <source>Description</source>
        <translation>Opis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Computer Network Names</source>
        <translation>Imena računalnikov v mreži</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1364"/>
        <source>Workgroup</source>
        <translation>Delovna skupina</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1377"/>
        <source>Workgroup:</source>
        <translation>Delovna skupina:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1390"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa strežnik za MS Networking</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1406"/>
        <source>example.dom</source>
        <translation>primer.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1419"/>
        <source>Computer domain:</source>
        <translation>Domena računalnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1442"/>
        <source>Computer name:</source>
        <translation>Ime računalnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1497"/>
        <source>Localization Defaults</source>
        <translation>Privzete lokalne nastavitve</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>Locale:</source>
        <translation>Lokalizacija:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1537"/>
        <source>Configure Clock</source>
        <translation>Nastavitve časa:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1578"/>
        <source>Format:</source>
        <translation>Oblika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1606"/>
        <source>Timezone:</source>
        <translation>Časovni pas:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1651"/>
        <source>System clock uses local time</source>
        <translation>Sistemska ura uporablja krajevni čas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1673"/>
        <source>Service Settings (advanced)</source>
        <translation>Nastavitve storitev (napredno)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1691"/>
        <source>Adjust which services should run at startup</source>
        <translation>Določi, katere storitve naj se zaženejo ob zagonu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1694"/>
        <source>View</source>
        <translation>Prikaz</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1755"/>
        <source>Default User Account</source>
        <translation>Privzeti uporabniški račun</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1767"/>
        <source>Default user login name:</source>
        <translation>Ime privzetega uporabnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1783"/>
        <source>username</source>
        <translation>uporabniško ime</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1796"/>
        <source>Default user password:</source>
        <translation>Geslo privzetega uporabnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1822"/>
        <source>Confirm user password:</source>
        <translation>Potrdi geslo uporabnika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1851"/>
        <source>Root (administrator) Account</source>
        <translation>Korenski (administrativni) račun</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1869"/>
        <source>Root password:</source>
        <translation>Korensko geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1895"/>
        <source>Confirm root password:</source>
        <translation>Potrdite korensko geslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1924"/>
        <source>Autologin</source>
        <translation>Samodejna prijava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1931"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Modifikacije namizja, ki so bile opravljene v živem okolju, bodo prenešene na nameščen OS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1934"/>
        <source>Save live desktop changes</source>
        <translation>Shrani spremembe živega namizja</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1941"/>
        <source>Copy the contents of Live-usb-storage from the live medium to the installed system&apos;s home directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1944"/>
        <source>Copy Live-usb-storage to installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1983"/>
        <source>Existing Home Directory</source>
        <translation>Obstoječi /home direktorij</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Kaj bi radi storili s starim direktorijom?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1999"/>
        <source>Re-use it for this installation</source>
        <translation>Ponovno uporabi za to namestitev</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2006"/>
        <source>Rename it and create a new directory</source>
        <translation>Preimenuj in ustvari nov direktorij</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2013"/>
        <source>Delete it and create a new directory</source>
        <translation>Izbriši in ustvari nov direktorij</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2037"/>
        <source>Tips</source>
        <translation>Namigi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2069"/>
        <source>Installation complete</source>
        <translation>Namestitev je dokončana</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2075"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Samodejni ponovni zagon po tem, ko se namestitveni program zapre</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2094"/>
        <source>Reminders</source>
        <translation>Opomniki</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="410"/>
        <source>Please enter a computer name.</source>
        <translation>Vnesite ime računalnika.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="414"/>
        <source>The computer name contains invalid characters.</source>
        <translation>Ime računalnika vsebuje neveljavne znake.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="415"/>
        <location filename="../oobe.cpp" line="426"/>
        <location filename="../oobe.cpp" line="646"/>
        <source>Please choose a different name before proceeding.</source>
        <translation>Pred nadaljevanjem izberite drugo ime.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="421"/>
        <source>Please enter a domain name.</source>
        <translation>Prosiom vnesite ime domene.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="425"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>Domena računalnika vsebuje neveljavne znake.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="434"/>
        <source>Please enter a workgroup.</source>
        <translation>Vnesite ime delovne skupine</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="651"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>Uporabniško ime ne more vsebovati posebnih znakov ali presledkov.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="661"/>
        <source>The chosen user name is in use.</source>
        <translation>Izbrano uporabniško ime se že uporablja.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="670"/>
        <source>Are you sure you want to continue?</source>
        <translation>Želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="675"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Za %1 niste podali gesla</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="680"/>
        <source>You did not provide a password for the root account.</source>
        <translation>Niste podali gesla za korenski dostop.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="693"/>
        <source>Failed to set user account passwords.</source>
        <translation>Neuspela nastavitev gesla za uporabniški račun</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="725"/>
        <source>Failed to save old home directory.</source>
        <translation>Neuspešno shranjevanje starega /home direktorija</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="734"/>
        <source>Failed to delete old home directory.</source>
        <translation>Neuspešno brisanje starega /home direktorija.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="755"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Ustvarjanje uporabnikovega direktorija ni uspelo.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="763"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Poimenovanje uporabnikovega direktorija ni bilo uspešno.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="808"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Določitev lastništva ali dovoljenja za uproabniško mapo ni bilo uspešno.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="278"/>
        <location filename="../partman.cpp" line="956"/>
        <source>Virtual Devices</source>
        <translation>Virtualne naprave</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="555"/>
        <location filename="../partman.cpp" line="606"/>
        <source>&amp;Add partition</source>
        <translation>Dod&amp;aj razdelek</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="557"/>
        <source>&amp;Remove partition</source>
        <translation>Odstrani &amp;razdelek</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="566"/>
        <source>&amp;Lock</source>
        <translation>Zak&amp;leni</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="570"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Odklep</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="574"/>
        <location filename="../partman.cpp" line="803"/>
        <source>Add to crypttab</source>
        <translation>Dodaj v crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="581"/>
        <source>New subvolume</source>
        <translation>Nov podpogon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="582"/>
        <source>Scan subvolumes</source>
        <translation>Poišči podpogone</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="609"/>
        <source>New &amp;layout</source>
        <translation>Nova &amp;razdelitev</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="610"/>
        <source>&amp;Reset layout</source>
        <translation>Ponastavi &amp;razdelitev</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="612"/>
        <source>Layout &amp;Builder...</source>
        <translation>&amp;Razdeljevalnik...</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="639"/>
        <source>Remove subvolume</source>
        <translation>Odstrani podpogon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="797"/>
        <source>Unlock Drive</source>
        <translation>Odkleni pogon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="801"/>
        <source>Password:</source>
        <translation>&quot;Geslo:&quot;</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="833"/>
        <source>Could not unlock device.</source>
        <translation>Naprave ni bilo mogoče odkleniti.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="863"/>
        <source>Failed to close %1</source>
        <translation>Napaka pri zapiranju %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="877"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="896"/>
        <source>Invalid subvolume label</source>
        <translation>Napačna oznaka podpogona</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="904"/>
        <source>Duplicate subvolume label</source>
        <translation>Podvoji oznako podpogona</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="913"/>
        <source>Invalid use for %1: %2</source>
        <translation>Neveljavna raba za %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 je že izbran za: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="930"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Potreben je korenski razdelek z najmanj %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="947"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Ne morem ohraniti doma /home v korenu /root, če je priklopljen tudi ločen razdelek /home.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="960"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Pripravi %1 tabelo razdelkov na %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="958"/>
        <source>Re-use partition table on %1</source>
        <translation>Ponovno uporabi tabelo razdelkov na %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="834"/>
        <source>Possible incorrect password.</source>
        <translation>Geslo je verjetno napačno.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="967"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Ponovno uporabi (brez formatiranja) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="970"/>
        <source>Format %1</source>
        <translation>Formatiraj %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="971"/>
        <source>Format %1 to use for %2</source>
        <translation>Formatiraj %1 za uporabo kot %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="972"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Ponovno uporabi (brez formatiranja) %1 kot %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="973"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Izbriši podatke na %1, razen za /home za rabo z %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="976"/>
        <source>Create %1 without formatting</source>
        <translation>Ustvari %1 brez formatiranja</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="977"/>
        <source>Create %1, format to use for %2</source>
        <translation>Ustvari %1, formatiraj za rabo kot %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="992"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>Ponovno uporabi podrazdelek %1 kot %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="994"/>
        <source>Delete subvolume %1</source>
        <translation>Izbriši podrazdelek %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="997"/>
        <source>Overwrite subvolume %1</source>
        <translation>Prepiši podrazdelek %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="998"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>Prepiši podrazdelek %1 za uporabo z %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1000"/>
        <source>Create subvolume %1</source>
        <translation>Ustvari podrazdelek %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1001"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>Ustvari podrazdelek %1 za uporabo z %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <location filename="../partman.cpp" line="1084"/>
        <location filename="../partman.cpp" line="1119"/>
        <location filename="../partman.cpp" line="1161"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1017"/>
        <source>Encrypting root without a separate unencrypted boot partition is not supported.

Do you want to go back and select a boot partition?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1053"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) potrebuje %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1079"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>Namestitev morda ne bo uspela, ker so ti pogoni premajhni:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1081"/>
        <source>Are you sure you want to continue?</source>
        <translation>Želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1094"/>
        <source>This setup may produce an unbootable system. Do you want to continue?</source>
        <translation>Takšna nastavitev lahko povzroči, da se sistem ne bo mogel zagnati. Ali želite vseeno nadaljevati?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1100"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Ta sistem uporablja EFI, vendar ni bila določen ločen EFI sistemski razdelek za /boot/efi.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1103"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>Pogon določen za /boot/efi ni ustrezen EFI sistemski razdelek.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1146"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Naslednji pogoni so ali bodo nameščeni z GPT, a nimajo BIOS-GRUB razdelka:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1148"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Sistem se morda ne bo mogel zagnati z GPT pogonov, ki nimajo BIOS-GRUB razdelka.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1203"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Diski z razdelki, ki ste jih izbrali, odpovedujejo:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1207"/>
        <source>Smartmon tool output:</source>
        <translation>Izpis za Smarton orodje:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1208"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Diski z izbranimi razdelki za namestitev so sicer prestali SMART monitor test (smartctl), a je test pokazal, da bodo v bližnji prihodnosti imeli večjo možnost za napake.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1215"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Če niste prepričani, zaprite namestitveni program in zaženite GSmartControl za več informacij.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1219"/>
        <source>Do you want to abort the installation?</source>
        <translation>Želite prekiniti namestitev?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1225"/>
        <source>Do you want to continue?</source>
        <translation>Želite nadaljevati?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1294"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Ni bilo mogoče pripraviti zahtevanih razdelkov</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1338"/>
        <source>Preparing partition tables</source>
        <translation>Priprava tabel razdelkov</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1366"/>
        <source>Preparing required partitions</source>
        <translation>Pripravljanje zahtevanih razdelkov</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1430"/>
        <source>Failed to format partition.</source>
        <translation>Formatiranje razdelka ni uspelo.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1437"/>
        <source>Formatting: %1</source>
        <translation>Formatiranje: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1515"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Neuspešna priprava podpogona.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1516"/>
        <source>Preparing subvolumes</source>
        <translation>Pripravljanje podpogonov</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1643"/>
        <source>Failed to mount partition.</source>
        <translation>Priklapljanje razdelka ni uspelo.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1656"/>
        <source>Mounting: %1</source>
        <translation>Priklapljanje: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1840"/>
        <source>Model: %1</source>
        <translation>Model: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1848"/>
        <source>Free space: %1</source>
        <translation>Prostor na voljo: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1948"/>
        <source>Device</source>
        <translation>Naprava</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1949"/>
        <source>Size</source>
        <translation>Velikost</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1950"/>
        <source>Active</source>
        <translation>Aktivno</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1951"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1952"/>
        <source>Use For</source>
        <translation>Uporabi za</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1953"/>
        <source>Label</source>
        <translation>Vrsta</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1954"/>
        <source>Encrypt</source>
        <translation>Šifriranje</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1955"/>
        <source>Format</source>
        <translation>Format</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1956"/>
        <source>Check</source>
        <translation>Preveri</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1957"/>
        <source>Options</source>
        <translation>Možnosti</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1958"/>
        <source>Dump</source>
        <translation>Deponiraj</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1959"/>
        <source>Pass</source>
        <translation>Prehod</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1967"/>
        <source>Active partition</source>
        <translation>Aktivni razdelek</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1968"/>
        <source>EFI System Partition</source>
        <translation>EFI sistemski razdelek</translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2787"/>
        <source>&amp;Templates</source>
        <translation>&amp;Predloge</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2794"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Stiskanje (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2796"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Stiskanje (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2798"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Stiskanje (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Negligible</source>
        <translation>obupna</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Very weak</source>
        <translation>zelo šibka</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Weak</source>
        <translation>šibka</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Moderate</source>
        <translation>zmerna</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Strong</source>
        <translation>močna</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Very strong</source>
        <translation>zelo močna</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="156"/>
        <source>Password strength: %1</source>
        <translation>Jakost gesla: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Hide the password</source>
        <translation>Skrij geslo</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Show the password</source>
        <translation>Prikaži geslo</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Gazelle Installer</source>
        <translation>Gazelle namestilnik</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="126"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Prilagodljiva grafična namestitev za MX Linux in antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="129"/>
        <source>Enable advanced settings, even in regular installation mode.</source>
        <translation>Omogoči napredne nastavitve in to tudi v navadnem načinu nameščanja.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Samodejna namestitev z uporabo nastavitvene datoteke (več podatkov je spodaj).
- POZOR: je lahko nevarna možnost, saj bo razdelke samodejno pobrisala.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Prekliče preverjanja ohranjenosti na razdelkih in pogonih, zato bodo prikazana.
- POZOR: to lahko pokvari zadeve. Uporabite le, če podatki niso tako pomembni.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="134"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Naloži nastavitveno datoteko, kot jo določa &lt;config-file&gt;.
Priveta je uporaba /etc/minstall.conf.
To nastavitev je mogoče uporabiti z --auto za nenadzorovano namestitev.
Namestitveni program ustvari (ali prepiše) /mnt/antiX/etc/minstall.conf in shrani kopijo na /etc(minstalled.conf za rabo v prihodnosti.
Namestilnik ne bo zapisoval gesel ali neuporabljenih nastavitev v novo namestitveno datoteko.
Pomnite, da je to eksperimentalno. Prihodnji namestilniki so lahko nezdružljivi s obstoječimi namestitvenimi datotekami.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="140"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Po končani namestitvi se samodejno ponovno zaženi.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="141"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Ko končate, ne odklopite /mnt/antiX ali katerega od povezanih vsebnikov, </translation>
    </message>
    <message>
        <location filename="../app.cpp" line="142"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Namesti operacijski sistem in na ukaznih vrsticah počakaj na izbore uporabnika, dokler ne sledi prvi ponovni zagon.
Ob zagonu bo namestilnik zagnan z --oobe, tako da lahko uporabnik poda pte podrobnosti.
To je uporabno za OEM namestitve, z namenom prodaje ali oddaje računalnika, ki bo imel prednameščen OS.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="145"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Možnost izbire Izkušnje iz škatle.
To bo samodejno zagnano ob namestitvi z --oem možnostjo.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="147"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Poskusni način za grafični vmesnik. Lahko preizkusite različne zaslone, ne da bi dejansko kaj namestili.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="148"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Samodejni ponovni zagon po namestitvi.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="149"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Namestitev z rsync namesto cp na prilagojeni razdelitvi razdelkov.
- ne formatira korena /root in ne deluje s šifriranjem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="151"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Vedno na začetku preveri namestitveni nosilec.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="152"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>Na začetku ne preveri namestitvenega nosilca.
Ni priporočljivo, razen v primerih, ko je nosilec zagotovo brez napak.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="154"/>
        <source>Force TUI (Text User Interface) mode instead of GUI.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="155"/>
        <source>Jump directly to a specific page for testing (use with --pretend).
Page names: splash, terms, installation, partitions, confirm, boot, services, user, end</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="156"/>
        <source>&lt;page-name&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="157"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Naloži namestitveno datoteko, kot je določeno od &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="167"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Preveč argumentov. Preverite format ukaza z uporabo --help argumenta.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="177"/>
        <source>%1 Installer</source>
        <translation>%1 Namestilnik</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="187"/>
        <source>The installer appears to be running already.</source>
        <translation>Videti je, da je namestilnik že zagnan.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="188"/>
        <source>Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Zaprite ga, če je to mogoče, ali iz terminala zaženite &quot;pkill minstall&quot;</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="193"/>
        <location filename="../app.cpp" line="208"/>
        <location filename="../app.cpp" line="233"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="194"/>
        <source>The installer appears to be running already.
Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="203"/>
        <location filename="../app.cpp" line="209"/>
        <source>This operation requires root access.</source>
        <translation>To dejanje zahteva korenski dostop.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="229"/>
        <location filename="../app.cpp" line="234"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Konfiguracijska datoteka (%1) ni bila najdena.</translation>
    </message>
</context>
<context>
    <name>Replacer</name>
    <message>
        <location filename="../replacer.cpp" line="147"/>
        <source>Information</source>
        <translation>Podatki</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="148"/>
        <source>Could not open any of the locked encrypted containers.
Possible incorrect password. Press the &apos;Scan&apos; button to try again with a different password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="163"/>
        <source>Volume %1 on drive %2</source>
        <translation>Pogon %1 na pogonu %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="203"/>
        <location filename="../replacer.cpp" line="429"/>
        <location filename="../replacer.cpp" line="437"/>
        <source>Error</source>
        <translation>Napaka</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="204"/>
        <source>No existing installation selected.</source>
        <translation>Nobena obstoječa namestitev ni izbrana.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="281"/>
        <source>Replace the installation in %1: %2</source>
        <translation>Zamenjaj namestitev v %1: %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="303"/>
        <location filename="../replacer.cpp" line="359"/>
        <source>Unlock encrypted volumes</source>
        <translation>Odkleni šifrirane pogone</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="307"/>
        <location filename="../replacer.cpp" line="363"/>
        <source>Password:</source>
        <translation>&quot;Geslo:&quot;</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="365"/>
        <source>Ignore encrypted volumes</source>
        <translation>Prezri šifrirane pogone</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="430"/>
        <source>Cannot unlock encrypted partition: %1</source>
        <translation>Ne morem odpreti šifriranega razdelka %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="438"/>
        <source>Cannot find partition listed in crypttab: %1</source>
        <translation>Ne morem najti razdelka navedenega v crypttab: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="458"/>
        <source>Warning</source>
        <translation>Opozorilo</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="459"/>
        <source>Could not re-lock encrypted device(s): %1</source>
        <translation>Ne morem ponovno zakleniti šifrirane naprave: %1</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="57"/>
        <source>Recommended maximum: %1 MB</source>
        <translation>Priporočeni maksimum: %1MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="60"/>
        <source>Unable to query RAM size.</source>
        <translation>Ne morem določiti velikosti RAM.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="97"/>
        <source>Invalid location</source>
        <translation>Napačna lokacija</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="100"/>
        <source>Maximum: %1 MB</source>
        <translation>Največ: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="117"/>
        <source>Failed to configure zram swap.</source>
        <translation>Ni bilo mogoče nastaviti zram swap</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="127"/>
        <source>Failed to create or install swap file.</source>
        <translation>Namesitev izmenjevalne swap datoteke ni bilo uspešno.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="133"/>
        <source>Creating swap file</source>
        <translation>Ustvarjanje izmenjevalne swap datoteke.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="146"/>
        <source>Configuring swap file</source>
        <translation>Konfiguriranje izmenjevalne swap datoteke</translation>
    </message>
</context>
</TS>