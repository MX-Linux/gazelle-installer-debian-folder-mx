<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="ca">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Root</source>
        <translation>Arrel</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Home</source>
        <translation>Inici </translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="175"/>
        <source>The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>La unitat seleccionada té una capacitat de com a mínim 2 TB i s&apos;ha de formatar amb GPT. En alguns sistemes, un disc formatat amb GPT no arrencarà.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="177"/>
        <source>Are you sure you want to continue?</source>
        <translation>Segur que voleu continuar?</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="183"/>
        <source>The system and home drives cannot be the same for this type of installation.</source>
        <translation>El disc del sistema i el de la carpeta de l&apos;usuari no poden ser el mateix per a aquest tipus d&apos;instal·lació.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="187"/>
        <source>Format and use drives entirely for %1</source>
        <translation>Formata i usa els discs sencers per a %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="189"/>
        <source>System drive: %1</source>
        <translation>Disc del sistema: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="191"/>
        <source>Home drive: %1</source>
        <translation>Disc de la carpeta d&apos;usuari: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="194"/>
        <source>Format and use the entire drive for %1: %2</source>
        <translation>Formata i usa tot el disc sencer per a %1: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="224"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>Recomanat: %1
Mínim: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="226"/>
        <source>Minimum for hibernation support: %1</source>
        <translation>Suport mínim per a la hibernació: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="268"/>
        <source>Layout Builder</source>
        <translation>Creador de disposició</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="468"/>
        <source>%1% root
%2% home</source>
        <translation>%1% Arrel
%2% inici </translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="470"/>
        <source>Combined root and home</source>
        <translation>Inici i Arrel combinats</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="90"/>
        <source>Cannot access installation media.</source>
        <translation>No puc accedir al suport d&apos;instal·lació.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="260"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Ha fallat en esborrar el sistema anterior a la destinació.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="263"/>
        <source>Deleting old system</source>
        <translation>Esborrant el sistema antic </translation>
    </message>
    <message>
        <location filename="../base.cpp" line="287"/>
        <source>Failed to set the system configuration.</source>
        <translation>Ha fallat en definir la configuració del sistema.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="289"/>
        <source>Setting system configuration</source>
        <translation>Configuració de paràmetres del sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="451"/>
        <source>Copying new system</source>
        <translation>Copiant el nou sistema </translation>
    </message>
    <message>
        <location filename="../base.cpp" line="623"/>
        <source>Failed to copy the new system.</source>
        <translation>Ha fallat en copiar el nou sistema.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="133"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>La instal·lació de GRUB ha fallat. Podeu tornar a arrencar amb el disc autònom i usar el menú GRUB Rescue per esmenar la instal·lació.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="207"/>
        <source>Installing GRUB</source>
        <translation>S&apos;instal·la el GRUB </translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="470"/>
        <source>Updating initramfs</source>
        <translation>S&apos;actualitzen els initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="471"/>
        <source>Failed to update initramfs.</source>
        <translation>Ha fallat en actualitzar initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="529"/>
        <source>System boot disk:</source>
        <translation>Disc d&apos;arrencada: </translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="544"/>
        <location filename="../bootman.cpp" line="554"/>
        <source>Partition to use:</source>
        <translation>Partició a usar: </translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="67"/>
        <source>The installation media is corrupt.</source>
        <translation>El suport d&apos;instal·lació està malmès.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="76"/>
        <source>The installation media is still being checked.</source>
        <translation>Encara es comprova el suport d&apos;instal·lació.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="77"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>Esteu segur de voler ometre la comprovació del suport d&apos;instal·lació?</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="233"/>
        <source>Checking installation media.</source>
        <translation>Comprovant el suport d&apos;instal·lació.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="234"/>
        <source>Press ESC to skip.</source>
        <translation>Premeu ESC per ometre.</translation>
    </message>
</context>
<context>
    <name>Crypto</name>
    <message>
        <location filename="../crypto.cpp" line="63"/>
        <source>Failed to format LUKS container.</source>
        <translation>Ha fallat en formatar el contenidor LUKS.</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="67"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Creant el volum xifrat: %1</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="72"/>
        <source>Failed to open LUKS container.</source>
        <translation>Ha fallat en obrir el contenidor LUKS.</translation>
    </message>
</context>
<context>
    <name>Device</name>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Overwrite</source>
        <translation>Sobreescriu</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Create</source>
        <translation>Crea</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2367"/>
        <source>Delete</source>
        <translation>Esborra </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2371"/>
        <source>Preserve</source>
        <translation>Preserva</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2372"/>
        <source>Preserve (%1)</source>
        <translation>Conserva (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2373"/>
        <source>Preserve /home (%1)</source>
        <translation>Preserva /home (%1)</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="484"/>
        <source>Unknown release</source>
        <translation>Versió desconeguda</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="149"/>
        <source>Shutdown</source>
        <translation>Atura</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="442"/>
        <source>You are running 32-bit OS started in 64-bit UEFI mode.</source>
        <translation>Executeu un sistema operatiu de 32 bits iniciat en mode UEFI de 64 bits.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="443"/>
        <source>The system will not be able to boot unless you restart the system in Legacy Boot (or similar mode) before proceeding.</source>
        <translation>El sistema no podrà arrencar si no el reinicieu en mode Legacy Boot (o similar) abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="445"/>
        <source>Do you want to continue the installation?</source>
        <translation>Voleu continuar la instal·lació?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="487"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>L&apos;instal·lador %1 executarà ara les accions demanades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="488"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Aquestes accions no es poden desfer. Voleu continuar?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="500"/>
        <source>Support %1</source>
        <translation>S&apos;ofereix suport a %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="501"/>
        <source>%1 is supported by people like you. Some help others at the support forum, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 rep suport de gent com tu. Alguns ajuden els altres al fòrum de suport, o tradueixen fitxers d&apos;ajuda a diferents llengües, o fan suggeriments, escriuen documentació o ajuden a provar programari nou.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <location filename="../minstall.cpp" line="1769"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 és una distribució Linux independent basada en Debian Stable.

%1 usa alguns components de MEPIS Linux que estan alliberats sota una llicència Apache. S&apos;han modificat alguns components MEPIS per a %1.

Gaudiu usant %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>Preparing to install %1</source>
        <translation>Preparant per instal·lar %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>Paused for required operator input</source>
        <translation>En pausa esperant una entrada de l&apos;operador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>Setting system configuration</source>
        <translation>Configuració dels paràmetres del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>Cleaning up</source>
        <translation>Netejant</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>Finished</source>
        <translation>Acabat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="733"/>
        <source>Configuring system. Please wait.</source>
        <translation>Configurant el sistema. Si us plau, espereu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Configuració completa. Reiniciant el sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="744"/>
        <source>The installation was aborted.</source>
        <translation>S&apos;ha interromput la instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="768"/>
        <source>Pretending to install %1</source>
        <translation>Provant d&apos;instal·lar %1 </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="812"/>
        <source>Invalid settings found in configuration file (%1).</source>
        <translation>S&apos;han trobat paràmetres no vàlids al fitxer de configuració (%1).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="813"/>
        <source>Please review marked fields as you encounter them.</source>
        <translation>Si us plau, reviseu els camps marcats a mesura que els trobeu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="239"/>
        <location filename="../minstall.cpp" line="911"/>
        <location filename="../minstall.cpp" line="927"/>
        <location filename="../minstall.cpp" line="956"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>No es poden preservar les dades a /home perquè no s&apos;ha pogut obtenir la informació necessària.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="238"/>
        <location filename="../minstall.cpp" line="817"/>
        <location filename="../minstall.cpp" line="926"/>
        <location filename="../minstall.cpp" line="983"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Invalid settings found in configuration file (%1).
Please review marked fields as you encounter them.</source>
        <translation>S&apos;han trobat paràmetres no vàlids al fitxer de configuració (%1).
Si us plau, reviseu els camps marcats a mesura que els trobeu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="984"/>
        <location filename="../minstall.cpp" line="995"/>
        <source>Cannot find selected drive.</source>
        <translation>No he trobat la unitat seleccionada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1042"/>
        <source>The home directory for %1 already exists.</source>
        <translation>El directori d&apos;usuari per a %1 ja hi és.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1087"/>
        <source>General Instructions</source>
        <translation>Instruccions generals</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1088"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ABANS DE CONTINUAR, TANQUEU TOTES LES ALTRES APLICACIONS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1089"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>A cada pàgina, si us plau llegiu les instruccions, feu les vostres seleccions, i cliqueu a Següent quan estigueu a punt per continuar. Se us demanarà confirmació abans de fer cap acció destructiva.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1091"/>
        <source>Limitations</source>
        <translation>Limitacions</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1092"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Recordeu, aquest programari es facilita Tal-Qual, sense cap garantia específica. És responsabilitat vostra fer una còpia de seguretat abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1096"/>
        <source>Installation Options</source>
        <translation>Opcions d&apos;instal·lació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1097"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Si utilitzeu Mac OS o Windows OS (des de Vista endavant), haureu d&apos;usar el programari del sistema per ajustar les particions i el gestor d&apos;arrencada abans d&apos;instal·lar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1098"/>
        <source>Dual drive</source>
        <translation>Disc dual</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1099"/>
        <source>If your system has multiple storage drives, this option allows you to have the system files on one drive (the System drive), while keeping the data of all users on a separate drive (the Home drive).</source>
        <translation>Si el sistema té diverses unitats d&apos;emmagatzematge, aquesta opció us permet tenir els fitxers del sistema en una unitat (el disc del sistema), mentre que les dades de tots els usuaris són en un disc independent (el de la carpeta de l&apos;usuari).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1101"/>
        <source>Using the root-home space slider</source>
        <translation>Usant el control lliscant d&apos;espai root-home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1102"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>La unitat es pot dividir en particions separades usant el control lliscant: Sistema (root) i dades (home).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1103"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>La partició &lt;b&gt;root&lt;/b&gt; conté el sistema operatiu i les aplicacions.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1104"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>La partició &lt;b&gt;home&lt;/b&gt; conté les dades dels usuaris, tal com la configuració, fitxers, documents, imatges, música, vídeos, etc.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1105"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Moveu el control lliscant cap a la dreta per augmentar l&apos;espai per a &lt;b&gt;root&lt;/b&gt;. Moveu-lo cap a l&apos;esquerra per augmentar l&apos;espai per a &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1106"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Moveu el control lliscant  totalment cap a la dreta si voleu usar root i home a la mateixa partició.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1107"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Tenir el directori home en una partició separada millora la fiabilitat de les actualitzacions del Sistema Operatiu. També facilita les còpies de seguretat i la recuperació. Alhora, pot millorar el rendiment en mantenir els fitxers de sistema en una part definida del disc.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1109"/>
        <location filename="../minstall.cpp" line="1207"/>
        <location filename="../minstall.cpp" line="1227"/>
        <source>Encryption</source>
        <translation>Encriptació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1110"/>
        <location filename="../minstall.cpp" line="1208"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Es pot encriptar amb LUKS. Caldrà una contrasenya.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1111"/>
        <location filename="../minstall.cpp" line="1209"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Cal una partició d&apos;arrencada diferent, no encriptada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1112"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Quan s&apos;usa encriptació amb autoinstall, es crea automàticament una partició separada sense encriptar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1113"/>
        <source>Using a custom disk layout</source>
        <translation>Usant una disposició del disc a mida</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1114"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Si us cal més control sobre on s&apos;instal·la %1 trieu &quot;&lt;b&gt;%2&lt;/b&gt;&quot; i cliqueu&lt;b&gt;D&apos;acord&lt;/b&gt;. A la pròxima pàgina, podreu triar i configurar els dispositius d&apos;emmagatzematge i les particions que necessiteu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <location filename="../minstall.cpp" line="1122"/>
        <source>Replace existing installation</source>
        <translation>Substitueix la instal·lació existent.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <source>Replace existing installation option will attempt to replace an existing installation with the same disk configuration as the existing installation.  Home directories are preserved.</source>
        <translation>L&apos;opció de substituir la instal·lació actual substituirà la instal·lació actual amb la mateixa configuració de disc que la que hi ha. Es preservaran els directoris a /home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1123"/>
        <source>If you have an existing installation, you can use this function to replace it with a fresh installation.</source>
        <translation>Si ja teniu una instal·lació, podeu usar aquesta funció per substituir-la per una instal·lació nova.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1124"/>
        <source>This is particularly useful if you are upgrading from a previous version and want to preserve your data.</source>
        <translation>Això és especialment útil si actualitzeu el sistema des d&apos;una versió anterior i voleu conservar les dades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1126"/>
        <source>There is no guarantee of this working successfully. Ensure you have a good working backup of all important data before continuing.</source>
        <translation>No puc donar garantia que tot funcioni correctament. Assegureu-vos de tenir una bona còpia de seguretat de totes les dades importants abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1127"/>
        <source>This feature is designed to replace an installation performed using the regular install method, and may fail to replace an installation with a complex layout or storage scheme. Corruption or data loss may occur.</source>
        <translation>Aquesta funció està dissenyada per substituir una instal·lació feta mitjançant el mètode d&apos;instal·lació normal i pot fallar la substitució d&apos;una instal·lació per una disposició o un esquema d&apos;emmagatzematge complexos. Pot haver-hi corrupció o pèrdua de dades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>To replace an installation with a complex layout or storage scheme, it is recommended to use the custom layout option instead.</source>
        <translation>Per substituir una instal·lació per una disposició o un esquema d&apos;emmagatzematge complexos, es recomana usar l&apos;opció de disseny personalitzat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1137"/>
        <source>Choose Partitions</source>
        <translation>Tria de Particions</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1138"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>La llista de particions us permet triar quines particions s&apos;usaran per a aquesta instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1139"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Dispositiu&lt;/i&gt; - Aquest és el nom del dispositiu de blocs que és, o serà, assignat a la partició creada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1140"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Mida&lt;/i&gt; - La mida de la partició. Només es pot canviar en una disposició nova.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1141"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Usa Per&lt;/i&gt; - Per usar aquesta partició en la instal·lació, cal que seleccioneu quelcom aquí.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1143"/>
        <source>Format without mounting</source>
        <translation>Formata sense muntar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1144"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>Partició d&apos;arrencada BIOS GPT per GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1145"/>
        <location filename="../minstall.cpp" line="1184"/>
        <source>EFI System Partition</source>
        <translation>Partició de Sistema EFI </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1147"/>
        <source>Boot manager</source>
        <translation>Gestor d&apos;arrencada</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1148"/>
        <source>System root</source>
        <translation>Arrel del Sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1149"/>
        <source>User data</source>
        <translation>Dades d&apos;usuari</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1150"/>
        <source>Static data</source>
        <translation>Dades estàtiques</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1151"/>
        <source>Variable data</source>
        <translation>Dades variables</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1152"/>
        <source>Temporary files</source>
        <translation>Fitxers temporals</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>Swap files</source>
        <translation>Fitxers d&apos;intercanvi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1154"/>
        <source>Swap partition</source>
        <translation>Partició d&apos;intercanvi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1156"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>A més d&apos;aquests,  podeu crear els vostres punts de muntatge. Aquests han de començar per una barra inclinada (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1157"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etiqueta&lt;/i&gt; - L&apos;etiqueta que s&apos;assigna a una partició un cop formatada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1158"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Encriptació&lt;/i&gt; - Usa l&apos;encriptació de LUKS per a aquesta partició. La contrasenya s&apos;aplica a totes les particions encriptades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Format&lt;/i&gt; - Aquest és el format de la partició. Els formats disponibles depenen de l&apos;ús de la partició. Quan treballeu amb una disposició existent, podeu preservar el format de la partició seleccionant &lt;b&gt;Conserva&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1161"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>En seleccionar&lt;b&gt;Preserva /home&lt;/b&gt; per la partició arrel preserva el contingut del directori /home, eliminant tota la resta. Aquesta opció només es pot usar quan  /home està a la mateixa partició que l&apos;arrel.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1163"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Se suporten els sistemes de fitxer Linux ext2, ext3, ext4, jfs, xfs i btrfs; es recomana  ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Comprova&lt;/i&gt; - Comprova i corregeix blocs defectuosos a la unitat (no suportat per tots els formats). Això triga bastant, o sigui que potser voleu ometre aquest pas, llevat que sospiteu que la vostra unitat té blocs defectuosos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1166"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Opcions de muntatge&lt;/i&gt; - Especifica les opcions de muntatge que s&apos;usaran per a aquesta partició.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1167"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Dump&lt;/i&gt; - Informa l&apos;eina dump d&apos;incloure aquesta partició a la còpia de seguretat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1168"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Pass&lt;/i&gt; - La seqüència en què es comprova aquest sistema de fitxers a l&apos;arrencada. Si és zero, no es comprova el sistema de fitxers.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1169"/>
        <source>Menus and actions</source>
        <translation>Menús i accions</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Hi ha diverses opcions disponibles fent clic-dret sobre qualsevol disc o partició de la llista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1171"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Els botons a la dreta de la llista es poden usar també per manipular les entrades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1172"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>L&apos;instal·lador no pot modificar la disposició que ja té la unitat. Per crear una disposició a mida, marqueu la unitat per a una nova disposició amb l&apos;acció de menú o botó (%1) &lt;b&gt;Nova disposició&lt;/b&gt;. Això neteja la disposició existent.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1175"/>
        <source>Basic layout requirements</source>
        <translation>Requisits de la disposició bàsica</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1176"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>Cal una partició arrel per a %1. La partició d&apos;intercanvi és opcional però molt recomanada. Si voleu usar la característica de Suspendre al Disc de %1, cal una partició d&apos;intercanvi més gran que la mida de la vostra memòria física.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1178"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Si escolliu una partició d&apos;usuaris (/home) separada, us resultarà més fàcil actualitzar el sistema en el futur, però això no serà possible si actualitzeu des d&apos;una instal·lació que no té una partició /home separada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1180"/>
        <source>Active partition</source>
        <translation>Partició activa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Per tal que arrenqui el Sistema Operatiu instal·lat, cal que la partició adient (usualment la partició arrel o boot) estigui marcada com a activa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1182"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>La partició activa d&apos;una unitat es pot establir usant l&apos;acció del menú &lt;b&gt;Partició activa&lt;/b&gt;,</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Una partició amb asterisc (*) al costat del nom de la unitat és, o serà, la partició activa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1185"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Si el vostre sistema usa la Extensible Firmware Interface (EFI), cal una partició anomenada EFI System Partition (ESP) per arrencar el sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1186"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Aquests sistemes no necessiten una partició marcada com a Activa, però, en canvi, cal una partició formatada amb el Sistema de Fitxers FAT, marcada com a ESP.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1187"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>Molts sistemes fabricats en els darrers 10 anys usen EFI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>Boot partition</source>
        <translation>Partició d&apos;arrencada</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1189"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Aquesta partició normalment només és necessària per particions arrel en dispositius virtuals com els encriptats, LVM o volums RAID per programari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1190"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Conté un nucli bàsic i els controladors usats per accedir a un disc encriptat o dispositius virtuals.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>BIOS-GRUB partition</source>
        <translation>Partició BIOS-GRUB </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1192"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>En usar una unitat formatada com a GPT en un sistema no-EFI,  cal una partició d&apos;arrencada BIOS d&apos;1MB BIOS quan s&apos;utilitza GRUB.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1193"/>
        <source>Need help creating a layout?</source>
        <translation>Us cal ajuda per crear una disposició?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1194"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Feu clic dret sobre una unitat i trieu&lt;b&gt;Creador de disposició&lt;/b&gt; del menú. Això crearà una disposició similar a la d&apos;una instal·lació normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1195"/>
        <source>Upgrading</source>
        <translation>S&apos;actualitza</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1196"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Per actualitzar des d&apos;una instal·lació Linux existent, seleccioneu la mateixa partició home com abans i trieu com a format&lt;b&gt;Preserva&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1197"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Si no useu una partició /home separada, trieu&lt;b&gt;Preserva /home&lt;/b&gt; a l&apos;entrada del sistema de fitxers per preservar el directori actual /home ubicat a la vostra partició arrel. L&apos;instal·lador només preservarà  /home, i esborrarà tots els altres. En conseqüència, la instal·lació necessita molt més temps del normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1199"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipus de Sistema  de Fitxers preferit</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Per %1, podeu triar formatar les particions com a ext2, ext3, ext4, f2fs, jfs, xfs o btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1201"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Es pot disposar d&apos;opcions de compressió addicionals als discos que usen BTRFS. LZO és més ràpid, però la compressió és menor. ZLIB és més lent, però comprimeix més.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1203"/>
        <source>System partition management tool</source>
        <translation>Eina de gestió de les particions del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1204"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Per tenir més control sobre la disposició del disc (tal com modificar el seu format) cliqueu el botó de gestió de la partició (%1). Això engegarà l&apos;eina de gestió de particions del Sistema Operatiu, el què us permetrà crear la disposició que necessiteu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1210"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Per preservar una partició encriptada, feu-hi clic dret i seleccioneu &lt;b&gt;Desbloca&lt;/b&gt;. Al diàleg que apareix, escriviu el nom i la contrasenya del dispositiu virtual. Quan es desbloca el dispositiu, el nom que heu triat apareixerà a  &lt;i&gt;Dispositius Virtuals&lt;/i&gt;, amb opcions semblants a una partició normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Per tal que una partició encriptada es desbloqui en arrencar,  cal que l&apos;afegiu al fitxer crypttab. Useu l&apos;acció del menú&lt;b&gt;Afegeix a crypttab&lt;/b&gt; per fer-ho. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1213"/>
        <source>Other partitions</source>
        <translation>Altres particions </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1214"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>L&apos;instal·lador us permet crear altres particions o bé usar-les per altres propòsits, però cal tenir en compte que els sistemes antics no poden gestionar discos amb més de 4 particions primàries.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1215"/>
        <source>Subvolumes</source>
        <translation>Subvolums</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1216"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Alguns sistemes de fitxers, tal com Btrfs, donen suport a múltiples subvolums en una sola partició. Aquestes subdivisions no són físiques, i per tant no importa el seu ordre.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1218"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Useu l&apos;acció del menú &lt;b&gt;Escaneja subvolums&lt;/b&gt; per cercar subvolums en una partició Btrfs existent. Per a crear un subvolum nou, useu l&apos;acció del menú,&lt;b&gt;Subvolum nou&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1220"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Es poden preservar els subvolums actuals, tanmateix, el nom ha de ser el mateix. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1221"/>
        <source>Virtual Devices</source>
        <translation>Dispositius Virtuals</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1222"/>
        <source>If the installer detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Si l&apos;instal·lador detecta dispositius virtuals tals com particions LUKS obertes, volums lògics LVM o volums RAID basats en programari, aquests es podran usar per a la instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1223"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>L&apos;ús de dispositius virtuals (més enllà de preservar els sistemes de fitxers) és una característica avançada. Potser us cal editar algun fitxer (ex: initramfs, crypttab, fstab) per assegurar-vos que s&apos;han creat els dispositius virtuals en arrencar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1228"/>
        <source>You have chosen to encrypt at least one volume, and more information is required before continuing.</source>
        <translation>Heu triat encriptar com a mínim un volum i cal més informació abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1233"/>
        <source>Final Review and Confirmation</source>
        <translation>Comprovació final i confirmació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Please review this list carefully. This is the last opportunity to check, review and confirm the actions of the installation process before proceeding.</source>
        <translation>Si us plau, reviseu la llista amb cura- Aquesta és la darrera oportunitat per comprovar, revisar i confirmar les accions del procés d&apos;instal·lació abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1244"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instal·la GRUB per Linux i Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1245"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1 usa el carregador GRUB per arrencar %1 i Microsoft Windows.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1246"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Per omissió GRUB s&apos;instal·la al Master Boot Record (MBR) o l&apos;ESP (EFI System Partition per sistemes UEFI de 64-bit) del vostre disc d&apos;arrencada i reemplaça el carregador que estàveu usant fins llavors. Això és normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1247"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Si trieu instal·lar el GRUB al Partition Boot Record (PBR) en lloc del MBR, llavors el GRUB s&apos;instal·larà a l&apos;inici de la partició especificada. Aquesta opció és només per experts.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1248"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Si desactiveu la casella d&apos;instal·lar el GRUB, aquest no s&apos;instal·larà en aquest moment. Aquesta opció és només per experts.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Generate host-specific initramfs will try to create an initramfs tailored for the particular device rather than a generic all-purpose initramfs. This option is for experts only.</source>
        <translation>Genera initramfs específic per l&apos;amfitrió intentarà crear un fitxer initramfs a mida per al dispositiu particular en comptes d&apos;un initramfs genèric multiús. Aquesta opció és només per a experts.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Zram swap is a method of putting swap space in RAM.  A compressed swap device is placed in RAM.  It may be used in conjunction with other forms of swap, or on its own.</source>
        <translation>L&apos;intercanvi Zram és un mètode per ubicar l&apos;espai d&apos;intercanvi (swap) a la RAM. S&apos;instal·la un dispositiu d&apos;intercanvi comprimit a la RAM. Es pot usar conjuntament amb altres formes de &apos;swap&apos; o per sí sol.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Automatically restart when the installation is done</source>
        <translation>Reinicia automàticament quan la instal·lació s&apos;hagi completat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Welcome to %1 Installer</source>
        <translation>Benvingut/da a l&apos;instal·lador per a %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2296"/>
        <source>reset size</source>
        <translation>restableix-ne la mida</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2684"/>
        <source>The system is being installed.
This may take several minutes.</source>
        <translation>El sistema s&apos;instal·la.
Això pot trigar uns quants minuts.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2690"/>
        <source>Reboot automatically when installation completes</source>
        <translation>Reinicia automàticament quan s&apos;acabi la instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2724"/>
        <source>Installation complete</source>
        <translation>Instal·lació completa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4123"/>
        <source>Installing...</source>
        <translation>Instal·lant... </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4442"/>
        <source>Could not unlock device. Incorrect password?</source>
        <translation>No s&apos;ha pogut desblocar el dispositiu. La contrasenya és incorrecta?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>Installation Confirmation</source>
        <translation>Confirmació de la instal·lació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1935"/>
        <source>Please review the installation settings.

This is the last opportunity to check and confirm
the actions of the installation process.

Press ENTER to begin installation or Backspace to go back.</source>
        <translation>Si us plau, reviseu la configuració d&apos;instal·lació.

Aquesta és la darrera oportunitat per comprovar i confirmar les accions del procés d&apos;instal·lació.

Premeu RETORN per iniciar la instal·lació o la tecla de Retrocés per tornar enrere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1960"/>
        <source>Enter computer name</source>
        <translation>Introduïu el nom de l&apos;ordinador.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1975"/>
        <source>Enter domain name</source>
        <translation>Introduïu el nom del domini.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1989"/>
        <source>Workgroup</source>
        <translation>WORKGROUP</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2072"/>
        <source>Localization Settings</source>
        <translation>Paràmetres de localització</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2078"/>
        <source>Locale:</source>
        <translation>Locale: </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2089"/>
        <source>Time Area:</source>
        <translation>Àrea de l&apos;hora:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2100"/>
        <source>Time Zone:</source>
        <translation>Zona horària:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2176"/>
        <source>System services will be configured with default settings.
You can modify service settings after installation
using your system's service manager.

Press ENTER to continue.</source>
        <translation>Els serveis del sistema es configuraran amb la configuració predeterminada.
Podeu modificar la configuració del servei després de la instal·lació
mitjançant el gestor de serveis del sistema.

Premeu RETORN per continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2194"/>
        <source>Replace Existing Installation</source>
        <translation>Substitueix la instal·lació existent.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2210"/>
        <source>Custom Partitioning</source>
        <translation>Particions personalitzades</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2224"/>
        <source>Apply</source>
        <translation>Aplica</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2258"/>
        <source>Swap File Configuration</source>
        <translation>Configuració del fitxer d&apos;intercanvi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2271"/>
        <source>Location:</source>
        <translation>Ubicació: </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2282"/>
        <source>Size (MB):</source>
        <translation>Mida (MB):</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2302"/>
        <source>Enable hibernation support</source>
        <translation>Activa el suport per a la hibernació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2308"/>
        <source>Zram swap</source>
        <translation>Intercanvi de Zram</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2313"/>
        <source>Enable zram swap</source>
        <translation>Activa l&apos;intercanvi zram.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2320"/>
        <source>Allocate based on RAM (%):</source>
        <translation>Assignació segons la RAM (%):</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2335"/>
        <source>Allocate fixed size (MB):</source>
        <translation>Assignació amb una mida fixa (MB):</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2482"/>
        <source>Encryption options</source>
        <translation>Opcions d&apos;encriptació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2487"/>
        <source>Encryption password:</source>
        <translation>Contrasenya d&apos;encriptació: </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2498"/>
        <source>Confirm password:</source>
        <translation>Confirmeu la contrasenya: </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2540"/>
        <source>Enter username</source>
        <translation>Introduïu el nom d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2554"/>
        <source>Enter password</source>
        <translation>Introduïu la contrasenya.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2567"/>
        <source>Re-enter password</source>
        <translation>Torneu a introduir la contrasenya.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2640"/>
        <source>A home directory already exists for this user name.
Choose what to do with it:</source>
        <translation>Ja existeix un directori de l&apos;usuari per a aquest nom d&apos;usuari.
Trieu què voleu fer-ne:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4937"/>
        <source>Passwords must match and not be empty.</source>
        <translation>Les contrasenyes han de coincidir i no han d&apos;estar buides.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5274"/>
        <source>Please enter a computer name.</source>
        <translation>Si us plau, entreu un nom per a l&apos;ordinador.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5277"/>
        <source>The computer name contains invalid characters.</source>
        <translation>El nom de l&apos;ordinador conté caràcters no vàlids.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5280"/>
        <source>Please enter a domain name.</source>
        <translation>Si us plau, entreu un nom de domini.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5283"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>El domini de l&apos;ordinador conté caràcters no vàlids.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5286"/>
        <source>Please enter a workgroup.</source>
        <translation>Si us plau, entreu un grup de treball.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5617"/>
        <source>Please fill in all required fields before continuing.</source>
        <translation>Si us plau, ompliu tots els camps obligatoris abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5625"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>El nom d&apos;usuari no pot contenir caràcters especials ni espais.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5628"/>
        <location filename="../minstall.cpp" line="5631"/>
        <source>Please ensure the passwords match.</source>
        <translation>Si us plau, assegureu-vos que les contrasenyes coincideixin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5646"/>
        <source>The chosen user name is in use.</source>
        <translation>El nom d&apos;usuari triat ja s&apos;usa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5650"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>No heu donat la contrasenya per %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5658"/>
        <source>You did not provide a password for the root account.</source>
        <translation>No heu proporcionat una contrasenya per al compte d&apos;arrel.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5747"/>
        <source>Please select an option to continue.</source>
        <translation>Seleccioneu una opció per continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1254"/>
        <location filename="../minstall.cpp" line="2263"/>
        <source>Create a swap file</source>
        <translation>Crea un fitxer d&apos;intercanvi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="485"/>
        <source>Experimental</source>
        <comment>As In feature is not polished and may not work properly</comment>
        <translation>Experimental</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1255"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Un fitxer d&apos;intercanvi és més flexible que una partició d&apos;intercanvi; és molt més fàcil redimensionar un fitxer d&apos;intercanvi per adaptar-se als canvis en l&apos;ús del sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Per omissió, està activat si no s&apos;han definit particions d&apos;intercanvi, i desactivat si hi ha particions d&apos;intercanvi definides. Aquesta opció s&apos;hauria de deixar tal com està, i és només per experts.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1262"/>
        <source>Common Services to Enable</source>
        <translation>Serveis comuns a habilitar </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1263"/>
        <source>Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.</source>
        <translation>Seleccioneu qualsevol d&apos;aquests serveis comuns que pugueu necessitar amb la configuració del sistema i els serveis s&apos;iniciaran automàticament quan inicieu %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1268"/>
        <source>Computer Identity</source>
        <translation>Identitat de l&apos;ordinador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1269"/>
        <source>The computer name is a common unique name which will identify your computer if it is on a network.</source>
        <translation>El nom de l&apos;ordinador és un nom únic comú que identificarà l&apos;ordinador en una xarxa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1270"/>
        <source>The computer domain is unlikely to be used unless your ISP or local network requires it.</source>
        <translation>És poc probable que s&apos;usi el domini de l&apos;ordinador tret que el vostre proveïdor d&apos;Internet o la xarxa local ho requereixin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1271"/>
        <source>The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens.</source>
        <translation>Els noms d&apos;ordinador i de domini només poden contenir caràcters alfanumèrics, punts i guions. No poden contenir espais en blanc, ni començar ni acabar amb guions.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1273"/>
        <source>The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.</source>
        <translation>Cal activar el servidor SaMBa si voleu usar-lo per compartir alguns dels vostres directoris o impressores amb un ordinador local que executi MS-Windows o Mac OSX.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Localization Defaults</source>
        <translation>Localització per omissió</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1279"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Trieu el locale per omissió. S&apos;aplicarà aquest, llevat que posteriorment sigui modificat per l&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1280"/>
        <source>Configure Clock</source>
        <translation>Configura el rellotge</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1281"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Si teniu un ordinador Apple o bé purament Unix, per omissió el rellotge del sistema està definit  a l&apos;hora GMT (Greenwich Meridian Time) o UTC (Coordinated Universal Time). Per canviar-ho, comproveu la casella &quot;&lt;b&gt;El rellotge de sistema usa l&apos;hora local&lt;/b&gt;&quot;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1283"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>El sistema arrenca amb l&apos;hora del sistema definida com a GMT/UTC. Per a canviar la zona horària, després de tornar-ho a engegar, feu clic dret sobre el rellotge a la Barra de Tasques i seleccioneu Propietats.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1285"/>
        <source>Service Settings</source>
        <translation>Paràmetres de Servei</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1286"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>A molts usuaris no els hi cal canviar els valors per omissió. Els usuaris amb ordinadors de pocs recursos a vegades volen desactivar serveis innecessaris per tal d&apos;estalviar RAM. Assegureu-vos que sabeu el que esteu fent!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1293"/>
        <source>Default User Login</source>
        <translation>Inici de sessió de l&apos;usuari per omissió</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1294"/>
        <source>Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Si us plau, entreu el nom per a un nou compte d&apos;usuari (per omissió) que usareu diàriament. Si cal, podeu afegir després altres comptes d&apos;usuari amb el Gestor d&apos;Usuaris de %1. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1296"/>
        <source>Root (administrator) account</source>
        <translation>Compte Root (administrador)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1297"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account.</source>
        <translation>L&apos;usuari Root és semblant a l&apos;administrador en altres Sistemes Operatius. No hauríeu d&apos;usar mai l&apos;usuari root com el vostre compte habitual.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1299"/>
        <source>The root account is disabled on MX Linux, as administrative tasks are performed with an elevation prompt for the default user.</source>
        <translation>L&apos;usuari Root està desactivat en MX Linux, atès que les tasques administratives tenen lloc amb una elevació de nivell de l&apos;usuari per omissió.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1300"/>
        <source>Enabling the root account is strongly recommended for antiX Linux.</source>
        <translation>Es recomana activar el compte de root a antiX Linux.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1301"/>
        <source>Passwords</source>
        <translation>Contrasenyes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1302"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Entreu una nova contrasenya per a l&apos;usuari per omissió i per al comte d&apos;usuari principal: cal entrar cada contrasenya dos cops.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1304"/>
        <source>No passwords</source>
        <translation>Sense contrasenyes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Si voleu que l&apos;usuari per omissió no tingui contrasenya, deixeu buides les caselles de contrasenya. Això us permet iniciar la sessió sense entrar cap contrasenya.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1307"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Òbviament, això només s&apos;hauria de fer en situacions on el compte d&apos;usuari no cal que sigui segur, com en terminals d&apos;ús públic.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1316"/>
        <location filename="../minstall.cpp" line="2634"/>
        <source>Old Home Directory</source>
        <translation>Director d&apos;usuaris anterior</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1317"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Ja hi ha un directori d&apos;usuari amb el nom que heu triat. Aquesta pantalla us permet escollir què fer amb aquest directori.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1319"/>
        <location filename="../minstall.cpp" line="2646"/>
        <source>Re-use it for this installation</source>
        <translation>Tornar a usar-lo per aquesta instal·lació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1320"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>S&apos;usarà el directori d&apos;usuari anterior. És una bona elecció quan actualitzeu, i es localitzaran fàcilment els vostres paràmetres i fitxers.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1322"/>
        <location filename="../minstall.cpp" line="2653"/>
        <source>Rename it and create a new directory</source>
        <translation>Canvia el nom i crea un nou directori</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1323"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Es crearà un nou directori per aquest usuari, però en mantindrà el directori antic amb un altre nom. Els vostres paràmetres i fitxers no seran visibles immediatament per la nova instal·lació, però seran accessibles usant el directori amb el nou nom.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1325"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>El directori anterior tindrà una xifra al final del nom, depenent de quantes vegades se li hagi canviat el nom.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1326"/>
        <location filename="../minstall.cpp" line="2660"/>
        <source>Delete it and create a new directory</source>
        <translation>Esborrar-lo i crear un directori nou</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1327"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>S&apos;esborrarà el directori d&apos;usuari anterior, i se&apos;n crearà un de bell nou.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1125"/>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Warning</source>
        <translation>Atenció </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1329"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Si trieu aquesta opció, s&apos;esborraran permanentment tots els paràmetres i fitxers. La possibilitat de recuperar-los és mínima.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1341"/>
        <location filename="../minstall.cpp" line="2678"/>
        <source>Installation in Progress</source>
        <translation>Instal·lació en curs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1342"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>S&apos;instal·la %1. Per a una instal·lació nova, calen entre 3 i 20 minuts, segons la velocitat del sistema i la mida de les particions que es reformaten.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1344"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Si cliqueu el botó d&apos;interrupció, la instal·lació s&apos;aturarà tan aviat com sigui possible.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1346"/>
        <source>Change settings while you wait</source>
        <translation>Canvieu els paràmetres mentre espereu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1347"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Mentre s&apos;instal·la %1 , podeu clicar els botons &lt;b&gt;Següent&lt;/b&gt; o &lt;b&gt;Enrere&lt;/b&gt; per introduir altres informacions necessàries per a la instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Completeu aquests passos al vostre ritme. L&apos;instal·lador esperarà la vostra entrada si és necessari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1361"/>
        <source>Congratulations!</source>
        <translation>Enhorabona!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>You have completed the installation of %1.</source>
        <translation>Heu completat la instal·lació de l&apos;%1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1363"/>
        <source>Finding Applications</source>
        <translation>Trobar aplicacions</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>There are hundreds of excellent applications installed with %1. The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus.</source>
        <translation>Hi ha centenars d&apos;aplicacions excel·lents instal·lades a l&apos;%1. La millor manera d&apos;aprendre&apos;n sobre és navegar pel menú i provar-les. Moltes de les aplicacions es van desenvolupar específicament per al projecte %1. Aquestes es mostren als menús principals.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1368"/>
        <source>In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.</source>
        <translation>A més, l&apos;%1 inclou moltes aplicacions estàndard de Linux que només s&apos;executen des de la línia d&apos;ordres i, per tant, no apareixen al menú.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1370"/>
        <source>Enjoy using %1</source>
        <translation>Gaudiu de l&apos;ús de %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1444"/>
        <source>Finish</source>
        <translation>Acaba</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1447"/>
        <source>Start</source>
        <translation>Inici</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1450"/>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1452"/>
        <source>Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>The installation and configuration is incomplete.</source>
        <translation>La instal·lació i la configuració estan incompletes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1593"/>
        <source>Do you really want to stop now?</source>
        <translation>De veritat voleu parar ara?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Obtenir Ajuda&lt;/b&gt;&lt;br/&gt;La informació bàsica quant a %1 està a %2.&lt;/p&gt;&lt;p&gt;Trobareu voluntaris per ajudar-vos al fòrum de %3 , %4&lt;/p&gt;&lt;p&gt;Si demaneu ajuda, si us plau recordeu-vos de descriure en detall l&apos;ordinador i el vostre problema. Normalment frases com &apos;No funciona&apos; no ajuden gens. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparar la instal·lació&lt;/b&gt;&lt;br/&gt;Si %1 deixa de funcionar des del disc dur, a vegades es pot arreglar arrencant des del DVD Autònom o Live USB i executant alguna de les utilitats incorporades a %1 o bé usant una de les eines clàssiques de Linux per reparar el sistema.&lt;/p&gt;&lt;p&gt;Fins i tot podeu usar el vostre DVD Autònom o Live USB de %1 per recuperar dades dels sistemes MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ajustatges del mesclador de so&lt;/b&gt;&lt;br/&gt; %1 prova de configurar el mesclador de so per vosaltres, però a vegades us serà necessari pujar el volum o desenmudir canals al mesclador per escoltar so.&lt;/p&gt; &lt;p&gt;Trobareu la drecera del mesclador al menú. Cliqueu-hi per obrir el mesclador. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mantingueu la vostra còpia de %1 al dia&lt;/b&gt;&lt;br/&gt;Per més informació i actualitzacions podeu visitar &lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Agraïments&lt;/b&gt;&lt;br/&gt;Gràcies a tothom que ha triat donar suport a  %1 amb el seu temps, diners, suggeriments, treball, lloances, idees, promoció i/o ànims.&lt;/p&gt;&lt;p&gt;Sense vosaltres no hi hauria %1.&lt;/p&gt;&lt;p&gt;L&apos;Equip de Desenvolupament de %2.&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ajuda </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Registre Live</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="78"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="85"/>
        <source>Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="91"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="120"/>
        <source>Installation in progress</source>
        <translation>Instal·lació en curs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="135"/>
        <source>Abort</source>
        <translation>Interromp </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="138"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="158"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="177"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Recollint informació, espereu si us plau.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="209"/>
        <source>Terms of Use</source>
        <translation>Condicions d&apos;ús</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Keyboard Settings</source>
        <translation>Paràmetres del teclat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="256"/>
        <source>Model:</source>
        <translation>Model:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="271"/>
        <source>Variant:</source>
        <translation>Variant:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="297"/>
        <source>Change Keyboard Settings</source>
        <translation>Canvia la disposició del teclat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="309"/>
        <source>Layout:</source>
        <translation>Disposició: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Trieu el tipus d&apos;instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <source>Root</source>
        <translation>Arrel</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="445"/>
        <source>Home</source>
        <translation>Inici </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="520"/>
        <location filename="../meinstall.ui" line="542"/>
        <location filename="../meinstall.ui" line="1216"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="555"/>
        <source>Encrypt</source>
        <translation>Encripta</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1184"/>
        <source>Enable hibernation support</source>
        <translation>Activa el suport per a la hibernació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Instal·lació normal usant tot el disc </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="381"/>
        <source>Dual drive</source>
        <translation>Disc dual</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="391"/>
        <source>System drive:</source>
        <translation>Disc del sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <source>Home drive:</source>
        <translation>Disc de la carpeta de l&apos;usuari:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="565"/>
        <source>Customize the disk layout</source>
        <translation>Defineix el format del disc </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="572"/>
        <source>Replace existing installation</source>
        <translation>Substitueix la instal·lació existent.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="617"/>
        <source>Replace an existing installation</source>
        <translation>Substitueix una instal·lació existent.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="639"/>
        <source>Device</source>
        <translation>Dispositiu </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Installation</source>
        <translation>Instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Scan for existing installations</source>
        <translation>Cerca instal·lacions existents</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="679"/>
        <source>Replacement options</source>
        <translation>Opcions de substitució</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Attempt to upgrade packages</source>
        <translation>Intenta actualitzar els paquets.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="696"/>
        <source>Choose partitions</source>
        <translation>Trieu les particions</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Marca la unitat seleccionada per netejar-la amb una disposició nova.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Show Grid</source>
        <translation>Mostra la Graella</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Executa l&apos;aplicació de gestió de particions d&apos;aquest Sistma Operatiu.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="747"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Elimina una entrada existent de la disposició. Això només funciona en entrades d&apos;una disposició nova.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Consulta el sistema operatiu i torna a carregar les disposicions de totes les unitats.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="795"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Afegiu una nova entrada de partició. Això només funciona en una disposició nova.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="806"/>
        <source>Show advanced fields.</source>
        <translation>Mostra els camps avançats.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="836"/>
        <source>Encryption options</source>
        <translation>Opcions d&apos;encriptació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="842"/>
        <source>Encryption password:</source>
        <translation>Contrasenya d&apos;encriptació: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="859"/>
        <source>Confirm password:</source>
        <translation>Confirmeu la contrasenya: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="893"/>
        <source>Installation Confirmation</source>
        <translation>Confirmació de la instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="936"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instal·la GRUB per Linux i Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="951"/>
        <source>System boot disk:</source>
        <translation>Disc d&apos;arrencada: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="999"/>
        <source>EFI System Partition</source>
        <translation>EFI System Partition</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1021"/>
        <source>Partition Boot Record</source>
        <translation>Registre d&apos;arrencada de partició</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1024"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1046"/>
        <source>Master Boot Record</source>
        <translation>Registre d&apos;Arrencada Principal</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1052"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1055"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <source>Location to install on:</source>
        <translation>Ubicació on instal·lar:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1075"/>
        <source>Generate host-specific initramfs image</source>
        <translation>Genera una imatge d&apos;initramfs específica de l&apos;amfitrió.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1114"/>
        <source>Create a swap file</source>
        <translation>Crea un fitxer d&apos;intercanvi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1131"/>
        <location filename="../meinstall.ui" line="1255"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1154"/>
        <source>Size:</source>
        <translation>Mida:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1177"/>
        <source>Location:</source>
        <translation>Ubicació: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1194"/>
        <source>Enable zram swap</source>
        <translation>Activa l&apos;intercanvi zram.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1206"/>
        <source>Allocate based on RAM:</source>
        <translation>Assignació segons la RAM:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1235"/>
        <source>Recommended maximum: 100%</source>
        <translation>Màxim recomanat: 100 %</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1242"/>
        <source>Allocate fixed size:</source>
        <translation>Assigna una mida fixa:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1292"/>
        <source>Common Services to Enable</source>
        <translation>Serveis comuns a habilitar </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1302"/>
        <source>Service</source>
        <translation>Servei </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1307"/>
        <source>Description</source>
        <translation>Descripció </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Computer Network Names</source>
        <translation>Noms de Xarxa d&apos;ordinadors</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1364"/>
        <source>Workgroup</source>
        <translation>WORKGROUP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1377"/>
        <source>Workgroup:</source>
        <translation>Grup de treball: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1390"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Servidor SaMBa per a xarxa MS </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1406"/>
        <source>example.dom</source>
        <translation>exemple.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1419"/>
        <source>Computer domain:</source>
        <translation>Domini de l&apos;ordinador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1442"/>
        <source>Computer name:</source>
        <translation>Nom d&apos;ordinador: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1497"/>
        <source>Localization Defaults</source>
        <translation>Localització per omissió</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>Locale:</source>
        <translation>Locale: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1537"/>
        <source>Configure Clock</source>
        <translation>Configura el rellotge</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1578"/>
        <source>Format:</source>
        <translation>Format: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1606"/>
        <source>Timezone:</source>
        <translation>Fus horari: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1651"/>
        <source>System clock uses local time</source>
        <translation>El rellotge de sistema usa l&apos;hora local</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1673"/>
        <source>Service Settings (advanced)</source>
        <translation>Paràmetres de Serveis (avançat)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1691"/>
        <source>Adjust which services should run at startup</source>
        <translation>Trieu quins serveis cal executar en engegar </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1694"/>
        <source>View</source>
        <translation>Veure </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1755"/>
        <source>Default User Account</source>
        <translation>Compte d&apos;usuari per omissió</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1767"/>
        <source>Default user login name:</source>
        <translation>Nom de registre d&apos;usuari per omissió: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1783"/>
        <source>username</source>
        <translation>nomdusuari </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1796"/>
        <source>Default user password:</source>
        <translation>Contrasenya d&apos;usuari per omissió: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1822"/>
        <source>Confirm user password:</source>
        <translation>Confirmeu la contrasenya d&apos;usuari: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1851"/>
        <source>Root (administrator) Account</source>
        <translation>Compte Root (administrador)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1869"/>
        <source>Root password:</source>
        <translation>Contrasenya de root: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1895"/>
        <source>Confirm root password:</source>
        <translation>Confirmeu la contrasenya de root: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1924"/>
        <source>Autologin</source>
        <translation>Entrada automàtica </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1931"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Les modificacions fetes a l&apos;entorn autònom es traslladaran al S. O. instal·lat </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1934"/>
        <source>Save live desktop changes</source>
        <translation>Desa els canvis de l&apos;escriptori autònom </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1941"/>
        <source>Copy the contents of Live-usb-storage from the live medium to the installed system&apos;s home directory</source>
        <translation>Copia el contingut del suport USB autònom des del mitjà autònom al directori principal del sistema instal·lat.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1944"/>
        <source>Copy Live-usb-storage to installed system</source>
        <translation>Copia el contingut del suport USB autònom al sistema instal·lat.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1983"/>
        <source>Existing Home Directory</source>
        <translation>Directori d&apos;usuari existent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Què en voleu fer amb el directori antic?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1999"/>
        <source>Re-use it for this installation</source>
        <translation>Tornar a usar-lo per aquesta instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2006"/>
        <source>Rename it and create a new directory</source>
        <translation>Canviar-li el nom i crear un nou directori</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2013"/>
        <source>Delete it and create a new directory</source>
        <translation>Esborrar-ho i crear un nou directori</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2037"/>
        <source>Tips</source>
        <translation>Trucs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2069"/>
        <source>Installation complete</source>
        <translation>Instal·lació completa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2075"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Torna a arrencar el sistema en acabar la instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2094"/>
        <source>Reminders</source>
        <translation>Recordatoris</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="410"/>
        <source>Please enter a computer name.</source>
        <translation>Si us plau, entreu un nom per a l&apos;ordinador.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="414"/>
        <source>The computer name contains invalid characters.</source>
        <translation>El nom de l&apos;ordinador conté caràcters no vàlids.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="415"/>
        <location filename="../oobe.cpp" line="426"/>
        <location filename="../oobe.cpp" line="646"/>
        <source>Please choose a different name before proceeding.</source>
        <translation>Si us plau, trieu un nom diferent abans de continuar.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="421"/>
        <source>Please enter a domain name.</source>
        <translation>Si us plau, entreu un nom de domini.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="425"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>El domini de l&apos;ordinador conté caràcters no vàlids.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="434"/>
        <source>Please enter a workgroup.</source>
        <translation>Si us plau, entreu un grup de treball.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="651"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>El nom d&apos;usuari no pot contenir caràcters especials ni espais.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="661"/>
        <source>The chosen user name is in use.</source>
        <translation>El nom d&apos;usuari triat ja s&apos;usa.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="670"/>
        <source>Are you sure you want to continue?</source>
        <translation>Segur que voleu continuar?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="675"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>No heu donat la contrasenya per %1.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="680"/>
        <source>You did not provide a password for the root account.</source>
        <translation>No heu proporcionat una contrasenya per al compte Arrel.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="693"/>
        <source>Failed to set user account passwords.</source>
        <translation>Ha fallat en establir les contrasenyes dels comptes d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="725"/>
        <source>Failed to save old home directory.</source>
        <translation>Ha fallat en desar l&apos;antic directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="734"/>
        <source>Failed to delete old home directory.</source>
        <translation>Ha fallat en esborrar l&apos;antic directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="755"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Ho sento, ha fallat la creació del directori d&apos;usuari. </translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="763"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Ho sento, ha fallat en nomenar el directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="808"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Ha fallat en definir el propietari o permisos del directori d&apos;usuari.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="278"/>
        <location filename="../partman.cpp" line="956"/>
        <source>Virtual Devices</source>
        <translation>Dispositius Virtuals</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="555"/>
        <location filename="../partman.cpp" line="606"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Afegeix partició</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="557"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Elimina partició</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="566"/>
        <source>&amp;Lock</source>
        <translation>B&amp;loqueja</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="570"/>
        <source>&amp;Unlock</source>
        <translation>Desbloq&amp;ueja</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="574"/>
        <location filename="../partman.cpp" line="803"/>
        <source>Add to crypttab</source>
        <translation>Afegeix a crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="581"/>
        <source>New subvolume</source>
        <translation>Subvolum nou</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="582"/>
        <source>Scan subvolumes</source>
        <translation>Escaneja subvolums</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="609"/>
        <source>New &amp;layout</source>
        <translation>Nova &amp;disposició</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="610"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Restableix la disposició</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="612"/>
        <source>Layout &amp;Builder...</source>
        <translation>Creador de &amp;Disposició...</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="639"/>
        <source>Remove subvolume</source>
        <translation>Elimina el subvolum</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="797"/>
        <source>Unlock Drive</source>
        <translation>Desbloca la unitat</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="801"/>
        <source>Password:</source>
        <translation>Contrasenya: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="833"/>
        <source>Could not unlock device.</source>
        <translation>No s&apos;ha pogut desblocar el dispositiu.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="863"/>
        <source>Failed to close %1</source>
        <translation>Ha fallat en tancar %1 </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="877"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="896"/>
        <source>Invalid subvolume label</source>
        <translation>Etiqueta de subvolum no vàlida </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="904"/>
        <source>Duplicate subvolume label</source>
        <translation>Etiqueta de subvolum duplicada </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="913"/>
        <source>Invalid use for %1: %2</source>
        <translation>Ús no vàlid per %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 ja s&apos;ha seleccionat per: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="930"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Cal una partició arrel de, com a mínim, %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="947"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>No puc conservar /home dins de root (/) si ja hi ha una altra partició /home muntada.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="960"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Prepara la taula de particions %1 a %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="958"/>
        <source>Re-use partition table on %1</source>
        <translation>Reutilitza la taula de particions de %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="834"/>
        <source>Possible incorrect password.</source>
        <translation>Possible contrasenya incorrecta.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="967"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Reutilitza (sense reformatar) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="970"/>
        <source>Format %1</source>
        <translation>Formata %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="971"/>
        <source>Format %1 to use for %2</source>
        <translation>Formata %1 per a usar-la com %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="972"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Reutilitzar (sense reformatar) %1 com a %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="973"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Esborra les dades a %1 amb l&apos;excepció de /home, per usar-la com %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="976"/>
        <source>Create %1 without formatting</source>
        <translation>Crea %1 sense formatar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="977"/>
        <source>Create %1, format to use for %2</source>
        <translation>Crea %1, formata per a usar-la com a %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="992"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>Reutilitza el subvolum %1 com a %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="994"/>
        <source>Delete subvolume %1</source>
        <translation>Esborra el subvolum %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="997"/>
        <source>Overwrite subvolume %1</source>
        <translation>Sobreescriu el subvolum %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="998"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>Sobreescriu el subvolum %1 per usar-lo per %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1000"/>
        <source>Create subvolume %1</source>
        <translation>Crea el subvolum %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1001"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>Crea el subvolum %1 per usar per %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <location filename="../partman.cpp" line="1084"/>
        <location filename="../partman.cpp" line="1119"/>
        <location filename="../partman.cpp" line="1161"/>
        <source>Warning</source>
        <translation>Atenció </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1017"/>
        <source>Encrypting root without a separate unencrypted boot partition is not supported.

Do you want to go back and select a boot partition?</source>
        <translation>No es permet encriptar l&apos;arrel sense una partició d&apos;arrencada no encriptada separada.

Voleu tornar enrere i seleccionar una partició d&apos;arrencada?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1053"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) necessita %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1079"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>La instal·lació pot fallar perquè aquests volums són massa petits:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1081"/>
        <source>Are you sure you want to continue?</source>
        <translation>Segur que voleu continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1094"/>
        <source>This setup may produce an unbootable system. Do you want to continue?</source>
        <translation>Aquesta configuració pot produir un sistema que no pugui arrencar. Voleu continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1100"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Aquest sistema usa EFI, però s&apos;ha assignat separadament una partició de sistema EFI no vàlida a /boot/efi.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1103"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>El volum assignat a /boot/efi no és una partició de sistema EFI vàlida.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1146"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Aquestes unitats són o seran configurades en GPT, però no hi ha una partició BIOS-GRUB: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1148"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>El sistema no podrà arrencar amb unitats GPT sense una partició BIOS-GRUB.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1203"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Els discs amb les particions que heu seleccionat per la instal·lació estan fallant:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1207"/>
        <source>Smartmon tool output:</source>
        <translation>Sortida de l&apos;eina Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1208"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Els discs amb les particions que heu seleccionat passen les proves SMART monitor (smartctl), però les proves indiquen que tenen una possibilitat de fallada en el futur superior a la mitjana: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1215"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Si no en teniu la seguretat, sortiu de l&apos;instal·lador i executeu GSmartControl per a més informació.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1219"/>
        <source>Do you want to abort the installation?</source>
        <translation>Voleu interrompre la instal·lació? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1225"/>
        <source>Do you want to continue?</source>
        <translation>Voleu continuar? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1294"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Ha fallat en preparar les particions necessàries.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1338"/>
        <source>Preparing partition tables</source>
        <translation>Preparant les taules de partició </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1366"/>
        <source>Preparing required partitions</source>
        <translation>Preparant les particions adients </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1430"/>
        <source>Failed to format partition.</source>
        <translation>Ha fallat en formatar la partició.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1437"/>
        <source>Formatting: %1</source>
        <translation>Formatant: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1515"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Ha fallat en preparar els subvolums.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1516"/>
        <source>Preparing subvolumes</source>
        <translation>Preparant subvolums</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1643"/>
        <source>Failed to mount partition.</source>
        <translation>Ha fallat en muntar la partició.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1656"/>
        <source>Mounting: %1</source>
        <translation>Muntant: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1840"/>
        <source>Model: %1</source>
        <translation>Model: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1848"/>
        <source>Free space: %1</source>
        <translation>Espai lliure: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1948"/>
        <source>Device</source>
        <translation>Dispositiu </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1949"/>
        <source>Size</source>
        <translation>Mida </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1950"/>
        <source>Active</source>
        <translation>Actiu</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1951"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1952"/>
        <source>Use For</source>
        <translation>Usa Com </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1953"/>
        <source>Label</source>
        <translation>Etiqueta </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1954"/>
        <source>Encrypt</source>
        <translation>Encripta</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1955"/>
        <source>Format</source>
        <translation>Format </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1956"/>
        <source>Check</source>
        <translation>Comprova</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1957"/>
        <source>Options</source>
        <translation>Opcions </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1958"/>
        <source>Dump</source>
        <translation>Dump</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1959"/>
        <source>Pass</source>
        <translation>Pass</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1967"/>
        <source>Active partition</source>
        <translation>Partició activa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1968"/>
        <source>EFI System Partition</source>
        <translation>Partició de Sistema EFI </translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2787"/>
        <source>&amp;Templates</source>
        <translation>Plan&amp;tilles</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2794"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Compressió (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2796"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Compressió (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2798"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Compressió (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Negligible</source>
        <translation>Negligible</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Very weak</source>
        <translation>Molt feble</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Weak</source>
        <translation>Feble</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Moderate</source>
        <translation>Moderat</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Strong</source>
        <translation>Fort</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Very strong</source>
        <translation>Molt Fort</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="156"/>
        <source>Password strength: %1</source>
        <translation>Robustesa de la contrasenya: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Hide the password</source>
        <translation>Amaga la contrasenya</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Show the password</source>
        <translation>Mostra la contrasenya</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Gazelle Installer</source>
        <translation>Instal·lador Gazelle</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="126"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Instal·lador gràfic configurable per a MX Linux i antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="129"/>
        <source>Enable advanced settings, even in regular installation mode.</source>
        <translation>Habilita la configuració avançada, fins i tot al mode d&apos;instal·lació normal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Instal·la automàticament usant el fitxer de configuració (més informació a sota)-
-- ATENCIÓ: opció potencialment perillosa, esborrarà les particions automàticament.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>S&apos;absté de fer comprovacions en particions i unitats, mostrant el resultat en pantalla.
-- ATENCIÓ: Això pot causar danys, useu-ho només si no us preocupen les dades en aquesta unitat.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="134"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Carregueu un fitxer de configuració com s&apos;indica a &lt;config-file&gt;.
Per omissió s&apos;usa /etc/minstall.conf.
Si voleu una instal·lació desatesa, podeu usar l&apos;opció  --auto .
L&apos;instal·lador crea (o sobreescriu) /mnt/antiX/etc/minstall.conf i desa una còpia a  /etc/minstalled.conf per a un ús futur.
L&apos;instal·lador no escriurà cap contrasenya o ajustos desconeguts al nou fitxer de configuració.
Tingueu en compte que això és experimental. Les futures versions de l&apos;instal·lador poden trencar la compatibilitat amb els fitxers d&apos;instal·lació actuals.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="140"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Atura automàticament en acabar la instal·lació.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="141"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>No desmunteu /mnt/antiX o tanqueu cap dels contenidors LUKS associats en acabar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="142"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Instal·la el Sistema Operatiu, retardant les preguntes per a les opcions específiques de l&apos;usuari fins a la pròxima arrencada.
Un cop reiniciat, l&apos;instal·lador s&apos;executarà amb l&apos;opció -oobe, per tal que l&apos;usuari pugui facilitar aquests detalls.
Això pot ser interessant per a les instal·lacions OEM, per vendre o regalar un ordinador amb un S.O. preinstal·lat.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="145"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Opció &apos;de bell nou&apos;.
Arrencarà automàticament si s&apos;ha instal·lat amb l&apos;opció --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="147"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Mode de prova per IGU, es pot avançar per diferents pantalles sense instal·lar realment.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="148"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Reinicia automàticament en acabar la instal·lació.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="149"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Instal·lació amb rsync  en comptes de cp en fer particions a mida. 
-- No formata /root i no funciona amb encriptació.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="151"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Comproveu sempre el suport d&apos;instal·lació en començar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="152"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>No comprova el suport d&apos;instal·lació en començar.
No es recomana, llevat que el suport d&apos;instal·lació garanteixi estar lliure d&apos;errors.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="154"/>
        <source>Force TUI (Text User Interface) mode instead of GUI.</source>
        <translation>Força el mode ITU (Interfície de text) en comptes del mode IGU (Interfície gràfica).</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="155"/>
        <source>Jump directly to a specific page for testing (use with --pretend).
Page names: splash, terms, installation, partitions, confirm, boot, services, user, end</source>
        <translation>Salta directament a una pàgina específica per fer proves (useu-la amb --pretend).
Noms de pàgina: splash, terms, installation, partitions, confirm, boot, services, user, end</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="156"/>
        <source>&lt;page-name&gt;</source>
        <translation>&lt;page-name&gt;</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="157"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Carrega un fitxer de configuració tal com s&apos;especifica a &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="167"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Massa arguments. Si us plau, comproveu el format de l&apos;ordre executant el programa amb --help</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="177"/>
        <source>%1 Installer</source>
        <translation>Instal·lador per a %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="187"/>
        <source>The installer appears to be running already.</source>
        <translation>Sembla que l&apos;instal·lador ja s&apos;executa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="188"/>
        <source>Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Si us plau, tanqueu-lo si és possible o executeu &apos;pkill mininstall&apos; al terminal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="193"/>
        <location filename="../app.cpp" line="208"/>
        <location filename="../app.cpp" line="233"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="194"/>
        <source>The installer appears to be running already.
Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Sembla que l&apos;instal·lador ja s&apos;executa.
Si us plau, tanqueu-lo si és possible o executeu «pkill mininstall» al terminal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="203"/>
        <location filename="../app.cpp" line="209"/>
        <source>This operation requires root access.</source>
        <translation>Per aquesta opció cal accedir com a administrador.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="229"/>
        <location filename="../app.cpp" line="234"/>
        <source>Configuration file (%1) not found.</source>
        <translation>No he trobat el fitxer de configuració (%1).</translation>
    </message>
</context>
<context>
    <name>Replacer</name>
    <message>
        <location filename="../replacer.cpp" line="147"/>
        <source>Information</source>
        <translation>Informació</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="148"/>
        <source>Could not open any of the locked encrypted containers.
Possible incorrect password. Press the &apos;Scan&apos; button to try again with a different password.</source>
        <translation>No s&apos;ha pogut obrir cap dels contenidors encriptats blocats.
Possible contrasenya incorrecta. Premeu el botó d&apos;exploració per tornar-ho a intentar amb una contrasenya diferent.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="163"/>
        <source>Volume %1 on drive %2</source>
        <translation>Volum %1 al disc %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="203"/>
        <location filename="../replacer.cpp" line="429"/>
        <location filename="../replacer.cpp" line="437"/>
        <source>Error</source>
        <translation>Error</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="204"/>
        <source>No existing installation selected.</source>
        <translation>No s&apos;ha seleccionat cap instal·lació existent.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="281"/>
        <source>Replace the installation in %1: %2</source>
        <translation>Substitueix la instal·lació %1: %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="303"/>
        <location filename="../replacer.cpp" line="359"/>
        <source>Unlock encrypted volumes</source>
        <translation>Desbloca els volums encriptats</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="307"/>
        <location filename="../replacer.cpp" line="363"/>
        <source>Password:</source>
        <translation>Contrasenya: </translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="365"/>
        <source>Ignore encrypted volumes</source>
        <translation>Ignora els volums encriptats</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="430"/>
        <source>Cannot unlock encrypted partition: %1</source>
        <translation>No es pot desblocar la partició encriptada: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="438"/>
        <source>Cannot find partition listed in crypttab: %1</source>
        <translation>No es pot trobar la partició llistada a crypttab: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="458"/>
        <source>Warning</source>
        <translation>Atenció </translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="459"/>
        <source>Could not re-lock encrypted device(s): %1</source>
        <translation>No he pogut tornar a blocar els discs encriptats: %1</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="57"/>
        <source>Recommended maximum: %1 MB</source>
        <translation>Màxim recomanat: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="60"/>
        <source>Unable to query RAM size.</source>
        <translation>No es pot consultar la mida de la RAM.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="97"/>
        <source>Invalid location</source>
        <translation>Ubicació no vàlida</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="100"/>
        <source>Maximum: %1 MB</source>
        <translation>Màxim: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="117"/>
        <source>Failed to configure zram swap.</source>
        <translation>Ha fallat en configurar l&apos;intercanvi de zram.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="127"/>
        <source>Failed to create or install swap file.</source>
        <translation>Ha fallat en crear o instal·lar el fitxer d&apos;intercanvi.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="133"/>
        <source>Creating swap file</source>
        <translation>Creant un fitxer d&apos;intercanvi</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="146"/>
        <source>Configuring swap file</source>
        <translation>Configurant el fitxer d&apos;intercanvi</translation>
    </message>
</context>
</TS>