inline const QString VERSION {"26.5.1mx25"};
