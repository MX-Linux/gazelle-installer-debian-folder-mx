<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="sq">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Root</source>
        <translation>Rrënjë</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="62"/>
        <source>Home</source>
        <translation>Hyrje</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="139"/>
        <location filename="../autopart.cpp" line="141"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>E rekomanduar: %1
Minimumi: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="178"/>
        <source>Layout Builder</source>
        <translation>Ndërtues Skeme</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="323"/>
        <source>%1% root
%2% home</source>
        <translation>Rrënja për %1%
Shtëpia e %2%</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="325"/>
        <source>Combined root and home</source>
        <translation>Rrënjë dhe shtëpi të ndërthurura</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="56"/>
        <source>Cannot access installation media.</source>
        <translation>S’hapet dot media e instalimit.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="156"/>
        <source>Deleting old system</source>
        <translation>Po fshihet sistemi i vjetër</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="153"/>
        <source>Failed to delete old system on destination.</source>
        <translation>S’u arrit të fshihet sistemi i vjetër te vendmbërritje.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="164"/>
        <source>Creating system directories</source>
        <translation>Po krijohen drejtori sistemi</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="175"/>
        <source>Fixing configuration</source>
        <translation>Po ndreqet formësimi</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="240"/>
        <source>Copying new system</source>
        <translation>Po kopjohet sistemi i ri</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="270"/>
        <source>Failed to copy the new system.</source>
        <translation>S’u arrit të kopjohej sistemi i ri.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="266"/>
        <source>Updating initramfs</source>
        <translation>Po përditësohet initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="126"/>
        <source>Installing GRUB</source>
        <translation>Po instalohet GRUB-i</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="104"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>Instalimi i GRUB-it dështoi. Mund të rinisni median për sistemin live dhe të përdorni menunë GRUB Rescue që të riparoni instalimin.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="267"/>
        <source>Failed to update initramfs.</source>
        <translation>S’u arrit të përditësohej initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="292"/>
        <source>System boot disk:</source>
        <translation>Disk nisjeje sistemi:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="311"/>
        <location filename="../bootman.cpp" line="323"/>
        <source>Partition to use:</source>
        <translation>Pjesë për t’u përdorur:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="38"/>
        <source>Checking installation media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="39"/>
        <source>Press ESC to skip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="56"/>
        <source>The installation media is corrupt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="120"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceItem</name>
    <message>
        <location filename="../partman.cpp" line="1926"/>
        <source>EFI System Partition</source>
        <translation>Pjesë EFI Sistemi</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1927"/>
        <source>swap space</source>
        <translation>hapësirë swap</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1928"/>
        <source>format only</source>
        <translation>vetëm formatim</translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">Krijoje</translation>
    </message>
    <message>
        <source>Preserve</source>
        <translation type="vanished">Ruaje</translation>
    </message>
    <message>
        <source>Preserve (%1)</source>
        <translation type="vanished">Ruaje (%1)</translation>
    </message>
    <message>
        <source>Preserve /home (%1)</source>
        <translation type="vanished">Ruaje /home (%1)</translation>
    </message>
</context>
<context>
    <name>DeviceItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2472"/>
        <source>&amp;Templates</source>
        <translation>&amp;Gjedhe</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2484"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Ngjeshje (&amp;ZLIB)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2480"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Ngjeshje (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2482"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Ngjeshje (&amp;LZO)</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="84"/>
        <source>Shutdown</source>
        <translation>Fike</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="140"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>Po xhironi një OS 32bit të nisur nën mënyrën UEFI, sistemi s’do të jetë në gjendje të bëjë nisjen, veç në përzgjedhshi Nisje e Dikurshme ose diçka të ngjashme, gjatë rinisjes.
Këshillojmë të dilni tani dhe ta rinisni nën Nisje e Dikurshme

Doni të vazhdohet instalimi?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="186"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Përkrahni %1

%1-i përkrahet nga njerëz si ju. Disa ndihmojnë të tjerët te forumi i asistencës - %2, ose përkthejnë në gjuhë të ndryshme kartela ndihme, ose bëjnë sugjerime, shkruajnë dokumentim, ose ndihmojnë të testohet software i ri.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="226"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 është një shpërndarje e pavarur Linux e bazuar në Debian Stable

%1 përdor disa përbërës nga MEPIS Linux, që mund të përdoren sipas një licence të lirë Apache. Disa përbërës MEPIS janë ndryshuar për %1.

Shijoni përdorimin e %1-it</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="343"/>
        <source>Pretending to install %1</source>
        <translation>Po pretendohet të instalohet %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="361"/>
        <source>Preparing to install %1</source>
        <translation>Po përgatitet të instalohet %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="385"/>
        <source>Paused for required operator input</source>
        <translation>Ndalur, për veprim të domosdoshëm të operatorit</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="397"/>
        <source>Setting system configuration</source>
        <translation>Po ujdiset formësim sistemi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="409"/>
        <source>Cleaning up</source>
        <translation>Po pastrohet</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="413"/>
        <source>Finished</source>
        <translation>U përfundua</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="437"/>
        <source>The installation was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="522"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>U gjetën rregullime të pavlefshme në kartelën e formësimit (%1). Ju lutemi, shqyrtoni fushat me shenjë, teksa hasni të tilla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="542"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>OK për formatim dhe përdorim të krejt diskut (%1) për %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>KUJDES: Disku i përzgjedhur ka një kapacitet të paktën 2TB dhe duhet formatuar duke përdorur GPT. Në disa sisteme, një disk i formatuar me GPT s’do të arrijë të niset.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="575"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Të dhënat në /home s’mund të ruhen, ngaqë s’merren dot hollësi të domosdoshme.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="599"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Drejtoria shtëpi për %1 ekziston tashmë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="635"/>
        <source>General Instructions</source>
        <translation>Udhëzime të Përgjithshme</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="636"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>PARA SE TË ECNI MË TEJ, MBYLLNI KREJT APLIKACIONET E TJERA.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="637"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Në çdo faqe, ju lutemi, lexoni udhëzimet, bëni përzgjedhjet tuaja dhe mandej klikoni mbi Pasuesi, kur të jeni gati për të vazhduar. Para se të kryhet çfarëdo veprimi asgjësues, do t’ju kërkohet të jepni ripohimin tuaj.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="639"/>
        <source>Limitations</source>
        <translation>Kufizime</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="640"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Mbani mend, ky software jepet SIÇ-ËSHTË. pa ndonjë garanci të çfarëdo lloji. Është përgjegjësi vetëm e juaja të kopjeruani të dhënat tuaja, para se të ecni më tej.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="645"/>
        <source>Installation Options</source>
        <translation>Mundësi Instalimi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="646"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Nëse xhironi Mac OS ose Windows OS (nga Vista e sipër), mund t’ju duhet të përdorni software të atij sistemi për të ujdisur pjesë dhe përgjegjës nisjesh, para se të instaloni.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="647"/>
        <source>Using the root-home space slider</source>
        <translation>Përmes rrëshqitësi hapësirash rrënjë-shtëpi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="648"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>Duke përdorur rrëshqitësin, disku mund të ndahet në pjesë sistemi (rrënjë) dhe të dhënash përdoruesi (shtëpi) më vete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="649"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>Pjesa &lt;b&gt;rrënjë&lt;/b&gt; do të përmbajë sistemin operativ dhe aplikacione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="650"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>Pjesa &lt;b&gt;shtëpi&lt;/b&gt; do të përmbajë të dhënat e krejt përdoruesve, bie fjala rregullimet, kartelat, dokumentet, fotot, muzikën, videot e tyre, etj.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Për të shtuar hapësirën për &lt;b&gt;rrënjën&lt;/b&gt;, lëvizeni rrëshqitësin djathtas. Për të shtuar hapësirën për &lt;b&gt;shtëpinë&lt;/b&gt;, lëvizeni rrëshqitësin majtas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="652"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Lëvizeni rrëshqitësin tërësisht djathtas, nëse doni rrënjën dhe shtëpinë në të njëjtën pjesë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="653"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Mbajtja e drejtorisë shtëpi në një pjesë më vete përmirëson qëndrueshmërinë e përmirësimeve të sistemit operativ. Bën gjithashtu më të lehta kopjeruajtjet dhe rikthimet. Kjo mund të përmirësojë gjithashtu punimin në përgjithësi, duke detyruar mbajtjen e kartelave të sistemit te një pjesë e caktuar e diskut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="655"/>
        <location filename="../minstall.cpp" line="729"/>
        <source>Encryption</source>
        <translation>Fshehtëzim</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="656"/>
        <location filename="../minstall.cpp" line="730"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Fshehtëzimi është i mundshëm përmes LUKS-it. Për këtë lypset një fjalëkalim.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="657"/>
        <location filename="../minstall.cpp" line="731"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Është e domosdoshme një pjesë nisjeje e pafshehtëzuar, më vete.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="658"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Kur fshehtëzimi përdoret me vetëinstalimin, pjesa ndarazi për nisjen do të krijohet automatikisht.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="659"/>
        <source>Using a custom disk layout</source>
        <translation>Përdorim i një skeme vetjake disku</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="660"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Nëse ju duhet më tepër kontroll mbi se ku instalohet %1, përzgjidhni &quot;&lt;b&gt;%2&lt;/b&gt;&quot; dhe klikoni mbi &lt;b&gt;Pasuesi&lt;/b&gt;. Në faqen pasuese mandej, do të jeni në gjendje të përzgjidhni dhe formësoni pajisje depozitimi dhe pjesë që ju duhen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="667"/>
        <source>Choose Partitions</source>
        <translation>Zgjidhni Pjesë</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Lista e pjesëve ju lejon të zgjidhni cilat pjesë përdoren për këtë instalim.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="669"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Pajisje&lt;/i&gt; - Ky është emri për “block device” që i është caktuar, ose do t’i caktohet, pjesës së krijuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="670"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Madhësi&lt;/i&gt; - Madhësia e pjesës. Kjo mund të ndryshohet vetëm për skema të reja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="671"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Përdore Për&lt;/i&gt; - Që këtë pjesë ta përdorni në një instalim, duhet të përzgjidhni diçka këtu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="672"/>
        <source>Format - Format without mounting.</source>
        <translation>Formatoje - Formatojeni pa e montuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="673"/>
        <source>BIOS-GRUB - BIOS Boot GPT partition for GRUB.</source>
        <translation>BIOS-GRUB - Pjesë BIOS Boot GPT për GRUB.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="674"/>
        <source>EFI - EFI System Partition.</source>
        <translation>EFI - Pjesë EFI Sistemi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="675"/>
        <source>boot - Boot manager (/boot).</source>
        <translation>boot - Përgjegjës nisjesh (/boot).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="676"/>
        <source>root - System root (/).</source>
        <translation>root - Rrënja e sistemit (/).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="677"/>
        <source>swap - Swap space.</source>
        <translation>swap - Hapësirë swap.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="678"/>
        <source>home - User data (/home).</source>
        <translation>home - Të dhëna përdoruesi (/home).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="679"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Përtej sa më sipër, mundeni edhe të shtypni pikën tuaj të montimit. Pika vetjake montimi duhet të fillojnë me një pjerrake (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="680"/>
        <source>The installer treats &quot;/boot&quot;, &quot;/&quot;, and &quot;/home&quot; exactly the same as &quot;boot&quot;, &quot;root&quot;, and &quot;home&quot;, respectively.</source>
        <translation>Instaluesi i trajton përkatësisht &quot;/boot&quot;, &quot;/&quot;, dhe &quot;/home&quot; saktësisht si &quot;boot&quot;, &quot;root&quot;, dhe &quot;home&quot;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="681"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etiketë&lt;/i&gt; - Etiketa që i është caktuar pjesës, pasi të jetë formatuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="682"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Fshehtëzoje&lt;/i&gt; - Përdor fshehtëzim LUKS për këtë pjesë. Fjalëkalimi aplikohet për krejt pjesët e përzgjedhura për fshehtëzim.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Format&lt;/i&gt; - Ky është formati i pjesës. Formatet e mundshëm varen nga fakti se përse do të përdoret pjesa. Kur punohet me një skemë ekzistuese, mund të jeni në gjendje të ruani formatin e pjesës duke përzgjedhur &lt;b&gt;Ruaje&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="685"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root.</source>
        <translation>Përzgjedhja e &lt;b&gt;Ruaje /home&lt;/b&gt; për pjesën e rrënjës ruan lëndën e drejtorisë /home, duke fshirë gjithçka tjetër. Kjo mundësi mund të përdoret vetëm kur /home gjendet në të njëjtën pjesë me rrënjën.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="687"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Mbulohen sistemet ext2, ext3, ext4, jfs, xfs dhe btrfs të kartelave dhe rekomandohet ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="688"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Kontrolloje&lt;/i&gt; - Kontrollo te pajisja për blloqe të këqij dhe ndreqi (nuk mbulohet për krejt formatet). Kjo kërkon shumë kohë, ndaj mund të doni ta anashkaloni këtë hap, veç në dyshofshi se disku juaj ja blloqe të këqij.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="690"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Mundësi Montimi&lt;/i&gt; - Kjo përcakton mundësitë e montimit që do të përdoren për këtë pjesë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="691"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Dump&lt;/i&gt; - Udhëzon mjetin dump të përfshijë këtë pjesë te kopjeruajtja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="692"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Pass&lt;/i&gt; - Radha sipas të cilës ky sistem kartelash të kontrollohet gjatë nisjes. Në qoftë zero, sistemi i kartelave s’kontrollohet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="693"/>
        <source>Menus and actions</source>
        <translation>Menu dhe veprime</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="694"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Duke djathtasklikuar mbi cilindo disk apo cilëndo pjesë te lista, keni një larmi mundësish për përdorim.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Butonat në të djathtë të listës mund të përdoren edhe për të manipuluar zërat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="696"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>Instaluesi s’mund të ndryshojë skemën që disku ka tashmë. Që të krijoni një skemë vetjake, i vini shenjë diskut për skemën e re, përmes veprimit ose butonit &lt;b&gt;Skemë e re&lt;/b&gt; (%1). Kjo do të thotë spastrim i skemës ekzistuese.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="699"/>
        <source>Basic layout requirements</source>
        <translation>Domosdoshmëri skeme elementare</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="700"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1-i lyp një pjesë rrënjë. Pjesa “swap” është opsionale, por e rekomanduar me forcë. Nëse doni të përdorni veçorinë Pezulloje-në-Disk të %1-it, do t’ju duhet një pjesë “swap” që është më e madhe se sasia e kujtesës fizike të makinës tuaj.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="702"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Nëse zgjidhni një pjesë /home ndaras, do të jetë më e lehtë për ju të përmirësoni sistemin në të ardhmen, por kjo s’do të jetë e mundshme, nëse e përmirësoni prej një instalimi që nuk ka një pjesë /home ndarazi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="704"/>
        <source>Active partition</source>
        <translation>Pjesë aktive</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="705"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Që sistemi i instaluar të niset, pjesa e duhur (zakonisht pjesa “boot”, ose ajo rrënjë) duhet të jenë e treguar si aktive.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="706"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>Pjesa aktive e një disku mund të zgjidhet duke përdorur zërin &lt;b&gt;Pjesë aktive&lt;/b&gt; e menusë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Një pjesë, me një asterisk (*) në krah të emrit përkatës të pajisjes, është, ose do të jetë, pjesa aktive.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="708"/>
        <source>Boot partition</source>
        <translation>Pjesë nisjeje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="709"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Kjo pjesë zakonisht është e domosdoshme vetëm për pjesë rrënjë në pajisje virtuale, bie fjala, vëllime të fshehtëzuar LVM ose RAID përmes software-i.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="710"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Përmban një kernel elementar dhe pajisje elementare për të përdorur disqe ose pajisje virtuale të fshehtëzuara.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>BIOS-GRUB partition</source>
        <translation>Pjesë GRUB BIOS</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="712"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>Kur përdoret një disk i formatuar si GPT në një sistem jo EFI, lypset doemos një pjesë nisjeje 1MB BIOS, kur përdoret GRUB-i.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="713"/>
        <source>New drives are formatted in GPT if more than 4 partitions are to be created, or the drive has a capacity greater than 2TB. If the installer is about to format the disk in GPT, and there is no BIOS-GRUB partition, a warning will be displayed before the installation starts.</source>
        <translation>Disqet e rinj formatohet si GPT, nëse duhen krijuar më tepër se 4 pjesë, ose nëse disku ka një kapacitet më të madh se 2TB. Nëse instaluesi është gati për të formatuar diskun si GPT, dhe nuk ka pjesë BIOS-GRUB, para se të nisë instalimi do të shfaqet një sinjalizim.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="715"/>
        <source>Need help creating a layout?</source>
        <translation>Ju duhet ndihmë në krijimin e një skeme?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="716"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Thjesht djathtasklikoni mbi një disk dhe përzgjidhni &lt;b&gt;Ndërtues Skeme&lt;/b&gt; që nga menuja. Kjo mund të krijojë një skemë të ngjashme me atë të instalimit të rregullt.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="750"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalo GRUB për Linux dhe Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="751"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1 përdor ngarkuesin GRUB të nisjeve, për të nisur %1 dhe Microsoft-in Windows.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="752"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Si parazgjedhje, GRUB-i instalohet në Master Boot Record - Regjistër i Përgjithshëm Nisjesh - (MBR) ose ESP (EFI System Partition - Pjesë Sistemi EFI - për sisteme nisjeje 64-bit UEFI) të diskut tuaj të nisjes dhe zëvendëson ngarkuesin e nisjeve që përdorni më parë. Kjo është normale.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="753"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Nëse, në vend të kësaj,  zgjidhni të instaloni GRUB-in te Partition Boot Record - Regjistër Pjesësh Nisjeje - (PBR), atëherë GRUB-i do të instalohet në fillim të pjesës së përcaktuar. Kjo mundësi është vetëm për të sprovuarit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="754"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Nëse i hiqni shenjën kutizës Instalo GRUB-in, GRUB-i s’do të instalohet këtë herë. Kjo mundësi është vetëm për ekspertë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="755"/>
        <source>Create a swap file</source>
        <translation>Krijo një kartelë “swap”</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="756"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Një kartelë “swap” është zgjidhje më e zhdërvjellët se sa një pjesë “swap”, është goxha më e lehtë të ripërmasohet një kartelë “swap” për t’ia përshtatur ndryshimeve në përdorimin e sistemit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="757"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Si parazgjedhje, kësaj i vihet shenjë nëse s’janë ujdisur pjesë “swap” dhe lihet pa shenjë, nëse janë ujdisur pjesë “swap”. Te kjo mundësi s’duhen futur duart dhe është vetëm për të sprovuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="758"/>
        <source>Setting the size to 0 has the same effect as unchecking this option.</source>
        <translation>Caktimi i madhësisë si 0, ka të njëjtin efekt si mosvënia shenjë kësaj mundësie.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="865"/>
        <source>Enjoy using %1</source>
        <translation>Shijoni përdorimin e %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="717"/>
        <source>Upgrading</source>
        <translation>Përmirësim</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="718"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Që të përmirësoni një instalim Linux ekzistues, përzgjidhni të njëjtën pjesë shtëpi si më parë dhe si formatim përzgjidhni &lt;b&gt;Ruaje&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="719"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Nëse nuk përdorni një pjesë shtëpi më vete, përzgjidhni &lt;b&gt;Ruaje /home&lt;/b&gt;, te zëri për sistem kartelash rrënje, që të ruhet drejtoria ekzistuese /home e gjendur te pjesa juaj rrënjë. Instaluesi do të ruajë vetëm /home, dhe do të fshijë gjithçka tjetër. Si rrjedhojë, instalimi do të zgjasë shumë më tepër se sa zakonisht.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="721"/>
        <source>Preferred Filesystem Type</source>
        <translation>Lloj i Parapëlqyer Sistemi Kartelash</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="722"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Për %1, mund të zgjidhni t’i formatoni pjesët si ext2, ext3, ext4, f2fs, jfs, xfs ose btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="723"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Për disqe që përdorin btrfs, ka mundësi shtesë ngjeshjeje. Lzo-ja është e shpejtë, por shkalla e ngjeshjes është e ulët. Zlib është i ngadaltë, me shkallë ngjeshjeje të lartë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="725"/>
        <source>System partition management tool</source>
        <translation>Mjet administrimi pjesësh sistemi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="726"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Për më tepër kontroll mbi skemat e disqeve (bie fjala, ndryshim i skemës ekzistuese në një disk), klikoni butonin e administrimit të pjesëve (%1). Kjo do të vërë në punë mjetin e sistemit operativ për administrim pjesësh, që do t’ju lejojë të krijoni skemën e saktë që ju duhet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="732"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Që të ruhet një pjesë e fshehtëzuar, djathtasklikoni mbi të dhe përzgjidhni &lt;b&gt;Shkyçe&lt;/b&gt;. Te dialogu që shfaqet, jepni një emër për pajisjen virtuale dhe fjalëkalimin. Kur pajisja është e shkyçur, emri që zgjodhët do të shfaqet nën &lt;i&gt;Pajisje Virtuale&lt;/i&gt;, me mundësi të ngjashme me ato të një pjese normale.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="734"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Që pjesa e fshehtëzuar të shkyçet gjatë nisjes, duhet shtuar te kartela crypttab. Për të kryer këtë, përdorni veprimin &lt;b&gt;Shtoje te crypttab&lt;/b&gt; që nga menuja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="735"/>
        <source>Other partitions</source>
        <translation>Pjesë të tjera</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="736"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Instaluesi lejon të krijohen pjesë të tjera, ose të përdoren për qëllime të tjera, por kini parasysh se sisteme më të vjetër s’përdorin dot disqe me më shumë se 4 pjesë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Subvolumes</source>
        <translation>Nënvëllime</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="738"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Disa sisteme kartelash, bie fjala, Btrfs, mbulon nënvëllime të shumtë brenda një pjese të dhënë. Këta nuk janë nëndarje fizike, ndaj radha e tyre nuk ka rëndësi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="740"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Që të kërkohet për nënvëllime në një pjesë Btrfs ekzistuese, përdorni veprimin &lt;b&gt;Skano nënvëllime&lt;/b&gt; nga menuja. Që të krijoni një nënvëllim të ri, përdorni veprimin &lt;b&gt;Nënvëllim i ri&lt;/b&gt; nga menuja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="742"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Mund të ruhen nënvëllime ekzistues, por emri duhet të mbetet po ai.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="743"/>
        <source>Virtual Devices</source>
        <translation>Pajisje Virtuale</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="744"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Nëse instaluesi pika pajisje virtuale, bie fjala pjesë LUKS të hapura, vëllime logjike LVM, ose vëllime RAID me bazë software-i, ato mund të përdoren për instalimin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="745"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>Përdorimi i pajijeve virtuale (përtej qëllimit të ruajtjes së sistemeve të fshehtëzuar të kartelave) është një veçori e thelluar. Mund t’ju duhet të përpunoni ca kartela (p.sh., initramfs, crypttab, fstab), për të garantuar se pajisjet virtuale të përdorura krijohen gjatë nisjes to ensure the virtual devices used are created upon boot.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="764"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Shërbime të Rëndomtë për Aktivizim&lt;/b&gt;&lt;br/&gt;Përzgjidhni cilindo prej këtyre shërbimeve të rëndomtë që mund t’ju duhen me formësimin e sistemit tuaj dhe shërbimet do të nisen automatikisht, kur nisni %1-in.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="768"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identitet Kompjuteri&lt;/b&gt;&lt;br/&gt;Emri i kompjuterit është një emër i zakonshëm, unik, që do të identifikojë kompjuterin tuaj, nëse ky gjendet në një rrjet. Përkatësia e kompjuterit ka pak gjasa të përdoret, veç nëse e kërkon ISP-ja ose rrjeti juaj vendor.&lt;/p&gt;&lt;p&gt;Emrat e kompjuterit dhe përkatësisë mund të përmbajnë vetëm shenja alfanumerike, pika, vija ndarëse në mes. S’mund të përmbajnë hapësira të zbrazëta, të fillojnë ose mbarojnë me vija ndarëse në mes&lt;/p&gt;&lt;p&gt;Nëse doni ta përdorni për të ndarë me të tjerët disa nga drejtoritë tuaja, ose shtypësin, me një kompjuter që xhiron MS-Windows ose Mac OS, Shërbyesi SaMBa duhet aktivizuar.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="778"/>
        <source>Localization Defaults</source>
        <translation>Parazgjedhje Vendoreje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="779"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Caktoni vendoren parazgjedhje. Kjo është ajo që do të aplikohet, veç në u anashkaloftë më vonë nga përdoruesi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="780"/>
        <source>Configure Clock</source>
        <translation>Formësoni Sahatin</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="781"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Nëse keni një kompjuter Apple, ose puro Unix, si parazgjedhje, sahati i sistemit është vënë sa Greenwich Meridian Time (GMT), ose Koha Universale e Bashkërenduar (UTC). Që ta ndryshoni, i vini shenjë kutizës “&lt;b&gt;Sahati i sistemit përdor kohë vendore&lt;/b&gt;”.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="783"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Sistemi niset me zonën kohore të vënë si GMT/UTC. Që të ndryshoni zonën kohore, pasi rinisni një instalim të ri, djathtasklikoni mbi sahatin, te Paneli, dhe përzgjidhni Veti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="785"/>
        <source>Service Settings</source>
        <translation>Rregullime Shërbimesh</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="786"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Shumica e përdoruesve s’do të duhej të ndryshonin parazgjedhjet. Përdoruesit me kompjuter me pak takat, ndonjëherë, mund të duan të çaktivizojnë shërbime të panevojshme, për ta mbajtur përdorimin e RAM-it sa më ulët që të jetë e mundur. Sigurohuni se dini se ç’bëni!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="792"/>
        <source>Default User Login</source>
        <translation>Hyrje Përdoruesi Parazgjedhje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="793"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Përdoruesi rrënjë është i ngjashëm me përdoruesin Përgjegjës e disa sistemeve operativë të tjerë. S’duhet të përdorni përdoruesin rrënjë si llogarinë tuaj të përditshme të përdoruesit. Ju lutemi, jepni një emër për një llogari përdoruesi të ri (parazgjedhje), të cilën do ta përdorni përditë. Në qoftë e nevojshme, më vonë mund të shtoni llogari të tjera përdoruesish, me Përgjegjës Përdoruesish %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="797"/>
        <source>Passwords</source>
        <translation>Fjalëkalime</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="798"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Jepni një fjalëkalim të ri për llogarinë tuaj parazgjedhje si përdorues dhe për llogarinë rrënjë. Çdo fjalëkalim duhet dhënë dy herë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="800"/>
        <source>No passwords</source>
        <translation>Pa fjalëkalime</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="801"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Nëse doni që llogaria e përdoruesit, si parazgjedhje, të mos ketë fjalëkalim, lëreni të zbrazët fushën për fjalëkalimin e saj. Kjo ju lejon të hyni pa u dashur një fjalëkalim.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="803"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Kuptohet, kjo duhet bërë vetëm në raste kur llogaria e përdoruesit s’ka nevojë të jetë e siguruar, bie fjala në një terminal publik.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="811"/>
        <source>Old Home Directory</source>
        <translation>Drejtoria Shtëpi e Dikurshme</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="812"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Për emrin e përdoruesit që keni zgjedhur, ekziston tashmë një drejtori shtëpi. Kjo skenë ju lejon të zgjidhni ç’të bëhet me këtë drejtori.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="814"/>
        <source>Re-use it for this installation</source>
        <translation>Ripërdore për këtë instalim</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="815"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Drejtoria shtëpi e dikurshme do të përdoret për këtë llogari përdoruesi. Kjo është një zgjedhje e përshtatshme, kur përmirësohet një instalim, dhe kartelat dhe rregullimet tuaja do të jenë gati menjëherë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>Rename it and create a new directory</source>
        <translation>Riemërtoje dhe krijo drejtori të re</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Për përdoruesin do të krijohet një drejtori shtëpi e re, por drejtoria shtëpi e dikurshme do të riemërtohet. Kartelat dhe rregullimet tuaja s’do të jenë të dukshme menjëherë te instalimi i ri, por mund të ripërdoren duke përdorur drejtorinë e riemërtuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="820"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Drejtoria e dikurshme do të ketë një numër në fund të emrit të vet, që varet nga sa herë është riemërtuar drejtoria më parë.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>Delete it and create a new directory</source>
        <translation>Fshije dhe krijo drejtori të re</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="822"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Drejtoria e dikurshme shtëpi do të fshihet, dhe do të krijohet nga e para një e re.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="823"/>
        <source>Warning</source>
        <translation>Kujdes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Nëse përzgjidhet kjo mundësi, krejt kartelat dhe rregullimet do të fshihen përgjithmonë. Shanset tuaja për rikthim janë të pakta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="840"/>
        <source>Installation in Progress</source>
        <translation>Instalim në Ecuri e Sipër</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="841"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 po instalohet. Për një instalim fringo të ri, kjo do të dojë afërsisht 3-20 minuta, në varësi nga shpejtësia e sistemit tuaj dhe madhësia e çfarëdo pjese që po riformatoni.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="843"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Nëse klikoni butonin Ndërprite, instalimi do të ndalet sa më shpejt që të jetë e mundur.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <source>Change settings while you wait</source>
        <translation>Ndryshoni rregullimet, teksa prisni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="846"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Teksa %1-i instalohet, mund të klikoni mbi butonat &lt;b&gt;Pasuesi&lt;/b&gt; ose &lt;b&gt;Mbrapsht&lt;/b&gt;, që të jepni hollësitë e domosdoshme për instalimin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="848"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Plotësojini këto hapa me ritmin tuaj. Instaluesi do të presë për ndërhyrjet tuaja, nëse është e nevojshme.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="856"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Përgëzime!&lt;/b&gt;&lt;br/&gt;Keni plotësuar instalimin e %1-it&lt;/p&gt;&lt;p&gt;&lt;b&gt;Gjetje Aplikacionesh&lt;/b&gt;&lt;br/&gt;Ka qindra aplikacione të shkëlqyera të instaluara me %1-in Rruga më e mirë për të mësuar rreth tyre është t’i shfletoni përmes Menusë dhe t’i provoni. Mjaft nga aplikacionet janë zhvilluar posaçërisht për projektin %1. Këto shfaqen te menutë kryesore. &lt;p&gt;Veç tyre, %1-i përfshin mjaft aplikacione standarde Linux që përdoren vetëm nga rreshti i urdhrave, ndaj nuk shfaqen te Menuja.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="866"/>
        <location filename="../minstall.cpp" line="1127"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Përkrahni %1-in&lt;/b&gt;&lt;br/&gt;%1-i përkrahet nga njerëz si ju. Disa ndihmojnë të tjerët te forumi i asistencës - %2 - ose përkthejnë në gjuhë të ndryshme kartela ndihme, ose bëjnë sugjerime, shkruajnë dokumentim, ose ndihmojnë të testohet software i ri.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="896"/>
        <source>Finish</source>
        <translation>Përfundoje</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="899"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="901"/>
        <source>Next</source>
        <translation>Pasuesi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="425"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>Po formësohet sistemi. Ju lutemi, prisni.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="432"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Formësim i plotësuar. Po riniset sistemi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1054"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Instalimi dhe formësimi janë të paplotë.
Doni vërtet të ndalet tani?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1113"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Si të Merret Ndihmë&lt;/b&gt;&lt;br/&gt;Informacion elementar mbi %1 ka te %2.&lt;/p&gt;&lt;p&gt;Te forumi %3, %4 ka vullnetarë për t’ju ndihmuar&lt;/p&gt;&lt;p&gt;Nëse kërkoni ndihmë, ju lutemi, mos harroni të përshkruani paksa hollësisht problemin dhe kompjuterin tuaj. Zakonisht, pohime të llojit “nuk funksionoi”, s’bëjnë punë.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1121"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Si të Riparoni Instalimin Tuaj&lt;/b&gt;&lt;br/&gt;Nëse %1-i resht së funksionuari që nga disku HD, ndonjëherë është e mundshme të ndreqet problemi duke bërë nisjen nga LiveDVD ose LiveUSB dhe duke xhiruar një nga mjetet prej %1-it, ose duke përdorur një nga mjetet e zakonshme të Linux-it për riparim sistemi.&lt;/p&gt;&lt;p&gt;Mundeni edhe të përdorni %1 LiveDVD apo LiveUSB tuaj për të shpëtuar të dhëna nga sisteme MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1135"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Përimtim i Përzierësit Tuaj të Tingujve&lt;/b&gt;&lt;br/&gt; %1-i përpiqet të formësojë për ju përzierësin e tingujve, por ndonjëherë mund të duhet të ngrini volumet dhe të hiqni heshtim kanalesh te përzierësi, që të mund të dëgjoni tinguj.&lt;/p&gt; &lt;p&gt;Shkurtorja për përzierësin gjendet te menuja. Klikojeni që të hapet përzierësi. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1143"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mbajeni të përditësuar Kopjen Tuaj të %1-it&lt;/b&gt;&lt;br/&gt;Për informacion dhe përditësimet, ju lutemi, vizitoni&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1148"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Falënderime të Veçanta&lt;/b&gt;&lt;br/&gt;Falënderime për këdo që ka zgjedhur të përkrahë %1-in me kohë nga e tyrja, para, sugjerime, punë, vlerësim, ide, promovim, dhe/ose inkurajim.&lt;/p&gt;&lt;p&gt;Pa ju, s’do të kish %1.&lt;/p&gt;&lt;p&gt;Ekipi i Zhvillimit të %2-it&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MPassEdit</name>
    <message>
        <source>Use password</source>
        <translation type="vanished">Përdor fjalëkalim</translation>
    </message>
    <message>
        <source>Hide the password</source>
        <translation type="vanished">Fshihe fjalëkalimin</translation>
    </message>
    <message>
        <source>Show the password</source>
        <translation type="vanished">Shfaqe fjalëkalimin</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="43"/>
        <source>Help</source>
        <translation>Ndihmë</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="69"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="195"/>
        <source>Close</source>
        <translation>Mbylle</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="121"/>
        <source>Next</source>
        <translation>Pasuesi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="128"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="212"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Po Grumbullohen të Dhëna, ju lutemi, mos u largoni.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="244"/>
        <source>Terms of Use</source>
        <translation>Kushte Përdorimi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="332"/>
        <source>Change Keyboard Settings</source>
        <translation>Ndryshoni Rregullime Tastiere</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <source>Select type of installation</source>
        <translation>Përzgjidhni lloj instalimi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="422"/>
        <source>Regular install using the entire disk</source>
        <translation>Instalim i zakonshëm duke përdorur krejt diskun</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <source>Customize the disk layout</source>
        <translation>Përshtatni skemën e diskut</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="448"/>
        <source>Use disk:</source>
        <translation>Përdor diskun:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="602"/>
        <source>Encrypt</source>
        <translation>Fshehtëzoje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="614"/>
        <location filename="../meinstall.ui" line="817"/>
        <source>Encryption password:</source>
        <translation>Fjalëkalim fshehtëzimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="631"/>
        <location filename="../meinstall.ui" line="834"/>
        <source>Confirm password:</source>
        <translation>Ripohoni fjalëkalimin:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="482"/>
        <source>Root</source>
        <translation>Rrënjë</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="276"/>
        <source>Keyboard Settings</source>
        <translation>Rregullime Tastiere</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="291"/>
        <source>Model:</source>
        <translation>Model:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="306"/>
        <source>Variant:</source>
        <translation>Variant:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="344"/>
        <source>Layout:</source>
        <translation>Skemë:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="492"/>
        <source>Home</source>
        <translation>Hyrje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="567"/>
        <location filename="../meinstall.ui" line="589"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="651"/>
        <location filename="../meinstall.ui" line="1092"/>
        <source>Enable hibernation support</source>
        <translation>Aktivizo mbulim kalimi në plogështi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="689"/>
        <source>Choose partitions</source>
        <translation>Zgjidhni pjesë</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="729"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Kërko te sistemi operativ dhe ringarko skemat e krejt disqeve.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="762"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Hiqni prej skemës një zë ekzistues. Kjo funksionon vetëm me zëra te një skemë e re.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="751"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Shtoni një pjesë të re. Kjo funksionon vetëm me një skemë të re.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="698"/>
        <source>Show Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Vëri shenjë diskut të përzgjedhur për t’u spastruar për një skemë të re.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="740"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Xhiro aplikacionin e administrimit të pjesëve prej këtij sistemi operativ.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="811"/>
        <source>Encryption options</source>
        <translation>Mundësi fshehtëzimi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="870"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalo GRUB për Linux dhe Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="894"/>
        <source>Master Boot Record</source>
        <translation>Regjistër i Përgjithshëm Nisjesh</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="900"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="903"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="925"/>
        <source>EFI System Partition</source>
        <translation>Pjesë EFI Sistemi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="928"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="960"/>
        <source>Partition Boot Record</source>
        <translation>Regjistër Nisjesh i Pjesës</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="963"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="976"/>
        <source>System boot disk:</source>
        <translation>Disk nisjeje sistemi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="989"/>
        <source>Location to install on:</source>
        <translation>Vendndodhje ku të instalohet:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1025"/>
        <source>Create a swap file</source>
        <translation>Krijo një kartelë “swap”</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1042"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1062"/>
        <source>Size:</source>
        <translation>Madhësi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1085"/>
        <source>Location:</source>
        <translation>Vend:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1124"/>
        <source>Common Services to Enable</source>
        <translation>Shërbime të Rëndomtë për Aktivizim</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1143"/>
        <source>Service</source>
        <translation>Shërbim</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1148"/>
        <source>Description</source>
        <translation>Përshkrim</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1181"/>
        <source>Computer Network Names</source>
        <translation>Emra Rrjetesh Kompjuteri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1208"/>
        <source>Workgroup</source>
        <translation>Grup pune</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1221"/>
        <source>Workgroup:</source>
        <translation>Grup pune:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1234"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Shërbyes SaMBa për Punim Në Rrjet për MS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>example.dom</source>
        <translation>example.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1263"/>
        <source>Computer domain:</source>
        <translation>Përkatësi kompjuteri:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1289"/>
        <source>Computer name:</source>
        <translation>Emër kompjuteri:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1350"/>
        <source>Configure Clock</source>
        <translation>Formësoni Sahatin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1391"/>
        <source>Format:</source>
        <translation>Format:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1419"/>
        <source>Timezone:</source>
        <translation>Zonë kohore:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1464"/>
        <source>System clock uses local time</source>
        <translation>Sahati i sistemit përdor kohën vendore</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1496"/>
        <source>Localization Defaults</source>
        <translation>Parazgjedhje Vendoreje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1536"/>
        <source>Locale:</source>
        <translation>Vendore:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1558"/>
        <source>Service Settings (advanced)</source>
        <translation>Rregullime Shërbimesh (të mëtejshme)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1576"/>
        <source>Adjust which services should run at startup</source>
        <translation>Përimtoni cilat shërbime duhen xhiruar që në nisje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1579"/>
        <source>View</source>
        <translation>Shiheni</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1624"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Ndryshimet e bëra në desktop që nga mjedisi live do të barten te OS-i i instaluar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1627"/>
        <source>Save live desktop changes</source>
        <translation>Ruaji ndryshimet te desktopi live</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1640"/>
        <source>Default User Account</source>
        <translation>Llogari Parazgjedhje Përdoruesish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1652"/>
        <source>Default user login name:</source>
        <translation>Emër parazgjedhje hyrjeje për përdoruesin:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1684"/>
        <source>Default user password:</source>
        <translation>Fjalëkalim përdoruesi parazgjedhje:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1713"/>
        <source>Confirm user password:</source>
        <translation>Ripohoni fjalëkalim përdoruesi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1671"/>
        <source>username</source>
        <translation>emër përdoruesi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1745"/>
        <source>Root (administrator) Account</source>
        <translation>Llogari Rrënjë (përgjegjësi)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1763"/>
        <source>Root password:</source>
        <translation>Fjalëkalim rrënje:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1792"/>
        <source>Confirm root password:</source>
        <translation>Ripohoni fjalëkalim rrënje:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1824"/>
        <source>Autologin</source>
        <translation>Vetëhyrje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>Existing Home Directory</source>
        <translation>Drejtori Home Ekzistuese</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1869"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Ç’do të donit të bëhet me drejtorinë e dikurshme?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1876"/>
        <source>Re-use it for this installation</source>
        <translation>Ripërdore për këtë instalim</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1883"/>
        <source>Rename it and create a new directory</source>
        <translation>Riemërtoje dhe krijo drejtori të re</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1890"/>
        <source>Delete it and create a new directory</source>
        <translation>Fshije dhe krijo drejtori të re</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Tips</source>
        <translation>Ndihmëza</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1979"/>
        <source>Installation complete</source>
        <translation>Instalim i plotësuar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1985"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Rinise automatikisht sistemin, kur mbyllet instaluesi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2004"/>
        <source>Reminders</source>
        <translation>Kujtues</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="107"/>
        <source>Back</source>
        <translation>Mbrapsht</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="114"/>
        <source>Alt+K</source>
        <translation>Alt+M</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Installation in progress</source>
        <translation>Instalim në ecuri e sipër</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="172"/>
        <source>Abort</source>
        <translation>Ndërprite</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="175"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="332"/>
        <source>Please enter a computer name.</source>
        <translation>Ju lutemi, jepni emër kompjuteri.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="336"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Na ndjeni, emri i kompjuterit tuaj përmban shenja
të pavlefshme. Do t’ju duhet të përzgjidhni
tjetër emër, para se të ecni më tej.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="341"/>
        <source>Please enter a domain name.</source>
        <translation>Ju lutemi, jepni një emër përkatësie.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="345"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Na ndjeni, përkatësia e kompjuterit tuaj përmban
shenja të pavlefshme. Do t’ju duhet të përzgjidhni
tjetër emër, para se të ecni më tej.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="352"/>
        <source>Please enter a workgroup.</source>
        <translation>Ju lutemi, jepni një grup pune.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="492"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Emri i përdoruesit s’mund të përmbajë shenja speciale ose
Ju lutemi, para se të ecet më tej, zgjidhni një emër tjetër.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="503"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Na ndjeni, ai emër është në përdorim. 
Ju lutemi, përzgjidhni një emër tjetër.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="512"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="513"/>
        <source>Are you sure you want to continue?</source>
        <translation type="unfinished">Jeni i sigurt se doni të vazhdohet?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="519"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>S’dhatë fjalëkalim për llogarinë rrënjë. Doni të vazhdohet?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="532"/>
        <source>Failed to set user account passwords.</source>
        <translation>S’u arrit të caktohen fjalëkalime llogarish përdoruesi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="558"/>
        <source>Failed to save old home directory.</source>
        <translation>S’u arrit të ruhet drejtoria shtëpi e dikurshme.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="567"/>
        <source>Failed to delete old home directory.</source>
        <translation>S’u arrit të fshihet drejtoria e dikurshme shtëpi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="587"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Na ndjeni, s’u arrit të krijohej drejtori përdoruesi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="590"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Na ndjeni, s’u arrit të emërtohet drejtori përdoruesi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="626"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>S’u arrit të ujdisej pronësi ose leje drejtorie përdoruesi.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="229"/>
        <source>Virtual Devices</source>
        <translation>Pajisje Virtuale</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="456"/>
        <location filename="../partman.cpp" line="510"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Shtoni pjesë</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="458"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Hiqni pjesë</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="468"/>
        <source>&amp;Lock</source>
        <translation>&amp;Kyçe</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="472"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Shkyçe</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="477"/>
        <location filename="../partman.cpp" line="610"/>
        <source>Add to crypttab</source>
        <translation>Shtoje te crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="483"/>
        <source>Active partition</source>
        <translation>Pjesë aktive</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="489"/>
        <source>New subvolume</source>
        <translation>Nënvëllim i ri</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="490"/>
        <source>Scan subvolumes</source>
        <translation>Skano nënvëllime</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="513"/>
        <source>New &amp;layout</source>
        <translation>&amp;Skemë e re</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="514"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Riktheje skemën te parazgjedhjet</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="537"/>
        <source>Remove subvolume</source>
        <translation>Hiq nënvëllim</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="607"/>
        <source>Unlock Drive</source>
        <translation>Shkyçe Diskun</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="613"/>
        <source>Virtual Device:</source>
        <translation>Pajisje Virtuale:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="614"/>
        <source>Password:</source>
        <translation>Fjalëkalim:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="642"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation>Pajisja s’u shkyç dot. Mundet nga fjalëkalim i pasaktë.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="671"/>
        <source>Failed to close %1</source>
        <translation>S’u arrit të mbyllet %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="715"/>
        <source>Invalid subvolume label</source>
        <translation>Etiketë nënvëllimi e pavlefshme</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="726"/>
        <source>Duplicate subvolume label</source>
        <translation>Etiketë nënvëllimi e përsëdytur</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="735"/>
        <source>Invalid use for %1: %2</source>
        <translation>Përdorim i pavlefshëm për %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="746"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 është përzgjedhur tashmë për: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="760"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Lypset një pjesë rrënjë të paktën %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="766"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>S’ruhet dot /home brenda rrënje (/), nëse ndarazi është montuar gjithashtu një pjesë /home.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="789"/>
        <source>Reuse (no reformat) %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="810"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="812"/>
        <source>Delete subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="815"/>
        <source>Overwrite subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="816"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="818"/>
        <source>Create subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="819"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="834"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Kur fshehtëzohet rrënja, duhet të zgjidhni një pjesë nisjesh më vete.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="779"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Përgatit tabelë pjesësh %1 te %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="792"/>
        <source>Format %1 to use for %2</source>
        <translation>Formatoje %1 për ta përdorur për %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="793"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Ripërdor (pa formatim) %1 si %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="794"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Fshini të dhënat te %1, hiq ato në /home, që të përdoret për %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="797"/>
        <source>Create %1 without formatting</source>
        <translation>Krijoje %1 pa e formatuar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="798"/>
        <source>Create %1, format to use for %2</source>
        <translation>Krijoje %1, formatoje për ta përdorur për %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="946"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Disqet pasues janë, ose të do të jenë, ujdisur me GPT, por nuk kanë një pjesë BIOS-GRUB:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="948"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Ky sistem mund të mos niset nga disqe GPT pa një pjesë BIOS-GRUB.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="835"/>
        <location filename="../partman.cpp" line="919"/>
        <location filename="../partman.cpp" line="949"/>
        <source>Are you sure you want to continue?</source>
        <translation>Jeni i sigurt se doni të vazhdohet?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="516"/>
        <source>Layout &amp;Builder...</source>
        <translation>&amp;Ndërtues Skemash…</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="889"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) lyp %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="917"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>Instalimi mund të dështojë, ngaqë vëllimet vijuese janë shumë të vegjël:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="841"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>Instaluesi %1 tani do të kryejë veprimet e kërkuara.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="842"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Këto veprime s’mund të zhbëhen. Doni të vazhdohet?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="988"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Disqet me pjesët që përzgjodhët për instalim s’po funksionojnë:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="992"/>
        <source>Smartmon tool output:</source>
        <translation>Përfundim nga mjeti Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="993"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Disqet me pjesët që përzgjodhët për instalim, e kalojnë testin e mbikëqyrjeve SMART (smartctl), por testet tregojnë se tani afër do të ketë një numër dështimesh më të lartë se sa mesatarja.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="998"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Nëse jeni i pasigurt, ju lutemi, mbylleni Instaluesin dhe xhironi GSmartControl, për më tepër hollësi.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1000"/>
        <source>Do you want to abort the installation?</source>
        <translation>Doni të ndërpritet instalimi?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1005"/>
        <source>Do you want to continue?</source>
        <translation>Doni të vazhdohet?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <source>Failed to format LUKS container.</source>
        <translation>S’u arrit të formatohej kontejner LUKS.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1025"/>
        <source>Failed to open LUKS container.</source>
        <translation>S’u arrit të hapej kontejner LUKS.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1349"/>
        <source>Failed to finalize encryption setup.</source>
        <translation>S’u arrit të përfundohet ujdisja e fshehtëzimit.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1125"/>
        <source>Failed to prepare required partitions.</source>
        <translation>S’u arrit të përgatiten pjesët e domosdoshme.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1168"/>
        <source>Preparing partition tables</source>
        <translation>Po përgatiten tabela pjesësh</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1185"/>
        <source>Preparing required partitions</source>
        <translation>Po përgatiten pjesët e domosdoshme</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1251"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Po krijohet vëllim i fshehtëzuar: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1256"/>
        <source>Formatting: %1</source>
        <translation>Po formatohet: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1239"/>
        <source>Failed to format partition.</source>
        <translation>S’u arrit të formatohej pjesa.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1315"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>S’u arrit të përgatiten nënvëllime.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1316"/>
        <source>Preparing subvolumes</source>
        <translation>Po përgatitet nënvëllime</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1426"/>
        <source>Failed to mount partition.</source>
        <translation>S’u arrit të montohej pjesë.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1431"/>
        <source>Mounting: %1</source>
        <translation>Po montohet: %1</translation>
    </message>
    <message>
        <source>Model: %1</source>
        <translation type="vanished">Model: %1</translation>
    </message>
    <message>
        <source>Free space: %1</source>
        <translation type="vanished">Hapësirë e lirë: %1</translation>
    </message>
    <message>
        <source>Device</source>
        <translation type="vanished">Pajisje</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">Madhësi</translation>
    </message>
    <message>
        <source>Use For</source>
        <translation type="vanished">Përdore Për</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="vanished">Etiketë</translation>
    </message>
    <message>
        <source>Encrypt</source>
        <translation type="vanished">Fshehtëzoje</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="vanished">Formatoje</translation>
    </message>
    <message>
        <source>Check</source>
        <translation type="vanished">Kontrolloje</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">Mundësi</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="144"/>
        <source>Negligible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="144"/>
        <source>Very weak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="144"/>
        <source>Weak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="145"/>
        <source>Moderate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="145"/>
        <source>Strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="145"/>
        <source>Very strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="147"/>
        <source>Password strength: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="180"/>
        <source>Hide the password</source>
        <translation type="unfinished">Fshihe fjalëkalimin</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="180"/>
        <source>Show the password</source>
        <translation type="unfinished">Shfaqe fjalëkalimin</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="87"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Instalues GUI i ndryshueshëm, për MX Linux dhe antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="90"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Instalon automatikisht, duke përdorur kartelën e formësimeve (më tepër hollësi më poshtë).
-- KUJDES: mundësi potencialisht e rrezikshme, do të fshijë pjesën(t) automatikisht.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="92"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Anashkalon kontrolle saktësie në pjesë dhe disqe, duke shkaktuar shfaqjen e tyre.
-- KUJDES: kjo mund të hapë telashe, përdoreni vetëm nëse s’ju bëhet vonë për të dhëna te disku.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="94"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Ngarko një kartelë formësimi të dhënë nga &lt;config-file&gt;.
Si parazgjedhje, përdoret /etc/minstall.conf.
Ky formësim mund të përdore me --auto, për instalime pa u ndenjur mbi kokë.
Instaluesi krijon (ose mbishkruan) /mnt/antiX/etc/minstall.conf dhe ruan një kopje te /etc/minstalled.conf, për përdorim në të ardhmen.
Instaluesi s’do të shkruajë te kartela e re e formësimit ndonjë fjalëkalim, apo rregullime të shpërfillura.
Ju lutemi, kini parasysh, kjo është eksperimentale. Versione të ardhshëm të instaluesit mund të mos jenë të përputhshëm me kartela ekzistuese formësimesh.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="100"/>
        <source>Shutdowns automatically when done installing.</source>
        <translation>Bëhet fikje vetvetiu, kur të ketë përfunduar instalimi.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="101"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation>Përdor përherë GPT, kur bëhet instalim në krejt diskun, pavarësisht nga kapaciteti.
Pa këtë mundësi, GPT-ja do të përdoret vetëm në disqe me kapacitet të paktën 2TB.
Në sisteme UEFI, GPT-ja përdoret përherë në instalime në krejt diskun, pavarësisht kapacitetit, edhe pa zgjedhjen e kësaj mundësie.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="104"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Kur përfundohet, mos çmontoni /mnt/antiX, apo të mbyllni çfarëdo kontejneri LUKS të përshoqëruar.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="105"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation>Një tjetër mënyrë testimi për instaluesin, pjesët/disqet do të FORMATOHEN, kopjimi i kartelave do të anashkalohet.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="106"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Instalo sistemin operativ, duke lënë mënjanë hapat për mundësi që lidhen me përdoruesin, deri në rinisjen e parë.
Gjatë rinisjes, instaluesi do të xhirojë me --oobe, që kështu përdoruesi të mund të japë këto hollësi.
Kjo është e dobishme për instalime OEM, për shitje ose dhënie të një kompjuteri me një OS të parangarkuar në të.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="109"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Mundësia “Fill Pas Instalimi”.
Kjo do të instalohet automatikisht, nëse instalimi bëhet me mundësinë --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="111"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Mënyrë test për GUI-n, mund të kaloni nëpër skena të ndryshme pa instaluar gjë faktikisht.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="112"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Riniset vetvetiu, kur të ketë përfunduar instalimi.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Po instalohet me rsync, në vend se cp, në pjesëtim vetjak.
-- s’formatohet /root dhe s’funksionon me fshehtëzimin.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="115"/>
        <source>Always check the installation media at the beginning.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="116"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="118"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Ngarko një kartelë formësimi të specifikuar nga &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="122"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Më tepër argumente se sa duhen. Ju lutemi, kontrolloni, formatin e urdhrit duke xhiruar programin me --help</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>%1 Installer</source>
        <translation>Instalues %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="135"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Instaluesi s’do të niset, ngaqë duket se është duke xhiruar tashmë në prapaskenë.
Ju lutemi, mbylleni, nëse është e mundur, ose xhironi “pkill minstall” në terminal.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="142"/>
        <source>This operation requires root access.</source>
        <translation>Ky veprim lyp hyrje si rrënjë.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="163"/>
        <source>Configuration file (%1) not found.</source>
        <translation>S’u gjet kartelë formësimi (%1).</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="67"/>
        <source>Failed to create or install swap file.</source>
        <translation>S’u arrit të krijohej ose instalohej “swap”.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="73"/>
        <source>Creating swap file</source>
        <translation>Po krijohet kartelë “swap”</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="85"/>
        <source>Configuring swap file</source>
        <translation>Po formësohet “swap”</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="121"/>
        <source>Invalid location</source>
        <translation>Vendndodhje e pavlefshme</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="124"/>
        <source>Maximum: %1 MB</source>
        <translation>Maksimum: %1 MB</translation>
    </message>
</context>
</TS>
