const QString VERSION {"23.7.09mx23"};
