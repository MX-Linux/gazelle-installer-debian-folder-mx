<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="hi">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Root</source>
        <translation>रूट</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="62"/>
        <source>Home</source>
        <translation>होम</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="139"/>
        <location filename="../autopart.cpp" line="141"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="178"/>
        <source>Layout Builder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="323"/>
        <source>%1% root
%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="325"/>
        <source>Combined root and home</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="56"/>
        <source>Cannot access installation media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base.cpp" line="151"/>
        <source>Deleting old system</source>
        <translation>पुराना सिस्टम हटाना जारी</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="155"/>
        <source>Failed to delete old system on destination.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../base.cpp" line="161"/>
        <source>Creating system directories</source>
        <translation>सिस्टम डायरेक्टरी सृजन जारी</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="167"/>
        <source>Fixing configuration</source>
        <translation>विन्यास सुधार जारी</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="236"/>
        <source>Copying new system</source>
        <translation>नवीन सिस्टम कॉपी करना जारी</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="266"/>
        <source>Failed to copy the new system.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="281"/>
        <source>Updating initramfs</source>
        <translation>Initramfs अपडेट करना जारी</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="148"/>
        <source>Installing GRUB</source>
        <translation>GRUB इंस्टॉल करना जारी</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="149"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>GRUB इंस्टॉल विफल। आप लाइव मध्यम में पुनः बूट कर GRUB निवारण मेन्यू द्वारा इंस्टॉल प्रक्रिया सुधार सकते हैं।</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="282"/>
        <source>Failed to update initramfs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="308"/>
        <source>System boot disk:</source>
        <translation>सिस्टम बूट डिस्क :</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="327"/>
        <location filename="../bootman.cpp" line="339"/>
        <source>Partition to use:</source>
        <translation>उपयोग हेतु विभाजन :</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="38"/>
        <source>Checking installation media.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="39"/>
        <source>Press ESC to skip.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="56"/>
        <source>The installation media is corrupt.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="112"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>DeviceItem</name>
    <message>
        <location filename="../partman.cpp" line="1880"/>
        <source>EFI System Partition</source>
        <translation>EFI सिस्टम विभाजन</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1881"/>
        <source>swap space</source>
        <translation>स्वैप स्पेस</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1882"/>
        <source>format only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Create</source>
        <translation type="vanished">बनाएँ</translation>
    </message>
    <message>
        <source>Preserve (%1)</source>
        <translation type="vanished">संरक्षण (%1)</translation>
    </message>
</context>
<context>
    <name>DeviceItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2412"/>
        <source>&amp;Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2424"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2420"/>
        <source>Compression (Z&amp;STD)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2422"/>
        <source>Compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="83"/>
        <source>Shutdown</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="138"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>आपके द्वारा 32-बिट ओएस को 64 बिट UEFI मोड में आरंभ किया गया, सिस्टम तब तक आरंभ नहीं होगा जब तक आप पुनः आरंभ पर Legacy Boot या कोई समान विकल्प का चयन नहीं करेंगें।
हम अनुशंसित करते हैं कि आप सिस्टम अभी बंद कर Legacy Boot में पुनः आरंभ करें।
क्या आप इंस्टॉल प्रक्रिया जारी रखें चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="182"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 का समर्थन करें

%1 लिनक्स के समर्थक आप जैसे उपयोक्ता हैं। कुछ चर्चा-मंच %2 पर सहायता कर या विभिन्न भाषाओं में फाइलों का अनुवाद कर या सुझाव प्रदान कर, प्रलेख लेखन द्वारा या नवीन सॉफ्टवेयर का परीक्षण कर इस परियोजना में योगदान करते हैं।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="222"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 : स्थिर डेबियन पर आधारित एक स्वतंत्र लिनक्स वितरण है।

%1 लिनक्स द्वारा अपाचे निःशुल्क लाइसेंस के अंतर्गत प्रकाशित मेपिस लिनक्स के कुछ अनुभाग प्रयुक्त है। कुछ मेपिस अनुभागों को %1 अनुसार परिवर्तित किया गया है।

%1 के उपयोग का आनंद लें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="326"/>
        <source>Pretending to install %1</source>
        <translation>%1 को परिवर्तन रहित इंस्टॉल जारी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="344"/>
        <source>Preparing to install %1</source>
        <translation>%1 इंस्टॉल हेतु तैयारी जारी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="370"/>
        <source>Paused for required operator input</source>
        <translation>उपयोक्ता द्वारा आवश्यक इनपुट की प्रतीक्षा में</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="381"/>
        <source>Setting system configuration</source>
        <translation>सिस्टम विन्यास सेट करना जारी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="392"/>
        <source>Cleaning up</source>
        <translation>अनावश्यक वस्तुएँ हटाना जारी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="396"/>
        <source>Finished</source>
        <translation>पूर्ण हुआ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="420"/>
        <source>The installation was aborted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="517"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>विन्यास फाइल (%1) में अमान्य सेटिंग्स मिली। कृपया प्रक्रिया के दौरान चिन्हित क्षेत्रों पर ध्यान दें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="537"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>क्या %2 हेतु फॉर्मेट कर समूची डिस्क (%1) उपयोग करें?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="541"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>चेतावनी : चयनित ड्राइव की क्षमता कम-से-कम 2टीबी की है व इस हेतु GPT विभाजन विधि आवश्यक है। कुछ सिस्टम पर GPT डिस्क आरंभ नहीं होती है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="570"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>/home का डेटा संचित करना विफल क्योंकि इस हेतु आवश्यक सूचना प्राप्त नहीं हो सकी।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="594"/>
        <source>The home directory for %1 already exists.</source>
        <translation>%1 हेतु होम डायरेक्टरी पहले से मौजूद है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="630"/>
        <source>General Instructions</source>
        <translation>सामान्य दिशानिर्देश</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="631"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>जारी रखने से पहले सभी कार्यरत अनुप्रयोग बंद कर लें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="632"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>प्रत्येक पृष्ठ पर उपलब्ध दिशानिर्देश पढ़ें, इच्छित चयन करें, व प्रक्रिया जारी रखने हेतु अगला पर क्लिक करें। किसी प्रकार का हानिकारक कार्य करने से पूर्व पुष्टिकरण विंडो प्रदर्शित होगी।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="634"/>
        <source>Limitations</source>
        <translation>उपयोग सीमाएँ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="635"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>ध्यान रहें कि यह वारंटी रहित सॉफ्टवेयर अपने वर्तमान वास्तविक स्वरूप आपको प्रदान किया जा रहा है। प्रक्रिया जारी रखने से पहले डेटा बैकअप करना पूर्णतया आपका दायित्व है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="640"/>
        <source>Installation Options</source>
        <translation>इंस्टॉल प्रक्रिया विकल्प</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="641"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>यदि आप मैक ओएस या विंडोज ओएस (विस्टा उपरांत) उपयोग कर रहें हैं तो इंस्टॉल करने से पहले अपने सिस्टम के सॉफ्टवेयर द्वारा विभाजन व बूट प्रबंधक सेट करने की आवश्यकता हो सकती है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="642"/>
        <source>Using the root-home space slider</source>
        <translation>रूट-होम स्पेस परिवर्तन साधन (स्लाइडर) उपयोग होगा</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="643"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="644"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="645"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="646"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>परिवर्तन साधन (स्लाइडर) को दायीं ओर करने से &lt;b&gt;रूट&lt;/b&gt; हेतु स्पेस वर्धन होगा। परिवर्तन साधन (स्लाइडर) को बायीं ओर करने से &lt;b&gt;होम&lt;/b&gt; हेतु स्पेस वर्धन होगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="647"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>परिवर्तन साधन (स्लाइडर) को पूर्णतया दायीं ओर करने से रूट व होम दोनों एक ही विभाजन पर स्थित होंगें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="648"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>होम डायरेक्टरी को अलग विभाजन में रखने से ऑपरेटिंग सिस्टम अपग्रेड की विश्वसनीयता में सुधार होता है। इससे बैकअप व रिकवरी भी सरल होती है। इस कारण ड्राइव के परिभाषित भाग में सिस्टम फ़ाइलों को सीमित करके समग्र प्रदर्शन में भी सुधार संभव है। </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="650"/>
        <location filename="../minstall.cpp" line="724"/>
        <source>Encryption</source>
        <translation>एन्क्रिप्शन</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <location filename="../minstall.cpp" line="725"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>LUKS द्वारा एन्क्रिप्शन संभव है। कूटशब्द आवश्यक।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="652"/>
        <location filename="../minstall.cpp" line="726"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="653"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>स्वतः इंस्टॉल के साथ एन्क्रिप्शन प्रयुक्त होने पर पृथक बूट विभाजन का स्वतः सृजन होगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="654"/>
        <source>Using a custom disk layout</source>
        <translation>अनुकूलित डिस्क अभिन्यास प्रयुक्त होगा</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="655"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>%1 के इंस्टॉल स्थान हेतु अधिक नियंत्रण हेतु &quot;&lt;b&gt;%2&lt;/b&gt;&quot; चयन कर &lt;b&gt;अगला&lt;/b&gt; पर क्लिक करें। फिर अगले पृष्ठ पर आप आवश्यक संचय उपकरणों व विभाजनों का चयन एवं विन्यास कर सकेंगे।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="662"/>
        <source>Choose Partitions</source>
        <translation>विभाजन चयन</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="663"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>विभाजन सूची द्वारा आप इंस्टॉल प्रक्रिया हेतु प्रयुक्त होने वाले विभाजन चुन सकते हैं।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="664"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;उपकरण&lt;/i&gt; - यह बनाए गए विभाजन को आवंटित हुए या होने वाले ब्लॉक उपकरण का नाम है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="665"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;आकार&lt;/i&gt; - विभाजन का आकार। इसे केवल नवीन अभिन्यास पर ही बदलना संभव है। </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="666"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="667"/>
        <source>Format - Format without mounting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>BIOS-GRUB - BIOS Boot GPT partition for GRUB.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="669"/>
        <source>EFI - EFI System Partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="670"/>
        <source>boot - Boot manager (/boot).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="671"/>
        <source>root - System root (/).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="672"/>
        <source>swap - Swap space.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="673"/>
        <source>home - User data (/home).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="674"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="675"/>
        <source>The installer treats &quot;/boot&quot;, &quot;/&quot;, and &quot;/home&quot; exactly the same as &quot;boot&quot;, &quot;root&quot;, and &quot;home&quot;, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="676"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;उपनाम&lt;/i&gt; - फॉर्मेट होने के उपरांत विभाजन को आवंटित उपनाम।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="677"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="678"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;प्रारूप&lt;/i&gt; - यह विभाजन का प्रारूप है। उपलब्ध प्रारूप विभाजन के उपयोग पर निर्भर करता है। मौजूदा अभिन्यास उपयोग करते समय, &lt;b&gt;संरक्षण&lt;/b&gt; का चयन कर विभाजन का प्रारूप संरक्षित करना संभव है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="680"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="682"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="685"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;माउंट विकल्प&lt;/i&gt; - इससे विभाजन हेतु प्रयुक्त माउंट विकल्प निर्दिष्ट होंगें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="686"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="687"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="688"/>
        <source>Menus and actions</source>
        <translation>मेन्यू व कार्य</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="689"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>सूची से ड्राइव या विभाजन पर दायां-क्लिक कर विभिन्न कार्यों हेतु उपलब्ध विकल्प देखना संभव है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="690"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>सूची के दायीं ओर दिए बटन द्वारा प्रविष्टियों में परिवर्तन संभव है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="691"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>ड्राइव पर मौजूद अभिन्यास को इंस्टॉलर द्वारा बदलना संभव नहीं है। अनुकूलित अभिन्यास बनाने हेतु, ड्राइव को नवीन &lt;b&gt;अभिन्यास मेन्यू&lt;/b&gt; कार्य या बटन (%1) से नवीन अभिन्यास हेतु चिन्हित करें। इससे मौजूदा अभिन्यास रिक्त होगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="694"/>
        <source>Basic layout requirements</source>
        <translation>सामान्य अभिन्यास आवश्यकताएँ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 हेतु रूट विभाजन आवश्यक है। स्वैप विभाजन वैकल्पिक है परन्तु अनुशंसित भी। यदि आप %1 की डिस्क-पर-स्थगित सुविधा उपयोग करना चाहते हैं तो स्वैप का आकार वास्तविक मेमोरी से अधिक रखें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="697"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>भावी अपग्रेड प्रक्रिया सरल होगी यदि आप पृथक /home विभाजन का चयन करते हैं, परन्तु यह अपग्रेड ऐसे इंस्टॉल हेतु संभव नहीं होगा जिसका होम विभाजन पृथक नहीं है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="699"/>
        <source>Active partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="700"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="701"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="702"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="703"/>
        <source>Boot partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="704"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="705"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="706"/>
        <source>BIOS-GRUB partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="708"/>
        <source>New drives are formatted in GPT if more than 4 partitions are to be created, or the drive has a capacity greater than 2TB. If the installer is about to format the disk in GPT, and there is no BIOS-GRUB partition, a warning will be displayed before the installation starts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="710"/>
        <source>Need help creating a layout?</source>
        <translation>क्या अभिन्यास बनाने हेतु सहायता की आवश्यकता है?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="745"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>लिनक्स व विंडोज हेतु GRUB इंस्टॉल करें</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="746"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="747"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="748"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="749"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="750"/>
        <source>Create a swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="751"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="752"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="753"/>
        <source>Setting the size to 0 has the same effect as unchecking this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="860"/>
        <source>Enjoy using %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="712"/>
        <source>Upgrading</source>
        <translation>अपग्रेड जारी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="713"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="714"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="716"/>
        <source>Preferred Filesystem Type</source>
        <translation>इच्छित फाइल सिस्टम प्रकार</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="717"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="718"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>btrfs प्रयुक्त ड्राइव हेतु अतिरिक्त संपीड़न विकल्प उपलब्ध हैं। Lzo तीव्र है परन्तु संपीड़न मंद है। Zlib मंद है परन्तु संपीड़न उच्च है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="720"/>
        <source>System partition management tool</source>
        <translation>सिस्टम विभाजन प्रबंधन साधन</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="721"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>ड्राइव अभिन्यास हेतु अधिक नियंत्रण (जैसे डिस्क के मौजूदा अभिन्यास में परिवर्तन) हेतु विभाजन प्रबंधन बटन (%1) पर क्लिक करें। इससे ऑपरेटिंग सिस्टम का विभाजन प्रबंधक साधन निष्पादित होगा जिस द्वारा आप सटीक रूप से इच्छित अभिन्यास बना सकेंगे।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="727"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="729"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="730"/>
        <source>Other partitions</source>
        <translation>अन्य विभाजन</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="731"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>इंस्टॉलर द्वारा अन्य उद्देश्यों हेतु अन्य विभाजनों को बनाना या उपयोग करना संभव है, हालांकि यह ध्यान रहें कि पुराने सिस्टम की ड्राइव पर 4 से अधिक विभाजन बनाना संभव नहीं है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="732"/>
        <source>Subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="733"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="735"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="738"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="739"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="740"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="759"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;सक्रिय सेवाओं का चयन&lt;/b&gt;&lt;br/&gt;इनमें से अपने सिस्टम विन्यास हेतु इच्छित सामान्य सेवाएँ चुनें व %1 आरंभ होने पर चयनित सेवाएँ स्वतः ही आरंभ होंगी।&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="763"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;कंप्यूटर पहचान&lt;/b&gt;&lt;br/&gt;कंप्यूटर नाम एक सामान्य परन्तु विशिष्ट नाम होता है जो नेटवर्क पर आपके कंप्यूटर की पहचान होता है। कंप्यूटर डोमेन संभवतः कभी प्रयुक्त न हो जब तक आपके इंटरनेट प्रदाता या लोकल नेटवर्क हेतु इसकी आवश्यकता हो।&lt;/p&gt;&lt;p&gt;कंप्यूटर व डोमेन नामों में केवल अक्षरांक, बिंदु व हायफ़न ही स्वीकार्य हैं। रिक्त अक्षर व आरंभ या अंत में हायफ़न स्वीकार्य नहीं हैं।&lt;/p&gt;&lt;p&gt;साम्बा सर्वर द्वारा एमएस-विंडोज या मैक ओएस-एक्स कार्यरत अपने लोकल कंप्यूटर के साथ डायरेक्टरी फोल्डर या प्रिंटर सहभाजन करने हेतु साम्बा सर्वर सक्रिय करना आवश्यक है।&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="773"/>
        <source>Localization Defaults</source>
        <translation>स्थानिकी डिफ़ॉल्ट</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="774"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>डिफ़ॉल्ट स्थानिकी सेट करें। यह बाद में उपयोक्ता द्वारा अधिलेखित करने तक लागू रहेगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="775"/>
        <source>Configure Clock</source>
        <translation>घड़ी विन्यास</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="776"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>यदि आपका कंप्यूटर एप्पल या यूनिक्स कंप्यूटर है, तो डिफ़ॉल्ट रूप से सिस्टम घड़ी ग्रीनिच माध्य समय (जीएमटी) या समन्वित सार्वत्रिक समय (यूटीसी) पर सेट है। इसे बदलने हेतु &quot;&lt;b&gt;सिस्टम घड़ी द्वारा स्थानीय समय प्रयुक्त&lt;/b&gt;&quot; का विकल्प चिन्हित करें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="778"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>सिस्टम डिफ़ॉल्ट रूप से जीएमटी/यूटीसी अनुसार समय क्षेत्र के साथ बूट करता है। समय क्षेत्र परिवर्तन हेतु, नवीन इंस्टॉल में पुनः आरंभ उपरांत पैनल में घड़ी पर दायां-क्लिक कर विशेषताएँ चुनें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="780"/>
        <source>Service Settings</source>
        <translation>सेवा सेटिंग्स</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="781"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>अधिकांश उपयोक्ताओं को डिफ़ॉल्ट में परिवर्तन नहीं करना चाहिए। सीमित संसाधन वाले कंप्यूटर के उपयोक्ता कभी-कभी RAM उपयोग को यथासंभव कम रखने हेतु अनावश्यक सेवाओं को निष्क्रिय कर सकते हैं। सुनिश्चित करें कि आप कार्य से भलीभाँति परिचित हैं!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="787"/>
        <source>Default User Login</source>
        <translation>डिफ़ॉल्ट उपयोक्ता लॉगिन</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="788"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>कई अन्य ऑपरेटिंग सिस्टम में रूट उपयोक्ता प्रशासक उपयोक्ता के समान होता है। रूट उपयोक्ता को अपने दैनिक उपयोक्ता अकाउंट के रूप उपयोग न करें। कृपया दैनिक उपयोग के लिए अपने नवीन (डिफ़ॉल्ट) उपयोक्ता अकाउंट हेतु नाम दर्ज करें। आप बाद में आवश्यकता अनुसार %1 उपयोक्ता प्रबंधक उपयोग कर अन्य उपयोक्ता अकाउंट जोड़ सकते हैं।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="792"/>
        <source>Passwords</source>
        <translation>कूटशब्द</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="793"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>अपने डिफ़ॉल्ट उपयोक्ता अकाउंट व रूट अकाउंट हेतु नवीन कूटशब्द दर्ज करें। प्रत्येक कूटशब्द दो बार दर्ज करें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="795"/>
        <source>No passwords</source>
        <translation>कोई कूटशब्द नहीं</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="796"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>डिफ़ॉल्ट उपयोक्ता अकाउंट को कूटशब्द रहित रखने हेतु कूटशब्द क्षेत्र को रिक्त रखें। इससे आप बिना कूटशब्द के लॉगिन कर सकेंगे।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="798"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>स्वाभाविक रूप से ऐसा केवल ऐसी परिस्थिति में करना चाहिए जहाँ उपयोक्ता अकाउंट की सुरक्षा अनावश्यक है, जैसे कोई सार्वजानिक टर्मिनल।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="806"/>
        <source>Old Home Directory</source>
        <translation>पुरानी होम डायरेक्टरी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="807"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>चयनित उपयोक्ता नाम की होम डायरेक्टरी पहले से मौजूद है। इस स्क्रीन द्वारा आप इस डायरेक्टरी में होने वाले कार्य चुन सकते हैं।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="809"/>
        <source>Re-use it for this installation</source>
        <translation>इस इंस्टॉल हेतु पुनः उपयोग करें</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="810"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>इस उपयोक्ता अकाउंट हेतु पुरानी होम डायरेक्टरी प्रयुक्त होगी। अपग्रेड हेतु यह एक उचित विकल्प है व इससे आपकी फाइलों व सेटिंग्स की उपलब्धता भी सुनिश्चित रहेगी। </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="812"/>
        <source>Rename it and create a new directory</source>
        <translation>उसका नाम परिवर्तन कर एक नवीन डायरेक्टरी बनाएँ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="813"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>इस उपयोक्ता हेतु एक नवीन होम डायरेक्टरी का सृजन होगा परन्तु पुरानी होम डायरेक्टरी का नाम परिवर्तन होगा। आपकी फाइलों व सेटिंग्स तुरंत प्रभाव से उपलब्ध नहीं होंगी परन्तु वे परिवर्तित नाम वाली डायरेक्टरी में उपलब्ध होंगी।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="815"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>नाम परिवर्तन आवृत्ति की संख्या अनुसार पुरानी डायरेक्टरी के नाम के अंत में एक संख्या संलग्न होगी।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="816"/>
        <source>Delete it and create a new directory</source>
        <translation>उसे हटाकर कर एक नवीन डायरेक्टरी बनाएँ</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>पुरानी होम डायरेक्टरी हटा दी जाएगी एवं एक नई का सृजन होगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Warning</source>
        <translation>चेतावनी</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="819"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>यह विकल्प चयनित होने पर सभी फाइलों व सेटिंग्स को स्थायी रूप से हटा दिया जाएगा। व उन्हें पुनः प्राप्त करने की संभावना भी कम होगी।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>Installation in Progress</source>
        <translation>इंस्टॉल प्रक्रिया जारी है</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="836"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 का इंस्टॉल जारी है। आपके सिस्टम की गति व पुनः फॉर्मेट होने वाले विभाजनों के आकार के आधार पर एक नवीन इंस्टॉल हेतु सामान्यतः 3-20 मिनट का समय लगता है।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="838"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>निरस्त का बटन क्लिक करने के उपरांत शीघ्रतम समय में इंस्टॉल प्रक्रिया बंद की जाएगी।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="840"/>
        <source>Change settings while you wait</source>
        <translation>प्रतीक्षा अवधि का उपयोग सेटिंग्स परिवर्तन कर करें</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="841"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>%1 के इंस्टॉल होने तक आप &lt;b&gt;अगला&lt;/b&gt; या &lt;b&gt;पिछला&lt;/b&gt; बटन पर क्लिक कर इंस्टॉल प्रक्रिया हेतु आवश्यक अन्य सूचना दर्ज कर सकते हैं।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="843"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>इन चरणों को अपने अनुसार पूरा करें। आप द्वारा इनपुट आवश्यक होने पर इंस्टॉलर प्रतीक्षा करेगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="851"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;शुभकामनाएँ!&lt;/b&gt;&lt;br/&gt;आप द्वारा %1 का इंस्टॉल पूर्ण किया गया&lt;/p&gt;&lt;p&gt;&lt;b&gt;अनुप्रयोग खोज&lt;/b&gt;&lt;br/&gt; %1 में सैंकड़ों उत्कृष्ट अनुप्रयोग इंस्टॉल हैं। उनके बारे में जानने हेतु मेन्यू द्वारा उन्हें देखें व उपयोग करें। इनमें से कई अनुप्रयोग विशिष्ट रूप से %1 परियोजना हेतु विकसित किए गए हैं। ये मुख्य मेन्यू में प्रदर्शित हैं। &lt;p&gt;इसके अतिरिक्त %1 में कई मानक लिनक्स अनुप्रयोग सम्मिलित हैं जिनका निष्पादन केवल कमांड लाइन से संभव है, अतः ये मेन्यू में प्रदर्शित नहीं होते हैं।&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="861"/>
        <location filename="../minstall.cpp" line="1117"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;%1 का समर्थन करें&lt;/b&gt;&lt;br/&gt; %1 लिनक्स के समर्थक आप जैसे उपयोक्ता हैं। कुछ चर्चा-मंच %2 पर सहायता कर या विभिन्न भाषाओं में फाइलों का अनुवाद कर या सुझाव प्रदान कर, प्रलेख लेखन द्वारा या नवीन सॉफ्टवेयर का परीक्षण कर इस परियोजना में योगदान करते हैं।&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="891"/>
        <source>Finish</source>
        <translation>पूर्ण</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="894"/>
        <source>OK</source>
        <translation>ठीक है</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="896"/>
        <source>Next</source>
        <translation>अगला</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="408"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>सिस्टम विन्यास जारी। कृपया प्रतीक्षा करें।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="415"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>विन्यास प्रक्रिया पूर्ण। अब सिस्टम पुनः आरंभ होगा।</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1049"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>इंस्टॉल व विन्यास अभी पूर्ण नहीं हुई है।
क्या आप निश्चित ही अभी स्थगित करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1103"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;सहायता प्राप्ति&lt;/b&gt;&lt;br/&gt;%1 हेतु सामान्य सूचना %2 पर उपलब्ध है।&lt;/p&gt;&lt;p&gt; %3 चर्चा-मंच पर सहायता हेतु स्वयंसेवक %4 पर मौजूद हैं।&lt;/p&gt;&lt;p&gt;सहायता हेतु प्रश्न करते समय कृपया अपनी समस्या व अपने कंप्यूटर का विस्तार से वर्णन करें। आमतौर पर &apos;यह अनुप्रयोग उचित रूप से कार्य नहीं कर रहा है&apos; जैसे वाक्य समस्या निवारण हेतु सहायक नहीं होते हैं।&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1111"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;इंस्टॉल हेतु सुधार करना&lt;/b&gt;&lt;br/&gt;हार्ड ड्राइव से %1 कार्यरत करना विफल होने पर सामान्यतः लाइव डीवीडी या लाइव यूएसबी से %1 में सम्मिलित सिस्टम विन्यास के साधन निष्पादित कर या सिस्टम निवारण हेतु सामान्य लिनक्स साधन उपयोग कर यह समस्या हल करना संभव है।&lt;/p&gt;&lt;p&gt;%1 लाइव डीवीडी या लाइव यूएसबी उपयोग कर अपने एमएस-विंडो सिस्टम से भी डेटा की पुनः प्राप्ति संभव है!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1125"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;ध्वनि मिक्सर सेट करना&lt;/b&gt;&lt;br/&gt;%1 आप हेतु ध्वनि मिक्सर विन्यस्त करने के लिए प्रयासरत है परंतु कभी-कभी ध्वनि श्रवण करने हेतु आपको मिक्सर द्वारा ध्वनि वर्धन व चैनलों की ध्वनि बंद करने की आवश्यकता हो सकती है।&lt;/p&gt; &lt;p&gt;मिक्सर का शॉर्टकट मेन्यू में ही स्थित है। मिक्सर खोलने हेतु उस पर क्लिक करें।&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1133"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;अपने %1 को नवीनतम रखना&lt;/b&gt;&lt;br/&gt;कृपया सूचना व अपडेट हेतु देखें &lt;/p&gt;&lt;p&gt;%2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1138"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;विशिष्ट आभार&lt;/b&gt;&lt;br/&gt;उन सभी का धन्यवाद जिन्होंने अपने समय, धन राशि, सुझावों, कार्यों, प्रशंसा, विचारों, प्रचार व/या प्रोत्साहन के रूप में %1 का समर्थन किया।&lt;/p&gt;&lt;p&gt;आपके सहयोग के बिना %1 का अस्तित्व संभव नहीं था।&lt;/p&gt;&lt;p&gt;%2 सॉफ्टवेयर विकासकर्ता टीम&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MPassEdit</name>
    <message>
        <source>Use password</source>
        <translation type="vanished">कूटशब्द प्रयुक्त करें</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="43"/>
        <source>Help</source>
        <translation>सहायता</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="69"/>
        <source>Live Log</source>
        <translation>लाइव लॉग</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="195"/>
        <source>Close</source>
        <translation>बंद करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="121"/>
        <source>Next</source>
        <translation>अगला</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="128"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="212"/>
        <source>Gathering Information, please stand by.</source>
        <translation>सूचना एकत्र करना जारी, कृपया प्रतीक्षा करें।</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="244"/>
        <source>Terms of Use</source>
        <translation>उपयोग की शर्तें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="332"/>
        <source>Change Keyboard Settings</source>
        <translation>कुंजीपटल सेटिंग्स बदलें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <source>Select type of installation</source>
        <translation>इंस्टॉल प्रकार चुनें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="422"/>
        <source>Regular install using the entire disk</source>
        <translation>पूर्ण डिस्क उपयोग कर सामान्य इंस्टॉल</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <source>Customize the disk layout</source>
        <translation>डिस्क अभिन्यास अनुकूलित करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="448"/>
        <source>Use disk:</source>
        <translation>उपयोग हेतु डिस्क :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="602"/>
        <source>Encrypt</source>
        <translation>एन्क्रिप्ट करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="614"/>
        <location filename="../meinstall.ui" line="817"/>
        <source>Encryption password:</source>
        <translation>एन्क्रिप्शन कूटशब्द :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="631"/>
        <location filename="../meinstall.ui" line="834"/>
        <source>Confirm password:</source>
        <translation>कूटशब्द पुष्टिकरण :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="482"/>
        <source>Root</source>
        <translation>रूट</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="276"/>
        <source>Keyboard Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="291"/>
        <source>Model:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="306"/>
        <source>Variant:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="344"/>
        <source>Layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="492"/>
        <source>Home</source>
        <translation>होम</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="567"/>
        <location filename="../meinstall.ui" line="589"/>
        <source>%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="651"/>
        <location filename="../meinstall.ui" line="1092"/>
        <source>Enable hibernation support</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="689"/>
        <source>Choose partitions</source>
        <translation>विभाजन चयन</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="729"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>ऑपरेटिंग सिस्टम जाँचकर सभी ड्राइव के अभिन्यास पुनः लोड करें।</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="762"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>अभिन्यास से मौजूदा प्रविष्टि हटाएँ। यह केवल नवीन अभिन्यास के प्रविष्टियों हेतु संभव है।</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="751"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>नवीन विभाजन प्रविष्टि जोड़ें। यह केवल नवीन अभिन्यास हेतु संभव है।</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="698"/>
        <source>Show Grid</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Ctrl+G</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>नवीन अभिन्यास हेतु चयनित ड्राइव को रिक्त करना चिन्हित करें।</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="740"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>इस ऑपरेटिंग सिस्टम का विभाजन प्रबंधन अनुप्रयोग निष्पादित करें।</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="811"/>
        <source>Encryption options</source>
        <translation>एन्क्रिप्शन विकल्प</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="870"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>लिनक्स व विंडोज हेतु GRUB इंस्टॉल करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="894"/>
        <source>Master Boot Record</source>
        <translation>मास्टर बूट रिकॉर्ड</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="900"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="903"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="925"/>
        <source>EFI System Partition</source>
        <translation>EFI सिस्टम विभाजन</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="928"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="960"/>
        <source>Partition Boot Record</source>
        <translation>विभाजन बूट रिकॉर्ड</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="963"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="976"/>
        <source>System boot disk:</source>
        <translation>सिस्टम बूट डिस्क :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="989"/>
        <source>Location to install on:</source>
        <translation>इंस्टॉल हेतु स्थान :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1025"/>
        <source>Create a swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1042"/>
        <source> MB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1062"/>
        <source>Size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1085"/>
        <source>Location:</source>
        <translation>स्थान :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1124"/>
        <source>Common Services to Enable</source>
        <translation>सक्रिय सेवाओं का चयन</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1143"/>
        <source>Service</source>
        <translation>सेवा</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1148"/>
        <source>Description</source>
        <translation>विवरण</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1181"/>
        <source>Computer Network Names</source>
        <translation>कंप्यूटर नेटवर्क नाम</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1208"/>
        <source>Workgroup</source>
        <translation>कार्यसमूह</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1221"/>
        <source>Workgroup:</source>
        <translation>कार्यसमूह :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1234"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>एमएस-नेटवर्क हेतु साम्बा सर्वर</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>example.dom</source>
        <translation>example.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1263"/>
        <source>Computer domain:</source>
        <translation>कंप्यूटर डोमेन :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1289"/>
        <source>Computer name:</source>
        <translation>कंप्यूटर नाम :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1350"/>
        <source>Configure Clock</source>
        <translation>घड़ी विन्यास</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1391"/>
        <source>Format:</source>
        <translation>प्रारूप :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1419"/>
        <source>Timezone:</source>
        <translation>समय क्षेत्र :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1464"/>
        <source>System clock uses local time</source>
        <translation>सिस्टम घड़ी द्वारा स्थानीय समय प्रयुक्त होगा</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1496"/>
        <source>Localization Defaults</source>
        <translation>स्थानिकी डिफ़ॉल्ट</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1536"/>
        <source>Locale:</source>
        <translation>स्थानिकी :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1558"/>
        <source>Service Settings (advanced)</source>
        <translation>सेवा सेटिंग्स (विस्तृत)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1576"/>
        <source>Adjust which services should run at startup</source>
        <translation>सिस्टम आरंभ पर निष्पादन हेतु सेवाओं का चयन</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1579"/>
        <source>View</source>
        <translation>देखें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1624"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>लाइव वातावरण में किए गए डेस्कटॉप परिवर्तन इंस्टॉल होने वाले ओएस में सम्मिलित होंगें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1627"/>
        <source>Save live desktop changes</source>
        <translation>लाइव डेस्कटॉप परिवर्तन संचित करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1640"/>
        <source>Default User Account</source>
        <translation>डिफ़ॉल्ट उपयोक्ता अकाउंट</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1652"/>
        <source>Default user login name:</source>
        <translation>डिफ़ॉल्ट उपयोक्ता लॉगिन नाम :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1684"/>
        <source>Default user password:</source>
        <translation>डिफ़ॉल्ट उपयोक्ता कूटशब्द :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1713"/>
        <source>Confirm user password:</source>
        <translation>उपयोक्ता कूटशब्द पुष्टिकरण :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1671"/>
        <source>username</source>
        <translation>उपयोक्ता नाम</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1745"/>
        <source>Root (administrator) Account</source>
        <translation>रूट (प्रशासक) अकाउंट</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1763"/>
        <source>Root password:</source>
        <translation>रूट कूटशब्द :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1792"/>
        <source>Confirm root password:</source>
        <translation>रूट कूटशब्द पुष्टिकरण :</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1824"/>
        <source>Autologin</source>
        <translation>स्वतः लॉगिन</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>Existing Home Directory</source>
        <translation>मौजूदा होम डायरेक्टरी</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1869"/>
        <source>What would you like to do with the old directory?</source>
        <translation>आप पुरानी डायरेक्टरी हेतु क्या कार्य करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1876"/>
        <source>Re-use it for this installation</source>
        <translation>इस इंस्टॉल हेतु पुनः उपयोग करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1883"/>
        <source>Rename it and create a new directory</source>
        <translation>उसका नाम परिवर्तन कर एक नवीन डायरेक्टरी बनाएँ</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1890"/>
        <source>Delete it and create a new directory</source>
        <translation>उसे हटाकर कर एक नवीन डायरेक्टरी बनाएँ</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Tips</source>
        <translation>सहायक निर्देश</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1979"/>
        <source>Installation complete</source>
        <translation>इंस्टॉल प्रक्रिया पूर्ण</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1985"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>इंस्टॉलर बंद होने पर सिस्टम को स्वतः ही पुनः आरंभ करें</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2004"/>
        <source>Reminders</source>
        <translation>अनुस्मारक</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="107"/>
        <source>Back</source>
        <translation>पीछे</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="114"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Installation in progress</source>
        <translation>इंस्टॉल प्रक्रिया जारी है</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="172"/>
        <source>Abort</source>
        <translation>निरस्त</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="175"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="325"/>
        <source>Please enter a computer name.</source>
        <translation>कृपया कंप्यूटर नाम दर्ज करें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="329"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>क्षमा करें, आपके कंप्यूटर नाम में अमान्य अक्षर हैं।
कृपया प्रक्रिया जारी
रखने से पहले एक उचित नाम चुनें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="334"/>
        <source>Please enter a domain name.</source>
        <translation>कृपया डोमेन नाम दर्ज करें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="338"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>क्षमा करें, आपके कंप्यूटर डोमेन में अमान्य अक्षर हैं।
कृपया प्रक्रिया जारी
रखने से पहले एक उचित नाम चुनें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="345"/>
        <source>Please enter a workgroup.</source>
        <translation>कृपया कार्यसमूह दर्ज करें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="485"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>उपयोक्ता नाम में कोई विशिष्ट या रिक्त अक्षर न हो।
कृपया प्रक्रिया जारी रखने से पहले एक उचित नाम चुनें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="496"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>क्षमा करें, यह नाम पहले से प्रयुक्त है।
कृपया कोई भिन्न नाम चुनें।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="505"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>आपने रूट अकाउंट हेतु कोई कूटशब्द प्रदान नहीं किया है। क्या आप जारी रखना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="534"/>
        <source>Failed to set user account passwords.</source>
        <translation>उपयोक्ता अकाउंट हेतु कूटशब्द सेट करना विफल।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="553"/>
        <source>Failed to save old home directory.</source>
        <translation>पुरानी होम डायरेक्टरी संचित करना विफल।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="557"/>
        <source>Failed to delete old home directory.</source>
        <translation>पुरानी होम डायरेक्टरी हटाना विफल।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="578"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>क्षमा करें, उपयोक्ता डायरेक्टरी बनाना विफल।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="582"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>क्षमा करें, उपयोक्ता डायरेक्टरी नामांकन विफल।</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="624"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="228"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="453"/>
        <location filename="../partman.cpp" line="507"/>
        <source>&amp;Add partition</source>
        <translation>विभाजन जोड़ें (&amp;A)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="455"/>
        <source>&amp;Remove partition</source>
        <translation>विभाजन हटाएँ (&amp;R)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="465"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="474"/>
        <location filename="../partman.cpp" line="607"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="480"/>
        <source>Active partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="486"/>
        <source>New subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="487"/>
        <source>Scan subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="510"/>
        <source>New &amp;layout</source>
        <translation>नवीन अभिन्यास (&amp;l)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="511"/>
        <source>&amp;Reset layout</source>
        <translation>अभिन्यास पुनः सेट करें (&amp;R)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="534"/>
        <source>Remove subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="604"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="610"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="611"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="640"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="669"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="713"/>
        <source>Invalid subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="724"/>
        <source>Duplicate subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="733"/>
        <source>Invalid use for %1: %2</source>
        <translation>%1 का अमान्य उपयोग : %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="744"/>
        <source>%1 is already selected for: %2</source>
        <translation>इस हेतु %1 पहले से चयनित है : %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="771"/>
        <source>A root partition of at least %1 is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="779"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>रूट (/) में /home को संरक्षित करना संभव नहीं है यदि एक पृथक /home विभाजन भी माउंट है।</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="775"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>रूट का एन्क्रिप्शन करते समय एक पृथक बूट विभाजन का चयन आवश्यक है।</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="793"/>
        <source>Prepare %1 partition table on %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="807"/>
        <source>Format %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="808"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>%1 का %2 के रूप में पुनःउपयोग करें (पुनः फॉर्मेट नहीं)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="809"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="812"/>
        <source>Create %1 without formatting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="813"/>
        <source>Create %1, format to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="868"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="870"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="864"/>
        <location filename="../partman.cpp" line="871"/>
        <source>Are you sure you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="513"/>
        <source>Layout &amp;Builder...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="787"/>
        <source>%1 (%2) requires %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="804"/>
        <source>Reuse (no reformat) %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="825"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="827"/>
        <source>Delete subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="830"/>
        <source>Overwrite subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="831"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="833"/>
        <source>Create subvolume %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="834"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="861"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="875"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="876"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>ये कार्य पूर्ववत करना संभव नहीं है। क्या आप निश्चित ही जारी रखना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="923"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>आपके द्वारा इंस्टॉल हेतु चयनित विभाजनों युक्त विकृत डिस्क :</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="927"/>
        <source>Smartmon tool output:</source>
        <translation>Smartmon साधन आउटपुट :</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="928"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>आप द्वारा इंस्टॉल हेतु चयनित विभाजन युक्त डिस्क की SMART निरीक्षण जाँच (smartctl) सफल रही, परन्तु परिणामों के अनुसार इसकी विफलता दर औसत से अधिक रहने की संभावना है।</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="933"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>अनिश्चित होने के स्थिति में, इंस्टॉलर को बंद कर अधिक सूचना हेतु GSmartControl निष्पादित करें।</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="935"/>
        <source>Do you want to abort the installation?</source>
        <translation>क्या आप इंस्टॉल प्रक्रिया निरस्त करना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="940"/>
        <source>Do you want to continue?</source>
        <translation>क्या आप जारी रखना चाहते हैं?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="955"/>
        <source>Failed to format LUKS container.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="964"/>
        <source>Failed to open LUKS container.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1034"/>
        <source>Failed to finalize encryption setup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1041"/>
        <source>Failed to prepare required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1072"/>
        <source>Preparing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1088"/>
        <source>Preparing required partitions</source>
        <translation>आवश्यक विभाजन तैयार करना जारी</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1154"/>
        <source>Creating encrypted volume: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1159"/>
        <source>Formatting: %1</source>
        <translation>फॉर्मेट करना जारी : %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1162"/>
        <source>Failed to format partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1221"/>
        <source>Failed to prepare subvolumes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1222"/>
        <source>Preparing subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1392"/>
        <source>Failed to mount partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1397"/>
        <source>Mounting: %1</source>
        <translation>माउंट करना जारी : %1</translation>
    </message>
    <message>
        <source>Device</source>
        <translation type="vanished">उपकरण</translation>
    </message>
    <message>
        <source>Size</source>
        <translation type="vanished">आकार</translation>
    </message>
    <message>
        <source>Use For</source>
        <translation type="vanished">उपयोग उद्देश्य</translation>
    </message>
    <message>
        <source>Label</source>
        <translation type="vanished">उपनाम</translation>
    </message>
    <message>
        <source>Encrypt</source>
        <translation type="vanished">एन्क्रिप्ट करें</translation>
    </message>
    <message>
        <source>Format</source>
        <translation type="vanished">प्रारूप</translation>
    </message>
    <message>
        <source>Options</source>
        <translation type="vanished">विकल्प</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="100"/>
        <source>Use password</source>
        <translation type="unfinished">कूटशब्द प्रयुक्त करें</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="134"/>
        <source>Negligible</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="134"/>
        <source>Very weak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="134"/>
        <source>Weak</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="135"/>
        <source>Moderate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="135"/>
        <source>Strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="135"/>
        <source>Very strong</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="137"/>
        <source>Password strength: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="170"/>
        <source>Hide the password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="170"/>
        <source>Show the password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="87"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>एमएक्स लिनक्स व एंटी-एक्स लिनक्स हेतु अनुकूलन युक्त ग्राफिकल अंतरफलक इंस्टॉलर</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="90"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>विन्यास फाइल प्रयुक्त कर स्वतः इंस्टॉल (अधिक सूचना नीचे प्रदर्शित है)।
-- चेतावनी : संभवतः हानिकारक विकल्प, इससे सभी विभाजन स्वतः ही पूर्ण रूप से हट जाएँगे।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="92"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>विभाजनों व ड्राइव हेतु उपयुक्तता जाँच को अधिलेखित कर उन्हें प्रदर्शित करता है।
-- चेतावनी : इससे सिस्टम हानि संभव है, इसे केवल तभी उपयोग करें जब आपके अनुसार ड्राइव डेटा का महत्त्व शून्य है।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="94"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>&lt;config-file&gt; द्वारा निर्दिष्ट विन्यास फाइल लोड करें।
डिफ़ॉल्ट रूप से /etc/minstall.conf प्रयुक्त होगी।
इस विन्यास का उपयोग एक स्वछंद इंस्टॉल हेतु --auto के साथ करना संभव है।
इंस्टॉलर /mnt/antiX/etc/minstall.conf सृजन (या इसे अधिलेखित) कर भविष्य में उपयोग हेतु एक प्रतिलिपि /etc/minstalled.conf पर संचित करता है।
नवीन विन्यास फाइल में इंस्टॉलर द्वारा कोई कूटशब्द या अनदेखी की गई सेटिंग्स सम्मिलित नहीं होंगी।
कृपया ध्यान दें, यह प्रायोगिक है। भावी इंस्टॉलर संस्करणों द्वारा मौजूदा विन्यास फाइलों की संगतता का क्षय होना संभव है।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="100"/>
        <source>Shutdowns automatically when done installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="101"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation>संचय क्षमता की अनदेखी करते हुए सदैव सम्पूर्ण-ड्राइव इंस्टॉल हेतु GPT ही उपयोग करें।
इस विकल्प के बिना GPT का उपयोग केवल कम-से-कम 2 टीबी की ड्राइव पर ही संभव है।
इस विकल्प के बिना भी संचय क्षमता की अनदेखी करते हुए UEFI सिस्टम पर सदैव सम्पूर्ण-ड्राइव इंस्टॉल हेतु का GPT ही उपयोग होता है।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="104"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="105"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation>इंस्टॉलर हेतु एक अन्य जाँच मोड, विभाजन/ड्राइव फॉर्मेट होंगी, फाइलें कॉपी नहीं होगीं। </translation>
    </message>
    <message>
        <location filename="../app.cpp" line="106"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>ऑपरेटिंग सिस्टम इंस्टॉल कर, सिस्टम पुनः आरंभ होने तक उपयोक्ता-विशिष्ट विकल्पों की सूचना विंडो लंबित करें।
पुनः आरंभ उपरांत इंस्टॉलर --oobe के साथ निष्पादित होगा ताकि उपयोक्ता सूचना दर्ज कर सके।
यह मूल उपकरण निर्माता (ओईएम) इंस्टॉल हेतु उपयोगी है, ऐसे कंप्यूटर जिनका विक्रय ऑपरेटिंग सिस्टम सहित होता है।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="109"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>असंशोधित वास्तविक स्वरूप के अनुभव हेतु विकल्प।
--oem विकल्प के साथ इंस्टॉल होने पर यह स्वतः ही आरंभ होगा।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="111"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>ग्राफिकल अंतरफलक हेतु जाँच मोड, आप बिना वास्तव में इंस्टॉल करें विभिन्न स्क्रीन देख सकते हैं।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="112"/>
        <source>Reboots automatically when done installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>अनुकूलित विभाजन हेतु cp के स्थान पर rsync के साथ इंस्टॉल करना जारी है।
-- /root फॉर्मेट नहीं होगा व यह एन्क्रिप्शन हेतु संगत नहीं है।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="115"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>&lt;config-file&gt; द्वारा निर्दिष्ट विन्यास फाइल लोड करें।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="119"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="124"/>
        <source>%1 Installer</source>
        <translation>%1 इंस्टॉलर</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>इंस्टॉलर आरंभ विफल क्योंकि प्रतीत होता है कि वह पहले से ही बैकग्राउंड में कार्यरत है।

संभव हो तो उसे बंद करें अन्यथा टर्मिनल में &apos;pkill minstall&apos; कमांड निष्पादित करें।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="139"/>
        <source>This operation requires root access.</source>
        <translation>इस कार्य हेतु रूट अभिगम आवश्यक है।</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="160"/>
        <source>Configuration file (%1) not found.</source>
        <translation>विन्यास फाइल (%1) नहीं मिली।</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="67"/>
        <source>Failed to create or install swap file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="74"/>
        <source>Creating swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="86"/>
        <source>Configuring swap file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="128"/>
        <source>Invalid location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="131"/>
        <source>Maximum: %1 MB</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
