<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="fi">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Home</source>
        <translation>Koti</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="175"/>
        <source>The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>Valitun aseman kapasiteetti on oltava vähintään 2 Tt ja se alustetaan GPT:llä. Joissakin järjestelmissä GPT-formatoitu levy ei käynnisty.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="177"/>
        <source>Are you sure you want to continue?</source>
        <translation>Haluatko varmasti jatkaa?</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="183"/>
        <source>The system and home drives cannot be the same for this type of installation.</source>
        <translation>Järjestelmä- ja kotiasema ei voi olla sama tällaisessa asennuksessa.</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="187"/>
        <source>Format and use drives entirely for %1</source>
        <translation>Alusta ja käytä levyjä kokonaan kohteelle %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="189"/>
        <source>System drive: %1</source>
        <translation>Järjestelmäasema: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="191"/>
        <source>Home drive: %1</source>
        <translation>Kotiasema: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="194"/>
        <source>Format and use the entire drive for %1: %2</source>
        <translation>Alusta ja käytä koko levyä kohteelle %1: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="224"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>Suositus: %1
Minimi: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="226"/>
        <source>Minimum for hibernation support: %1</source>
        <translation>Lepotilan minimimäärä: %1</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="268"/>
        <source>Layout Builder</source>
        <translation>Layout Builder</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="468"/>
        <source>%1% root
%2% home</source>
        <translation>%1% root
%2% home</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="470"/>
        <source>Combined root and home</source>
        <translation>Yhdistetty juuri- sekä kotihakemisto</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="90"/>
        <source>Cannot access installation media.</source>
        <translation>Asennusmediaa ei voi käyttää.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="261"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Vanhan järjestelmän poistaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="264"/>
        <source>Deleting old system</source>
        <translation>Poistetaan vanhaa järjestelmää</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="288"/>
        <source>Failed to set the system configuration.</source>
        <translation>Järjestelmän asetusten määritys epäonnistui.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="290"/>
        <source>Setting system configuration</source>
        <translation>Asetetaan järjestelmän kokoonpano</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="452"/>
        <source>Copying new system</source>
        <translation>Kopioidaan uutta järjestelmää</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="624"/>
        <source>Failed to copy the new system.</source>
        <translation>Uuden järjestelmän kopioiminen epäonnistui.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="133"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>GRUB:in asennus epäonnistui. Voit uudelleenkäynnistää live-tilaan ja käyttää GRUB Rescue valikkoa korjataksesi asennuksen.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="207"/>
        <source>Installing GRUB</source>
        <translation>Asennetaan GRUB</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="470"/>
        <source>Updating initramfs</source>
        <translation>Päivitetään initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="471"/>
        <source>Failed to update initramfs.</source>
        <translation>Initramfs:n päivitys epäonnistui.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="529"/>
        <source>System boot disk:</source>
        <translation>Järjestelmän käynnistyslevy:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="544"/>
        <location filename="../bootman.cpp" line="554"/>
        <source>Partition to use:</source>
        <translation>Osio jota käytetään:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="67"/>
        <source>The installation media is corrupt.</source>
        <translation>Asennusmedia on viallinen.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="76"/>
        <source>The installation media is still being checked.</source>
        <translation>Asennusmediaa tarkistetaan edelleen.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="77"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>Haluatko ohittaa asennusmedian tarkistamisen?</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="233"/>
        <source>Checking installation media.</source>
        <translation>Tarkistetaan asennusmediaa.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="234"/>
        <source>Press ESC to skip.</source>
        <translation>Ohita painamalla ESC.</translation>
    </message>
</context>
<context>
    <name>Crypto</name>
    <message>
        <location filename="../crypto.cpp" line="63"/>
        <source>Failed to format LUKS container.</source>
        <translation>LUKS-kontin alustaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="67"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Luodaan salattua levyä: %1</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="72"/>
        <source>Failed to open LUKS container.</source>
        <translation>LUKS-kontin avaaminen epäonnistui.</translation>
    </message>
</context>
<context>
    <name>Device</name>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Overwrite</source>
        <translation>Korvaa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Create</source>
        <translation>Luo</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2367"/>
        <source>Delete</source>
        <translation>Poista</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2371"/>
        <source>Preserve</source>
        <translation>Säilytä</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2372"/>
        <source>Preserve (%1)</source>
        <translation>Säilytä (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2373"/>
        <source>Preserve /home (%1)</source>
        <translation>Säilytä /home (%1)</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="484"/>
        <source>Unknown release</source>
        <translation>Tuntematon julkaisu</translation>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="149"/>
        <source>Shutdown</source>
        <translation>Sammuta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="442"/>
        <source>You are running 32-bit OS started in 64-bit UEFI mode.</source>
        <translation>Käytät 32bit käyttöjärjestelmää, joka on käynnistetty 64bit UEFI-moodissa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="443"/>
        <source>The system will not be able to boot unless you restart the system in Legacy Boot (or similar mode) before proceeding.</source>
        <translation>Tietokone ei voi käynnistyä, ellet käynnistä sitä uudelleen Legacy Boot -tilassa (tai vastaavassa) ennen jatkamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="445"/>
        <source>Do you want to continue the installation?</source>
        <translation>Haluatko jatkaa asennusta?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="487"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>Asennusohjelma %1 suorittaa nyt pyydetyt toiminnot.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="488"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Näitä toimenpiteitä ei voida kumota. Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="500"/>
        <source>Support %1</source>
        <translation>Tuettu %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="501"/>
        <source>%1 is supported by people like you. Some help others at the support forum, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>%1 on sinun kaltaisten ihmisten tukena. Jotkut auttavat muita tukifoorumilla, kääntävät ohjeita eri kielille, tekevät ehdotuksia, kirjoittavat dokumentaatiota tai auttavat testaamaan uusia ohjelmia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <location filename="../minstall.cpp" line="1769"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 on itsenäinen Linux jakelu, pohjautuu Debian Stable haaraan.

%1 käyttää joitakin MEPIS Linux komponentteja jotka on julkaistu Apachen vapaalla lisenssillä. Jotkin MEPIS komponentit on muokattu %1:ia varten.

Pidä hauskaa käyttäessäsi %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>Preparing to install %1</source>
        <translation>Valmistautuu asentamaan %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>Paused for required operator input</source>
        <translation>Pysäytetty käyttäjän syötettä varten</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>Setting system configuration</source>
        <translation>Asetetaan järjestelmän kokoonpano</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>Cleaning up</source>
        <translation>Siivotaan</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>Finished</source>
        <translation>Viimeistelty</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="733"/>
        <source>Configuring system. Please wait.</source>
        <translation>Määritetään järjestelmää. Ole hyvä ja odota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Järjestelmän määritys valmistui. Käynnistetään järjestelmä uudelleen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="744"/>
        <source>The installation was aborted.</source>
        <translation>Asennus keskeytettiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="768"/>
        <source>Pretending to install %1</source>
        <translation>Asennuksen teeskentely %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="812"/>
        <source>Invalid settings found in configuration file (%1).</source>
        <translation>Virheellisiä asetuksia löytyi määritystiedostosta (%1).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="813"/>
        <source>Please review marked fields as you encounter them.</source>
        <translation>Tarkista merkityt rivit sitä mukaa kun kohtaat niitä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="239"/>
        <location filename="../minstall.cpp" line="911"/>
        <location filename="../minstall.cpp" line="927"/>
        <location filename="../minstall.cpp" line="956"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Sisältöä kohteessa /home ei voida säilyttää koska vaadittuja tietoja ei voitu hakea. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="238"/>
        <location filename="../minstall.cpp" line="817"/>
        <location filename="../minstall.cpp" line="926"/>
        <location filename="../minstall.cpp" line="983"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Invalid settings found in configuration file (%1).
Please review marked fields as you encounter them.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="984"/>
        <location filename="../minstall.cpp" line="995"/>
        <source>Cannot find selected drive.</source>
        <translation>Valittua asemaa ei löydy.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1042"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Kotihakemisto käyttäjälle %1 on jo olemassa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1087"/>
        <source>General Instructions</source>
        <translation>Yleiset ohjeet</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1088"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>SULJE KAIKKI MUUT SOVELLUKSET ENNEN JATKAMISTA.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1089"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Lue ohjeet jokaisella sivulla, tee valintasi ja paina &quot;Seuraava&quot; kun olet valmis jatkamaan.  Sinua pyydetään vahvistusta ennen kuin tuhoavat toimet suoritetaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1091"/>
        <source>Limitations</source>
        <translation>Rajoitukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1092"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Muistathan, että tämä ohjelmisto toimitetaan SELLAISENAAN ilman mitään takuuta. On yksin sinun omalla vastuullasi tehdä varmuuskopiot tiedostoistasi ennen jatkamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1096"/>
        <source>Installation Options</source>
        <translation>Asennusvalinnat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1097"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Mikäli ajat Mac- tai Windows-käyttöjärjestelmää (Vista:sta eteenpäin lukien), voi olla että sinun pitää käyttää kyseisen järjestelmän ohjelmia luodaksesi osiot ja käynnistyksen hallinnan ennen asennusta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1098"/>
        <source>Dual drive</source>
        <translation>Kaksi kiintolevyä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1099"/>
        <source>If your system has multiple storage drives, this option allows you to have the system files on one drive (the System drive), while keeping the data of all users on a separate drive (the Home drive).</source>
        <translation>Jos tietokoneessa on useita kiintolevyjä, vaihtoehto mahdollistaa järjestelmän sijoittamisen yhdelle asemalle (järjestelmäasema) ja käyttäjien tietojen säilyttämisen erilliselle asemalle (kotiasema).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1101"/>
        <source>Using the root-home space slider</source>
        <translation>Käytetään juurihakemisto-kotihakemiston levytilan liukusäädintä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1102"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>Asema voidaan jakaa erillisiin osiin järjestelmä (root) ja käyttäjän tiedostoihin (koti) liukusäätimen avulla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1103"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>Osio &lt;b&gt;root&lt;/b&gt; sisältää käyttöjärjestelmän sekä sovellukset.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1104"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>&lt;b&gt;home&lt;/b&gt; osio sisältää kaikkien käyttäjien tiedot kuten heidän omat asetukset, tiedostot, asiakirjat, kuvat, musiikin, videot jne.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1105"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Liikuta säädintä oikelle kasvattaaksesi &lt;b&gt;root&lt;/b&gt; tilaa. Liikuta säädintä vasemmalle kasvattaaksesi osiota &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1106"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Siirrä liukusäädin kokonaan oikealle jos haluat juuriaseman ja kotihakemiston samalle osiolle.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1107"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Kotihakemiston sijoittaminen erilliselle osiolle parantaa käyttöjärjestelmän toimintavarmuutta päivitettäessä. Se myös helpottaa varmuuskopiointia ja järjestelmän palautusta. Tämä myös parantaa yleistä suorituskykyä rajaamalla järjestelmätiedostot tiettyyn paikkaan kiintolevyllä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1109"/>
        <location filename="../minstall.cpp" line="1207"/>
        <location filename="../minstall.cpp" line="1227"/>
        <source>Encryption</source>
        <translation>Salaus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1110"/>
        <location filename="../minstall.cpp" line="1208"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Kiintolevyn salaus on mahdollista LUKS:in kautta. Salasana vaaditaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1111"/>
        <location filename="../minstall.cpp" line="1209"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Erillinen salaamaton käynnistusosio vaaditaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1112"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Kun salausta käytetään automaattisen asennuksen yhteydessä, erillinen käynnistys-osio luodaan automaattisesti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1113"/>
        <source>Using a custom disk layout</source>
        <translation>Käytetään mukautettua kiintolevyn järjestelyä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1114"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Jos haluat hallita tarkemmin mihin %1 asennetaan, valitse &quot;&lt;b&gt;%2&lt;/b&gt;&quot; ja klikkaa &lt;b&gt;Next&lt;/b&gt;. Seuraavalla sivulla, voit valita ja konfiguroida tarvitsemiasi tallennuslaitteita sekä osioita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <location filename="../minstall.cpp" line="1122"/>
        <source>Replace existing installation</source>
        <translation>Korvaa olemassa oleva asennus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <source>Replace existing installation option will attempt to replace an existing installation with the same disk configuration as the existing installation.  Home directories are preserved.</source>
        <translation>Valinta &quot;Korvaa olemassa oleva asennus&quot; korvaa olemassa olevan asennuksen samalla levykokoonpanolla kuin olemassa oleva asennus. Kotihakemistot säilytetään.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1123"/>
        <source>If you have an existing installation, you can use this function to replace it with a fresh installation.</source>
        <translation>Jos sinulla on olemassa oleva asennus, voit käyttää tätä toimintoa korvataksesi sen uudella asennuksella.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1124"/>
        <source>This is particularly useful if you are upgrading from a previous version and want to preserve your data.</source>
        <translation>Tämä on hyödyllistä, jos päivität aiemmasta versiosta ja haluat säilyttää tiedostosi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1126"/>
        <source>There is no guarantee of this working successfully. Ensure you have a good working backup of all important data before continuing.</source>
        <translation>Toimivuutta ei voida taata. Varmista, että sinulla on toimiva varmuuskopio kaikista tärkeistä tiedoista ennen kuin jatkat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1127"/>
        <source>This feature is designed to replace an installation performed using the regular install method, and may fail to replace an installation with a complex layout or storage scheme. Corruption or data loss may occur.</source>
        <translation>Ominaisuus on suunniteltu korvaamaan normaalin asennustavan, eikä se välttämättä korvaa manuaalista asettelua tai eri tallennusjärjestelmiä. Tietoja voi vioittua tai kadota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>To replace an installation with a complex layout or storage scheme, it is recommended to use the custom layout option instead.</source>
        <translation>Jos haluat korvata asennuksen manuaalisella asettelulla, on suositeltavaa käyttää valintaa mukautettu asennus.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1137"/>
        <source>Choose Partitions</source>
        <translation>Valitse osiot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1138"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Osioluettelo sallii sinun valita mitä osioita käytetään tässä asennuksessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1139"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Device&lt;/i&gt; - Tämä on lohkolaitteen nykyinen tai tuleva nimi, joka annetaan luodulle osiolle.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1140"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Size&lt;/i&gt; - Osion koko. Tätä voidaan muuttaa vain täysin uudessa järjestelyssä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1141"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Use For&lt;/i&gt; - Jos haluat käyttää tätä osiota asennuksessa, sinun on valittava jotain täältä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1143"/>
        <source>Format without mounting</source>
        <translation>Alusta ilman kiinnittävää liittosta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1144"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>BIOS Boot GPT osio GRUB:lle</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1145"/>
        <location filename="../minstall.cpp" line="1184"/>
        <source>EFI System Partition</source>
        <translation>EFI Järjestelmäosio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1147"/>
        <source>Boot manager</source>
        <translation>Käynnistyksen hallinta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1148"/>
        <source>System root</source>
        <translation>Järjestelmän root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1149"/>
        <source>User data</source>
        <translation>Käyttäjän data</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1150"/>
        <source>Static data</source>
        <translation>Staattinen data</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1151"/>
        <source>Variable data</source>
        <translation>Muuttuva data</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1152"/>
        <source>Temporary files</source>
        <translation>Väliaikaiset tiedostot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>Swap files</source>
        <translation>Swap tiedostot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1154"/>
        <source>Swap partition</source>
        <translation>Swap osio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1156"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Yllä olevien lisäksi voit kirjoittaa myös oman kiinnityksen. Omien kiinnitysten alussa on oltava vinoviiva (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1157"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Label&lt;/i&gt; - Nimikyltti joka määritetään osiolle kun se on alustettu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1158"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Encrypt&lt;/i&gt; - Käytä LUKS-salausta tähän osioon. Salasana koskee kaikkia salattavaksi valittuja osioita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Format&lt;/i&gt; - Tämä on osion formaatti. Käytettävissä oleva alustamisen muoto riippuu siitä, mihin osiota käytetään. Kun työskentelet olemassa olevan alustuksen kanssa, voit ehkä säilyttää osion formaatin valitsemalla Säilytä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1161"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>Valitsemalla &lt;b&gt;Säilytä /home&lt;/b&gt; se säilyttää /home hakemiston sisällön, mutta poistaa kaiken muun. Tätä voidaan käyttää vain kun /home on samassa osiossa kuin root osio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1163"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Linux yhteensopivat ext2, ext3, ext4, jfs, xfs ja btrfs tuetaan ja ext4 on suositus.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Check&lt;/i&gt; - Tarkista ja korjaa vialliset sektorit kiintolevyllä (ei tueta kaikissa formaateissa). Tämä vie paljon aikaa, joten sinun kannattaa ohittaa tämä vaihe, ellet epäile, että kiintolevyssäsi on jotain vikaa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1166"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Kiinnitysvaihtoehdot&lt;/i&gt; - Tämä määrittelee liittämisen asetukset, joita käytetään tälle osiolle.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1167"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Dump&lt;/i&gt; - Kehottaa dump-ohjelmaa sisällyttämään tämän osion varmuuskopioon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1168"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Pass&lt;/i&gt; - Järjestys, jossa tarkistetaan tiedostojärjestelmä käynnistyksen yhteydessä. Jos nolla niin ei tarkisteta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1169"/>
        <source>Menus and actions</source>
        <translation>Valikot ja toiminnot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Laaja valikoima toimintoja on käytettävissä hiiren oikealla painikkeella, missä tahansa aseman tai osion kohdassa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1171"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Luettelon oikeanpuoleisella laidalla olevia painikkeita voidaan myös käyttää kohteiden muokkaamiseen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1172"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>Asennusohjelma ei voi muuttaa asemassa jo valmiina olevaa asettelua. Voit luoda mukautetun asettelun merkitsemällä aseman uutta asettelua varten &lt;b&gt;Uusi asettelu&lt;/b&gt; valikosta tai painikkeella (%1). Tämä tyhjentää nykyisen asettelun.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1175"/>
        <source>Basic layout requirements</source>
        <translation>Perusvaatimukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1176"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 vaatii root juuriosion. Sivutusosio eli swap on valinnainen mutta erittäin suositeltava. Mikäli haluat käyttää lepotilaa kiintolevylle %1, tarvitset sivutustiedostolle osion joka on kooltaan suurempi kuin tietokoneen kusmuistin määrä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1178"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Mikäli valitset erillisen /home osion, tarkoittaa se helpompaa siirtymäpäivitystä tulevaisuudessa, mutta ei ole mahdollista päivitettäessä asennuksesta ilman erillistä koti-osiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1180"/>
        <source>Active partition</source>
        <translation>Aktiivinen osio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Jotta asennettu käyttöjärjestelmä voisi käynnistyä, asianmukainen osio (yleensä boot tai root) on merkittävä aktiiviseksi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1182"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>Aseman aktiivinen osio valitaan &lt;b&gt;Aktiivinen osio&lt;/b&gt; valikosta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Osio, jonka laitenimen vieressä on tähti (*), on aktiivinen osio tai tulossa sellainen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1185"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Jos tietokoneesi käyttää Extensible Firmware Interface (EFI) niin tarvitset osion, joka tunnetaan nimellä EFI System Partition (ESP). Tämä käynnistää järjestelmän.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1186"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Nämä eivät vaadi aktiiviseksi merkittyä osiota, vaan ne edellyttävät FAT-tiedostojärjestelmällä alustettua osiota, joka on merkitty ESP:ksi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1187"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>Tietokoneet, jotka on tehty viimeisen 10 vuoden aikana käyttävät EFI menetelmää.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>Boot partition</source>
        <translation>Käynnistysosio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1189"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Tätä osiota vaaditaan yleensä vain virtuaalisten, kuten salattujen, LVM tai ohjelmistopohjaisen RAID-taltion, root juuriosioille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1190"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Sisältää perus kernelin ja ajurit, joita käytetään salatun levyn tai virtuaalisen käyttämiseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>BIOS-GRUB partition</source>
        <translation>BIOS-GRUB osio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1192"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>Käytettäessä GPT alustettua asemaa ilman tai EFI:n ulkopuolella, GRUB:ia varten tarvitaan 1 Mt kokoinen BIOS käynnistysosio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1193"/>
        <source>Need help creating a layout?</source>
        <translation>Tarvitsetko apua asettelun luomisessa?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1194"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Paina hiiren oikeaa ja valitse valikosta &lt;b&gt;Layout Builder&lt;/b&gt;. Tämä voi luoda tavallisen asennuksen kaltaisen asettelun.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1195"/>
        <source>Upgrading</source>
        <translation>Päivittäminen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1196"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Jos haluat päivittää jo olemassa olevan Linux-asennuksen, valitse sama kotiosio kuin ennen ja valitse &lt;b&gt;Säilytä&lt;/b&gt; formaatikisi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1197"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Jos et käytä erillistä kotiosiota, valitse &lt;b&gt;Säilytä /home&lt;/b&gt; säilyttääksesi samassa root juuriosiossa olevan /home kotihakemiston. Asennusohjelma säilyttää vain /home hakemiston ja poistaa kaiken muun. Tämän takia asennus kestää tavallista kauemmin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1199"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tiedostojärjestelmän suositeltu tyyppi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>Kohdassa %1 voit formatoida osiot ext2, ext3, ext4, f2fs, jfs, xfs tai btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1201"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Pakkauksen lisävalinnat ovat tarjolla kiintolevyille jotka käyttävät btrfs-tiedostojärjestelmää. Lzo on nopea, mutta pakkaus on vähäisempi. Zlib on hitaampi, korkeammalla pakkauksella.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1203"/>
        <source>System partition management tool</source>
        <translation>Järjestelmän osiohallinta työkalu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1204"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Voit hallita asemaa (kuten muuttaa levyllä olevaa asettelua) painamalla osiohallinta painiketta (%1). Tämä käynnistää käyttöjärjestelmän osiohallinta työkalun, jonka avulla voit luoda osiot juuri tarvitsemasi asettelun mukaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1210"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Jos haluat säilyttää salatun osion, paina sitä hiirellä ja valitse &lt;b&gt;Avaa lukitus&lt;/b&gt;. Kirjoita tulevaan valintaikkunaan virtuaalilaitteen nimi ja salasana. Kun laitteen lukitus on avattu, valitsemasi nimi näkyy kohdassa &lt;i&gt;Virtuaalilaitteet&lt;/i&gt;. Sillänä on samanlaiset asetukset kuin tavallisella osiolla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Jotta salattu osio avataan käynnistyksen yhteydessä, se on lisättävä crypttab-tiedostoon. Käytä &lt;b&gt;Lisää taulukkoon Crypttab&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1213"/>
        <source>Other partitions</source>
        <translation>Muut osiot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1214"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Asennusohjelma sallii muiden osioiden luomisen tai käyttämisen eri tarkoituksiin. Muista, että vanhemmat järjestelmät eivät pysty käsittelemään asemia, joissa on enemmän kuin 4 osiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1215"/>
        <source>Subvolumes</source>
        <translation>Alitaltiot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1216"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Tiedostojärjestelmät, kuten Btrfs, tukevat useita alitaltioita yhdessä osiossa. Nämä eivät ole fyysisiä alaryhmiä, joten niiden järjestyksellä ei ole väliä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1218"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Käytä valikosta &lt;b&gt;Skannaa alitaltiot&lt;/b&gt; toimintoa ja etsi alitaltiot olemassa olevasta Btrfs-osiosta. Voit luoda uuden alitaltion käyttämällä valikosta &lt;b&gt;Uusi alitaltio&lt;/b&gt; toimintoa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1220"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Olemassa olevat alitaltiot voidaan säilyttää, mutta nimen on pysyttävä samana.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1221"/>
        <source>Virtual Devices</source>
        <translation>Virtuaaliset laitteet</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1222"/>
        <source>If the installer detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Jos asennusohjelma havaitsee virtuaalilaitteita, kuten avattuja LUKS-osioita, LVM-loogisia asemia tai ohjelmistopohjaisia RAID-taltioita. Niitä voidaan käyttää asennuksessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1223"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>Virtuaalilaitteiden käyttö (salattujen tiedostojärjestelmien säilyttäminen) on edistynyt ominaisuus. Saatat joutua muokkaamaan joitain tiedostoja (esim. initramfs, crypttab, fstab) varmistaaksesi, että käytetyt virtuaalilaitteet luodaan käynnistyksen yhteydessä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1228"/>
        <source>You have chosen to encrypt at least one volume, and more information is required before continuing.</source>
        <translation>Olet valinnut vähintään yhden taltion salaamisen ja lisätietoja tarvitaan ennen kuin voit jatkaa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1233"/>
        <source>Final Review and Confirmation</source>
        <translation>Lopullinen tarkistus ja vahvistus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Please review this list carefully. This is the last opportunity to check, review and confirm the actions of the installation process before proceeding.</source>
        <translation>Lue tämä luettelo huolellisesti. Tämä on viimeinen tilaisuus tarkistaa ja vahvistaa asennusprosessi ennen kuin jatkat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1244"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Asenna GRUB Linuxille ja Windowsille</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1245"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1 käyttää GRUB-käynnistyslatainta %1 ja Microsoft Windowsin käynnistämiseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1246"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Oletuksena GRUB asennetaan käynnistysasemasi Master Boot Record (MBR) tai ESP (EFI System Partition for 64bit UEFI boot system) osioon ja korvaa aiemmin käyttämäsi lataajan. Tämä on normaalia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1247"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Jos päättäisit sen sijaan asentaa GRUB osion käynnistystietueeseen (PBR) niin GRUB asennetaan asetetun osion alkuun. Tämä valinta on vain asiantuntijoille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1248"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Jos poistat valinnan ruudusta &quot;Asenna GRUB&quot; niin sitä ei asenneta. Tämä valinta on vain asiantuntijoille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Generate host-specific initramfs will try to create an initramfs tailored for the particular device rather than a generic all-purpose initramfs. This option is for experts only.</source>
        <translation>&quot;Generate host-specific initramfs&quot; luo tiettyyn laitteeseen räätälöidyn initramfs:n yleiskäyttöisen initramfs:n sijaan. Tämä valinta on tarkoitettu vain asiantuntijoille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Zram swap is a method of putting swap space in RAM.  A compressed swap device is placed in RAM.  It may be used in conjunction with other forms of swap, or on its own.</source>
        <translation>Zram-swap on menetelmä swapin lisäämiseksi RAM-muistiin. Pakattu swap sijoitetaan keskusmuistiin ja sitä voidaan käyttää yhdessä muiden swap-määritysten rinnalla tai yksinään.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Automatically restart when the installation is done</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Welcome to %1 Installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2296"/>
        <source>reset size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2684"/>
        <source>The system is being installed.
This may take several minutes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2690"/>
        <source>Reboot automatically when installation completes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2724"/>
        <source>Installation complete</source>
        <translation>Asennus on valmis</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4128"/>
        <source>Installing...</source>
        <translation>Asennetaan...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4447"/>
        <source>Could not unlock device. Incorrect password?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>Installation Confirmation</source>
        <translation>Asennuksen vahvistus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1935"/>
        <source>Please review the installation settings.

This is the last opportunity to check and confirm
the actions of the installation process.

Press ENTER to begin installation or Backspace to go back.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1960"/>
        <source>Enter computer name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1975"/>
        <source>Enter domain name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1989"/>
        <source>Workgroup</source>
        <translation>Työryhmä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2072"/>
        <source>Localization Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2078"/>
        <source>Locale:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2089"/>
        <source>Time Area:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2100"/>
        <source>Time Zone:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2176"/>
        <source>System services will be configured with default settings.
You can modify service settings after installation
using your system's service manager.

Press ENTER to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2194"/>
        <source>Replace Existing Installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2210"/>
        <source>Custom Partitioning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2224"/>
        <source>Apply</source>
        <translation>Hyväksy</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2258"/>
        <source>Swap File Configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2271"/>
        <source>Location:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2282"/>
        <source>Size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2302"/>
        <source>Enable hibernation support</source>
        <translation>Lepotilan tuki käyttöön</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2308"/>
        <source>Zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2313"/>
        <source>Enable zram swap</source>
        <translation>Ota zram swap käyttöön</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2320"/>
        <source>Allocate based on RAM (%):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2335"/>
        <source>Allocate fixed size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2482"/>
        <source>Encryption options</source>
        <translation>Salauksen valinnat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2487"/>
        <source>Encryption password:</source>
        <translation>Salauksen salasana:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2498"/>
        <source>Confirm password:</source>
        <translation>Vahvista salasana:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2540"/>
        <source>Enter username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2554"/>
        <source>Enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2567"/>
        <source>Re-enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2640"/>
        <source>A home directory already exists for this user name.
Choose what to do with it:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4942"/>
        <source>Passwords must match and not be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5279"/>
        <source>Please enter a computer name.</source>
        <translation>Syötä nimi tietokoneelle. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5282"/>
        <source>The computer name contains invalid characters.</source>
        <translation>Tietokoneen nimi sisältää virheellisiä merkkejä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5285"/>
        <source>Please enter a domain name.</source>
        <translation>Syötä verkko-domain nimi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5288"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>Tietokoneen toimialue sisältää virheellisiä merkkejä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5291"/>
        <source>Please enter a workgroup.</source>
        <translation>Syötä työryhmä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5622"/>
        <source>Please fill in all required fields before continuing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5630"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>Käyttäjätunnus ei saa sisältää erikoismerkkejä tai välilyöntejä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5633"/>
        <location filename="../minstall.cpp" line="5636"/>
        <source>Please ensure the passwords match.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5651"/>
        <source>The chosen user name is in use.</source>
        <translation>Käyttäjätunnus on käytössä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5655"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Et antanut salasanaa kohteelle %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5663"/>
        <source>You did not provide a password for the root account.</source>
        <translation>Et antanut root-tilin salasanaa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5752"/>
        <source>Please select an option to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1254"/>
        <location filename="../minstall.cpp" line="2263"/>
        <source>Create a swap file</source>
        <translation>Luo swap-tiedosto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="485"/>
        <source>Experimental</source>
        <comment>As In feature is not polished and may not work properly</comment>
        <translation>Kokeellinen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1255"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Swap tiedostona on joustavampi kuin swap osio; huomattavasti helpompaa muuttaa swap tustiedoston kokoa mukautumaan vaikkapa järjestelmän keskusmuistin lisäämiseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Oletuksena valittuna, jos swap osioita ei ole asetettu erikseen tai ei valittuna, vaikka swap olisi jo tehty. Tämä valinta kannattaa jättää koskematta, jos et ole asiantuntija.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1262"/>
        <source>Common Services to Enable</source>
        <translation>Yleiset käyttöön otettavat palvelut</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1263"/>
        <source>Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.</source>
        <translation>Valitse mikä tahansa näistä palveluista, joita saatat tarvita kokoonpanossasi. Kun käynnistät %1, palvelut käynnistyy automaattisesti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1268"/>
        <source>Computer Identity</source>
        <translation>Tietokoneen identiteetti</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1269"/>
        <source>The computer name is a common unique name which will identify your computer if it is on a network.</source>
        <translation>Tietokoneen nimi on yksilöllinen nimi, joka tunnistetaan jos se on verkossa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1270"/>
        <source>The computer domain is unlikely to be used unless your ISP or local network requires it.</source>
        <translation>Tietokoneen toimialuetta ei todennäköisesti käytetä, ellei internet-palveluntarjoajasi tai lähiverkkosi sitä erikseen vaadi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1271"/>
        <source>The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens.</source>
        <translation>Tietokoneen ja toimialueen nimet voivat sisältää vain aakkosia, numeroita, pisteitä ja yhdysviivoja. Ei saa sisältää välilyöntejä, eikä saa alkaa tai päättyä yhdysviivoihin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1273"/>
        <source>The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.</source>
        <translation>Samba-palvelin on aktivoitava, jos haluat käyttää kansioiden tai tulostimen jakoa lähiverkossa MS-Windows tai Mac OSX tietokoneiden kanssa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Localization Defaults</source>
        <translation>Kotoistuksen oletukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1279"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Aseta oletusarvo sijainnille. Tämä valinta pysyy niin kauan kunnes käyttäjä muokkaa sitä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1280"/>
        <source>Configure Clock</source>
        <translation>Kellon asetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1281"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Mikäli sinulla on Apple tai täysin puhdas Unix-työasema, järjestelmän kellonaika asetetaan oletuksena Greenwitchin aikaan (GMT) tai Koordinoituun yleisaikaan (UCT). Vaihtaaksesi tämän, valitse &quot;&lt;b&gt;Järjestelmän kello käyttää paikallista aikaa&lt;/b&gt;&quot; valintaruutu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1283"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Järjestelmä käynnistyy aikavyöhyke esiasetettuna GMT/UTC aikaan. Vaihtaaksesi aikavyöhykettä, järjestelmän käynnistyttyä uudelleen, klikkaa kakkospainikkeella kelloa Paneelissa ja valitse Ominaisuudet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1285"/>
        <source>Service Settings</source>
        <translation>Palveluiden asetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1286"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Useimpien käyttäjien ei tulisi muuttaa oletusasetuksia. Pienitehoisilla koneilla olevat käyttäjät haluavat usein poistaa käytöstä tarpeettomia toimintoja pitääkseen RAM-muistin käytön mahdollisimman pienenä. Varmista että tiedät mitä teet!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1293"/>
        <source>Default User Login</source>
        <translation>Oletuskäyttäjän kirjautuminen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1294"/>
        <source>Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Anna nimi uudelle (oletus) käyttäjälle, jota käytät päivittäin. Tarvittaessa voit lisätä muita käyttäjäiä myöhemmin %1 Käyttäjien hallinan avulla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1296"/>
        <source>Root (administrator) account</source>
        <translation>Root-tili (järjestelmänvalvoja)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1297"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account.</source>
        <translation>Root-käyttäjä on samanlainen kuin järjestelmänvalvoja muissa käyttöjärjestelmissä. Sinun ei pitäisi käyttää root-käyttäjää päivittäisenä käyttäjätilinä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1299"/>
        <source>The root account is disabled on MX Linux, as administrative tasks are performed with an elevation prompt for the default user.</source>
        <translation>Root-tili on poistettu käytöstä MX Linuxissa, koska hallinnolliset tehtävät suoritetaan oletuskäyttäjän avulla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1300"/>
        <source>Enabling the root account is strongly recommended for antiX Linux.</source>
        <translation>Root-tilin käyttöönotto on erittäin suositeltavaa antiX Linuxille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1301"/>
        <source>Passwords</source>
        <translation>Salasanat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1302"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Syötä uusi salasana oletus-käyttäjätilillesi sekä pääkäyttäjälle. Kumpikin salasana pitää syöttää kahdesti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1304"/>
        <source>No passwords</source>
        <translation>Ei salasanoja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Jos et halua oletus-käyttäjätilillä olevan salasanaa, jätä sen salasanojen kentät tyhjiksi. Tämä sallii sinun kirjautua sisään ilman salasanaa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1307"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Tämä kannattaa ilmiselvästi tehdä vain tilanteissa joissa käyttäjätilin ei tarvitse olla turvallinen, kuten julkiset tietokoneet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1316"/>
        <location filename="../minstall.cpp" line="2634"/>
        <source>Old Home Directory</source>
        <translation>Vanha Kotihakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1317"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Kotikansio on valmiiksi olemassa valitsemallesi käyttäjänimelle. Tämä ruutu sallii sinun valita mitä tälle hakemistolle tapahtuu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1319"/>
        <location filename="../minstall.cpp" line="2646"/>
        <source>Re-use it for this installation</source>
        <translation>Käytä se uudelleen tätä asennusta varten</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1320"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Vanhaa kotikansiota tullaan käyttämään tälle käyttäjätilille. Tämä on hyvä valinta päivityksen tullessa kyseeseen, ja tiedostosi kuin myös asetuksesi tulevat olemaan valmiina ennallaan. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1322"/>
        <location filename="../minstall.cpp" line="2653"/>
        <source>Rename it and create a new directory</source>
        <translation>Uudelleennimeä se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1323"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Käyttäjälle tullaan luomaan uusi kotikansio, mutta vanha kotikansio nimetään uudelleen. Tiedostosi ja asetuksesi eivät tule olemaan välittömästi näkyvillä uudessa asennuksessa, mutta niihin pääsee käsiksi käyttäen uudelleennimettyä kansiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1325"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Vanhan hakemiston nimessä tulee olemaan numero sen lopussa, riippuen siitä kuinka minta kertaa tuo hakemisto on aiemmin uudelleennimetty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1326"/>
        <location filename="../minstall.cpp" line="2660"/>
        <source>Delete it and create a new directory</source>
        <translation>Poista se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1327"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Vanha hakemisto poistetaan ja luodaan tilalle täysin uusi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1125"/>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1329"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Kaikki tiedostot ja asetukset poistetaan pysyvästi jos tämä vaihtoehto on valittuna. Mahdollisuutesi palauttaa ne ovat pienet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1341"/>
        <location filename="../minstall.cpp" line="2678"/>
        <source>Installation in Progress</source>
        <translation>Asennus Käynnissä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1342"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 asentuu. Puhtaan asennuksen ollessa kyseessä, se luultavasti kestää 3-20 minuuttia, riippuen järjestelmäsi nopeudesta ja uudelleenalustettavien osioiden koosta. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1344"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Jos napsautat Keskeytä painiketta, asennus pysäytetään niin pian kuin mahdollista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1346"/>
        <source>Change settings while you wait</source>
        <translation>Muuta asetuksia odottaessasi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1347"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Sillä välin kun %1 asentuu, voit napsauttaa &lt;b&gt;Seuraava&lt;/b&gt;tai &lt;b&gt;Takaisin&lt;/b&gt; painikkeita lukeaksesi muita asennuksen vaatimia tietoja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Saata nämä askeleet valmiiksi omaan tahtiisi. Asennusohjelma odottaa syötteitäsi tarpeen vaatiessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1361"/>
        <source>Congratulations!</source>
        <translation>Sinä onnistuit!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>You have completed the installation of %1.</source>
        <translation>%1 asennus on valmis.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1363"/>
        <source>Finding Applications</source>
        <translation>Sovellusten etsiminen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>There are hundreds of excellent applications installed with %1. The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus.</source>
        <translation>%1-projektiin on asennettu satoja sovelluksia. Paras tapa oppia niistä on selata valikkoa ja kokeilla niitä. Monet sovelluksista on kehitetty erityisesti %1-projektia varten. Nämä näkyvät päävalikoissa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1368"/>
        <source>In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.</source>
        <translation>%1 sisältää lisäksi useita Linux-vakiosovelluksia, jotka suoritetaan vain komentoriviltä, ​​eivätkä siksi näy valikossa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1370"/>
        <source>Enjoy using %1</source>
        <translation>Nauti %1:n käytöstä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1444"/>
        <source>Finish</source>
        <translation>Lopeta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1447"/>
        <source>Start</source>
        <translation>Aloita</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1450"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1452"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>The installation and configuration is incomplete.</source>
        <translation>Asennus ja määritykset ovat keskeneräisiä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1593"/>
        <source>Do you really want to stop now?</source>
        <translation>Haluatko todella lopettaa?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Avun hakeminen &lt;/b&gt;&lt;br/&gt; Perustiedot liittyen %1 on %2. &lt;/p&gt;&lt;p&gt; Vapaaehtoiset ovat valmiina auttamaan sinua %3 foorumilla, %4 &lt;/p&gt;&lt;p&gt; Kun pyydät apua, muista kuvailla ongelmasi sekä myös tietokoneesi niin hyvin kuin mahdollista. Yleensä lausunnot kuten &apos;se ei toiminut&apos; eivät ole avullisia.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Asennuksen korjaaminen&lt;/b&gt;&lt;br/&gt;Jos %1 lakkaa toimimasta kiintolevyllä, joskus ongelma on mahdollista korjata käynnistämällä järjestelmä LiveDVD:n tai LiveUSB:in kautta ja suorittamalla jokin vaihtoehto mukana olevasta %1 tai käyttämällä jotakin yleistä Linux-työkalua järjestelmän korjaamiseen.&lt;/p&gt;&lt;p&gt;Voit myös käyttää %1 LiveDVD:tä tai LiveUSB:ia palauttaaksesi tiedostoja MS-Windows käyttöjärjestelmistä!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Äänimikserin säätäminen &lt;/b&gt;&lt;br/&gt; %1 pyrkii määrittelemään äänimikserin sinulle valmiiksi mutta joskus on välttämätöntä itse säätää äänitasoja ja poistaa äänikanavien mykistys mikserissä kuullaksesi ääntä. &lt;/p&gt;&lt;p&gt; Mikserin oikopolkulinkki sijaitsee käynnistysvalikossa. Klikkaa sitä avataksesi mikserin. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Pidä %1-kopiosi ajan tasalla&lt;/b&gt;&lt;br/&gt;Saadaksesi lisätietoja sekä viimeisimmät päivitykset, vieraile osoitteessa&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Erityiskiitokset&lt;/b&gt;&lt;br/&gt;Kiitokset kaikille jotka ovat valinneet tukevansa %1 omalla ajalla, rahalla, ehdotuksilla, työllä, kehuilla, ideoilla, mainonnalla, ja/tai sitoutumisella.&lt;/p&gt;&lt;p&gt;Ilman teitä %1 ei olisi olemassa.&lt;/p&gt;&lt;p&gt;%2 Kehitystiimi&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Live-loki</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Takaisin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="78"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="85"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="91"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="120"/>
        <source>Installation in progress</source>
        <translation>Asennus käynnissä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="135"/>
        <source>Abort</source>
        <translation>Keskeytä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="138"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="158"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="177"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Tietoja kerätään, odota.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="209"/>
        <source>Terms of Use</source>
        <translation>Käyttöehdot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Keyboard Settings</source>
        <translation>Näppäimistön asetuksia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="256"/>
        <source>Model:</source>
        <translation>Malli:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="271"/>
        <source>Variant:</source>
        <translation>Vaihtoehto:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="297"/>
        <source>Change Keyboard Settings</source>
        <translation>Muuta näppäimistön asetuksia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="309"/>
        <source>Layout:</source>
        <translation>Asettelu:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Valitse asennustyyppi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="445"/>
        <source>Home</source>
        <translation>Kotihakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="520"/>
        <location filename="../meinstall.ui" line="542"/>
        <location filename="../meinstall.ui" line="1216"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="555"/>
        <source>Encrypt</source>
        <translation>Salaa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1184"/>
        <source>Enable hibernation support</source>
        <translation>Lepotilan tuki käyttöön</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Normaali asennus käyttäen koko levyä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="381"/>
        <source>Dual drive</source>
        <translation>Kaksi kiintolevyä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="391"/>
        <source>System drive:</source>
        <translation>Järjestelmäasema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <source>Home drive:</source>
        <translation>Kotiasema: %1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="565"/>
        <source>Customize the disk layout</source>
        <translation>Mukauta kiintolevyn asettelua</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="572"/>
        <source>Replace existing installation</source>
        <translation>Korvaa olemassa oleva asennus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="617"/>
        <source>Replace an existing installation</source>
        <translation>Korvaa olemassa oleva asennus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="639"/>
        <source>Device</source>
        <translation>Laite</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Installation</source>
        <translation>Asennus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Scan for existing installations</source>
        <translation>Tarkista olemassa olevat asennukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="679"/>
        <source>Replacement options</source>
        <translation>Korvaamisen vaihtoehdot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Attempt to upgrade packages</source>
        <translation>Pyri päivittämään paketit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="696"/>
        <source>Choose partitions</source>
        <translation>Valitse osiot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Merkitse tyhjennetyksi valittu asema, uutta asettelua varten.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Show Grid</source>
        <translation>Näytä ruudukko</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Suorita tämän käyttöjärjestelmän osiohallinta työkalu.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="747"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Poista aiemmat merkinnät asettelusta. Tämä toimii vain uudessa asettelussa.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Tee käyttöjärjestelmästä kysely ja saat uudelleen kaikkien asemien asettelut.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="795"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Lisää uusi osio. Tämä toimii vain uudessa asettelussa.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="806"/>
        <source>Show advanced fields.</source>
        <translation>Näytä lisäkentät.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="836"/>
        <source>Encryption options</source>
        <translation>Salauksen valinnat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="842"/>
        <source>Encryption password:</source>
        <translation>Salauksen salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="859"/>
        <source>Confirm password:</source>
        <translation>Salasanan varmistus:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="893"/>
        <source>Installation Confirmation</source>
        <translation>Asennuksen vahvistus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="936"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Asenna GRUB Linuxille ja Windowsille</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="951"/>
        <source>System boot disk:</source>
        <translation>Järjestelmän käynnistyslevy:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="999"/>
        <source>EFI System Partition</source>
        <translation>EFI Järjestelmäosio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1021"/>
        <source>Partition Boot Record</source>
        <translation>Osiokäynnistystaltio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1024"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1046"/>
        <source>Master Boot Record</source>
        <translation>Pääkäynnistyslohko</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1052"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1055"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <source>Location to install on:</source>
        <translation>Kohde johon asennetaan:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1075"/>
        <source>Generate host-specific initramfs image</source>
        <translation>Luo konekohtainen initramfs-kuva</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1114"/>
        <source>Create a swap file</source>
        <translation>Luo swap tiedosto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1131"/>
        <location filename="../meinstall.ui" line="1255"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1154"/>
        <source>Size:</source>
        <translation>Koko:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1177"/>
        <source>Location:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1194"/>
        <source>Enable zram swap</source>
        <translation>Ota zram swap käyttöön</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1206"/>
        <source>Allocate based on RAM:</source>
        <translation>Varaa keskusmuistin perusteella:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1235"/>
        <source>Recommended maximum: 100%</source>
        <translation>Suositeltu maksimi: 100%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1242"/>
        <source>Allocate fixed size:</source>
        <translation>Varaa kiinteä koko:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1292"/>
        <source>Common Services to Enable</source>
        <translation>Yleiset käyttöön otettavat palvelut</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1302"/>
        <source>Service</source>
        <translation>Palvelu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1307"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Computer Network Names</source>
        <translation>Tietokoneen Verkkonimet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1364"/>
        <source>Workgroup</source>
        <translation>Työryhmä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1377"/>
        <source>Workgroup:</source>
        <translation>Työryhmä:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1390"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa-palvelin Microsoftin verkkojakoa varten</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1406"/>
        <source>example.dom</source>
        <translation>esimerkki.fi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1419"/>
        <source>Computer domain:</source>
        <translation>Tietokoneen toimialue:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1442"/>
        <source>Computer name:</source>
        <translation>Tietokoneen nimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1497"/>
        <source>Localization Defaults</source>
        <translation>Kotoistuksen oletukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>Locale:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1537"/>
        <source>Configure Clock</source>
        <translation>Kellon asetukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1578"/>
        <source>Format:</source>
        <translation>Muoto:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1606"/>
        <source>Timezone:</source>
        <translation>Aikavyöhyke:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1651"/>
        <source>System clock uses local time</source>
        <translation>Järjestelmän kello käyttää paikallista aikaa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1673"/>
        <source>Service Settings (advanced)</source>
        <translation>Palveluasetukset (edistyneille)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1691"/>
        <source>Adjust which services should run at startup</source>
        <translation>Määritä, mitkä palvelut tulisi käynnistää järjestelmän käynnistyessä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1694"/>
        <source>View</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1755"/>
        <source>Default User Account</source>
        <translation>Oletuskäyttäjät</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1767"/>
        <source>Default user login name:</source>
        <translation>Käyttäjätunnus:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1783"/>
        <source>username</source>
        <translation>käyttäjänimi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1796"/>
        <source>Default user password:</source>
        <translation>Käyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1822"/>
        <source>Confirm user password:</source>
        <translation>Vahvista käyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1851"/>
        <source>Root (administrator) Account</source>
        <translation>Root (pääkäyttäjä)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1869"/>
        <source>Root password:</source>
        <translation>Root salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1895"/>
        <source>Confirm root password:</source>
        <translation>Vahvista root-salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1924"/>
        <source>Autologin</source>
        <translation>Kirjaudu automaattisesti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1931"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Liveympäristössä tehdyt työpöydän muutokset siirtyvät asennettuun käyttöjärjestelmään</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1934"/>
        <source>Save live desktop changes</source>
        <translation>Tallenna livetilan muutokset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1941"/>
        <source>Copy the contents of Live-usb-storage from the live medium to the installed system&apos;s home directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1944"/>
        <source>Copy Live-usb-storage to installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1983"/>
        <source>Existing Home Directory</source>
        <translation>Olemassaoleva kotihakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Mitä haluaisit tehdä vanhan hakemiston suhteen?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1999"/>
        <source>Re-use it for this installation</source>
        <translation>Käytä se uudelleen tätä asennusta varten</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2006"/>
        <source>Rename it and create a new directory</source>
        <translation>Uudelleennimeä se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2013"/>
        <source>Delete it and create a new directory</source>
        <translation>Poista se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2037"/>
        <source>Tips</source>
        <translation>Vinkkejä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2069"/>
        <source>Installation complete</source>
        <translation>Asennus on valmis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2075"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Uudelleenkäynnistä järjestelmä automaattiseti kun asennusohjelma suljetaan</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2094"/>
        <source>Reminders</source>
        <translation>Muistutukset</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="410"/>
        <source>Please enter a computer name.</source>
        <translation>Anna tietokoneelle nimi. </translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="414"/>
        <source>The computer name contains invalid characters.</source>
        <translation>Tietokoneen nimi sisältää virheellisiä merkkejä.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="415"/>
        <location filename="../oobe.cpp" line="426"/>
        <location filename="../oobe.cpp" line="646"/>
        <source>Please choose a different name before proceeding.</source>
        <translation>Valitse toinen nimi ennen kuin jatkat.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="421"/>
        <source>Please enter a domain name.</source>
        <translation>Anna toimialueen nimi.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="425"/>
        <source>The computer domain contains invalid characters.</source>
        <translation>Tietokoneen toimialue sisältää virheellisiä merkkejä.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="434"/>
        <source>Please enter a workgroup.</source>
        <translation>Anna lähiverkon työryhmä.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="651"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation>Käyttäjätunnus ei saa sisältää erikoismerkkejä tai välilyöntejä.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="661"/>
        <source>The chosen user name is in use.</source>
        <translation>Käyttäjätunnus on käytössä.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="670"/>
        <source>Are you sure you want to continue?</source>
        <translation>Haluatko varmasti jatkaa?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="675"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Et antanut salasanaa kohteelle %1.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="680"/>
        <source>You did not provide a password for the root account.</source>
        <translation>Et antanut root-tilin salasanaa.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="693"/>
        <source>Failed to set user account passwords.</source>
        <translation>Käyttäjätilien salasanojen asettaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="725"/>
        <source>Failed to save old home directory.</source>
        <translation>Vanhan kotikansion tallentaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="734"/>
        <source>Failed to delete old home directory.</source>
        <translation>Vanhan kotikansion poistaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="755"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Käyttäjähakemistoa ei voitu luoda.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="763"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Valitettavasti käyttäjäkansion nimeäminen ei onnistunut.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="808"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Käyttäjän oman hakemiston omistajuuden tai käyttöoikeuksien asettaminen epäonnistui.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="278"/>
        <location filename="../partman.cpp" line="956"/>
        <source>Virtual Devices</source>
        <translation>Virtuaaliset laitteet</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="555"/>
        <location filename="../partman.cpp" line="606"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Lisää osio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="557"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Poista osio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="566"/>
        <source>&amp;Lock</source>
        <translation>&amp;Lukitse</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="570"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Avaa lukitus</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="574"/>
        <location filename="../partman.cpp" line="803"/>
        <source>Add to crypttab</source>
        <translation>Lisää taulukkoon Crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="581"/>
        <source>New subvolume</source>
        <translation>Uusi alitaltio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="582"/>
        <source>Scan subvolumes</source>
        <translation>Skannaa alitaltiot</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="609"/>
        <source>New &amp;layout</source>
        <translation>Uusi &amp;asettelu</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="610"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Nollaa asettelu</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="612"/>
        <source>Layout &amp;Builder...</source>
        <translation>Layout &amp;Builder...</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="639"/>
        <source>Remove subvolume</source>
        <translation>Poista alitaltio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="797"/>
        <source>Unlock Drive</source>
        <translation>Avaa levyn lukitus</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="801"/>
        <source>Password:</source>
        <translation>Salasana:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="833"/>
        <source>Could not unlock device.</source>
        <translation>Lukituksen avaaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="863"/>
        <source>Failed to close %1</source>
        <translation>%1 sulkeminen epäonnistui</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="877"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="896"/>
        <source>Invalid subvolume label</source>
        <translation>Virheellinen alitaltion nimi</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="904"/>
        <source>Duplicate subvolume label</source>
        <translation>Päällekkäinen alitaltion nimi</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="913"/>
        <source>Invalid use for %1: %2</source>
        <translation>Käyttövirhe %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 on jo valittu: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="930"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Vähintään %1 root juuriosio vaaditaan.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="947"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Mahdoton toteuttaa /home alla root (/), jos erillinen /home osio on otettu käyttöön.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="960"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Valmistele osiotaulu %1 %2:lle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="958"/>
        <source>Re-use partition table on %1</source>
        <translation>Käytä osiotaulukkoa uudelleen kohteessa %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="834"/>
        <source>Possible incorrect password.</source>
        <translation>Mahdollisesti väärä salasana.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="967"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Käytä uudelleen (ei alusteta) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="970"/>
        <source>Format %1</source>
        <translation>Alusta %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="971"/>
        <source>Format %1 to use for %2</source>
        <translation>Alusta %1 käytettäväksi %2:lle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="972"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Käytä uudelleen (ei alustusta) %1 as %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="973"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Poista data sijainnista %1 paitsi /home, käytettäväksi %2:lle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="976"/>
        <source>Create %1 without formatting</source>
        <translation>Luo %1 ilman alustamista</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="977"/>
        <source>Create %1, format to use for %2</source>
        <translation>Luo %1 ja alusta se %2:lle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="992"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>Käytä alitaltiota %1 uudelleen nimellä %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="994"/>
        <source>Delete subvolume %1</source>
        <translation>Poista alitaltio %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="997"/>
        <source>Overwrite subvolume %1</source>
        <translation>Ylikirjoita alitaltio %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="998"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>Ylikirjoita alitaltio %1 käytettäväksi %2:lle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1000"/>
        <source>Create subvolume %1</source>
        <translation>Luo alitaltio %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1001"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>Luo alitaltio %1 käytettäväksi %2:lle</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <location filename="../partman.cpp" line="1084"/>
        <location filename="../partman.cpp" line="1119"/>
        <location filename="../partman.cpp" line="1161"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1017"/>
        <source>Encrypting root without a separate unencrypted boot partition is not supported.

Do you want to go back and select a boot partition?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1053"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) vaatii %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1079"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>Asennus voi epäonnistua, koska seuraavat asemat ovat liian pieniä:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1081"/>
        <source>Are you sure you want to continue?</source>
        <translation>Haluatko varmasti jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1094"/>
        <source>This setup may produce an unbootable system. Do you want to continue?</source>
        <translation>Tämä asennus saattaa tuottaa järjestelmän, jota ei voi käynnistää. Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1100"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Tämä tietokone käyttää EFI:ä, mutta kelvollista EFI osiota ei ole määritetty /boot/efi:lle erikseen.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1103"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>Tiedostolle /boot/efi määritetty asema ei ole kelvollinen EFI-järjestelmäosio.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1146"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>Seuraavat asemat on asennettu tai tullaan asentamaan GPT:n kanssa, mutta niissä ei ole BIOS-GRUB osiota:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1148"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>Tämä tietokone ei välttämättä käynnisty GPT-asemilta ilman BIOS-GRUB osiota.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1203"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Levyt ja niiden asennukseen valitut osiot ovat vikautumassa:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1207"/>
        <source>Smartmon tool output:</source>
        <translation>Smartmon-työkalun ulosanti:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1208"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Asennukseen valitut levyt ja niiden osiot läpäisivät SMART-valvontatestin (smartctl), mutta suoritetut kokeet osoittavat keskimääräistä korkeampaa hajoamisvaaran tasoa lähitulevaisuudessa.  </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1215"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Jos olet epävarma, poistu asennusohjelmasta sekä aja GSmartControl-ohjelma saadaksesi enemmän tietoa.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1219"/>
        <source>Do you want to abort the installation?</source>
        <translation>Haluatko keskeyttää asennuksen?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1225"/>
        <source>Do you want to continue?</source>
        <translation>Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1294"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Vaadittujen osioiden valmistelu epäonnistui.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1338"/>
        <source>Preparing partition tables</source>
        <translation>Valmistellaan osiointitauluja</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1366"/>
        <source>Preparing required partitions</source>
        <translation>Valmistellaan vaadittavia osioita</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1430"/>
        <source>Failed to format partition.</source>
        <translation>Osion alustaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1437"/>
        <source>Formatting: %1</source>
        <translation>Alustetaan: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1515"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Alitaltion valmistelu epäonnistui.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1516"/>
        <source>Preparing subvolumes</source>
        <translation>Valmistellaan alitaltioita</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1643"/>
        <source>Failed to mount partition.</source>
        <translation>Osion kiinnitys epäonnistui.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1656"/>
        <source>Mounting: %1</source>
        <translation>Kiinnitetään: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1840"/>
        <source>Model: %1</source>
        <translation>Malli: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1848"/>
        <source>Free space: %1</source>
        <translation>Tilaa vapaana: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1948"/>
        <source>Device</source>
        <translation>Laite</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1949"/>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1950"/>
        <source>Active</source>
        <translation>Aktiivinen</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1951"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1952"/>
        <source>Use For</source>
        <translation>Käytä tarkoitukseen</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1953"/>
        <source>Label</source>
        <translation>Nimilappu</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1954"/>
        <source>Encrypt</source>
        <translation>Salaa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1955"/>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1956"/>
        <source>Check</source>
        <translation>Tarkista</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1957"/>
        <source>Options</source>
        <translation>Asetukset</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1958"/>
        <source>Dump</source>
        <translation>Hylky</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1959"/>
        <source>Pass</source>
        <translation>Läpäisy</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1967"/>
        <source>Active partition</source>
        <translation>Aktiivinen osio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1968"/>
        <source>EFI System Partition</source>
        <translation>EFI Järjestelmäosio</translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2787"/>
        <source>&amp;Templates</source>
        <translation>&amp;Mallit</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2794"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Pakkaus (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2796"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Pakkaus (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2798"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Pakkaus (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Negligible</source>
        <translation>Mitätön</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Very weak</source>
        <translation>Erittäin heikko</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Weak</source>
        <translation>Heikko</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Moderate</source>
        <translation>Kohtalainen</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Strong</source>
        <translation>Vahva</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Very strong</source>
        <translation>Erittäin vahva</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="156"/>
        <source>Password strength: %1</source>
        <translation>Salasanan vahvuus: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Hide the password</source>
        <translation>Piilota salasana</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Show the password</source>
        <translation>Näytä salasana</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Gazelle Installer</source>
        <translation>Gazelle Installer</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="126"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Muokattava graafinen asennusohjelma MX Linux:ille ja antiX Linux:ille</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="129"/>
        <source>Enable advanced settings, even in regular installation mode.</source>
        <translation>Ota lisäasetukset käyttöön myös tavallisessa asennuksessa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Asentaa automaattisesti käyttäen määritystiedostoa (lisätietoja alla).
-- VAROITUS: mahdollisesti vaarallinen valinta, osio(t) tullaan pyyhkimään tyhjiksi automaattisesti.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Ohittaa osioiden ja asemien tarkistukset, jolloin ne näytetään.
-- VAROITUS: tämä voi rikkoa asioita. Käytä vain tapauksessa jossa aseman tietietojen häviämisellä ei ole merkitystä.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="134"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Lataa konfiguraatio, jonka määritetään &lt;config-file&gt;oletuksena
käyttämällä /etc/minstall.conf-tiedostoa.
Voidaan käyttää yhdessä --auto vivulla asennuksessa ilman valvontaa.
Asennusohjelma luo (tai korvaa) tiedoston /mnt/antiX/etc/minstall.conf ja tallentaa kopion tiedostoon /etc/minstalled.conf myöhempää käyttöä varten.
Asennusohjelma ei kirjoita salasanoja uuteen asetustiedostoon.
Huomaa, että tämä on kokeellista. Tulevat ohjelmaversiot voivat rikkoa yhteensopivuuden olemassa olevien määritystiedostojen kanssa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="140"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Sammuta automaattisesti kun asennus on valmis.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="141"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Älä irrota /mnt/antiX tai sulje mitään siihen liittyviä LUKS-säiliöitä, kun olet valmis.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="142"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Asenna käyttöjärjestelmä viivyttämällä käyttäjälle liittyvien asetusten kohteita ensimmäiseen uudelleenkäynnistykseen saakka. Käynnistyksen jälkeen asennusohjelma suoritetaan komennolla --oobe, jotta käyttäjä voi antaa omat tiedot. Tämä on hyödyllistä OEM-asennuksissa, myydessä tai luovuttaessa tietokonetta, jossa on valmiiksi ladattu käyttöjärjestelmä.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="145"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Suoraan paketista asetukset.
Käynnistyy automaattisesti, jos se asennetaan --oem-optiolla.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="147"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Graafinen testiversio, voit siirtyä eteenpäin eri näkymiin ilman varsinaista asennusta.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="148"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Käynnistyy automaattisesti uudelleen kun asennus on valmis.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="149"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Asennetaan käyttäen rsync:iä cp:n sijaan mukautetulla osioinnilla.
-- tämä ei formatoi /root-hakemistoa eikä toimi salauksen kanssa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="151"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Tarkasta asennusmedia aina alussa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="152"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>Älä tarkista asennusmediaa alussa. Ei suositella, ellei asennusmediassa ole taatusti virheitä.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="154"/>
        <source>Force TUI (Text User Interface) mode instead of GUI.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="155"/>
        <source>Jump directly to a specific page for testing (use with --pretend).
Page names: splash, terms, installation, partitions, confirm, boot, services, user, end</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="156"/>
        <source>&lt;page-name&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="157"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Lataa konfiguraatiotiedosto kuten&lt;config-file&gt; ilmaisee.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="167"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Liian monta argumenttia. Tarkista komento suorittamalla ohjelma lisäparametrin --help kanssa</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="177"/>
        <source>%1 Installer</source>
        <translation>Asennusohjelma %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="187"/>
        <source>The installer appears to be running already.</source>
        <translation>Asennusohjelma näyttää jo olevan käynnissä.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="188"/>
        <source>Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Sulje, jos mahdollista, tai suorita &quot;pkill minstall&quot; terminaalissa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="193"/>
        <location filename="../app.cpp" line="208"/>
        <location filename="../app.cpp" line="233"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="194"/>
        <source>The installer appears to be running already.
Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="203"/>
        <location filename="../app.cpp" line="209"/>
        <source>This operation requires root access.</source>
        <translation>Tämä toiminto vaatii pääkäyttäjän oikeudet.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="229"/>
        <location filename="../app.cpp" line="234"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Asetustiedostoa (%1) ei löytynyt.</translation>
    </message>
</context>
<context>
    <name>Replacer</name>
    <message>
        <location filename="../replacer.cpp" line="147"/>
        <source>Information</source>
        <translation>Tietoja</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="148"/>
        <source>Could not open any of the locked encrypted containers.
Possible incorrect password. Press the &apos;Scan&apos; button to try again with a different password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="163"/>
        <source>Volume %1 on drive %2</source>
        <translation>Osio %1 asemalla %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="203"/>
        <location filename="../replacer.cpp" line="429"/>
        <location filename="../replacer.cpp" line="437"/>
        <source>Error</source>
        <translation>Virhe</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="204"/>
        <source>No existing installation selected.</source>
        <translation>Olemassa olevaa asennusta ei ole valittu.</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="281"/>
        <source>Replace the installation in %1: %2</source>
        <translation>Korvaa asennus kohteessa %1: %2</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="303"/>
        <location filename="../replacer.cpp" line="359"/>
        <source>Unlock encrypted volumes</source>
        <translation>Avaa salatut osiot</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="307"/>
        <location filename="../replacer.cpp" line="363"/>
        <source>Password:</source>
        <translation>Salasana:</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="365"/>
        <source>Ignore encrypted volumes</source>
        <translation>Ohita salatut osiot</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="430"/>
        <source>Cannot unlock encrypted partition: %1</source>
        <translation>Salauksen sisältävää osiota ei voida avata: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="438"/>
        <source>Cannot find partition listed in crypttab: %1</source>
        <translation>Crypttab-lueteltua osiota ei löydy: %1</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="458"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="459"/>
        <source>Could not re-lock encrypted device(s): %1</source>
        <translation>Salattuja asemia ei voitu lukita uudelleen: (%1)</translation>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="57"/>
        <source>Recommended maximum: %1 MB</source>
        <translation>Suositeltu maksimi: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="60"/>
        <source>Unable to query RAM size.</source>
        <translation>Keskusmuistin koon kysely epäonnistui.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="97"/>
        <source>Invalid location</source>
        <translation>Virheellinen sijainti</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="100"/>
        <source>Maximum: %1 MB</source>
        <translation>Enintään: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="117"/>
        <source>Failed to configure zram swap.</source>
        <translation>Määritys zram-swap epäonnistui.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="127"/>
        <source>Failed to create or install swap file.</source>
        <translation>Swap tiedoston luonti tai asennus epäonnistui.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="133"/>
        <source>Creating swap file</source>
        <translation>Luodaan swap tiedostoa</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="146"/>
        <source>Configuring swap file</source>
        <translation>Konfiguroidaan swap tiedostoa</translation>
    </message>
</context>
</TS>