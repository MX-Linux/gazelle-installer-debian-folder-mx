<?xml version="1.0" ?><!DOCTYPE TS><TS version="2.1" language="gl">
<context>
    <name>AutoPart</name>
    <message>
        <location filename="../autopart.cpp" line="60"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="61"/>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="175"/>
        <source>The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="177"/>
        <source>Are you sure you want to continue?</source>
        <translation>Tes a certeza de que queres continuar?</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="183"/>
        <source>The system and home drives cannot be the same for this type of installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="187"/>
        <source>Format and use drives entirely for %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="189"/>
        <source>System drive: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="191"/>
        <source>Home drive: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="194"/>
        <source>Format and use the entire drive for %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="224"/>
        <source>Recommended: %1
Minimum: %2</source>
        <translation>Recomendado: %1
Mínimo: %2</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="226"/>
        <source>Minimum for hibernation support: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../autopart.cpp" line="268"/>
        <source>Layout Builder</source>
        <translation>Construtor de Layout</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="468"/>
        <source>%1% root
%2% home</source>
        <translation>%1% raíz
%2% inicio</translation>
    </message>
    <message>
        <location filename="../autopart.cpp" line="470"/>
        <source>Combined root and home</source>
        <translation>Raíz e inicio combinados</translation>
    </message>
</context>
<context>
    <name>Base</name>
    <message>
        <location filename="../base.cpp" line="90"/>
        <source>Cannot access installation media.</source>
        <translation>Non se pode acceder á fonte de instalación.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="261"/>
        <source>Failed to delete old system on destination.</source>
        <translation>Fallou a eliminación do sistema antigo no destino.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="264"/>
        <source>Deleting old system</source>
        <translation>Eliminando o sistema antigo</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="288"/>
        <source>Failed to set the system configuration.</source>
        <translation>Fallou a configuración do sistema.</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="290"/>
        <source>Setting system configuration</source>
        <translation>Establecendo a configuración do sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="452"/>
        <source>Copying new system</source>
        <translation>Gravando o novo sistema</translation>
    </message>
    <message>
        <location filename="../base.cpp" line="624"/>
        <source>Failed to copy the new system.</source>
        <translation>Fallou a copia do novo sistema.</translation>
    </message>
</context>
<context>
    <name>BootMan</name>
    <message>
        <location filename="../bootman.cpp" line="133"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>A instalación do GRUB fallou. É posible reparar a instalación do GRUB reiniciando o computador co sistema externo e usando o menú &apos;Recuperación do GRUB&apos;.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="207"/>
        <source>Installing GRUB</source>
        <translation>Instalando GRUB</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="470"/>
        <source>Updating initramfs</source>
        <translation>Actualizando initramfs</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="471"/>
        <source>Failed to update initramfs.</source>
        <translation>Fallou a actualización do initramfs.</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="529"/>
        <source>System boot disk:</source>
        <translation>Disco de arranque do sistema:</translation>
    </message>
    <message>
        <location filename="../bootman.cpp" line="544"/>
        <location filename="../bootman.cpp" line="554"/>
        <source>Partition to use:</source>
        <translation>Partición para usar:</translation>
    </message>
</context>
<context>
    <name>CheckMD5</name>
    <message>
        <location filename="../checkmd5.cpp" line="67"/>
        <source>The installation media is corrupt.</source>
        <translation>O medio de instalación está corrupto.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="76"/>
        <source>The installation media is still being checked.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="77"/>
        <source>Are you sure you want to skip checking the installation media?</source>
        <translation>Estás seguro de que queres omitir a comprobación dos medios de instalación?</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="233"/>
        <source>Checking installation media.</source>
        <translation>Comprobando os medios de instalación.</translation>
    </message>
    <message>
        <location filename="../checkmd5.cpp" line="234"/>
        <source>Press ESC to skip.</source>
        <translation>Premede ESC para saltar.</translation>
    </message>
</context>
<context>
    <name>Crypto</name>
    <message>
        <location filename="../crypto.cpp" line="63"/>
        <source>Failed to format LUKS container.</source>
        <translation>Fallou o formato do contedor LUKS.</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="67"/>
        <source>Creating encrypted volume: %1</source>
        <translation>Creando o volume cifrado: %1</translation>
    </message>
    <message>
        <location filename="../crypto.cpp" line="72"/>
        <source>Failed to open LUKS container.</source>
        <translation>Erro ao abrir o contedor LUKS.</translation>
    </message>
</context>
<context>
    <name>Device</name>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Overwrite</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="2366"/>
        <source>Create</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="2367"/>
        <source>Delete</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="2371"/>
        <source>Preserve</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="2372"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="2373"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="484"/>
        <source>Unknown release</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="149"/>
        <source>Shutdown</source>
        <translation>Apagar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="442"/>
        <source>You are running 32-bit OS started in 64-bit UEFI mode.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="443"/>
        <source>The system will not be able to boot unless you restart the system in Legacy Boot (or similar mode) before proceeding.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="445"/>
        <source>Do you want to continue the installation?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="487"/>
        <source>The %1 installer will now perform the requested actions.</source>
        <translation>O instalador %1 agora realizará as accións solicitadas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="488"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Estas accións non poden ser revertidas. Continuar?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="500"/>
        <source>Support %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="501"/>
        <source>%1 is supported by people like you. Some help others at the support forum, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <location filename="../minstall.cpp" line="1769"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>O %1 é unha distribución Linux independente baseada na distribución Debian Stable.

O %1 usa algúns compoñentes do MEPIS Linux publicados abaixo a Licenza Apache. Algúns compoñentes do MEPIS foron modificados para o %1. 

Disfruta usando %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="668"/>
        <source>Preparing to install %1</source>
        <translation>Preparando para instalar o %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="683"/>
        <source>Paused for required operator input</source>
        <translation>Agardando que o operador introduza información requerida</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="695"/>
        <source>Setting system configuration</source>
        <translation>Establecendo a configuración do sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="707"/>
        <source>Cleaning up</source>
        <translation>Limpando</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="711"/>
        <source>Finished</source>
        <translation>Rematado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="733"/>
        <source>Configuring system. Please wait.</source>
        <translation>Configurando o sistema. Agarde.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="737"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Configuración completa. Reiniciando o sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="744"/>
        <source>The installation was aborted.</source>
        <translation>A instalación foi abortada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="768"/>
        <source>Pretending to install %1</source>
        <translation>Simulando a instalación do %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="812"/>
        <source>Invalid settings found in configuration file (%1).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="813"/>
        <source>Please review marked fields as you encounter them.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="239"/>
        <location filename="../minstall.cpp" line="911"/>
        <location filename="../minstall.cpp" line="927"/>
        <location filename="../minstall.cpp" line="956"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Os datos en /home non poden ser preservados porque a información requerida para este proceso non pode ser obtida.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="238"/>
        <location filename="../minstall.cpp" line="817"/>
        <location filename="../minstall.cpp" line="926"/>
        <location filename="../minstall.cpp" line="983"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Invalid settings found in configuration file (%1).
Please review marked fields as you encounter them.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="984"/>
        <location filename="../minstall.cpp" line="995"/>
        <source>Cannot find selected drive.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1042"/>
        <source>The home directory for %1 already exists.</source>
        <translation>O cartafol persoal par a%1 xa existe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1087"/>
        <source>General Instructions</source>
        <translation>Instrucións xerais</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1088"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ANTES DE PROSEGUIR, PECHAR TODOS OS OUTROS APLICATIVOS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1089"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>En cada página, ler as instrucións, facer as escollas requeridas e premer en Seguinte. Será pedida confirmación de continuación antes de calquera accións destructivas seren executadas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1091"/>
        <source>Limitations</source>
        <translation>Limitacións</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1092"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Ter presente: este software está dispoñible COMO ESTÁ, sen ningún tipo de garantia. É da exclusiva responsabilidade do usuario facer unha copia de seguranza dos datos que teña no computador, antes de proseguir.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1096"/>
        <source>Installation Options</source>
        <translation>Opcións da instalación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1097"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>En computadores con sistema operativo Mac ou Windows (Vista ou posterior), poderá ser necesario usar o software do sistema existente para facer particións e instalar o xestor de arranque antes de proceder á instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1098"/>
        <source>Dual drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1099"/>
        <source>If your system has multiple storage drives, this option allows you to have the system files on one drive (the System drive), while keeping the data of all users on a separate drive (the Home drive).</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1101"/>
        <source>Using the root-home space slider</source>
        <translation>Usando o control deslizante de espazo raíz-home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1102"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation>A unidade pódese dividir en particións separadas do sistema (raíz) e dos datos do usuario (casa) usando o control deslizante.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1103"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation>A partición &lt;b&gt;raíz&lt;/b&gt; conterá o sistema operativo e os aplicativos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1104"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation>A partición do &lt;b&gt;inicio&lt;/b&gt; conterá os datos de todos os usuarios, como a súa configuración, ficheiros, documentos, imaxes, música, vídeos, etc.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1105"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Move o control deslizante cara á dereita para aumentar o espazo para &lt;b&gt;raíz&lt;/b&gt;. Móveo cara á esquerda para aumentar o espazo para o &lt;b&gt;inicio&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1106"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Move o control deslizante completamente cara á dereita se queres tanto raíz como inicio na mesma partición.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1107"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Manter o directorio de inicio nunha partición separada mellora a fiabilidade das actualizacións do sistema operativo. Tamén facilita a copia de seguridade e a recuperación. Isto tamén pode mellorar o rendemento xeral ao limitar os ficheiros do sistema a unha parte definida da unidade.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1109"/>
        <location filename="../minstall.cpp" line="1207"/>
        <location filename="../minstall.cpp" line="1227"/>
        <source>Encryption</source>
        <translation>Encriptación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1110"/>
        <location filename="../minstall.cpp" line="1208"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>É posible encriptación vía LUKS. É necesario un contrasinal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1111"/>
        <location filename="../minstall.cpp" line="1209"/>
        <source>A separate unencrypted boot partition is required.</source>
        <translation>Requírese unha partición de arranque sen cifrar separada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1112"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Cando é feita unha instalación automática encriptada, é automaticamente creada unha partición de arranque separada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1113"/>
        <source>Using a custom disk layout</source>
        <translation>Usando un deseño de disco personalizado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1114"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Se precisa máis control sobre onde está instalado %1, seleccione &quot;&lt;b&gt;%2&lt;/b&gt;&quot; e prema &lt;b&gt;Seguinte&lt;/b&gt;. Na seguinte páxina, entón poderás seleccionar e configurar os dispositivos de almacenamento e as particións que necesitas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <location filename="../minstall.cpp" line="1122"/>
        <source>Replace existing installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1117"/>
        <source>Replace existing installation option will attempt to replace an existing installation with the same disk configuration as the existing installation.  Home directories are preserved.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1123"/>
        <source>If you have an existing installation, you can use this function to replace it with a fresh installation.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1124"/>
        <source>This is particularly useful if you are upgrading from a previous version and want to preserve your data.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1126"/>
        <source>There is no guarantee of this working successfully. Ensure you have a good working backup of all important data before continuing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1127"/>
        <source>This feature is designed to replace an installation performed using the regular install method, and may fail to replace an installation with a complex layout or storage scheme. Corruption or data loss may occur.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>To replace an installation with a complex layout or storage scheme, it is recommended to use the custom layout option instead.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1137"/>
        <source>Choose Partitions</source>
        <translation>Escoller particións</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1138"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>A lista de particións permítelle escoller que particións se usan para esta instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1139"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Dispositivo&lt;/i&gt; - Este é o nome do dispositivo de bloque que se asigna ou será asignado á partición creada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1140"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Tamaño&lt;/i&gt; - O tamaño da partición. Isto só se pode cambiar nun novo arranxo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1141"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation>&lt;i&gt;Usar para&lt;/i&gt; - Para usar esta partición nunha instalación, debes seleccionar algo aquí.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1143"/>
        <source>Format without mounting</source>
        <translation>Formatar sen montaxe</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1144"/>
        <source>BIOS Boot GPT partition for GRUB</source>
        <translation>Partición de Arranque BIOS  GPT para GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1145"/>
        <location filename="../minstall.cpp" line="1184"/>
        <source>EFI System Partition</source>
        <translation>Partición do sistema EFI</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1147"/>
        <source>Boot manager</source>
        <translation>Xestor de Boot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1148"/>
        <source>System root</source>
        <translation>Sistema raíz</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1149"/>
        <source>User data</source>
        <translation>Datos do usuario</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1150"/>
        <source>Static data</source>
        <translation>Datos estáticos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1151"/>
        <source>Variable data</source>
        <translation>Datos variables</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1152"/>
        <source>Temporary files</source>
        <translation>Ficheiros temporarios</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>Swap files</source>
        <translation>Arquivos swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1154"/>
        <source>Swap partition</source>
        <translation>partición swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1156"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation>Ademais do anterior, tamén pode escribir o seu propio punto de montaxe. Os puntos de montaxe personalizados deben comezar cunha barra (&quot;/&quot;).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1157"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etiqueta&lt;/i&gt; - A etiqueta que se lle asigna á partición unha vez formatada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1158"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation>&lt;i&gt;Cifrar&lt;/i&gt; - Use o cifrado LUKS para esta partición. O contrasinal aplícase a todas as particións seleccionadas para o cifrado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Formato&lt;/i&gt; - Este é o formato da partición. Os formatos dispoñibles dependen do que se utilice a partición. Cando traballes cun deseño existente, podes conservar o formato da partición seleccionando &lt;b&gt;Conservar&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1161"/>
        <source>Selecting &lt;b&gt;Preserve /home&lt;/b&gt; for the root partition preserves the contents of the /home directory, deleting everything else. This option can only be used when /home is on the same partition as the root partition.</source>
        <translation>Seleccionar &lt;b&gt;Preservar /home&lt;/b&gt; para a partición raíz preserva o contido do directorio /home, eliminando todo o demais. Esta opción só pode ser utilizada cando /home está na mesma partición que a partición raíz.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1163"/>
        <source>The ext2, ext3, ext4, jfs, xfs and btrfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Os sistemas de ficheiros Linux ext2, ext3, ext4, jfs, xfs e btrfs son compatibles e recoméndase o ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>&lt;i&gt;Check&lt;/i&gt; - Check and correct for bad blocks on the drive (not supported for all formats). This is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>&lt;i&gt;Comprobar&lt;/i&gt; - Comprobe e corrixa os bloques defectuosos na unidade (non é compatible con todos os formatos). Isto leva moito tempo, polo que pode querer omitir este paso a menos que sospeite que a súa unidade ten bloques defectuosos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1166"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Opcións de montaxe&lt;/i&gt; - Especifica as opcións de montaxe que se usarán para esta partición.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1167"/>
        <source>&lt;i&gt;Dump&lt;/i&gt; - Instructs the dump utility to include this partition in the backup.</source>
        <translation>&lt;i&gt;Volcado&lt;/i&gt; - Indica á utilidade de volcado que inclúa esta partición na copia de seguridade.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1168"/>
        <source>&lt;i&gt;Pass&lt;/i&gt; - The sequence in which this file system is to be checked at boot. If zero, the file system is not checked.</source>
        <translation>&lt;i&gt;Pasar&lt;/i&gt; - A secuencia na que se comprobará este sistema de ficheiros no inicio. Se é cero, o sistema de ficheiros non está marcado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1169"/>
        <source>Menus and actions</source>
        <translation>Menús e accións</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Hai unha variedade de accións dispoñibles premendo co botón dereito en calquera elemento da unidade ou partición da lista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1171"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Os botóns á dereita da lista tamén se poden usar para manipular as entradas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1172"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>O instalador non pode modificar o deseño que xa está na unidade. Para crear un deseño personalizado, marque a unidade para un novo deseño co botón ou acción do menú &lt;b&gt;Novo deseño&lt;/b&gt; (% 1). Isto borra o deseño existente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1175"/>
        <source>Basic layout requirements</source>
        <translation>Requisitos básicos de disposición</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1176"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>O %1 require unha partición raíz. A partición de trocas é opcional mais altamente recomendada. Para usar a función Hibernar do %1 é necesaria unha partición de trocas maior que a memoria RAM física no computador.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1178"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Ter unha partición /home separada facilitará no futuro a substitución do sistema por unha nova versión. Mais se o sistema instalado non tiver nunha partición /home separada, non será posible creala posteriormente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1180"/>
        <source>Active partition</source>
        <translation>Partición activa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>For the installed operating system to boot, the appropriate partition (usually the boot or root partition) must be the marked as active.</source>
        <translation>Para que o sistema operativo instalado se inicie, a partición adecuada (normalmente a partición de inicio ou raíz) debe estar marcada como activa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1182"/>
        <source>The active partition of a drive can be chosen using the &lt;b&gt;Active partition&lt;/b&gt; menu action.</source>
        <translation>A partición activa dunha unidade pódese escoller mediante a acción do menú &lt;b&gt;Partición activa&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>A partition with an asterisk (*) next to its device name is, or will become, the active partition.</source>
        <translation>Unha partición cun asterisco (*) xunto ao nome do seu dispositivo é, ou pasará a ser, a partición activa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1185"/>
        <source>If your system uses the Extensible Firmware Interface (EFI), a partition known as the EFI System Partition (ESP) is required for the system to boot.</source>
        <translation>Se o teu sistema utiliza a Interface de Firmware Extensible (EFI), é necesario unha partición coñecida como Partición do Sistema EFI (ESP) para que o sistema se inicie.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1186"/>
        <source>These systems do not require any partition marked as Active, but instead require a partition formatted with a FAT file system, marked as an ESP.</source>
        <translation>Estes sistemas non requiren ningunha partición marcada como Activa, senón que requiren unha partición formatada cun sistema de ficheiros FAT, marcada como ESP.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1187"/>
        <source>Most systems built within the last 10 years use EFI.</source>
        <translation>A maioría dos sistemas construídos nos últimos 10 anos usan EFI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>Boot partition</source>
        <translation>Partición de arranque</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1189"/>
        <source>This partition is generally only required for root partitions on virtual devices such as encrypted, LVM or software RAID volumes.</source>
        <translation>Esta partición xeralmente só é necesaria para particións raíz en dispositivos virtuais, como volumes cifrados, LVM ou RAID de soporte lóxico.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1190"/>
        <source>It contains a basic kernel and drivers used to access the encrypted disk or virtual devices.</source>
        <translation>Contén un núcleo básico e controladores utilizados para acceder ao disco cifrado ou aos dispositivos virtuais.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>BIOS-GRUB partition</source>
        <translation>Partición BIOS-GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1192"/>
        <source>When using a GPT-formatted drive on a non-EFI system, a 1MB BIOS boot partition is required when using GRUB.</source>
        <translation>Cando se utiliza unha unidade con formato GPT nun sistema que non é EFI, é necesaria unha partición de arranque da BIOS de 1 MB cando se utiliza GRUB.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1193"/>
        <source>Need help creating a layout?</source>
        <translation>Necesitas axuda para crear un deseño?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1194"/>
        <source>Just right-click on a drive and select &lt;b&gt;Layout Builder&lt;/b&gt; from the menu. This can create a layout similar to that of the regular install.</source>
        <translation>Só tes que facer clic co botón dereito nunha unidade e seleccionar &lt;b&gt;Constructor de Layout&lt;/b&gt; do menú. Isto pode crear un deseño semellante ao da instalación regular.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1195"/>
        <source>Upgrading</source>
        <translation>Actualizando</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1196"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation>Para actualizar desde unha instalación de Linux existente, seleccione a mesma partición doméstica que antes e seleccione &lt;b&gt;Conservar&lt;/b&gt; como formato.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1197"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation>Se non utiliza unha partición de inicio separada, seleccione &lt;b&gt;Conservar /home&lt;/b&gt; na entrada do sistema de ficheiros raíz para conservar o directorio /home existente situado na súa partición raíz. O instalador só conservará /home e eliminará todo o demais. Como resultado, a instalación levará moito máis tempo do habitual.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1199"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipo de sistema de ficheiros preferido</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs or btrfs.</source>
        <translation>%1, pode ser instalado en particións formatadas como ext2, ext3, ext4, f2fs, jfs, xfs ou btrfs.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1201"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Particións formatadas como btrfs poden usar opcións adicionais de compresión. O sistema Lzo proporciona rapidez de compresión, mais a taxa de compresión é menor. O sistema Zlib proporciona maior compresión, mais menor rapidez.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1203"/>
        <source>System partition management tool</source>
        <translation>Ferramenta de xestión de particións do sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1204"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Para obter máis control sobre os deseños das unidades (como modificar o deseño existente nun disco), preme no botón de xestión de particións (%1). Isto executará a ferramenta de xestión de particións do sistema operativo, que che permitirá crear o deseño exacto que necesitas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1210"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation>Para conservar unha partición cifrada, preme co botón dereito sobre ela e selecciona &lt;b&gt;Desbloquear&lt;/b&gt;. No diálogo que aparece, introduza un nome para o dispositivo virtual e o contrasinal. Cando se desbloquee o dispositivo, o nome que escolleches aparecerá en &lt;i&gt;Dispositivos virtuais&lt;/i&gt;, con opcións similares ás dunha partición normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation>Para que a partición cifrada se desbloquee no arranque, debe engadirse ao ficheiro crypttab. Use a acción do menú &lt;b&gt;Engadir a crypttab&lt;/b&gt; para facelo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1213"/>
        <source>Other partitions</source>
        <translation>Outras particións</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1214"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>O instalador permite que outras particións se creen ou usen para outros fins, pero ten en conta que os sistemas máis antigos non poden manexar unidades con máis de 4 particións.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1215"/>
        <source>Subvolumes</source>
        <translation>Subvolumes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1216"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation>Algúns sistemas de ficheiros, como Btrfs, admiten varios subvolumes nunha única partición. Non son subdivisións físicas, polo que non importa a súa orde.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1218"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation>Use a acción de menú &lt;b&gt;Escanear subvolumes&lt;/b&gt; para buscar subvolumes nunha partición Btrfs existente. Para crear un novo subvolume, use a acción do menú &lt;b&gt;Novo subvolume&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1220"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation>Poden conservarse os subvolumes existentes, pero o nome debe seguir sendo o mesmo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1221"/>
        <source>Virtual Devices</source>
        <translation>Dispositivos virtuais</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1222"/>
        <source>If the installer detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation>Se o instalador detecta algún dispositivo visual, como particións LUKS abertas, volumes lóxicos LVM ou volumes RAID baseados en software, pódense utilizar para a instalación.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1223"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation>O uso de dispositivos virtuais (alén de preservar os sistemas de ficheiros cifrados) é unha característica avanzada. Pode que teña que editar algúns ficheiros (por exemplo, initramfs, crypttab, fstab) para asegurarse de que os dispositivos virtuais utilizados se cren ao iniciar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1228"/>
        <source>You have chosen to encrypt at least one volume, and more information is required before continuing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1233"/>
        <source>Final Review and Confirmation</source>
        <translation>Revisión final e confirmación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Please review this list carefully. This is the last opportunity to check, review and confirm the actions of the installation process before proceeding.</source>
        <translation>Por favor, revise esta lista coidadosamente. Esta é a última oportunidade para comprobar, revisar e confirmar as accións do proceso de instalación antes de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1244"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalar GRUB para Linux e Windows</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1245"/>
        <source>%1 uses the GRUB bootloader to boot %1 and Microsoft Windows.</source>
        <translation>%1 utiliza o carregador de arranque GRUB para arrancar %1 e Microsoft Windows.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1246"/>
        <source>By default GRUB is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.</source>
        <translation>Por defecto, GRUB está instalado no Master Boot Record (MBR) ou ESP (EFI System Partition para sistemas de arranque UEFI de 64 bits) do teu disco de arranque e substitúe o gestor de arranque que estabas a usar antes. Isto é normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1247"/>
        <source>If you choose to install GRUB to Partition Boot Record (PBR) instead, then GRUB will be installed at the beginning of the specified partition. This option is for experts only.</source>
        <translation>Se escolle instalar GRUB no Rexistro de Arranque da Partición (PBR) en lugar diso, entón GRUB instalarase no comezo da partición especificada. Esta opción é só para expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1248"/>
        <source>If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.</source>
        <translation>Se desmarca a caixa Instalar GRUB, GRUB non se instalará neste momento. Esta opción é só para expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Generate host-specific initramfs will try to create an initramfs tailored for the particular device rather than a generic all-purpose initramfs. This option is for experts only.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Zram swap is a method of putting swap space in RAM.  A compressed swap device is placed in RAM.  It may be used in conjunction with other forms of swap, or on its own.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Automatically restart when the installation is done</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Welcome to %1 Installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2296"/>
        <source>reset size</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2684"/>
        <source>The system is being installed.
This may take several minutes.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2690"/>
        <source>Reboot automatically when installation completes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2724"/>
        <source>Installation complete</source>
        <translation>Instalación completada</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4128"/>
        <source>Installing...</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4447"/>
        <source>Could not unlock device. Incorrect password?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>Installation Confirmation</source>
        <translation>Confirmación de instalación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1935"/>
        <source>Please review the installation settings.

This is the last opportunity to check and confirm
the actions of the installation process.

Press ENTER to begin installation or Backspace to go back.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1960"/>
        <source>Enter computer name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1975"/>
        <source>Enter domain name</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1989"/>
        <source>Workgroup</source>
        <translation>Grupo de traballo</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2072"/>
        <source>Localization Settings</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2078"/>
        <source>Locale:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2089"/>
        <source>Time Area:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2100"/>
        <source>Time Zone:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2176"/>
        <source>System services will be configured with default settings.
You can modify service settings after installation
using your system's service manager.

Press ENTER to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2194"/>
        <source>Replace Existing Installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2210"/>
        <source>Custom Partitioning</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2224"/>
        <source>Apply</source>
        <translation>Aplicar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2258"/>
        <source>Swap File Configuration</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2271"/>
        <source>Location:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2282"/>
        <source>Size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2302"/>
        <source>Enable hibernation support</source>
        <translation>Habilitar o soporte de hibernación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2308"/>
        <source>Zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2313"/>
        <source>Enable zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2320"/>
        <source>Allocate based on RAM (%):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2335"/>
        <source>Allocate fixed size (MB):</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2482"/>
        <source>Encryption options</source>
        <translation>Opcións de encriptación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2487"/>
        <source>Encryption password:</source>
        <translation>Contrasinal de encriptación:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2498"/>
        <source>Confirm password:</source>
        <translation>Confirmar contrasinal:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2540"/>
        <source>Enter username</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2554"/>
        <source>Enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2567"/>
        <source>Re-enter password</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2640"/>
        <source>A home directory already exists for this user name.
Choose what to do with it:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="4942"/>
        <source>Passwords must match and not be empty.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5279"/>
        <source>Please enter a computer name.</source>
        <translation>Inserir un nome do computador.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5282"/>
        <source>The computer name contains invalid characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5285"/>
        <source>Please enter a domain name.</source>
        <translation>Introducir un nome de dominio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5288"/>
        <source>The computer domain contains invalid characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5291"/>
        <source>Please enter a workgroup.</source>
        <translation>Introducir un grupo de traballo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5622"/>
        <source>Please fill in all required fields before continuing.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5630"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5633"/>
        <location filename="../minstall.cpp" line="5636"/>
        <source>Please ensure the passwords match.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5651"/>
        <source>The chosen user name is in use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5655"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Non inseriches unha frase de acceso para %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5663"/>
        <source>You did not provide a password for the root account.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="5752"/>
        <source>Please select an option to continue.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1254"/>
        <location filename="../minstall.cpp" line="2263"/>
        <source>Create a swap file</source>
        <translation>Crear ficheiro swap</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="485"/>
        <source>Experimental</source>
        <comment>As In feature is not polished and may not work properly</comment>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1255"/>
        <source>A swap file is more flexible than a swap partition; it is considerably easier to resize a swap file to adapt to changes in system usage.</source>
        <translation>Un arquivo de swap é máis flexible ca unha partición swap; é considerablemente máis doado redimensionar un arquivo de swap para adaptarse aos cambios no uso do sistema.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>By default, this is checked if no swap partitions have been set, and unchecked if swap partitions are set. This option should be left untouched, and is for experts only.</source>
        <translation>Por defecto, isto está marcado se non se estableceron particións swap e desmarcado se se estableceron particións seap. Esta opción debe deixarse sen cambios e está destinada só a expertos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1262"/>
        <source>Common Services to Enable</source>
        <translation>Activar servizos comúns</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1263"/>
        <source>Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1268"/>
        <source>Computer Identity</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1269"/>
        <source>The computer name is a common unique name which will identify your computer if it is on a network.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1270"/>
        <source>The computer domain is unlikely to be used unless your ISP or local network requires it.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1271"/>
        <source>The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1273"/>
        <source>The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Localization Defaults</source>
        <translation>Configuración rexional predeterminada</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1279"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Establece a configuración rexional predeterminada. Isto aplicarase a non ser que sexan substituídos máis tarde polo usuario.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1280"/>
        <source>Configure Clock</source>
        <translation>Configurar reloxo</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1281"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Se tes un ordenador Apple ou Unix puro, o reloxo do sistema está configurado por defecto na hora do meridiano de Greenwich (GMT) ou na hora universal coordinada (UTC). Para cambialo, marque a caixa &lt;b&gt;&quot;O reloxo do sistema usa a hora local&quot;&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1283"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>O sistema arranca coa zona horaria predefinida como GMT/UTC. Para cambiar a zona horaria, despois de reiniciar a nova instalación, preme co botón dereito no reloxo no Panel e selecciona Propiedades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1285"/>
        <source>Service Settings</source>
        <translation>Configuración de servizos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1286"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>A maioría dos usuarios non deberían cambiar os valores predeterminados. Os usuarios con ordenadores con poucos recursos ás veces queren desactivar os servizos innecesarios para manter o uso da memoria RAM o máis baixo posible. Asegúrate de saber o que estás facendo!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1293"/>
        <source>Default User Login</source>
        <translation>Inicio de sesión de usuario predeterminado</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1294"/>
        <source>Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1296"/>
        <source>Root (administrator) account</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1297"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1299"/>
        <source>The root account is disabled on MX Linux, as administrative tasks are performed with an elevation prompt for the default user.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1300"/>
        <source>Enabling the root account is strongly recommended for antiX Linux.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1301"/>
        <source>Passwords</source>
        <translation>Contrasinais</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1302"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Introduza un novo contrasinal para a súa conta de usuario predeterminada e para a conta raíz. Cada contrasinal debe introducirse dúas veces.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1304"/>
        <source>No passwords</source>
        <translation>Non hai contrasinais</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Se queres que a conta de usuario predeterminada non teña contrasinal, deixa os campos de contrasinal baleiros. Isto permítelle iniciar sesión sen necesidade de contrasinal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1307"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Obviamente, isto só se debe facer en situacións nas que a conta de usuario non precisa estar segura, como un terminal público.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1316"/>
        <location filename="../minstall.cpp" line="2634"/>
        <source>Old Home Directory</source>
        <translation>Directorio home existente</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1317"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Xa existe un cartafol de usuario para o nome de usuario escollido. Esta táboa permítelle escoller que facer con este cartafol.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1319"/>
        <location filename="../minstall.cpp" line="2646"/>
        <source>Re-use it for this installation</source>
        <translation>Reusar para esta instalación</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1320"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>O cartafol de usuario existente utilizarase para esta conta de usuario. Esta é unha boa opción no caso de actualizarse, xa que os ficheiros e configuracións do usuario estarán inmediatamente dispoñibles.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1322"/>
        <location filename="../minstall.cpp" line="2653"/>
        <source>Rename it and create a new directory</source>
        <translation>Renomear e crear un novo cartafol</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1323"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Crearase un novo cartafol de usuario e cambiarase o nome ao cartafol existente. Os ficheiros e axustes de usuario non serán visibles de inmediato na nova instalación, pero pódese acceder mediante o cartafol renomeado.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1325"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>O cartafol de usuario existente terá un número ao final, que dependerá de cantas veces se cambiou o nome do cartafol antes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1326"/>
        <location filename="../minstall.cpp" line="2660"/>
        <source>Delete it and create a new directory</source>
        <translation>ELiminar e crear un novo cartafol de usuario</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1327"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>O cartafol do usuario existente será eliminada e será creado un novo. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1125"/>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1329"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Se é seleccionada esta opción, eliminaranse permanentemente todos os ficheiros e configuracións. A probabilidade de recuperarse é baixa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1341"/>
        <location filename="../minstall.cpp" line="2678"/>
        <source>Installation in Progress</source>
        <translation>Instalación en curso</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1342"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>Estase instalando %1. Unha nova instalación levará de 3 a 20 minutos, probablemente dependendo da velocidade do sistema e do tamaño das particións a reformatar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1344"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Premendo no botón Abrotar, a instalación será interormpida así que posible</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1346"/>
        <source>Change settings while you wait</source>
        <translation>Cambiar configuracións mentres espera</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1347"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Mentres se instala %1, é posible introducir outra información requirida premendo nos botóns &lt;b&gt;Seguinte&lt;/b&gt; e &lt;b&gt;Anterior&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Completar estes pasos sen présa. O instalador agardará pola introdución de información, se é necesario.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1361"/>
        <source>Congratulations!</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>You have completed the installation of %1.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1363"/>
        <source>Finding Applications</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>There are hundreds of excellent applications installed with %1. The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1368"/>
        <source>In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1370"/>
        <source>Enjoy using %1</source>
        <translation>Desfruta %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1444"/>
        <source>Finish</source>
        <translation>Finalizar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1447"/>
        <source>Start</source>
        <translation>Iniciar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1450"/>
        <source>OK</source>
        <translation>Aceptar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1452"/>
        <source>Next</source>
        <translation>Seguinte</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>The installation and configuration is incomplete.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1593"/>
        <source>Do you really want to stop now?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Obter axuda&lt;/b&gt;&lt;br/&gt; Información básica sobre% 1 en % 2. &lt;/p&gt;&lt;p&gt;Hai voluntarios que prestan axuda no foro% 3, % 4&lt;/p&gt;&lt;p&gt; Cando solicite axuda, teña presente a necesidade de detallar suficientemente a descrición do problema, así como información sobre o ordenador. Como regra xeral, as afirmacións como &quot;non funcionaron&quot; axudan a proporcionar unha boa axuda.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparación do sistema / instalación&lt;/b&gt;&lt;br/&gt; Se% 1 falla, ás veces é posible reparar o problema a través do soporte executable externo - CD / DVD ou penUSB - empregando calquera das utilidades% 1 ou unha das ferramentas estándar de Linux. &lt;/p&gt;&lt;p&gt;CD / DVD executable ou penUSB tamén se poden usar para recuperar datos de sistemas MS-Windows.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ao axustar o mesturador de son&lt;/b&gt;&lt;br/&gt;% 1 téntase configurar o mesturador de son, pero ás veces é necesario aumentar o volume ou desactivar a función &quot;silenciar&quot; nas canles do mesturador para escoitar o son. &lt;/p&gt;&lt;p&gt;O atallo para o mesturador atópase no menú. Prema para abrir o mesturador.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Manter o %1 actualizado&lt;/b&gt;&lt;br/&gt; Para informacións e actualizacións do %1, visitar &lt;/p&gt;&lt;p&gt;%2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1697"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Agradecementos&lt;/b&gt;&lt;br/&gt; a todos os que decidiron apoiar a% 1 co seu tempo, doazóns, suxestións, traballo, loanzas, ideas, promocionalo e / ou animándonos. &lt;/p&gt;&lt;p&gt;Sen eles% 1 non existiría.&lt;/p&gt;&lt;p&gt;O equipo de desenvolvemento% 2&lt;/p&gt;</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Axuda</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="51"/>
        <source>Live Log</source>
        <translation>Rexistro en directo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="72"/>
        <source>Back</source>
        <translation>Volver atrás</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="78"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="85"/>
        <source>Next</source>
        <translation>Seguinte</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="91"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="120"/>
        <source>Installation in progress</source>
        <translation>Instalación en curso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="135"/>
        <source>Abort</source>
        <translation>Abortar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="138"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="158"/>
        <source>Close</source>
        <translation>Cerrar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="177"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Recollendo información. Agarda.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="209"/>
        <source>Terms of Use</source>
        <translation>Termos de uso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Keyboard Settings</source>
        <translation>Configuración do teclado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="256"/>
        <source>Model:</source>
        <translation>Modelo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="271"/>
        <source>Variant:</source>
        <translation>Variante:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="297"/>
        <source>Change Keyboard Settings</source>
        <translation>Cambiar a configuración do teclado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="309"/>
        <source>Layout:</source>
        <translation>Esquema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Seleccionar o tipo de instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="435"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="445"/>
        <source>Home</source>
        <translation>Inicio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="520"/>
        <location filename="../meinstall.ui" line="542"/>
        <location filename="../meinstall.ui" line="1216"/>
        <source>%</source>
        <translation>%</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="555"/>
        <source>Encrypt</source>
        <translation>Encriptar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1184"/>
        <source>Enable hibernation support</source>
        <translation>Habilitar o soporte de hibernación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Instalación regular usando o disco enteiro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="381"/>
        <source>Dual drive</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="391"/>
        <source>System drive:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <source>Home drive:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="565"/>
        <source>Customize the disk layout</source>
        <translation>Personalizar o deseño do disco</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="572"/>
        <source>Replace existing installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="617"/>
        <source>Replace an existing installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="639"/>
        <source>Device</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Installation</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Scan for existing installations</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="679"/>
        <source>Replacement options</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Attempt to upgrade packages</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="696"/>
        <source>Choose partitions</source>
        <translation>Escoller as particións</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="705"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Marque a unidade seleccionada para que se borre para un novo deseño.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Show Grid</source>
        <translation>Mostrar grella</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Ctrl+G</source>
        <translation>Ctrl+G</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Execute o aplicativo de xestión de particións deste sistema operativo.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="747"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Eliminar unha entrada existente do deseño. Isto só funciona con entradas nun novo deseño.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Consulta o sistema operativo e recarga os deseños de todas as unidades.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="795"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Engada unha nova entrada de partición. Isto só funciona cun deseño novo.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="806"/>
        <source>Show advanced fields.</source>
        <translation>Mostrar campos avanzados.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="836"/>
        <source>Encryption options</source>
        <translation>Opcións de encriptación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="842"/>
        <source>Encryption password:</source>
        <translation>Contrasinal de encriptación:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="859"/>
        <source>Confirm password:</source>
        <translation>Confirmar contrasinal:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="893"/>
        <source>Installation Confirmation</source>
        <translation>Confirmación de instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="936"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instalar GRUB para Linux e Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="951"/>
        <source>System boot disk:</source>
        <translation>Disco de arranque do sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="999"/>
        <source>EFI System Partition</source>
        <translation>Partición do sistema EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1021"/>
        <source>Partition Boot Record</source>
        <translation>Opcións de arranque</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1024"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1046"/>
        <source>Master Boot Record</source>
        <translation>Gravar a instalación principal</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1052"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1055"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1068"/>
        <source>Location to install on:</source>
        <translation>Local onde instalar:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1075"/>
        <source>Generate host-specific initramfs image</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1114"/>
        <source>Create a swap file</source>
        <translation>Crear ficheiro de trocas</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1131"/>
        <location filename="../meinstall.ui" line="1255"/>
        <source> MB</source>
        <translation> MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1154"/>
        <source>Size:</source>
        <translation>Tamaño:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1177"/>
        <source>Location:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1194"/>
        <source>Enable zram swap</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1206"/>
        <source>Allocate based on RAM:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1235"/>
        <source>Recommended maximum: 100%</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1242"/>
        <source>Allocate fixed size:</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1292"/>
        <source>Common Services to Enable</source>
        <translation>Activar servizos comúns</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1302"/>
        <source>Service</source>
        <translation>Servizo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1307"/>
        <source>Description</source>
        <translation>Descrición</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Computer Network Names</source>
        <translation>Nomes do computador na rede</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1364"/>
        <source>Workgroup</source>
        <translation>Grupo de traballo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1377"/>
        <source>Workgroup:</source>
        <translation>Grupo de traballo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1390"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Servidor de ficheiros Samba, para interacción co sistema MS Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1406"/>
        <source>example.dom</source>
        <translation>exemplo.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1419"/>
        <source>Computer domain:</source>
        <translation>Dominio do computador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1442"/>
        <source>Computer name:</source>
        <translation>Nome do computador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1497"/>
        <source>Localization Defaults</source>
        <translation>Localización predeterminada</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>Locale:</source>
        <translation>Localización:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1537"/>
        <source>Configure Clock</source>
        <translation>Configurar reloxo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1578"/>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1606"/>
        <source>Timezone:</source>
        <translation>Zona horaria:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1651"/>
        <source>System clock uses local time</source>
        <translation>O reloxo do sistema usa a hora local</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1673"/>
        <source>Service Settings (advanced)</source>
        <translation>Servizos predeterminados (avanzados)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1691"/>
        <source>Adjust which services should run at startup</source>
        <translation>Definir os servizos a seren activados ao iniciar</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1694"/>
        <source>View</source>
        <translation>Vista</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1755"/>
        <source>Default User Account</source>
        <translation>Conta do usuario predeterminado</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1767"/>
        <source>Default user login name:</source>
        <translation>Usuario predeterminado:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1783"/>
        <source>username</source>
        <translation>nome do usuario</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1796"/>
        <source>Default user password:</source>
        <translation>Contrasinal do usuario predeterminado:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1822"/>
        <source>Confirm user password:</source>
        <translation>Confirmar o contrasinal do usuario:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1851"/>
        <source>Root (administrator) Account</source>
        <translation>Conta root (administrador)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1869"/>
        <source>Root password:</source>
        <translation>Contrasinal do root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1895"/>
        <source>Confirm root password:</source>
        <translation>Confirmar o contrasinal do root:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1924"/>
        <source>Autologin</source>
        <translation>Inicio de sesión automático</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1931"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Os cambios no ambiente de traballo feitas na sesión da instalación externa erán transpostas para o sistema instalado no disco ríxido</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1934"/>
        <source>Save live desktop changes</source>
        <translation>Gardar os cambios feitos na sesión da instalación externa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1941"/>
        <source>Copy the contents of Live-usb-storage from the live medium to the installed system&apos;s home directory</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1944"/>
        <source>Copy Live-usb-storage to installed system</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1983"/>
        <source>Existing Home Directory</source>
        <translation>Cartafol do usuario existente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Que facer co cartafol existente?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1999"/>
        <source>Re-use it for this installation</source>
        <translation>Reusar para esta instalación</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2006"/>
        <source>Rename it and create a new directory</source>
        <translation>Renomear e crear un novo cartafo</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2013"/>
        <source>Delete it and create a new directory</source>
        <translation>ELiminar e crear un novo cartafol de usuario</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2037"/>
        <source>Tips</source>
        <translation>Consellos</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2069"/>
        <source>Installation complete</source>
        <translation>Instalación completada</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2075"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Reiniciar automaticamente o sistema cando o instaldor se peche</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2094"/>
        <source>Reminders</source>
        <translation>Recordatorios</translation>
    </message>
</context>
<context>
    <name>Oobe</name>
    <message>
        <location filename="../oobe.cpp" line="410"/>
        <source>Please enter a computer name.</source>
        <translation>Inserir un nome do computador.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="414"/>
        <source>The computer name contains invalid characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../oobe.cpp" line="415"/>
        <location filename="../oobe.cpp" line="426"/>
        <location filename="../oobe.cpp" line="646"/>
        <source>Please choose a different name before proceeding.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../oobe.cpp" line="421"/>
        <source>Please enter a domain name.</source>
        <translation>Introducir un nome de dominio.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="425"/>
        <source>The computer domain contains invalid characters.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../oobe.cpp" line="434"/>
        <source>Please enter a workgroup.</source>
        <translation>Introducir un grupo de traballo.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="651"/>
        <source>The user name cannot contain special characters or spaces.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../oobe.cpp" line="661"/>
        <source>The chosen user name is in use.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../oobe.cpp" line="670"/>
        <source>Are you sure you want to continue?</source>
        <translation>Tes a certeza de que queres continuar?</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="675"/>
        <source>You did not provide a passphrase for %1.</source>
        <translation>Non inseriches unha frase de acceso para %1.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="680"/>
        <source>You did not provide a password for the root account.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../oobe.cpp" line="693"/>
        <source>Failed to set user account passwords.</source>
        <translation>Fallo ao crear contrasinais para a conta de usuario.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="725"/>
        <source>Failed to save old home directory.</source>
        <translation>Fallou ao gardar o cartafol persoal existente.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="734"/>
        <source>Failed to delete old home directory.</source>
        <translation>Fallou ao eliminar o cartafol persoal existente.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="755"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>A creación do cartafol de usuario fallou.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="763"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>A atribución do nome ao cartafol do usuario fallou.</translation>
    </message>
    <message>
        <location filename="../oobe.cpp" line="808"/>
        <source>Failed to set ownership or permissions of user directory.</source>
        <translation>Fallou ao establecer a propiedade ou permisos do directorio do usuario.</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="278"/>
        <location filename="../partman.cpp" line="956"/>
        <source>Virtual Devices</source>
        <translation>Dispositivos virtuais</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="555"/>
        <location filename="../partman.cpp" line="606"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Engadir partición</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="557"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Eliminar partición</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="566"/>
        <source>&amp;Lock</source>
        <translation>&amp;Bloquear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="570"/>
        <source>&amp;Unlock</source>
        <translation>&amp;Desbloquear</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="574"/>
        <location filename="../partman.cpp" line="803"/>
        <source>Add to crypttab</source>
        <translation>Engadir a crypttab</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="581"/>
        <source>New subvolume</source>
        <translation>Novo subvolume</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="582"/>
        <source>Scan subvolumes</source>
        <translation>Escanear subvolumes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="609"/>
        <source>New &amp;layout</source>
        <translation>Novo &amp;deseño</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="610"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Restablecer deseño</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="612"/>
        <source>Layout &amp;Builder...</source>
        <translation>Deseño &amp; Construtor de esquemas...</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="639"/>
        <source>Remove subvolume</source>
        <translation>Eliminar subvolume</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="797"/>
        <source>Unlock Drive</source>
        <translation>Desbloquear unidade</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="801"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="833"/>
        <source>Could not unlock device.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="863"/>
        <source>Failed to close %1</source>
        <translation>Erro ao pechar %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="877"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="896"/>
        <source>Invalid subvolume label</source>
        <translation>Etiqueta do subvolume inválida</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="904"/>
        <source>Duplicate subvolume label</source>
        <translation>Etiqueta do subvolume duplicada</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="913"/>
        <source>Invalid use for %1: %2</source>
        <translation>Uso inválido para %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="919"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 xa está seleccionado para: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="930"/>
        <source>A root partition of at least %1 is required.</source>
        <translation>Requírese unha partición de raíz de polo menos %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="947"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Non se pode conservar /home dentro da raíz (/) se tamén se monta unha partición /home separada.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="960"/>
        <source>Prepare %1 partition table on %2</source>
        <translation>Prepare a táboa de particións %1 en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="958"/>
        <source>Re-use partition table on %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="834"/>
        <source>Possible incorrect password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="967"/>
        <source>Reuse (no reformat) %1</source>
        <translation>Reutilizar (sen reformatar) %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="970"/>
        <source>Format %1</source>
        <translation>Formatar %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="971"/>
        <source>Format %1 to use for %2</source>
        <translation>Formatar %1 para usar para %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="972"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Reutiliza (sen reformatar) %1 como %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="973"/>
        <source>Delete the data on %1 except for /home, to use for %2</source>
        <translation>Elimina os datos en %1 excepto en /home, para usar en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="976"/>
        <source>Create %1 without formatting</source>
        <translation>Crear %1 sen formatar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="977"/>
        <source>Create %1, format to use for %2</source>
        <translation>Crear %1, formato para usar para %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="992"/>
        <source>Reuse subvolume %1 as %2</source>
        <translation>Reutilizar o subvolume %1 como %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="994"/>
        <source>Delete subvolume %1</source>
        <translation>Eliminar subvolume %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="997"/>
        <source>Overwrite subvolume %1</source>
        <translation>Sobrescribir subvolume %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="998"/>
        <source>Overwrite subvolume %1 to use for %2</source>
        <translation>Sobrescribe o subvolume %1 para usar en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1000"/>
        <source>Create subvolume %1</source>
        <translation>Crear subvolume %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1001"/>
        <source>Create subvolume %1 to use for %2</source>
        <translation>Crea o subvolume %1 para usar en %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <location filename="../partman.cpp" line="1084"/>
        <location filename="../partman.cpp" line="1119"/>
        <location filename="../partman.cpp" line="1161"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1017"/>
        <source>Encrypting root without a separate unencrypted boot partition is not supported.

Do you want to go back and select a boot partition?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1053"/>
        <source>%1 (%2) requires %3</source>
        <translation>%1 (%2) require %3</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1079"/>
        <source>The installation may fail because the following volumes are too small:</source>
        <translation>A instalación pode fallar porque os seguintes volumes son demasiado pequenos:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1081"/>
        <source>Are you sure you want to continue?</source>
        <translation>Tes a certeza de que queres continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1094"/>
        <source>This setup may produce an unbootable system. Do you want to continue?</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1100"/>
        <source>This system uses EFI, but no valid EFI system partition was assigned to /boot/efi separately.</source>
        <translation>Este sistema utiliza EFI, pero non se asignou ningunha partición de sistema EFI válida a /boot/efi por separado.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1103"/>
        <source>The volume assigned to /boot/efi is not a valid EFI system partition.</source>
        <translation>O volume asignado a /boot/efi non é unha partición do sistema EFI válida.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1146"/>
        <source>The following drives are, or will be, setup with GPT, but do not have a BIOS-GRUB partition:</source>
        <translation>As seguintes unidades están, ou serán, configuradas con GPT, pero non teñen unha partición BIOS-GRUB:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1148"/>
        <source>This system may not boot from GPT drives without a BIOS-GRUB partition.</source>
        <translation>É posible que este sistema non se inicie desde as unidades GPT sen unha partición BIOS-GRUB.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1203"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Os discos coas particións seleccionadas para a instalación están a fallar:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1207"/>
        <source>Smartmon tool output:</source>
        <translation>Resultados da ferramenta Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1208"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Os discos coas particións seleccionadas para instalación pasaron a proba de monitorización SMART (smartctl), mais as probas indican que terán unha taxa de falla superior á media no futuro próximo.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1215"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Se non ten a certeza, saia do instalador e execute o GSmartControl para máis información.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1219"/>
        <source>Do you want to abort the installation?</source>
        <translation>Abortar a instalación?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1225"/>
        <source>Do you want to continue?</source>
        <translation>Continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1294"/>
        <source>Failed to prepare required partitions.</source>
        <translation>Produciuse un erro ao preparar as particións necesarias.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1338"/>
        <source>Preparing partition tables</source>
        <translation>Preparando as táboas da partición</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1366"/>
        <source>Preparing required partitions</source>
        <translation>Preparando as particións necesarias</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1430"/>
        <source>Failed to format partition.</source>
        <translation>Fallou o formato da partición.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1437"/>
        <source>Formatting: %1</source>
        <translation>Formatando: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1515"/>
        <source>Failed to prepare subvolumes.</source>
        <translation>Produciuse un erro ao preparar os subvolumes.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1516"/>
        <source>Preparing subvolumes</source>
        <translation>Preparando subvolumes</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1643"/>
        <source>Failed to mount partition.</source>
        <translation>Fallou o montaxe da partición.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1656"/>
        <source>Mounting: %1</source>
        <translation>Montando: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1840"/>
        <source>Model: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1848"/>
        <source>Free space: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1948"/>
        <source>Device</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1949"/>
        <source>Size</source>
        <translation>Tamaño</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1950"/>
        <source>Active</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1951"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1952"/>
        <source>Use For</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1953"/>
        <source>Label</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1954"/>
        <source>Encrypt</source>
        <translation>Encriptar</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1955"/>
        <source>Format</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1956"/>
        <source>Check</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1957"/>
        <source>Options</source>
        <translation>Opcións</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1958"/>
        <source>Dump</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1959"/>
        <source>Pass</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../partman.cpp" line="1967"/>
        <source>Active partition</source>
        <translation>Partición activa</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1968"/>
        <source>EFI System Partition</source>
        <translation>Partición do sistema EFI</translation>
    </message>
</context>
<context>
    <name>PartMan::ItemDelegate</name>
    <message>
        <location filename="../partman.cpp" line="2787"/>
        <source>&amp;Templates</source>
        <translation>&amp;Modelos</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2794"/>
        <source>Compression (Z&amp;STD)</source>
        <translation>Compresión (Z&amp;STD)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2796"/>
        <source>Compression (&amp;LZO)</source>
        <translation>Compresión (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="2798"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation>Compresión (&amp;ZLIB)</translation>
    </message>
</context>
<context>
    <name>PassEdit</name>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Negligible</source>
        <translation>Insignificante</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Very weak</source>
        <translation>Moito débil</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="153"/>
        <source>Weak</source>
        <translation>Débil</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Moderate</source>
        <translation>Moderado</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Strong</source>
        <translation>Forte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="154"/>
        <source>Very strong</source>
        <translation>Moito forte</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="156"/>
        <source>Password strength: %1</source>
        <translation>Forza do contrasinal: %1</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Hide the password</source>
        <translation>Agochar o contrasinal</translation>
    </message>
    <message>
        <location filename="../passedit.cpp" line="189"/>
        <source>Show the password</source>
        <translation>Amosar o contrasinal</translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../app.cpp" line="123"/>
        <source>Gazelle Installer</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="126"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Instalador de GUI personalizable para MX Linux e antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="129"/>
        <source>Enable advanced settings, even in regular installation mode.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="130"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Instálase automaticamente mediante o ficheiro de configuración (máis información a continuación).
-- AVISO: opción potencialmente perigosa, borrará as partición(s) automaticamente.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="132"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Anula as comprobacións de cordura en particións e unidades, facendo que se amosen.
-- AVISO: isto pode romper cousas, úsao só se non che importan os datos da unidade.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="134"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Cargue un ficheiro de configuración segundo o especificado por &lt;config-file&gt;.
Por defecto utilízase /etc/minstall.conf.
Esta configuración pódese usar con --auto para unha instalación desatendida.
O instalador crea (ou sobrescribe) /mnt/antiX/etc/minstall.conf e garda unha copia en /etc/minstalled.conf para uso futuro.
O instalador non escribirá ningún contrasinal nin configuración ignorada no novo ficheiro de configuración.
Teña en conta que isto é experimental. As versións futuras do instalador poden romper a compatibilidade cos ficheiros de configuración existentes.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="140"/>
        <source>Shutdown automatically when done installing.</source>
        <translation>Apagado automático ao rematar a instalación.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="141"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation>Non desmonte /mnt/antiX nin peche ningún dos colectores LUKS asociados cando remate.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="142"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Instale o sistema operativo, atrasando as solicitudes de opcións específicas do usuario ata o primeiro reinicio.
Ao reiniciar, o instalador executarase con --oobe para que o usuario poida proporcionar estes detalles.
Isto é útil para instalacións OEM, vendendo ou regalando un ordenador cun sistema operativo precargado.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="145"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Opción de experiencia fóra da caixa.
Isto comezará automaticamente se o instala xunto coa opción --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="147"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Modo de proba para a GUI, pode avanzar a diferentes pantallas sen instalar realmente.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="148"/>
        <source>Reboots automatically when done installing.</source>
        <translation>Reinicia automaticamente ao rematar a instalación.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="149"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Instalación con rsync en lugar de cp en partición personalizada.
-- non formata /root e non funciona co cifrado.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="151"/>
        <source>Always check the installation media at the beginning.</source>
        <translation>Sempre comprobe os medios de instalación no comezo.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="152"/>
        <source>Do not check the installation media at the beginning.
Not recommended unless the installation media is guaranteed to be free from errors.</source>
        <translation>Non comprobe os medios de instalación no comezo.
Non se recomenda a menos que se garanta que os medios de instalación están libres de erros.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="154"/>
        <source>Force TUI (Text User Interface) mode instead of GUI.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="155"/>
        <source>Jump directly to a specific page for testing (use with --pretend).
Page names: splash, terms, installation, partitions, confirm, boot, services, user, end</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="156"/>
        <source>&lt;page-name&gt;</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="157"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Cargue un ficheiro de configuración segundo o especificado por &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="167"/>
        <source>Too many arguments. Please check the command format by running the program with --help</source>
        <translation>Demasiados argumentos. Comprobe o formato do comando executando o programa con --help</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="177"/>
        <source>%1 Installer</source>
        <translation>Instalador do %1</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="187"/>
        <source>The installer appears to be running already.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="188"/>
        <source>Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="193"/>
        <location filename="../app.cpp" line="208"/>
        <location filename="../app.cpp" line="233"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="194"/>
        <source>The installer appears to be running already.
Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../app.cpp" line="203"/>
        <location filename="../app.cpp" line="209"/>
        <source>This operation requires root access.</source>
        <translation>A operación require o acceso root.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="229"/>
        <location filename="../app.cpp" line="234"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Ficheiro de configuración (%1) non atopado.</translation>
    </message>
</context>
<context>
    <name>Replacer</name>
    <message>
        <location filename="../replacer.cpp" line="147"/>
        <source>Information</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="148"/>
        <source>Could not open any of the locked encrypted containers.
Possible incorrect password. Press the &apos;Scan&apos; button to try again with a different password.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="163"/>
        <source>Volume %1 on drive %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="203"/>
        <location filename="../replacer.cpp" line="429"/>
        <location filename="../replacer.cpp" line="437"/>
        <source>Error</source>
        <translation>Erro</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="204"/>
        <source>No existing installation selected.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="281"/>
        <source>Replace the installation in %1: %2</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="303"/>
        <location filename="../replacer.cpp" line="359"/>
        <source>Unlock encrypted volumes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="307"/>
        <location filename="../replacer.cpp" line="363"/>
        <source>Password:</source>
        <translation>Contrasinal:</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="365"/>
        <source>Ignore encrypted volumes</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="430"/>
        <source>Cannot unlock encrypted partition: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="438"/>
        <source>Cannot find partition listed in crypttab: %1</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../replacer.cpp" line="458"/>
        <source>Warning</source>
        <translation>Aviso</translation>
    </message>
    <message>
        <location filename="../replacer.cpp" line="459"/>
        <source>Could not re-lock encrypted device(s): %1</source>
        <translation type="unfinished"/>
    </message>
</context>
<context>
    <name>SwapMan</name>
    <message>
        <location filename="../swapman.cpp" line="57"/>
        <source>Recommended maximum: %1 MB</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../swapman.cpp" line="60"/>
        <source>Unable to query RAM size.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../swapman.cpp" line="97"/>
        <source>Invalid location</source>
        <translation>Opción inválida</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="100"/>
        <source>Maximum: %1 MB</source>
        <translation>Máximo: %1 MB</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="117"/>
        <source>Failed to configure zram swap.</source>
        <translation type="unfinished"/>
    </message>
    <message>
        <location filename="../swapman.cpp" line="127"/>
        <source>Failed to create or install swap file.</source>
        <translation>Fallou ao crear ou instalar o ficheiro swap.</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="133"/>
        <source>Creating swap file</source>
        <translation>Crear ficheiro swap</translation>
    </message>
    <message>
        <location filename="../swapman.cpp" line="146"/>
        <source>Configuring swap file</source>
        <translation>Configurando o ficheiro swap</translation>
    </message>
</context>
</TS>