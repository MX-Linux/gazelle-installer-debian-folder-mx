inline const QString VERSION {"26.5.2mx25"};
