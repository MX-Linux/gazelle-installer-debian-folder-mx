<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="it">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="96"/>
        <source>%1 Installer</source>
        <translation>%1 Installer</translation>
    </message>
    <message>
        <source>Gathering Information, please stand by.</source>
        <translation type="vanished">Fase di elaborazione delle informazioni, si prega di attendere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="56"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="113"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Sostieni %1

%1 è sostenuta da persone come te. Alcuni aiutano altri nel forum di supporto - %2, o traducono guide in lingue diverse, danno consigli, scrivono documentazione, o aiutano a testare nuovo software.</translation>
    </message>
    <message>
        <source>Cannot access source medium.
Activating pretend installation.</source>
        <translation type="vanished">Impossibile accedere al supporto di origine.
Attivazione dell&apos;installazione fittizia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="350"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 è una distribuzione Linux independente basata su Debian Stabile.

%1 usa alcuni componenti da MEPIS Linux che sono rilasciati con una licenza libera Apache. Alcuni componenti MEPIS sono stati modificati per %1.

Prova il piacere di usare %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="472"/>
        <source>Pretending to install %1</source>
        <translation>Simulazione di installazione di %1</translation>
    </message>
    <message>
        <source>target drive</source>
        <translation type="vanished">unità di destinazione</translation>
    </message>
    <message>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="vanished">I dischi con le partizioni che hai selezionato per l&apos;installazione non rispondono:</translation>
    </message>
    <message>
        <source>Smartmon tool output:</source>
        <translation type="vanished">Output dello strumento Smartmon:</translation>
    </message>
    <message>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="vanished">I dischi con le partizioni che hai selezionato per l&apos;installazione hanno superato il test S.M.A.R.T. (smartctl), ma i test riferiscono che ci sono alte probabilità che nel prossimo futuro si possano presentare un numero di non conformità superiori alla media.</translation>
    </message>
    <message>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="vanished">Se non sei sicuro, per favore esci dall&apos;Installer e avvia GSmartControl per avere più informazioni.

</translation>
    </message>
    <message>
        <source>Do you want to abort the installation?</source>
        <translation type="vanished">Vuoi annullare l&apos;installazione?</translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="vanished">Vuoi continuare?</translation>
    </message>
    <message>
        <source>The password needs to be at least
%1 characters long. Please select
a longer password before proceeding.</source>
        <translation type="vanished">La password deve essere lunga almeno
%1 caratteri. Per favore, scegli
 una password più lunga prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="528"/>
        <source>Preparing to install %1</source>
        <translation>Preparazione all&apos;installazione di %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="540"/>
        <source>Failed to format required partitions.</source>
        <translation>Non si è riusciti a formattare le partizioni richieste.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="551"/>
        <source>Paused for required operator input</source>
        <translation>In pausa per necessità di input dell&apos;operatore</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="561"/>
        <source>Setting system configuration</source>
        <translation>Impostazioni di configurazione del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="579"/>
        <source>Cleaning up</source>
        <translation>Fase di pulizia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="739"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>Sono state riscontrate impostazioni non corrette nel file di configurazione (%1). Per cortesia ricontrolla i campi contrassegnati che ti verranno presentati.</translation>
    </message>
    <message>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="vanished">Configurazione dei contenitori criptati LUKS</translation>
    </message>
    <message>
        <source>Formatting swap partition</source>
        <translation type="vanished">Formattazione della partizione di swap in corso</translation>
    </message>
    <message>
        <source>Formatting the / (root) partition</source>
        <translation type="vanished">Formattazione della partizione / (root) in corso</translation>
    </message>
    <message>
        <source>Formatting boot partition</source>
        <translation type="vanished">Formattazione della partizione boot in corso</translation>
    </message>
    <message>
        <source>Formatting EFI System Partition</source>
        <translation type="vanished">Formattazione di EFI System Partition</translation>
    </message>
    <message>
        <source>Formatting the /home partition</source>
        <translation type="vanished">Formattazione della partizione /home in corso</translation>
    </message>
    <message>
        <source>Mounting the /home partition</source>
        <translation type="vanished">Montaggio della partizione  /home</translation>
    </message>
    <message>
        <source>Sorry, could not create %1 LUKS partition</source>
        <translation type="vanished">Spiacente, non si riesce a creare %1 partizione LUKS</translation>
    </message>
    <message>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation type="vanished">Spiacente, non si riesce ad aprire %1 contenitore LUKS </translation>
    </message>
    <message>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="vanished">Devi scegliere una partizione boot separata quando cripti root.</translation>
    </message>
    <message>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="vanished">Devi scegliere una partizione root.
La partizione root deve essere come minimo di %1 .</translation>
    </message>
    <message>
        <source>Delete the data on %1 except for /home</source>
        <translation type="vanished">Cancellare i dati su %1 ad eccezione della /home</translation>
    </message>
    <message>
        <source>Reuse (no reformat) %1 as the /home partition</source>
        <translation type="vanished">Riusare (senza riformattare) %1 come partizione /home</translation>
    </message>
    <message>
        <source>Configure %1 as swap space</source>
        <translation type="vanished">Configura %1 come spazio swap</translation>
    </message>
    <message>
        <source>The partition you selected for /boot is larger than expected.</source>
        <translation type="vanished">La partizione selezionata per /boot, è più grande di quel che ci si aspettava.</translation>
    </message>
    <message>
        <source>%1 for the %2 partition</source>
        <translation type="vanished">%1 per la partizione %2</translation>
    </message>
    <message>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="vanished">Le partizioni seguenti, che hai selezionato, non sono partizioni Linux:</translation>
    </message>
    <message>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="vanished">Sei sicuro di voler riformattare queste partizioni?</translation>
    </message>
    <message>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="vanished">%1 installer ora andrà a formattare e a distruggere i dati delle partizioni seguenti:</translation>
    </message>
    <message>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="vanished">%1 installer ora eseguirà le seguenti azioni:</translation>
    </message>
    <message>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="vanished">Queste azioni non possono essere annullate. Sei sicuro di voler continuare?</translation>
    </message>
    <message>
        <source>Creating required partitions</source>
        <translation type="vanished">Creazione delle partizioni richieste</translation>
    </message>
    <message>
        <source>Preparing required partitions</source>
        <translation type="vanished"> Preparazione delle partizioni richieste</translation>
    </message>
    <message>
        <source>Mounting the / (root) partition</source>
        <translation type="vanished">Montaggio della partizione  / (root)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Deleting old system</source>
        <translation>Eliminazione del vecchio sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Fallita eliminizione del vecchio %1 dalla sua posizione.
Torna allo Step 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="839"/>
        <source>Creating system directories</source>
        <translation>Creazione delle cartelle di sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="849"/>
        <source>Fixing configuration</source>
        <translation>Riparazione della configurazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="891"/>
        <source>Copying new system</source>
        <translation>Copia del nuovo sistema in corso</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="931"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Avanzamento di copiatura sconosciuto. Nessuna statistica del filesystem</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="940"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Fallita scrittura di %1 nella sua destinazione.
Torna allo Step 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="993"/>
        <source>Installing GRUB</source>
        <translation>Installazione di GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1061"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>L&apos;installazione di GRUB non è riuscita. Ad ogni modo è possibile riparare l&apos;installazione riavviando l&apos;unità live e poi utilizzare Ripara GRUB per riparare l&apos;installazione.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">Errore nell&apos;aggiornamento della variabile di boot NVRAM. Il sistema potrebbe non avviarsi, ma può essere riparato con il menu di boot Ripara GRUB.</translation>
    </message>
    <message>
        <source>Please enter a user name.</source>
        <translation type="vanished">Inserisci un nome utente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1184"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Il nome utente non può contenere caratteri speciali o spazi.
Prego, scegli un altro nome prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1195"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Spiacente, quel nome è già in uso.
Per favore, scegli un nome differente.</translation>
    </message>
    <message>
        <source>Please enter the user password.</source>
        <translation type="vanished">Inserisci la password dell&apos;utente</translation>
    </message>
    <message>
        <source>Please enter the root password.</source>
        <translation type="vanished">Inserisci la password di root</translation>
    </message>
    <message>
        <source>The user password entries do not match.
Please try again.</source>
        <translation type="vanished">Le password utente non combaciano.
Prego, riprova.</translation>
    </message>
    <message>
        <source>The root password entries do not match.
Please try again.</source>
        <translation type="vanished">Le password di root non combaciano.
Prego, riprova.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1214"/>
        <source>The home directory for %1 already exists.</source>
        <translation>La directory home per %1 esiste già.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1243"/>
        <source>Failed to set user account passwords.</source>
        <translation>Non si è riusciti ad impostare le password dell&apos;account utente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1263"/>
        <source>Failed to save old home directory.</source>
        <translation>Non si è riusciti a salvare la vecchia directory home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1270"/>
        <source>Failed to delete old home directory.</source>
        <translation>Non si è riusciti ad eliminare la vecchia directory home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1288"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Spiacente, la creazione della cartella utente è fallita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1296"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Spiacente, la denominazione della cartella utente è fallita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1317"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Spiacente, l&apos;impostazione della proprietà della cartella utente è fallita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1364"/>
        <source>Please enter a computer name.</source>
        <translation>Inserisci un nome per il computer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1368"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Il nome del tuo computer contiene caratteri non validi.
Devi scegliere un nome differente
prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1374"/>
        <source>Please enter a domain name.</source>
        <translation>Inserisci un nome di dominio.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1378"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Il dominio del tuo computer contiene caratteri non validi.
Devi scegliere un nome differente
 prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1385"/>
        <source>Please enter a workgroup.</source>
        <translation>Inserisci un nome di gruppo di lavoro.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1628"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>OK per formatare e usare l&apos;intero Disco (%1) per %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1632"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>ATTENZIONE: l&apos;unità selezionata ha una capacità di almeno 2 TB e deve essere formattata usando GPT. Su alcuni sistemi, un disco con formattazione GPT non si avvia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1657"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>I dati in /home non possono essere preservati perchè non è stato possibile ottenere le informazioni richieste.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1658"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation>Se la partizione contenente /home è crittografata, assicurarsi che sia selezionata correttamente la casella &quot;Crittografa&quot; (Encrypt) e che la password inserita sia corretta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1659"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation>L&apos;installer non può crittografare una directory o partizione /home già esistente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>General Instructions</source>
        <translation>Istruzioni generali</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1716"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>PRIMA DI PROCEDERE, CHIUDI TUTTE LE ALTRE APPLICAZIONI.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Si prega di leggere le istruzioni di ogni pagina, effettuate le vostre scelte, quindi cliccate su Avanti quando si è pronti a procedere. Vi verrà richiesta una conferma prima di qualsiasi azione distruttiva.</translation>
    </message>
    <message>
        <source>Installation requires about %1 of space. %2 or more is preferred. You can use the entire disk or you can put the installation on existing partitions.</source>
        <translation type="vanished">L&apos;installazione richiede circa %1 di spazio. %2 o più sono comunque preferibili. È possibile utilizzare l&apos;intero disco o effettuare l&apos;installazione su partizioni esistenti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Se stai usando Mac OS o Windows OS (da Vista in avanti), pui usare il software di quei sistemi per creare le partizioni e impostare il boot manager prima dell’installazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1769"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>I filesystem linux ext2, ext3, ext4, jfs, xfs, btrfs e reiserfs sono tutti supportati ma è raccomandato ext4.


</translation>
    </message>
    <message>
        <source>Autoinstall will place home on the root partition.</source>
        <translation type="vanished">L’installazione automatica posizionerà la home nella partizione root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1739"/>
        <location filename="../minstall.cpp" line="1801"/>
        <source>Encryption</source>
        <translation>Criptografia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <location filename="../minstall.cpp" line="1802"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>La crittografia è possibile attraverso LUKS. Si richiede una password.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1741"/>
        <location filename="../minstall.cpp" line="1803"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>È necessaria una partizione di boot separata non crittografata. Per impostazioni aggiuntive tra cui la scelta della cifratura, usa il pulsante &lt;b&gt;Impostazioni avanzate di crittografia&lt;/b&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Quando si utilizza l&apos;installazione automatica insieme alla crittografia, verrà creata automaticamente una partizione di boot separata .</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1719"/>
        <source>Limitations</source>
        <translation>Limitazioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="134"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished">Il programma di installazione non parte perché risulta essere già avviato in background.

Si prega di chiuderlo, se possibile, o eseguire &apos;pkill minstall&apos; nel terminale.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="167"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="218"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished">Stai usando un OS a 32 bit avviato in modalità UEFI a 64 bit, il sistema non sarà in grado di fare il boot a meno che non si vada a scegliere nel Bios la modalità Legacy Boot, o simile, al riavvio.
Noi ti raccomandiamo di chiudere ora e riavviare in Legacy Boot

Vuoi continuare l&apos;installazione ? </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="581"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="983"/>
        <source>Updating initramfs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Ricorda, questo software viene fornito così com&apos;è senza alcuna garanzia. È esclusiva responsabilità dell&apos;utente eseguire il backup dei dati prima di procedere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1725"/>
        <source>Installation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1731"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1735"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>Choose Partitions</source>
        <translation>Scegli le partizioni</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1763"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1765"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption. To preserve the format of an existing encrypted partition, you must use the same passphrase that it was originally encrypted with.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1772"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 richiede una partizione di root. La partizione di swap è facoltativa ma altamente consigliata. Se si desidera utilizzare la funzionalità di sospensione di %1, è necessario disporre di una partizione di swap con una dimensione più grande di quella della memoria fisica (RAM).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Se scegliete una partizione /home separata sarà più facile fare l&apos;aggiornamento in futuro, ma questo non sarà possibile se avete fatto l&apos;aggiornamento da un&apos;installazione che non ha una partizione home separata.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1784"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1785"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>Upgrading</source>
        <translation>Aggiornare</translation>
    </message>
    <message>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and check the preference to preserve data in /home.</source>
        <translation type="vanished">Per aggiornare da una esistente installazione Linux, selezionare la stessa partizione home precedente e confermare la preferenza per conservare i dati nella /home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1205"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1787"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation>Se conservate una directory /home esistente situata nella vostra partizione di root, l&apos;installer non riformatterà la partizione root. Come risultato, l&apos;installazione richiederà molto più tempo del previsto.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipo di Filesystem Preferito</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Per %1, potete scegliere di formattare le partizioni come ext2, ext3, ext4, f2fs, jfs, xfs. btrfs o reiser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Un&apos;addizionale opzione di compressione è disponibile per i dischi che usano btrfs. Lzo è veloce, ma la compressione è bassa. Zlib è lento, con una maggiore compressione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1794"/>
        <source>Bad Blocks</source>
        <translation>Blocco Difettoso</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Se scegliete ext2, ext3 o ext4 come tipo di format, avete l&apos;opzione di testare e correggere i blocchi difettosi nel disco. Il test dei blocchi difettosi richiede abbastanza tempo, così vorreste saltare questo passo senza sospettare che il vostro disco ha dei blocchi difettosi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1805"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>Advanced Encryption Settings</source>
        <translation>Impostazioni Avanzate di Crittografia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Questa pagina consente una regolazione precisa delle partizioni crittografate LUKS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1811"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Nella maggior parte dei casi, i valori predefiniti forniscono un pratico equilibrio tra sicurezza e prestazioni, che è una buona scelta per le applicazioni sensibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Questo testo affronta gli aspetti basilari dei parametri utilizzati con LUKS, il che non significa che sia una guida completa alla crittografia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>La modifica di una qualsiasi di queste impostazioni senza una buona conoscenza della crittografia può determinare l&apos;uso di una crittografia debole.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>La modifica di un campo spesso influisce sulle opzioni disponibili sotto di esso. I campi sottostanti possono essere automaticamente modificati con i valori consigliati.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Dove si ritiene di ottenere migliori prestazioni o maggiore sicurezza modificando le impostazioni dai valori raccomandati, lo si fa a proprio rischio e pericolo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Puoi usare il pulsante &lt;b&gt;Benchmark&lt;/b&gt; (che avvia la  &lt;i&gt;valutazione impostazioni di crittografia&lt;/i&gt; in un&apos;apposita finestra di terminale) per confrontare le prestazioni delle comuni combinazioni di hash, cifrari e modalità a catena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Si noti che &lt;i&gt;valutazione impostazioni di crittografia&lt;/i&gt; non considera tutte le combinazioni o selezioni possibili, e generalmente affronta le selezioni più comunemente utilizzate.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>Cipher</source>
        <translation>Cifrario</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>A variety of ciphers are available.</source>
        <translation>Sono disponibili una varietà di cifrari</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1822"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>è stato uno dei cinque migliori algoritmi AES. Si ritiene abbia un margine di sicurezza più elevato di Rijndael e di tutti gli altri finalisti per AES. Funziona meglio su alcune CPU a 64 bit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1823"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(anche conosciuto come &lt;i&gt;Rijndael&lt;/i&gt;) è un codice molto comune e molte CPU moderne includono istruzioni specifiche per AES, per via della sua ubiquità. Sebbene Rijndael sia stato designato come superiore a Serpent per le sue prestazioni, non ci si aspetta che siano praticabili attacchi attualmente.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1824"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>è il successore di Blowfish. È diventato uno dei cinque algoritmi finalisti per l&apos;AES, sebbene non sia stato scelto come standard.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1825"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) era un candidato al concorso per l&apos;AES, tuttavia non è diventato un finalista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1826"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>è un codice a blocchi a 64 bit creato da Bruce Schneier. Non è raccomandato per le applicazioni sensibili in quanto sono supportate solo le modalità CBC ed ECB. Blowfish supporta chiavi, multiple di 8, di dimensioni comprese tra 32 e 448 bit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>Chain mode</source>
        <translation>Modalità a catena</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Se i blocchi sono stati tutti crittografati utilizzando la stessa chiave, potrebbe emergere un modello e per riuscire a codificare il testo in chiaro.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1829"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>XEX-based Tweaked codebook with ciphertext Stealing) è una moderna modalità a catena, che supera CBC e EBC. E&apos; la modalità a catena di default (e raccomandata). Usando ESSIV su Plain64 si peggioreranno le prestazioni, con un guadagno in sicurezza trascurabile.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1830"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Cipher Block Chaining) è più semplice di XTS, ma vulnerabile ad un attacco padding oracle (in parte mitigato da ESSIV) e non è raccomandato per applicazioni sensibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1831"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic CodeBook) è meno sicuro di CBC e non dovrebbe essere usato per applicazioni sensibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1833"/>
        <source>IV generator</source>
        <translation>generatore di IV</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1833"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>Per XTS e CBC, questo seleziona come l&apos;&lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector viene generato. &lt;b&gt;ESSIV&lt;/b&gt; richiede una funzione di hash e perciò sarà disponibile un secondo menu a discesa se questo viene selezionato. Gli hash disponibili dipendono dal cifrario selezionato.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>La modalità ECB non utilizza un IV, per cui questi campi saranno tutti disabilitati se ECB è selezionata per la modalità a catena.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1836"/>
        <source>Key size</source>
        <translation>Dimensione chiave</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1836"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Imposta la dimensione della chiave in bit. Le dimensioni delle chiavi disponibili sono limitate dalle modalità a catena e cifratura.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1837"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>La modalità di cifratura a catena XTS divide la chiave a metà (per esempio, AES-256 in modalità XTS richiede una dimensione della chiave di 512-bit).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1839"/>
        <source>LUKS key hash</source>
        <translation>hash della chiave LUKS</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1839"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>l&apos;hash usata per PBKDF2 e per AF splitter.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 e RIPEMD-160 non sono più raccomandati per applicazioni sensibili in quanto si è riscontrato che possono essere rotti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1842"/>
        <source>Kernel RNG</source>
        <translation>Kernel RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1842"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Imposta quale generatore di numeri casuali del kernel verrà utilizzato per creare la chiave master del volume (che è una chiave a lungo termine).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1843"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Due opzioni sono disponibili: /dev/&lt;b&gt;random&lt;/b&gt; che blocca fino a quando si ottiene un&apos;entropia sufficiente (può impiegare molto tempo in situazioni di bassa entropia), e /dev/&lt;b&gt;urandom&lt;/b&gt; che non bloccherà anche se l&apos;entropia è insufficiente (è possibile che si abbiano chiavi più deboli).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1845"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF round time&lt;/b&gt;&lt;br/&gt;La quantità di tempo (in millisecondi) da impiegare con PBKDF2 passphrase processing.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1846"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Un valore di 0 seleziona il valore precompilato di default (esegui &lt;i&gt;cryptsetup --help&lt;/i&gt; per dettagli).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1847"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Se hai una macchina lenta, potresti voler aumentare questo valore per maggiore sicurezza, in cambio del tempo impiegato per sbloccare un volume dopo che è stata inserita una passphrase.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Seleziona Sistema di Boot&lt;/b&gt;&lt;br/&gt; %1 usa GRUB come caricatore del boot per l&apos;avvio sia di %1 che di MS-Windows. &lt;p&gt;Di default GRUB2 viene installato nell&apos;apposito Master Boot Record (MBR) o in ESP (EFI System Partition for 64-bit UEFI boot systems) presente nell&apos;Hard Disk o comunque nell&apos;unità che usi per il boot e va a rimpiazzare il caricatore del boot che stavi usando prima. Questa è la norma.&lt;/p&gt;&lt;p&gt;Se invece tu scegli di installare GRUB2 nel PBR (Partition Boot Record),  allora GRUB2 sarà installato all&apos;inizio della specifica partizione. Questa opzione è solo per gli esperti.&lt;/p&gt;&lt;p&gt;Se tu deselezioni la casella per l&apos;installazione di GRUB, allora GRUB non verrà installato in questo momento. Questa opzione è solo per esperti.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1867"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Servizi da Avviare in Automatico&lt;/b&gt;&lt;br/&gt;Seleziona quali tra questi servizi, che ritieni importanti per la configurazione del tuo sistema, vuoi che siano attivati automaticamente all&apos;avvio di %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identità del Computer&lt;/b&gt;&lt;br/&gt;Il nome del computer è un normale nome che identificherà il computer quando sarà all&apos;interno di un network di rete. Il dominio del computer è improbabile che sia usato a meno che non venga richiesto dal tuo ISP o network locale.&lt;/p&gt;&lt;p&gt;I nomi del computer e del dominio possono contenere solo caratteri alfanumerici, punti e trattini.  Non possono contenere spazi bianchi, iniziare o finire con trattini&lt;/p&gt;&lt;p&gt;Il server SaMBa deve essere attivato se vuoi condividere cartelle o stampanti con un computer locale che usa MS-Windows o Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1884"/>
        <source>Localization Defaults</source>
        <translation type="unfinished">Impostazioni di Localizzazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1885"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1886"/>
        <source>Configure Clock</source>
        <translation type="unfinished">Configura l&apos;Ora</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1887"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1889"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1898"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1899"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1903"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1904"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1906"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1907"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1909"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2112"/>
        <location filename="../minstall.cpp" line="2502"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2114"/>
        <location filename="../minstall.cpp" line="2510"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2461"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2461"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2507"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Localization Defaults&lt;/b&gt;&lt;br/&gt;Set the default keyboard and locale. These will apply unless they are overridden later by the user.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Configure Clock&lt;/b&gt;&lt;br/&gt;If you have an Apple or a pure Unix computer, by default the system clock is set to GMT or Universal Time. To change, check the box for &apos;System clock uses LOCAL.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timezone Settings&lt;/b&gt;&lt;br/&gt;The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Service Settings&lt;/b&gt;&lt;br/&gt;Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing! </source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Impostazioni di Localizzazione&lt;/b&gt;&lt;br/&gt;Impostare la lingua di default e relativa tastiera. Queste verranno applicate in questa fase, ma potranno anche essere modificate dall&apos;utente successivamente.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Configurare l&apos;Ora&lt;/b&gt;&lt;br/&gt;Se si dispone di un computer Apple o con un sistema Unix puro, l&apos;orologio è preselezionato su GMT o Ora Universale. Per cambiare, seleziona la casella &apos;Ora di sistema da usare LOCALE.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Impostazione Fuso Orario&lt;/b&gt;&lt;br/&gt;All&apos;installazione, il fuso orario è predefinito su GMT/UTC. Per cambiare il fuso orario, dopo l&apos;installazione fai il reboot poi clicca con tasto destro sull&apos;orologio presente sulla barra del Pannello e seleziona Proprietà.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Impostazione dei Servizi&lt;/b&gt;&lt;br/&gt;La maggior parte degli utenti non dovrebbe cambiare le impostazioni di defaults. Gli utenti con computer con poche risorse a volte desiderano disattivare alcuni servizi per mantenere l&apos;uso più basso possibile della RAM. In questo caso assicuratevi di sapere cosa state facendo!</translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Default User Login&lt;/b&gt;&lt;br/&gt;The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Passwords&lt;/b&gt;&lt;br/&gt;Enter a new password for your default user account and for the root account. Each password must be entered twice.&lt;/p&gt;</source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Login dell&apos;Utente di Default&lt;/b&gt;&lt;br/&gt;L&apos;utente root corrisponde all&apos;utente Amministratore di altri noti sistemi operativi. Non dovresti usare l&apos;utente root-amministratore come utente per il normale uso giornaliero. Prego, inserisci il nome di un nuovo account utente (utente di default) che userai per le normali attività giornaliere. Se necessario, potrai aggiungere altri account utente più tardi con %1 Manager Utenti. &lt;/p&gt;&lt;p&gt;&lt;b&gt;Passwords&lt;/b&gt;&lt;br/&gt;Inserisci una nuova password per l&apos;account del tuo utente di default e per l&apos;account di root-amministratore. Ogni password deve essere inserita due volte.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1918"/>
        <source>Old Home Directory</source>
        <translation>Vecchia Home Directory</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1919"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Per il nome-utente scelto esiste già una directory home. Questa schermata permette di decidere cosa fare con questa directory.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1921"/>
        <source>Re-use it for this installation</source>
        <translation>Riusa per questa installazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1922"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>La vecchia home directory verrà utilizzata per questo account utente. Questa è una buona scelta nel caso di un aggiornamento perchè i tuoi file e le tue impostazioni saranno immediatamente disponibili.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1924"/>
        <source>Rename it and create a new directory</source>
        <translation>Rinomina e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1925"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Verrà creata una nuova home directory per l&apos;utente, mentre la vecchia home directory verrà rinominata. I file e le impostazioni, della vecchia home, non saranno immediatamente visibili nella nuova installazione, ma ci si potrà accedere andando alla directory rinominata</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1927"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>La vecchia directory avrà un numero alla fine, in funzione di quante volte la directory è stata rinominata in precedenza.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1928"/>
        <source>Delete it and create a new directory</source>
        <translation>Cancella e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>La vecchia directory home verrà eliminata e ne verrà creata una nuova da zero.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1930"/>
        <source>Warning</source>
        <translation>Attenzione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1931"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Se questa opzione è selezionata, tutti i file e impostazioni verranno eliminati in modo permanente. Dopodichè la possibilità di recuperarli saranno molto scarse.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1947"/>
        <source>Installation in Progress</source>
        <translation>Installazione in avanzamento</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1948"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 è in corso di installazione. Una nuova installazione richiederà probabilmente da 3 a 20 minuti, a seconda della velocità del tuo sistema e della dimensione di ciascuna partizione che stai riformattando.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1950"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Se clicchi il pulsante Interrompi, l&apos;installazione verrà arrestata prima possibile.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1952"/>
        <source>Change settings while you wait</source>
        <translation>Modifica impostazioni durante l&apos;attesa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1953"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Mentre %1 è in corso d&apos;installazione, puoi cliccare sui pulsanti &lt;b&gt;Avanti&lt;/b&gt; o &lt;b&gt;Indietro&lt;/b&gt; per inserire ulteriori informazioni necessarie all&apos;installazione.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1955"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Completa questi passaggi senza fretta. Se necessario, l&apos;installer aspetterà i tuoi inserimenti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1964"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Congratulazioni!&lt;/b&gt;&lt;br/&gt;Hai completato l&apos;installazione di %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Trovare Applicazioni&lt;/b&gt;&lt;br/&gt;Ci sono centinaia di eccellenti applicazioni installate con %1 Il miglior modo di iniziare a conoscerle è di scorrere il Menu e cercarle. Molte applicazioni sono sviluppate specificatamente per il progetto %1. Queste sono visibili nei menu principali. &lt;p&gt;In aggiunta %1 include molte applicazioni standard di Linux che sono avviabili solo da riga di comando e quindi non appaiono nei menu.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1973"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Prova il piacere di usare %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1974"/>
        <location filename="../minstall.cpp" line="2388"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Sostieni %1&lt;/b&gt;&lt;br/&gt;%1 è sostenuta da persone come te. Alcuni aiutano altri nel forum di supporto - %2 - o traducono guide in lingue diverse, danno consigli, scrivono documentazione, o aiutano a testare nuovo software.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2005"/>
        <source>Finish</source>
        <translation>Finito</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2009"/>
        <source>OK</source>
        <translation>Ok</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2011"/>
        <source>Next</source>
        <translation>Avanti</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2046"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2049"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2053"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2070"/>
        <source>Loading...</source>
        <translation>Caricamento...</translation>
    </message>
    <message>
        <source>Select target root partition</source>
        <translation type="vanished">Seleziona la partizione root di destinazione</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2313"/>
        <source>Confirmation</source>
        <translation>Conferma</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2313"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>L&apos;intallazione e configurazione non è ultimata.
Vuoi davvero chiudere ora?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2374"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ricevere Assistenza&lt;/b&gt;&lt;br/&gt;Informazioni di base su %1 puoi trovarle in %2.&lt;/p&gt;&lt;p&gt;Ci sono volontari che ti possono aiutare nel Forum di %3 , %4&lt;/p&gt;&lt;p&gt;Se chiedi aiuto, per favore ricordati di fornire sufficienti dettagli per descrivere il tuo problema e il tuo computer. Di solito con richieste del tipo &apos;non funziona&apos; non si riceve aiuto.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2382"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Riparare la tua Installazione&lt;/b&gt;&lt;br/&gt;Se %1, installato sul disco, per qualche motivo non dovesse funzionare, talvolta è possibile riparare il danno avviando il DVD-Live o l&apos;USB-Live e facendo uso delle utility presenti negli specifici strumenti d&apos;aiuto contenuti in %1 o usando i normali strumenti Linux per riparare il sistema.&lt;/p&gt;&lt;p&gt;Puoi usare il DVD-Live o l&apos;USB-Live di  %1 anche per recuperare dati da un sistema MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2396"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Regolare il Mixer del Suono&lt;/b&gt;&lt;br/&gt; %1 cerca di configurare il mixer del suono per te, ma talvolta dopo l&apos;installazione sarà necessario alzare i volumi e attivare i canali per riuscire ad udire il suono.&lt;/p&gt; &lt;p&gt;L&apos;icona del mixer si trova nel pannello. Cliccaci col destro per aprire il mixer. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2404"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mantenere %1 aggiornato&lt;/b&gt;&lt;br/&gt;Per informazioni e aggiornamenti, prego visita&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2409"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ringraziamenti&lt;/b&gt;&lt;br/&gt;Grazie a tutti coloro che hanno deciso di supportare %1 con il loro tempo, denaro, promozione, consigli, lavoro, idee, lodi, e/o incoraggiamento.&lt;/p&gt;&lt;p&gt;Senza di voi non ci sarebbe %1.&lt;/p&gt;&lt;p&gt;%2 Team Sviluppatori&lt;/p&gt;</translation>
    </message>
    <message>
        <source>This option also encrypts swap partition if selected, which will render the swap partition unable to be shared with other installed operating systems.</source>
        <translation type="vanished">Questa opzione, se selezionata, crittografa anche la partizione di swap il che renderà la partizione di swap non condivisibile con altri sistemi operativi installati.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2664"/>
        <source>System boot disk:</source>
        <translation>Disco di avvio del sistema:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2678"/>
        <location filename="../minstall.cpp" line="2687"/>
        <source>Partition to use:</source>
        <translation>Partizione da usare:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="43"/>
        <source>Help</source>
        <translation>Aiuto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="148"/>
        <source>Next</source>
        <translation>Avanti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="154"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="369"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2359"/>
        <source>Back</source>
        <translation>Indietro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2365"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2378"/>
        <source>Installation in progress</source>
        <translation>Installazione in avanzamento</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2393"/>
        <source>Abort</source>
        <translation>Interrompi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1287"/>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="100"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="138"/>
        <source>Close</source>
        <translation>Chiudi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="201"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished">Fase di elaborazione delle informazioni, si prega di attendere.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="236"/>
        <source>Terms of Use</source>
        <translation>Termini d&apos;Uso</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="263"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Impostazione Tastiera&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="270"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modello:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="277"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variante:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="300"/>
        <source>Change Keyboard Settings</source>
        <translation>Cambia Impostazioni Tastiera </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="307"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>Rearrange disk partitions (optional)</source>
        <translation type="vanished">Riorganizza le partizioni del disco (facoltativo)</translation>
    </message>
    <message>
        <source>Modify partitions:</source>
        <translation type="vanished">Modifica le partizioni:</translation>
    </message>
    <message>
        <source>Run partition tool...</source>
        <translation type="vanished">Avvia partizionatore...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="357"/>
        <source>Select type of installation</source>
        <translation>Seleziona il tipo d&apos;installazione</translation>
    </message>
    <message>
        <source>Auto-install using entire disk </source>
        <translation type="vanished">Installaz automatica usando l&apos;intero disco </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="405"/>
        <location filename="../meinstall.ui" line="791"/>
        <source>Encryption password:</source>
        <translation>Password di crittografia:</translation>
    </message>
    <message>
        <source>MB </source>
        <translation type="vanished">MB </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="398"/>
        <location filename="../meinstall.ui" line="774"/>
        <source>Confirm password:</source>
        <translation>Conferma password:</translation>
    </message>
    <message>
        <source>Leave free space up to:</source>
        <translation type="vanished">Lasciare spazio libero:</translation>
    </message>
    <message>
        <source>Custom install on existing partitions</source>
        <translation type="vanished">Installaz personalizzata su partizioni esistenti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="421"/>
        <location filename="../meinstall.ui" line="814"/>
        <location filename="../meinstall.ui" line="846"/>
        <source>Advanced encryption settings</source>
        <translation>Impostazioni avanzate di crittografia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="463"/>
        <location filename="../meinstall.ui" line="672"/>
        <source>Encrypt</source>
        <translation>Crittografa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="437"/>
        <source>Use disk:</source>
        <translation>Usa il disco:</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Preferenze</translation>
    </message>
    <message>
        <source>Preserve data in /home (if upgrading)</source>
        <translation type="vanished">Preservare dati della /home (x aggiornare la distro)</translation>
    </message>
    <message>
        <source>Check for badblocks (takes longer)</source>
        <translation type="vanished">Ricerca badblocks (ci vorrà parecchio tempo)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="619"/>
        <source>Choose partitions</source>
        <translation>Scegli le partizioni</translation>
    </message>
    <message>
        <source>ext4</source>
        <translation type="vanished">ext4</translation>
    </message>
    <message>
        <source>ext3</source>
        <translation type="vanished">ext3</translation>
    </message>
    <message>
        <source>ext2</source>
        <translation type="vanished">ext2</translation>
    </message>
    <message>
        <source>f2fs</source>
        <translation type="vanished">f2fs</translation>
    </message>
    <message>
        <source>jfs</source>
        <translation type="vanished">jfs</translation>
    </message>
    <message>
        <source>xfs</source>
        <translation type="vanished">xfs</translation>
    </message>
    <message>
        <source>btrfs</source>
        <translation type="vanished">btrfs</translation>
    </message>
    <message>
        <source>btrfs-zlib</source>
        <translation type="vanished">btrfs-zlib</translation>
    </message>
    <message>
        <source>btrfs-lzo</source>
        <translation type="vanished">btrfs-lzo</translation>
    </message>
    <message>
        <source>reiserfs</source>
        <translation type="vanished">reiserfs</translation>
    </message>
    <message>
        <source>reiser4</source>
        <translation type="vanished">reiser4</translation>
    </message>
    <message>
        <source>boot:</source>
        <translation type="vanished">boot:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="662"/>
        <source>Label</source>
        <translation>Etichetta</translation>
    </message>
    <message>
        <source>root:</source>
        <translation type="vanished">root:</translation>
    </message>
    <message>
        <source>swap:</source>
        <translation type="vanished">swap:</translation>
    </message>
    <message>
        <source>root</source>
        <translation type="vanished">root</translation>
    </message>
    <message>
        <source>Type</source>
        <translation type="vanished">Tipo</translation>
    </message>
    <message>
        <source>home:</source>
        <translation type="vanished">home:</translation>
    </message>
    <message>
        <source>Location</source>
        <translation type="vanished">Posizione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Encryption options</source>
        <translation>Opzioni di crittografia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="862"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="867"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="872"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="877"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="882"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="899"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="918"/>
        <source> mS</source>
        <translation> mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="940"/>
        <source>LUKS key hash:</source>
        <translation>hash della chiave LUKS:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="953"/>
        <source>Key size:</source>
        <translation>Dimensione Chiave:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="979"/>
        <source>KDF round time:</source>
        <translation>KDF round time:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>Cipher:</source>
        <translation>Cifrario:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1022"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1027"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1032"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1037"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1042"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Benchmark...</source>
        <translation>Benchmark...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1089"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1094"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1099"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1104"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1109"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1123"/>
        <source>IV generator:</source>
        <translation>IV generatore:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1136"/>
        <source>Chain mode:</source>
        <translation>Modalita  a catena:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1156"/>
        <source>Kernel RNG:</source>
        <translation>Kernel RNG:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1164"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1169"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1196"/>
        <source>Select Boot Method</source>
        <translation>Selezionare il modo di avvio Boot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1233"/>
        <source>EFI System Partition</source>
        <translation>EFI System Partition</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1236"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1255"/>
        <source>Partition Boot Record</source>
        <translation>Partition Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1258"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1271"/>
        <source>Location to install on:</source>
        <translation>Posizione su cui installare:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1284"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Installare GRUB per Linux e Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1303"/>
        <source>System boot disk:</source>
        <translation>Disco di avvio del sistema:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1325"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1331"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1334"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1405"/>
        <source>Common Services to Enable</source>
        <translation>Servizi da avviare in automatico</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1424"/>
        <source>Service</source>
        <translation>Servizio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1429"/>
        <source>Description</source>
        <translation>Descrizione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1462"/>
        <source>Computer Network Names</source>
        <translation>Nome Computer in Rete</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1489"/>
        <source>Workgroup</source>
        <translation>Gruppolavoro</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1502"/>
        <source>Workgroup:</source>
        <translation>Gruppo di lavoro:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1515"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Server SaMBa per Network MS Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1531"/>
        <source>example.dom</source>
        <translation>example.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1544"/>
        <source>Computer domain:</source>
        <translation>Dominio computer:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1570"/>
        <source>Computer name:</source>
        <translation>Nome computer:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1631"/>
        <source>Configure Clock</source>
        <translation>Configura l&apos;Ora</translation>
    </message>
    <message>
        <source>System clock uses LOCAL</source>
        <translation type="vanished">Ora di sistema da usare LOCALE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1672"/>
        <source>Format:</source>
        <translation>Formato:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1700"/>
        <source>Timezone:</source>
        <translation>Fuso orario:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1745"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1777"/>
        <source>Localization Defaults</source>
        <translation>Impostazioni di Localizzazione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1817"/>
        <source>Locale:</source>
        <translation>Lingua locale:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1839"/>
        <source>Service Settings (advanced)</source>
        <translation>Impostazione Servizi (utenti avanzati)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1857"/>
        <source>Adjust which services should run at startup</source>
        <translation>Imposta quali servizi dovrebbero partire all&apos;avvio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>View</source>
        <translation>Mostra </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1918"/>
        <source>Root (administrator) Account</source>
        <translation>Account di root (amministratore)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1975"/>
        <source>Confirm root password:</source>
        <translation>Conferma la password amministratore</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1930"/>
        <source>Root password:</source>
        <translation>Password amministratore:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2004"/>
        <source>Default User Account</source>
        <translation>Account dell&apos;utente predefinito</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2106"/>
        <source>username</source>
        <translation>nome utente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2045"/>
        <source>Confirm user password:</source>
        <translation>Conferma la password utente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2032"/>
        <source>Default user password:</source>
        <translation>Password dell&apos;utente predefinito:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2016"/>
        <source>Default user login name:</source>
        <translation>Login dell&apos;utente predefinito:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="382"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="520"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="555"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="641"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="652"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="657"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="667"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="677"/>
        <source>Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="682"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="709"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="726"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2122"/>
        <source>Autologin</source>
        <translation>Login automatico</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2135"/>
        <source>Show passwords</source>
        <translation>Mostra le password</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2148"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Le modifiche del desktop, fatte in modalità &quot;live&quot;, verranno trasferite sul sistema una volta installato</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2151"/>
        <source>Save live desktop changes</source>
        <translation>Salva modifiche del desktop &quot;live&quot;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2174"/>
        <source>Existing Home Directory</source>
        <translation>Home Directory Esistente</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2183"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Cosa ne vorresti fare della vecchia directory ?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2190"/>
        <source>Re-use it for this installation</source>
        <translation>Riusa per questa installazione</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2197"/>
        <source>Rename it and create a new directory</source>
        <translation>Rinomina e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2204"/>
        <source>Delete it and create a new directory</source>
        <translation>Cancella e crea una nuova directory</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2249"/>
        <source>Tips</source>
        <translation>Informazioni</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2293"/>
        <source>Installation complete</source>
        <translation>Installazione completata</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2299"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Riavvia automaticamente il sistema quando l&apos;installer si chiude</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2318"/>
        <source>Reminders</source>
        <translation>Promemoria</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="557"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="260"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="259"/>
        <source>EFI System Partition</source>
        <translation type="unfinished">EFI System Partition</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="261"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="360"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="462"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="467"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="471"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="472"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="487"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="488"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="491"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="492"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="568"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="606"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="613"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished">Devi scegliere una partizione root.
La partizione root deve essere come minimo di %1 .</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="619"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished">Devi scegliere una partizione boot separata quando cripti root.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="634"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Configure %1 as swap space</source>
        <translation type="obsolete">Configura %1 come spazio swap</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="631"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished">Cancellare i dati su %1 ad eccezione della /home</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="640"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="643"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished">Le partizioni seguenti, che hai selezionato, non sono partizioni Linux:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="651"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished">Sei sicuro di voler riformattare queste partizioni?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="659"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished">%1 installer ora andrà a formattare e a distruggere i dati delle partizioni seguenti:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="667"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished">%1 installer ora eseguirà le seguenti azioni:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="671"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished">Queste azioni non possono essere annullate. Sei sicuro di voler continuare?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="768"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished">I dischi con le partizioni che hai selezionato per l&apos;installazione non rispondono:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="772"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished">Output dello strumento Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="773"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished">I dischi con le partizioni che hai selezionato per l&apos;installazione hanno superato il test S.M.A.R.T. (smartctl), ma i test riferiscono che ci sono alte probabilità che nel prossimo futuro si possano presentare un numero di non conformità superiori alla media.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="778"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished">Se non sei sicuro, per favore esci dall&apos;Installer e avvia GSmartControl per avere più informazioni.

</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="780"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished">Vuoi annullare l&apos;installazione?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="785"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished">Vuoi continuare?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="954"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="962"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished"> Preparazione delle partizioni richieste</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1016"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished">Configurazione dei contenitori criptati LUKS</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1033"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formatting EFI System Partition</source>
        <translation type="obsolete">Formattazione di EFI System Partition</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1204"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="vanished">Il programma di installazione non parte perché risulta essere già avviato in background.

Si prega di chiuderlo, se possibile, o eseguire &apos;pkill minstall&apos; nel terminale.</translation>
    </message>
    <message>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="vanished">Stai usando un OS a 32 bit avviato in modalità UEFI a 64 bit, il sistema non sarà in grado di fare il boot a meno che non si vada a scegliere nel Bios la modalità Legacy Boot, o simile, al riavvio.
Noi ti raccomandiamo di chiudere ora e riavviare in Legacy Boot

Vuoi continuare l&apos;installazione ? </translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must run this app as root.</source>
        <translation type="vanished">Devi eseguire questo programma come amministratore.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Non si è riusciti a trovare il file di configurazione (%1).</translation>
    </message>
</context>
</TS>
