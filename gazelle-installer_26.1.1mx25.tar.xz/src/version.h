inline const QString VERSION {"26.1.1mx25"};
