inline const QString VERSION {"26.1.2mx25"};
