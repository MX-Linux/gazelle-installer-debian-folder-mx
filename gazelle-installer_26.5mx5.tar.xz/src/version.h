inline const QString VERSION {"26.5mx5"};
