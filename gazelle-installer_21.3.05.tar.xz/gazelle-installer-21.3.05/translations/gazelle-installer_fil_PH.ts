<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fil_PH">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="95"/>
        <source>%1 Installer</source>
        <translation>%1 Installer</translation>
    </message>
    <message>
        <source>Gathering Information, please stand by.</source>
        <translation type="vanished">Antabay habang kumakalap ng impormasyon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="55"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="112"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Tumangkilik %1

%1 ay tinatangkilik ng mga taong kagaya mo. May ilang tumutulong sa pamamagitan ng paggabay sa forum - %2, o nagliliwat sa ibang wika, ay nagbibigay ng mungkahi, nagsusulat ng documentation, o tumutulong sa pagsubok ng bagong software.</translation>
    </message>
    <message>
        <source>Cannot access source medium.
Activating pretend installation.</source>
        <translation type="vanished">Di maaring mapasok ang source medium.
Ina-activate ang pretend installation.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="337"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 ay isang malayang   distribution ng Linux batay sa Debian Stable.

%1 ay gumagamit ng mga kagamitan mula sa MEPIS Linux na mga nailathala sa ilalim ng libre pahintulot ng Apache. May ilang kagamitan ng MEPIS na nabago para sa %1.

Gamiting may kagalakan ang %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="459"/>
        <source>Pretending to install %1</source>
        <translation>Wari baga ay ini-install ang  %1</translation>
    </message>
    <message>
        <source>target drive</source>
        <translation type="vanished">drive na pinupuntirya</translation>
    </message>
    <message>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="vanished">Ang disk na may partition na iyong napili para sa pag-iinstall ay pumalya:</translation>
    </message>
    <message>
        <source>Smartmon tool output:</source>
        <translation type="vanished">Output ng Smartmon tool :</translation>
    </message>
    <message>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="vanished">Ang disk na may partition na iyong napili pag sa pag-install ng pagsubok sa SMART monitor (smartctl), pero ang mag pagsubok ay nagsasalaysay na magkakaroon lamang ng mas higit na pagpalya sa hinaharap.</translation>
    </message>
    <message>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="vanished">Kung di tiyak ay itigil muna ang pag-install at patakbuhin ang GSmartControl para sa karagdagang kaalaman. </translation>
    </message>
    <message>
        <source>Do you want to abort the installation?</source>
        <translation type="vanished">Gusto mo bang itigil ang pag-iinstall?</translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="vanished">Gusto mo bang magpatuloy?</translation>
    </message>
    <message>
        <source>The password needs to be at least
%1 characters long. Please select
a longer password before proceeding.</source>
        <translation type="vanished">Ang password ay kinakailangan mahigit sa
%1 characters ang haba. Pumili
ang mas mahabang password bago magpatuloy.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="515"/>
        <source>Preparing to install %1</source>
        <translation>Inihahanda ang pag-iinstall %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="527"/>
        <source>Failed to format required partitions.</source>
        <translation>Pumalya sa pag-format ng hinihiling na partitions.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="538"/>
        <source>Paused for required operator input</source>
        <translation>Nakatigil para sa pag-input ng gumagamit</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="548"/>
        <source>Setting system configuration</source>
        <translation>Itinatakda ang configuration ng sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="568"/>
        <source>Cleaning up</source>
        <translation>Naglilinis</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="728"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>Nakatuklas ang maling setting sa configuration ng file (%1). Rebisahing muli ang mga natatatatakang fields kung iyong makikita sila.</translation>
    </message>
    <message>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="vanished">Itinatakda ang LUKS encrypted containers</translation>
    </message>
    <message>
        <source>Formatting swap partition</source>
        <translation type="vanished">Pino-format ang swap partition</translation>
    </message>
    <message>
        <source>Formatting the / (root) partition</source>
        <translation type="vanished">Pino-format ang / (root) partition</translation>
    </message>
    <message>
        <source>Formatting boot partition</source>
        <translation type="vanished">Pino-formatting ang boot partition</translation>
    </message>
    <message>
        <source>Formatting EFI System Partition</source>
        <translation type="vanished">Pino-format ang  Sistema ng EFI Partition</translation>
    </message>
    <message>
        <source>Formatting the /home partition</source>
        <translation type="vanished">Pino-format ang /home partition</translation>
    </message>
    <message>
        <source>Mounting the /home partition</source>
        <translation type="vanished">Imina-mount ang /home partition</translation>
    </message>
    <message>
        <source>Sorry, could not create %1 LUKS partition</source>
        <translation type="vanished">Paumanhin, di maaring makagawa ng %1 LUKS partition</translation>
    </message>
    <message>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation type="vanished">Paumanhin, Di maaring mabuksan ang %1 LUKS container.</translation>
    </message>
    <message>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="vanished">Dapat gumamit ng bukod na boot partition kapag ginagawan ng encrypting ang root.</translation>
    </message>
    <message>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="vanished">Dapat pumili ng root partition.
Ang root partition ay dapat mahigit sa %1.</translation>
    </message>
    <message>
        <source>Delete the data on %1 except for /home</source>
        <translation type="vanished">Tanggalin ang laman ng  %1 maliban na lamang sa /home</translation>
    </message>
    <message>
        <source>Reuse (no reformat) %1 as the /home partition</source>
        <translation type="vanished">gamiting ang reuse (huwag ang reformat) %1 gaya ng sa  /home partition</translation>
    </message>
    <message>
        <source>Configure %1 as swap space</source>
        <translation type="vanished">Baguhin ang %1 bilang swap space</translation>
    </message>
    <message>
        <source>The partition you selected for /boot is larger than expected.</source>
        <translation type="vanished">Ang  partition na iyong napili para sa  /boot ay mas malaki kaysa sa inaasahan.</translation>
    </message>
    <message>
        <source>%1 for the %2 partition</source>
        <translation type="vanished">%1 para sa %2 partition</translation>
    </message>
    <message>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="vanished">Ang mga  partitions na iyong napili ay Linux partitions:</translation>
    </message>
    <message>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="vanished">Nakakatiyak ka ba na gusto mong i-reformat ang mga partitions na ito?</translation>
    </message>
    <message>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="vanished">Ang %1 installer ay magsasagawa ngayon ng format at sisirain ang lahat ng laman na nasa partitions:</translation>
    </message>
    <message>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="vanished">Ang %1 installer ay magsasagawa ng mga sumusunod na aksyon:</translation>
    </message>
    <message>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="vanished">Ang mga akyson ay hindi maaring bawiin. Gusto mo bang magpatuloy?</translation>
    </message>
    <message>
        <source>Creating required partitions</source>
        <translation type="vanished">Nagsasagawa ng mga hinihinging partitions.</translation>
    </message>
    <message>
        <source>Preparing required partitions</source>
        <translation type="vanished">Inihahanda ang mga hinihinging partitions</translation>
    </message>
    <message>
        <source>Mounting the / (root) partition</source>
        <translation type="vanished">Imina-mount ang  / (root) partition</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>Deleting old system</source>
        <translation>Tinatanggal ang lumang sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Bigo sa pagtanggal ng lumang %1 on kinaroroonan
Babalik sa hakbang bilang 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Creating system directories</source>
        <translation>Nagsasagawa ng system directories</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="838"/>
        <source>Fixing configuration</source>
        <translation>Inaayos ang  configuration</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="880"/>
        <source>Copying new system</source>
        <translation>Kinokopya ang sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="920"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Ang pagproseso ng pagkopya ay wlaang katiyakan. Walang  statistics ng  file system</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="929"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Pumalya sa pagsulat  %1 sa kinalalagyan
Pabalik na sa hakbang bilang 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="947"/>
        <source>Installing GRUB</source>
        <translation>Ini-install ang GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1032"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>Pumalya ang pag-iinstall ng GRUB. Maaring simulang muli ang medium  gamit ang menu ng GRUB Rescue para kumpunihin ang installation.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1048"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation>Ang boot ng NVRAM variable update ay pumalya. Maaring hindi magsimula ang sistema ng boot, pero maaring makumpuni sa boot menu ng GRUB Rescue.</translation>
    </message>
    <message>
        <source>Please enter a user name.</source>
        <translation type="vanished">Ipasok ang pangalan ng gumagamit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1163"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Ang pangalan ng gumagamit ay hindi maaring maglamang ng mga espesyal na character maging ng espasyo.
Pumili ng ibang pangalan bago magpatuloy.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1174"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Paumanhin, ang pangalan ay gamit na.
Pumili ng ibang pangalan.</translation>
    </message>
    <message>
        <source>Please enter the user password.</source>
        <translation type="vanished">Ipasok ang password ng gumagamit.</translation>
    </message>
    <message>
        <source>Please enter the root password.</source>
        <translation type="vanished">Ipasok ang root password.</translation>
    </message>
    <message>
        <source>The user password entries do not match.
Please try again.</source>
        <translation type="vanished">Ang password ng gumagamit ay hindi tugma.
Subuking muli.</translation>
    </message>
    <message>
        <source>The root password entries do not match.
Please try again.</source>
        <translation type="vanished">Ang root password ay hindi nagtutugma.
Subuking muli.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1193"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Ang home directory para sa %1 ay umiiral na.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1222"/>
        <source>Failed to set user account passwords.</source>
        <translation>Pumalya sa pagtatakda ng passwords ng user account .</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1242"/>
        <source>Failed to save old home directory.</source>
        <translation>Pumalya sa pagse-save ng lumang home directory.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Failed to delete old home directory.</source>
        <translation>Pumalya sa pagtanggal ng lumang home directory.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1269"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Paumanhin, pumalya sa paggawa ng directory ng gumagamit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1277"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Paumanhin, pumalya sa paglalagay ng pangalan directory ng gumagamit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1298"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Paumanhin, pumalya sa pagtatakda ng pagmamay-ari ng directory ng gumagamit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>Please enter a computer name.</source>
        <translation>Ipasok ang pangalan ng computer.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Paumanhin, ang pangalan ng iyong computer ay naglalaman ng character na hindi katanggap tanggap.
Dapat pumili ng ibang
pangalan bago magpatuloy.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1355"/>
        <source>Please enter a domain name.</source>
        <translation>Ipasok ang pangalan ng domain.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1359"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Paumanhin, ang iyong computer ay naglalaman ng mga characters na hindi katanggap tanggap.
Dapat kang pumili ng ibang
pangalan bago magpatuloy.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1366"/>
        <source>Please enter a workgroup.</source>
        <translation>Magpasok ng workgroup.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1583"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>OK upang iformat at gamitin ang buong disk (%1) para sa %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1587"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>BABALA: Ang drive na napili ay may kakayahan na hindi bababa sa 2TB at dapat i-format gamit ang GPT. Sa ibang mga sistema ang disk na may GPT-format ay hindi aandar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1612"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Ang data sa /home ay hindi maaring mapreserve dahil hindi maaring makuhang ang hinihinging impormasyon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1613"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation>Ang partition na naglalamang ng  /home ay natatatakan, tiyaking tama ang &quot;Encrypt&quot; na napili, at tiyaking ang ipinasok na password ay tama.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1614"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation>Ang installer ay hindi maaring makapag-encrypt sa umiiral na /home directory o partition.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>General Instructions</source>
        <translation>Mga Bilin na Pangkalahatan</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ISARA MUNA LAHAT NG MGA IBANG APPLICATIONS BAGO MAGPATULOY.
</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1672"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Sa bawat pagina ay dapat basahin ang mga bilin, piliin ang iyong minamarapat at i-click ang Next kapat handa ng magpatuloy. Ikaw ay tatanungin para sa pagtitibay bago maganap ang anomang maaring makakapinsala sa isasagawa. 
</translation>
    </message>
    <message>
        <source>Installation requires about %1 of space. %2 or more is preferred. You can use the entire disk or you can put the installation on existing partitions.</source>
        <translation type="vanished">Ang installation ay nagkakailangan ng mga %1 ng espasyo. %2 or mas mataas ay mas mainam. Maari ding gamitin ang buong disk o maaring mailagay ang installation sa kasalukuyang partitions.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Kung gumagamit ka ng Mac OS o Window (mula Vista pasulong), maaring mangangailangan ka ng sistema ng gayong mga software para magawan ng set up ang partitions o boot manager bago mag-install.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Ang ext2, ext3, ext4, jfs, xfs, btrfs at reiserfs na mga Linux filesystems ay sinasangayunan at ang ext4 ay ipinapayo.</translation>
    </message>
    <message>
        <source>Autoinstall will place home on the root partition.</source>
        <translation type="vanished">Ilalagay ng Autoinstall ang home sa root partition.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <location filename="../minstall.cpp" line="1729"/>
        <source>Encryption</source>
        <translation>Encryption</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <location filename="../minstall.cpp" line="1730"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Ang Encryption ay maaring sa pamamgitan ng LUKS. Ang password ay kinakailangan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1686"/>
        <location filename="../minstall.cpp" line="1731"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Hindi kinakailangan ang hiwalay na unencrypted na partition ng boot. Para sa karagdagang pagsasaayos kalakip ng pagpili ng cipher ay gamitin ang &lt;b&gt;Para sa mas lubusang kaayusan ng encryption&lt;/b&gt; boton.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Kung ang encryption ay ginagamit lakip ng autoinstall, ang bukod na  boot partition ay kusang malilikha.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Limitations</source>
        <translation>Mga Limitasyon</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Paalala, ang software na ito ay ganito na at walang garantiya o kung ano pa man. Nasa sa iyo ang buong pananagutan na i-backup ang date bago magpatuloy.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1706"/>
        <source>Choose Partitions</source>
        <translation>Pumili ng partition</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>Ang %1 ay humihingi ng root partition. Ang swap partition ay di sapilitan bagaman iminumungkahit. Kung gusto mong gamitin ang   Suspend-sa-Disk na feature ng %1, mangangailangan ka ng swap na partition na yaon ay mas malaki sa totoo ng laki ng iyong tunay na memory. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1709"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Kung pipiliin mo ang bukod na /home partition ay mas magiging madali sa iyo ang upgrade sa hinaharap, bagaman hindi hindi ito maari kung ang upgrade ay mula sa installation na walang bukod na  home partition.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>Upgrading</source>
        <translation>Nagsasagawa ng upgrade</translation>
    </message>
    <message>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and check the preference to preserve data in /home.</source>
        <translation type="vanished">Upang mag-upgrade mula sa umiiral na  installation ng Linux, piliin ang gayunding home partition gaya ng dati ay siyasating ang mga  preference para maipanatili ang mga data sa /home.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1184"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1677"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>By default, the automatic install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1680"/>
        <source>Move the slider to the left to increase the space for &lt;b&gt;home&lt;/b&gt;. Move it to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move the slider all the way to the right if you want both root and home on the same partition; &lt;b&gt;this is not recommended.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1682"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1689"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1711"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1716"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation>Kung ipinapanatili mo ang kasalukuyang¿ /home directory tree na nasa iyong root partition, ang installer ay hindi magsasagawa ng reformat sa root partition. Bilang kalalabasan, ang installation ay mag magtatagal kaysa sa karaniwan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1719"/>
        <source>Preferred Filesystem Type</source>
        <translation>Mungkahing Uri ng Filesystem</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Para %1, maari kang mamili ng format sa partitions bilang ext2, ext3, ext4, f2fs, jfs, xfs, btrfs o reiser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Ang mga karagdagang pagpipilian sa compression maaring makuha para sa drives gamit ang btrfs. Lzo na mabilis, pero ang compression mababa. Ang Zlib ay mas mabagal pero may mataas na compression.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>Bad Blocks</source>
        <translation>Blocks na sira</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Kung makakapili ka sa  ext2, ext3 or ext4 bilang uri ng format, meron kang pagpipilian sa pagsisiyasat sa mga sirang blocks na nasa drive. Ang mga sirang block ay dapat masiyasat palagi bagaman mas makapagpapatagal, kaya naman maari mong lampasan ang hakbang na ito maliban na lamang kung may hinala ka na ang iyong drive ay may mga masamang blocks.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>System drive management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>If you want more control over the drive layouts than what can be provided on this page, click the button to the bottom-right of the list. This will run the drive management tool provided with the operating system, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>Advanced Encryption Settings</source>
        <translation>Mas Malawak na Ayos ng Encryption</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Ang pahinang ito ay nagpapahintulot na pakinisin ang encrypted na  partitions ng LUKS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1739"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Sa kadalasang mga pagkakataon, ang karaniwang ayos ay nagbibigay ng praktical na balanse sa pagitan ng siguridad at performance na naaangkop  sa mga maseselang applications. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1741"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Ang texto na ito ay sumasakop sa mga basiko ng mga parametro na gamit sa LUKS, bagamang hindi nangangahulugan pangmalawakang gabay sa cryptography. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Ang paglilikot o pagbabago kaayusan nito kung walang sapat na kaalaman sa cryptography ay maaring magbunga ng mahinang encryption na gamit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Ang pagbago sa field ay kadalasang nakakaapekto sa mga pagpipilian sa ibaba. Ang mga field sa baba ay maaring kusang mabago sa iminumungkahing bilang.  </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Samantalang ang mas mainam na performance o ang mas mahigpit na siguridad ay maaring mataglay sa pamamagitan ng pagbabago ng settings mula sa mga iminumungkahing bilang, yaon ay nasa sa iyong sariling ikapipinsala.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Maaring gamiting ang &lt;b&gt;para sa Benchmark&lt;/b&gt; boton (na aandar &lt;i&gt;cryptsetup benchmark&lt;/i&gt; sa kaniyang sariling terminal window) para maicompare ang pagtatrabaho ang karaniwang combination ng mga hash, ciphers at chain modes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Tandaan na ang &lt;i&gt;cryptsetup benchmark&lt;/i&gt; ay hindi sumasakop sa lahat ng  combination o mga posibleng pagpipilian at sa kadalasan ay sumasakop sa mga kadalasang mga selections na ginagamit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>Cipher</source>
        <translation>Cipher</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>A variety of ciphers are available.</source>
        <translation>Ang ibat ibang uri ng ciphers ay maaring makuha.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>isa sa limang  finalists ng AES. Ito ay itinuturing na may mas mataas na siguridad kaysa sa  Rijndael at iba pang mga finalists ng AES. Ito ay nagbibigay ng mas malakas na pagtatrabaho sa ibang mga  CPU na 64-bit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(kilala rin bilang &lt;i&gt;Rijndael&lt;/i&gt;) ay isang lalong karaniwang cipher, ang maraming mga makabagong CPU ay may kalakip na panuntunang mas masinsin para sa AES, dahil sa kaniyang pag-iral sa kadalasan. Bagaman ang Rijndael ay napili kaysa sa Serpent dahil sa kaniyang pagtatrabaho, walang praktikal attack sa kasalukuyan ang inaasahan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>ay ang kasunod ng Blowfish. Ito ay naging isa sa limang  finalist ng AES bagaman hindi napili bilang standard.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>Ang (CAST-256) ay kandidato sa paligsahan ng AES  bagaman hindi ito naging finalist.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>ay isang 64-bit block cipher na ginawa ni Bruce Schneier. Ito ay hindi iminumungkahi sa mga maseselang application bilang CBC at  ECB mode lamang ang sinusuportahan. Ang Blowfish ay tumatanggap ng dami ng key sa pagitan ng  32 and 448 bits na maaring maparami sa bilang ng 8.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>Chain mode</source>
        <translation>Chain mode</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Kung ang lahat ng  blocks ay encrypted gamit ang kaparehong key, isang padron ay maaring lumitaw para mahulaan ang payak na text.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>XEX-based Tweaked codebook na may lakip na pangnakaw ng ciphertext) ay isang makabagong chain mode, na humahangga sa CBC at EBC. Ito ay sa madalas at iminumungkahi) bilang chain mode. Gamit ang ESSIV kaysa sa Plain64 ay magaganap at magdudulot na pasakit sa pagtatrabaho, na may kalakip na maaring ipagwalang bahalang  pakinabang sa siguridad.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Ang Cipher Block Chaining) ay mas payak kaysa sa XTS, pero ito ay maaring tablan sa mga   attack ng padding oracle (parang pinahihina ng ESSIV) kung kayat hindi iminumungkahi para sa mga maselang applications.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Ang Electronic CodeBook) ay mas mahina sa siguridad kaysa sa CBC at hindi maaring gamiting sa mga maseselang applications.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>IV generator</source>
        <translation>IV generator</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>Para sa XTS at CBC, pinipili nito kung paanong ang &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector ay nalilikha. &lt;b&gt;Ang ESSIV&lt;/b&gt; ay humihingi ng pagtatrabaho ng hash at dahil sa roon ay ang ikalawang drop-down box ay maaring makuha kung ito ay napili. Ang mga hash ay maaring makuha depende na piling cipher.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>Ang ECB mode ay hindi gumagamit IV, so ang mga fields na ito ay di maaring magamit kung ang  ECB ay napili para sa chain mode.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>Key size</source>
        <translation>Laki ng Key</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Itatakda nito ang laki ng key sa bits. Ang mga key sizes na maaring makuha ay limitado ng cipher at ng  chain mode.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1765"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>Ang XTS cipher chain mode ay humahati ng key sa dalawa (halimbawa, ang AES-256 in XTS ay humihiling ng 512-bit na laki ng key).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>LUKS key hash</source>
        <translation>LUKS key hash</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>Ang hash na ginamit para sa PBKDF2 at para sa AF splitter.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>Ang SHA-1 at  RIPEMD-160 ang hindi na iminumungkahing gamitin dahil sa maseselang application yamang mga napag-aalamang sira.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Kernel RNG</source>
        <translation>Kernel RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Itinatakda kung aling  generator ng random number ng kernel ang gagamitin sa paggawa ng master key volume (pangmatagalang key)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>May maaring dalawang mapagpipilian: /dev/&lt;b&gt;random&lt;/b&gt; na sumasagka hanggang maging sapat ang nakukuhang entropy (maaring tumagal ng husto sa may kalagayang may mababang-entropy), at /dev/&lt;b&gt;urandom&lt;/b&gt; di hindi sumasagka bagaman may kakulangan sa entropy (mas malamang na mahinang keys)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF round time&lt;/b&gt;&lt;br/&gt;Ang gugugulin panahon (sa bahagi ng sandali) ay gagamitin sa PBKDF2 pagpoproceso ng passphrase</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Ang halaga ng 0 ay pipili ng compline-in default (patakbuhin ang &lt;i&gt;cryptsetup --help&lt;/i&gt; para sa iba pang kaalaman).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1775"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Kung mabagal ang iyong computer ay maari kang magdagdag ng bilang para sa siguridad, bilang kapalit ng oraspara matuklasan ang dami ng passphrase na naipasok</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ang Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 ay gumagamit ng GRUB bootloader upang magbukas %1 at MS-Windows. &lt;p&gt;Sa kalakaran ang GRUB2 ay nakainstall sa Master Boot Record (MBR) o ESP (EFI System Partition para sa 64-bit UEFI na system ng boot ) ng iyong drive na gamit sa pang boot at pinapalitan nito ang boot loader na dati mong ginagamit. Ito ay normal&lt;/p&gt;&lt;p&gt;Kung nais mong iinstall ang  GRUB2 sa Partition Boot Record (PBR) sa halip at pagkatapos ay ang GRUB2 ay aarangkasa sa iyong minamarapat na partition. Ang pagpiling ito ay para lamang sa mga bihasa.&lt;/p&gt;&lt;p&gt;Kung tatanggalang ng check ang  Install GRUB box, ang GRUB ay hindi maiinstal sa ngayon. Ang pagpiling ito ay para lamang sa mga bihasa.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Para sindihan ang Common Services &lt;/b&gt;&lt;br/&gt;Pumili ng alinman sa mga ito na common services na maari mong magamit sa configuration ng iyong sistema at ng mga services na maaring kusang umandar sa iyong pagsisimula  %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1817"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1820"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1826"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1827"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1831"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1832"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1835"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1837"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2041"/>
        <location filename="../minstall.cpp" line="2412"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2043"/>
        <location filename="../minstall.cpp" line="2417"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1846"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="133"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="158"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="209"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="570"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1712"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1847"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1849"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1850"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1853"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1855"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1856"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1857"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Warning</source>
        <translation>Babala</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>Installation in Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1878"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1881"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1883"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1902"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1903"/>
        <location filename="../minstall.cpp" line="2316"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1934"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1938"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Next</source>
        <translation>Kasunod</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1975"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1982"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1999"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2241"/>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2241"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2302"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2310"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2324"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2332"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2337"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2414"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2565"/>
        <source>System boot disk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2579"/>
        <location filename="../minstall.cpp" line="2588"/>
        <source>Partition to use:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="94"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Tulong</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="151"/>
        <source>Next</source>
        <translation>Kasunod</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2359"/>
        <source>Back</source>
        <translation>Magbalik</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2365"/>
        <source>Alt+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2378"/>
        <source>Installation in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2393"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1287"/>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Isara</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="204"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished">Antabay habang kumakalap ng impormasyon.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="239"/>
        <source>Terms of Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="266"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="280"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="303"/>
        <source>Change Keyboard Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="310"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="372"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="408"/>
        <location filename="../meinstall.ui" line="791"/>
        <source>Encryption password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <location filename="../meinstall.ui" line="774"/>
        <source>Confirm password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <location filename="../meinstall.ui" line="814"/>
        <location filename="../meinstall.ui" line="846"/>
        <source>Advanced encryption settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="466"/>
        <location filename="../meinstall.ui" line="675"/>
        <source>Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="440"/>
        <source>Use disk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Mga Minamarapat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="709"/>
        <source>Check for badblocks (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="622"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ext4</source>
        <translation type="vanished">ext4</translation>
    </message>
    <message>
        <source>ext3</source>
        <translation type="obsolete">ext3</translation>
    </message>
    <message>
        <source>ext2</source>
        <translation type="obsolete">ext2</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="665"/>
        <source>Label</source>
        <translation>Label</translation>
    </message>
    <message>
        <source>root</source>
        <translation type="vanished">root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Type</source>
        <translation>Uri</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Encryption options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="862"/>
        <source>SHA-512</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="867"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="872"/>
        <source>Whirlpool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="877"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="882"/>
        <source>RIPEMD-160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="899"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="918"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="940"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="953"/>
        <source>Key size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="979"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>Cipher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1022"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1027"/>
        <source>AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1032"/>
        <source>Twofish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1037"/>
        <source>CAST6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1042"/>
        <source>Blowfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1089"/>
        <source>ESSIV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1094"/>
        <source>Plain64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1099"/>
        <source>Plain64BE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1104"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1109"/>
        <source>BENBI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1123"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1136"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1156"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1164"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1169"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1196"/>
        <source>Select Boot Method</source>
        <translation>Pumili ng paraan ng pag Boot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1233"/>
        <source>EFI System Partition</source>
        <translation> Sistema ng Partition ng EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1236"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1255"/>
        <source>Partition Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1258"/>
        <source>PBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1271"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1284"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1303"/>
        <source>System boot disk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1325"/>
        <source>Master Boot Record</source>
        <translation>Pangunahing Record ng Boot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1331"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1334"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1405"/>
        <source>Common Services to Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1424"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1429"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1462"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1489"/>
        <source>Workgroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1502"/>
        <source>Workgroup:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1515"/>
        <source>SaMBa Server for MS Networking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1531"/>
        <source>example.dom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1544"/>
        <source>Computer domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1570"/>
        <source>Computer name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1631"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1672"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1700"/>
        <source>Timezone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1745"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1777"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1817"/>
        <source>Locale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1839"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1857"/>
        <source>Adjust which services should run at startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>View</source>
        <translation>Tanawan</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1918"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1975"/>
        <source>Confirm root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1930"/>
        <source>Root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2004"/>
        <source>Default User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2106"/>
        <source>username</source>
        <translation>pangalan ng user o tagagamit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2045"/>
        <source>Confirm user password:</source>
        <translation>Kumpirmahin ang password ng user of gumagamit:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2032"/>
        <source>Default user password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2016"/>
        <source>Default user login name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="385"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="523"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="558"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="655"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="660"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="693"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="726"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2122"/>
        <source>Autologin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2135"/>
        <source>Show passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2148"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2151"/>
        <source>Save live desktop changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2174"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2183"/>
        <source>What would you like to do with the old directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2190"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2197"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2204"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2249"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2293"/>
        <source>Installation complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2299"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2318"/>
        <source>Reminders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="448"/>
        <source>&amp;Reset to on-disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="338"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="253"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="440"/>
        <source>Template: BTRFS compression (ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="441"/>
        <source>Template: BTRFS compression (LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="450"/>
        <source>Template: &amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="451"/>
        <source>Template: &amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="514"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="252"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="251"/>
        <source>EFI System Partition</source>
        <translation type="unfinished"> Sistema ng Partition ng EFI</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="525"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="563"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="570"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished">Dapat pumili ng root partition.
Ang root partition ay dapat mahigit sa %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="576"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished">Dapat gumamit ng bukod na boot partition kapag ginagawan ng encrypting ang root.</translation>
    </message>
    <message>
        <source>Configure %1 as swap space</source>
        <translation type="obsolete">Baguhin ang %1 bilang swap space</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished">Tanggalin ang laman ng  %1 maliban na lamang sa /home</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="591"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="597"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="600"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished">Ang mga  partitions na iyong napili ay Linux partitions:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="608"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished">Nakakatiyak ka ba na gusto mong i-reformat ang mga partitions na ito?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="616"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished">Ang %1 installer ay magsasagawa ngayon ng format at sisirain ang lahat ng laman na nasa partitions:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="624"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished">Ang %1 installer ay magsasagawa ng mga sumusunod na aksyon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="628"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished">Ang mga akyson ay hindi maaring bawiin. Gusto mo bang magpatuloy?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="725"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished">Ang disk na may partition na iyong napili para sa pag-iinstall ay pumalya:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="729"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished">Output ng Smartmon tool :</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="730"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished">Ang disk na may partition na iyong napili pag sa pag-install ng pagsubok sa SMART monitor (smartctl), pero ang mag pagsubok ay nagsasalaysay na magkakaroon lamang ng mas higit na pagpalya sa hinaharap.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="735"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished">Kung di tiyak ay itigil muna ang pag-install at patakbuhin ang GSmartControl para sa karagdagang kaalaman. </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="737"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished">Gusto mo bang itigil ang pag-iinstall?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="742"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished">Gusto mo bang magpatuloy?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="916"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="924"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished">Inihahanda ang mga hinihinging partitions</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="978"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished">Itinatakda ang LUKS encrypted containers</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="995"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formatting EFI System Partition</source>
        <translation type="obsolete">Pino-format ang  Sistema ng EFI Partition</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1161"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
