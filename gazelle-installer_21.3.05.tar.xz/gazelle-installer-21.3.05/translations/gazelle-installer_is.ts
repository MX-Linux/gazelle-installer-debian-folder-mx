<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="is">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="95"/>
        <source>%1 Installer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="55"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="112"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="133"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="158"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="209"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="337"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="459"/>
        <source>Pretending to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="515"/>
        <source>Preparing to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="527"/>
        <source>Failed to format required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="538"/>
        <source>Paused for required operator input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="548"/>
        <source>Setting system configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="568"/>
        <source>Cleaning up</source>
        <translation>Hreinsa til</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="570"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="728"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="817"/>
        <source>Deleting old system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Creating system directories</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="838"/>
        <source>Fixing configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="880"/>
        <source>Copying new system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="920"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="929"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="947"/>
        <source>Installing GRUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1032"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1048"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1163"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1174"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1193"/>
        <source>The home directory for %1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1222"/>
        <source>Failed to set user account passwords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1242"/>
        <source>Failed to save old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Failed to delete old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1269"/>
        <source>Sorry, failed to create user directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1277"/>
        <source>Sorry, failed to name user directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1298"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>Please enter a computer name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1349"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1355"/>
        <source>Please enter a domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1359"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1366"/>
        <source>Please enter a workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1583"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1587"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1612"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1613"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1614"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>General Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1672"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <location filename="../minstall.cpp" line="1729"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <location filename="../minstall.cpp" line="1730"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1686"/>
        <location filename="../minstall.cpp" line="1731"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1706"/>
        <source>Choose Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1709"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1712"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>Upgrading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1184"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1677"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>By default, the automatic install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1680"/>
        <source>Move the slider to the left to increase the space for &lt;b&gt;home&lt;/b&gt;. Move it to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move the slider all the way to the right if you want both root and home on the same partition; &lt;b&gt;this is not recommended.&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1682"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1689"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1711"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1716"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1719"/>
        <source>Preferred Filesystem Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>Bad Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>System drive management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>If you want more control over the drive layouts than what can be provided on this page, click the button to the bottom-right of the list. This will run the drive management tool provided with the operating system, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>Advanced Encryption Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1739"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1741"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>A variety of ciphers are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>Chain mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>IV generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>Key size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1765"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>LUKS key hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1775"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1817"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1820"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1826"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1827"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1831"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1832"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1835"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1837"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2041"/>
        <location filename="../minstall.cpp" line="2412"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2043"/>
        <location filename="../minstall.cpp" line="2417"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1846"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1847"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1849"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1850"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1853"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1855"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1856"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1857"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Warning</source>
        <translation>Aðvörun</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>Installation in Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1878"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1881"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1883"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1902"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1903"/>
        <location filename="../minstall.cpp" line="2316"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1934"/>
        <source>Finish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1938"/>
        <source>OK</source>
        <translation>Í lagi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1975"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1982"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1999"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2241"/>
        <source>Confirmation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2241"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2302"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2310"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2324"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2332"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2337"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2414"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2565"/>
        <source>System boot disk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2579"/>
        <location filename="../minstall.cpp" line="2588"/>
        <source>Partition to use:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="94"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Hjálp</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="151"/>
        <source>Next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2359"/>
        <source>Back</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2365"/>
        <source>Alt+K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2378"/>
        <source>Installation in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2393"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1287"/>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Alt+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Hætta</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="204"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="239"/>
        <source>Terms of Use</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="266"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="280"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="303"/>
        <source>Change Keyboard Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="310"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="408"/>
        <location filename="../meinstall.ui" line="791"/>
        <source>Encryption password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <location filename="../meinstall.ui" line="774"/>
        <source>Confirm password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <location filename="../meinstall.ui" line="814"/>
        <location filename="../meinstall.ui" line="846"/>
        <source>Advanced encryption settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="466"/>
        <location filename="../meinstall.ui" line="675"/>
        <source>Encrypt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="440"/>
        <source>Use disk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="709"/>
        <source>Check for badblocks (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="622"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="372"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="665"/>
        <source>Label</source>
        <translation>Merki</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Type</source>
        <translation>Tegund</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="758"/>
        <source>Encryption options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="862"/>
        <source>SHA-512</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="867"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="872"/>
        <source>Whirlpool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="877"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="882"/>
        <source>RIPEMD-160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="899"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="918"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="940"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="953"/>
        <source>Key size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="979"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1002"/>
        <source>Cipher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1022"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1027"/>
        <source>AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1032"/>
        <source>Twofish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1037"/>
        <source>CAST6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1042"/>
        <source>Blowfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1089"/>
        <source>ESSIV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1094"/>
        <source>Plain64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1099"/>
        <source>Plain64BE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1104"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1109"/>
        <source>BENBI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1123"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1136"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1156"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1164"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1169"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1196"/>
        <source>Select Boot Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1233"/>
        <source>EFI System Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1236"/>
        <source>ESP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1255"/>
        <source>Partition Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1258"/>
        <source>PBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1271"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1284"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1303"/>
        <source>System boot disk:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1325"/>
        <source>Master Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1331"/>
        <source>MBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1334"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1405"/>
        <source>Common Services to Enable</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1424"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1429"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1462"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1489"/>
        <source>Workgroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1502"/>
        <source>Workgroup:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1515"/>
        <source>SaMBa Server for MS Networking</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1531"/>
        <source>example.dom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1544"/>
        <source>Computer domain:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1570"/>
        <source>Computer name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1631"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1672"/>
        <source>Format:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1700"/>
        <source>Timezone:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1745"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1777"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1817"/>
        <source>Locale:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1839"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1857"/>
        <source>Adjust which services should run at startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>View</source>
        <translation>Skoða</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1918"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1975"/>
        <source>Confirm root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1930"/>
        <source>Root password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2004"/>
        <source>Default User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2106"/>
        <source>username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2045"/>
        <source>Confirm user password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2032"/>
        <source>Default user password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2016"/>
        <source>Default user login name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="385"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="523"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="558"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="655"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="660"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="693"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="716"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="726"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="736"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2122"/>
        <source>Autologin</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2135"/>
        <source>Show passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2148"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2151"/>
        <source>Save live desktop changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2174"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2183"/>
        <source>What would you like to do with the old directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2190"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2197"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2204"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2249"/>
        <source>Tips</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2293"/>
        <source>Installation complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2299"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2318"/>
        <source>Reminders</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="448"/>
        <source>&amp;Reset to on-disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="338"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="253"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="440"/>
        <source>Template: BTRFS compression (ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="441"/>
        <source>Template: BTRFS compression (LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="450"/>
        <source>Template: &amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="451"/>
        <source>Template: &amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="514"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="252"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="251"/>
        <source>EFI System Partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="525"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="563"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="570"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="576"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="591"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="597"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="600"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="608"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="616"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="624"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="628"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="725"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="729"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="730"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="735"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="737"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="742"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="916"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="924"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="978"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="995"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1161"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
