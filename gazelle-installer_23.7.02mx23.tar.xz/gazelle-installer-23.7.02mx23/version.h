const QString VERSION {"23.7.02mx23"};
