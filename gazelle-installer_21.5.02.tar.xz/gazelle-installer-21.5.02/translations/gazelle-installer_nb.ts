<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="nb">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Avslutter</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation>Installering av %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Bidra til %1

%1 understøttes av folk som deg. Noen bidrar med brukerstøtte i forumet – %2, eller oversetter hjelpefiler til andre språk eller korrekturleser, skriver hjelpetekst eller tester ny programvare.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Installasjonsprogrammet kan ikke startes fordi det allerede kjører i bakgrunnen.

Lukk det hvis mulig, eller kjør &apos;pkill minstall&apos; i terminalen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation>Mangler tilgang til installasjonskilden.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>Systemet kjører et 32 biters OS som er startet i 64 biters UEFI-modus. Velg «Legacy boot» (gammel type oppstart) når maskinen starter, ellers vil ikke systemet kunne starte opp.
Det anbefales at du avslutter nå og starter på nytt med «Legacy boot».

Vil du fortsette installasjonen?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 er en uavhengig Linux-distribusjon basert på Debian Stable.

%1 bruker noen komponenter fra MEPIS Linux, som er utgitt under den frie lisensen Apache. Noen MEPIS-komponenter er endret for bruk i %1.

Lykke til med %1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation>Simulerer installasjon av %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="530"/>
        <source>Preparing to install %1</source>
        <translation>Forbereder installasjon av %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="542"/>
        <source>Failed to format required partitions.</source>
        <translation>Klarte ikke formatere nødvendige partisjoner.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="553"/>
        <source>Paused for required operator input</source>
        <translation>Pauset for nødvendig inndata fra bruker</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="563"/>
        <source>Setting system configuration</source>
        <translation>Setter opp systemet</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="581"/>
        <source>Cleaning up</source>
        <translation>Rydder opp</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="583"/>
        <source>Finished</source>
        <translation>Fullført</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="741"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>Fant ugyldige innstillinger i oppsettsfila (%1). Kontroller de markerte feltene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="797"/>
        <source>Deleting old system</source>
        <translation>Sletter gammelt system</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="801"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Klarte ikke slette gammel %1 på målet.
Går tilbake til første steg.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="808"/>
        <source>Creating system directories</source>
        <translation>Oppretter systemmapper</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Fixing configuration</source>
        <translation>Ferdigstiller oppsett</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="860"/>
        <source>Copying new system</source>
        <translation>Kopierer nytt system</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="900"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Ukjent framdrift for kopiering. Mangler statistikk fra filsystemet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="909"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Klarte ikke skrive %1 til målet.
Går tilbake til første steg.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="952"/>
        <source>Updating initramfs</source>
        <translation>Oppdaterer initramfs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="962"/>
        <source>Installing GRUB</source>
        <translation>Installerer GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1030"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>Klarte ikke installere GRUB. For å reparere installasjonen kan du starte maskinen med live-mediet og velge «GRUB Rescue» i menyen.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">Klarte ikke oppdatere NVRAM-oppstartsvariabel. Systemet kan få problemer med oppstart, og kan i så fall repareres med «GRUB Rescue» i oppstartsmenyen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Brukernavnet kan ikke inneholde spesialtegn eller mellomrom.
Velg et annet brukernavn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Brukernavnet er allerede i bruk.
Velg et annet brukernavn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1174"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>Root-kontoen mangler passord. Vil du fortsette?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Hjemmemappa for %1 finnes allerede.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>Failed to set user account passwords.</source>
        <translation>Klarte ikke lagre brukerpassord.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1229"/>
        <source>Failed to save old home directory.</source>
        <translation>Klarte ikke lagre gammel hjemmemappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Failed to delete old home directory.</source>
        <translation>Klarte ikke slette gammel hjemmemappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1252"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Klarte ikke opprette brukermappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Klarte ikke navngi brukermappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Klarte ikke endre rettigheter til brukermappe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1324"/>
        <source>Please enter a computer name.</source>
        <translation>Skriv inn datamaskinens navn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Datamaskinens navn kan ikke inneholde ugyldige tegn.
Velg et annet navn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1334"/>
        <source>Please enter a domain name.</source>
        <translation>Skriv inn et domenenavn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1338"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Domenenavnet kan ikke inneholde ugyldige tegn.
Velg et annet navn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>Please enter a workgroup.</source>
        <translation>Skriv inn en arbeidsgruppe.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1588"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Kan hele disken (%1) formateres og tas i bruk til %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>ADVARSEL: Valgt disk er minst 2 TB, og må formateres med GPT. Noen datamaskiner kan ikke starte opp med GPT-formaterte disker.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1618"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Data i /home kan ikke beholdes fordi nødvendig informasjon ikke kunne framskaffes.</translation>
    </message>
    <message>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="vanished">Dersom partisjonen som inneholder /home er kryptert må de riktige alternativer og passord for krypteringen oppgis.</translation>
    </message>
    <message>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="vanished">Installasjonsprogrammet kan ikke kryptere en eksisterende /home-mappe eller -partisjon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <source>General Instructions</source>
        <translation>Generelle instruksjoner</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>LUKK ALLE ANDRE PROGRAMMER FØR DU FORTSETTER.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Les instruksjonene på hver side før noe velges. Trykk «Neste» for å fortsette. Ødeleggende handlinger må bekreftes før de kjører.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>Limitations</source>
        <translation>Eget ansvar</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Denne programvaren tilbys slik den er, uten garanti av noe slag. Det er ditt eget ansvar å reservekopiere data før du fortsetter.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>Installation Options</source>
        <translation>Installasjonsalternativer</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation>Installasjonen krever omlag %1 diskplass. %2 eller mere er anbefalt.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1686"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Hvis maskinen har Mac OS eller Windows (fra og med Vista) må kanskje disses systemverktøy brukes til å sette opp partisjoner og oppstartslaster før installering.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1687"/>
        <source>Using the root-home space slider</source>
        <translation>Bruk av glidebryter for diskplass root-home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation>Standardinstallasjonen fordeler diskplass på root- og home-partisjoner. Glidebryteren lar deg velge hvordan diskplassen skal fordeles på hver partisjon. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Flytt bryteren til høyre for å la &lt;b&gt;root&lt;/b&gt; få mer plass. Flytt den til venstre for å la &lt;b&gt;home&lt;/b&gt; få mer plass.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1691"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Flytt bryteren helt til høyre for å la root og home være på samme partisjon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation>Hvis du vil installere mange eller store programmer, slik som grafikk-, lyd- eller videoredigeringsprogrammer, så bør &lt;b&gt;root&lt;/b&gt;-partisjonen være rommelig.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation>Hvis du vil lagre mye data, eller maskinen har mange brukere, så bør &lt;b&gt;home&lt;/b&gt;-partisjonen være rommelig.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1696"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Oppgradering av operativsystemet er mer pålitelig hvis home-mappa ligger på en separat partisjon. Reservekopiering og gjenoppretting blir også enklere. Dette kan øke ytelsen ved at systemfiler holdes på en bestemt partisjon på disken.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1698"/>
        <location filename="../minstall.cpp" line="1761"/>
        <source>Encryption</source>
        <translation>Kryptering</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1699"/>
        <location filename="../minstall.cpp" line="1762"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Data kan krypteres med LUKS. Det trengs i så fall et passord.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1700"/>
        <location filename="../minstall.cpp" line="1763"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Det trengs en separat ukryptert oppstartspartisjon. Velg &lt;b&gt;Avansert oppsett av kryptering&lt;/b&gt; for å velge flere alternativer, slik som krypteringsmetode.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Når kryptering brukes med autoinstallering så vil den separate oppstartspartisjonen bli opprettet automatisk.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Using a custom disk layout</source>
        <translation>Bruk av tilpasset diskutforming</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Velg «&lt;b&gt;%2&lt;/b&gt;» og trykk &lt;b&gt;Neste&lt;/b&gt; for mer kontroll på hvor %1 installeres til. På neste side kan du velge og sette opp nødvendige lagringsenheter og partisjoner.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1719"/>
        <source>Choose Partitions</source>
        <translation>Velg partisjoner</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Velg i partisjonslista hvilke partisjoner som skal brukes i denne installasjonen. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Enhet&lt;/i&gt; – dette er navnet på blokkenheten som er, eller skal, tilordnes den nye partisjonen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Størrelse&lt;/i&gt; – partisjonens størrelse. Den kan kun endres ved ny utforming. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Etikett&lt;/i&gt; – etiketten som tilordnes partisjonen ved formatering.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation>&lt;i&gt;Bruk som&lt;/i&gt; – velg noe her for å bruke partisjonen i installasjonen. Her kan også monteringspunkt velges, og det må starte med skråstrek – «/».</translation>
    </message>
    <message>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption. To preserve the format of an existing encrypted partition, you must use the same passphrase that it was originally encrypted with.</source>
        <translation type="vanished">&lt;i&gt;Kryptering&lt;/i&gt; – bruk LUKS-kryptering for denne partisjonen. Passordet gjelder for alle partisjoner valgt for kryptering. Bruk det originale passordet hvis du har en eksisterende kryptert partisjon som skal bevares.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation>&lt;i&gt;Format&lt;/i&gt; – partisjonens format. Tilgjengelige format avhenger av hva partisjonen skal brukes til. Opprinnelig format kan bevares ved å velge &lt;b&gt;Bevar&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Linux-filsystemene ext2, ext3, ext4, jfs, xfs, btrfs og reiserfs støttes, og ext4 anbefales.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Alternativer for montering&lt;/i&gt; – velg alternativer for montering av denne partisjonen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1731"/>
        <source>Menus and actions</source>
        <translation>Menyer og handlinger</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation>Høyreklikk en disk eller partisjon i lista for å få opp en rekke mulige handlinger.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Knappene på høyre side av lista kan også brukes til å behandle oppføringene.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation>Installasjonsprogrammet kan ikke endre diskens eksisterende utforming. For å lage en tilpasset utforming må du velge &lt;b&gt;Ny utforming&lt;/b&gt; i menyen eller velge knappen (%1). Dette sletter eksisterende layout.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Basic layout requirements</source>
        <translation>Grunnleggende krav for utforming</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 trenger en rotpartisjon. Vekselpartisjonen er valgfri, men anbefales sterkt. For å kunne bruke dvalemodus i %1 trengs en vekselpartisjon som er større enn RAM-størrelsen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>En separat /home-partisjon vil gjøre det lettere å oppgradere systemet i framtida. Det vil være besværlig å flytte /home til en egen partisjon senere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>Need help creating a layout?</source>
        <translation>Behov for hjelp ved opprettelse av utforming?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation>Høyreklikk på en disk for å få opp en meny. Velg en mal for utforming. Disse utformingene ligner den til vanlig installasjon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation>&lt;i&gt;Standardinstallasjon&lt;/i&gt; – passer de flese oppsett. Malen legger ikke til en separat boot-partisjon, og kan derfor ikke brukes med et kryptert operativsystem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation>&lt;i&gt;Kryptert system&lt;/i&gt; – inneholder boot-partisjonen som trengs for å laste et kryptert operativsystem. Malen kan også brukes som basis for et system med flere operativsystem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>Upgrading</source>
        <translation>Oppgradering</translation>
    </message>
    <message>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="vanished">For å oppgradere fra en eksisterende Linux-installasjon må samme home-partisjon som tidligere velges. Velg &lt;b&gt;behold&lt;/b&gt; som type filsystem.</translation>
    </message>
    <message>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="vanished">Installasjonsprogrammet vil ikke reformatere rotpartisjonen hvis det eksisterende /home-mappetreet skal bevares. Dermed vil installasjonen ta mye lenger tid enn vanlig.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>Preferred Filesystem Type</source>
        <translation>Foretrukket filsystemtype</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>%1 kan brukes med ext2, ext3, ext4, f2fs, jfs, xfs, btrfs og reiser. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Btrfs kan komprimere data. Algoritmen lzo er raskest, men komprimerer mindre enn zlib, som er treigere, men komprimerer bedre.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Bad Blocks</source>
        <translation>Dårlige blokker</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1755"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Det er mulig å undersøke og korrigere for dårlige blokker under formatering med ext2, ext3 eller ext4. Denne undersøkelsen tar mye tid og kan hoppes over hvis man ikke mistenker at harddisken har dårlige blokker.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>System partition management tool</source>
        <translation>Verktøy for behandling av systempartisjon</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation>Velg knappen partisjonsbehandling (%1) for mer kontroll over diskutforming (f.eks. endring av eksisterende utforming). Dette starter operativsystemets partisjonsverktøy, der eksakt utforming kan opprettes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>Other partitions</source>
        <translation>Andre partisjoner</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation>Installasjonsprogrammet tillater at andre partisjoner opprettes, eller brukes til andre formål. Men husk at eldre systemer ikke kan håndtere disker med flere enn fire partisjoner.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1769"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>Advanced Encryption Settings</source>
        <translation>Avansert oppsett av kryptering</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Her kan LUKS-krypterte partisjoner finjusteres.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Forvalgene vil stort sett gi en praktisk balanse mellom sikkerhet og ytelse som passer sensitive data.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Dette er en grunnleggende omtale av LUKS-parametrene, ikke en innføring i kryptografi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1781"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Disse innstillingene bør ikke endres uten solid kunnskap innen kryptografi for å sikre seg mot at svak kryptering tas i bruk.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Hvis et felt redigeres vil det vanligvis påvirke alternativene nedenfor. Disse feltene kan endres automatisk til anbefalte verdier.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>De anbefalte verdiene kan endres for å bedre ytelse eller sikkerhet. Dette skjer på egen risiko og eget ansvar. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1785"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Knappen &lt;b&gt;Ytelsestest&lt;/b&gt; (som kjører en test i &lt;i&gt;cryptsetup&lt;/i&gt;) kan sammenligne ytelsen til ulike kombinasjoner av hasher, krypteringsmetoder og kjedemoduser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Legg merke til at &lt;i&gt;ytelsestesten i cryptsetup&lt;/i&gt; dekker kun de mest vanlige kombinasjonene, ikke alle som er mulige. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>Cipher</source>
        <translation>Krypteringsmetode</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>A variety of ciphers are available.</source>
        <translation>Flere krypteringsmetoder er tilgjengelige.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>var en av fem AES-finalister. Den anses for å ha en høyere sikkerhetsmargin enn Rijndael og de andre AES-finalistene. Den yter bedre på noen 64-biters CPU-er.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(også kjent som &lt;i&gt;Rijndael&lt;/i&gt;) er en veldig vanlig krypteringsmetode, og mange moderne CPU-er har derfor egne instruksjoner for AES. Rijndael ble valgt framfor Serpent på grunn av ytelse. Det er per idag ikke grunn til å tro at det finnes noen praktiske angrep på metoden.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>er oppfølgeren til Blowfish. Den var en av fem AES-finalister, men ble ikke utvalgt som standardmetode.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) var en kandidat i AES-konkurransen, men ble ikke finalist.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>er en 64-biters blokk-krypteringsmetode laget av Bruce Schneier. Den anbefales ikke for sensitiv bruk fordi kun CBC- og ECB-modus støttes. Blowfish støtter nøkkelstørrelser mellom 32 og 448 biter som kan deles på 8.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Chain mode</source>
        <translation>Kjedemodus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Det ville ha dukket opp et mønster hvis alle blokker ble kryptert med samme nøkkel. Dermed ville datainnholdet kunne hentes fram uten nøkkelen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>(står for «XEX-based Tweaked codebook with ciphertext Stealing») er en moderne kjedemodus som erstatter CBC og EBC. Den er standard og anbefales som kjedemodus. Dersom ESSIV brukes framfor Plain64 vil ytelsen reduseres uten merkbar økning av sikkerhet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(står for «Cipher Block Chaining») er enklere enn XTS, men er sårbar for et såkalt «padding oracle»-angrep (som ESSIV i noen grad bøter på), og anbefales derfor ikke til sensitiv bruk.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(står for «Electronic CodeBook») er mindre sikker enn CBC og anbefales derfor ikke til sensitiv bruk.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>IV generator</source>
        <translation>IV-generator</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>XTS og CBC bruker en &lt;b&gt;i&lt;/b&gt;nitialiserings&lt;b&gt;v&lt;/b&gt;ektor, og her velges hvordan den skal genereres. &lt;b&gt;ESSIV&lt;/b&gt; trenger en hash-funksjon, og den kan velges i en egen nedtrekksliste. Hvilke hash-funksjoner som er valgbare kommer an på valgt krypteringsmetode.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>ECB-modus bruker ikke IV, så disse feltene slås av hvis ECB velges som kjedemodus.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Key size</source>
        <translation>Nøkkelstørrelse</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Nøkkelstørrelsen velges i biter. Det er krypteringsmetode og kjedemodus som bestemmer tilgjengelige nøkkelstørrelser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>Kjedemodusen XTS deler nøkkelen i to (for eksempel vil AES-256 i XTS-modus kreve en nøkkelstørrelse på 512 biter).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>LUKS key hash</source>
        <translation>Nøkkelhash for LUKS</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>Hashen som brukes til PBKDF2 og AF-splitteren.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 og RIPEMD-160 anbefales ikke til sensitiv bruk fordi man har oppdaget svakheter med dem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Kernel RNG</source>
        <translation>Kjerne-RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Velger hvilken RNG (generator av tilfeldige tall) som skal brukes til å lage hovednøkkelen (volumnøkkelen). Denne nøkkelen brukes over lang tid.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Det finnes to muligheter: /dev/&lt;b&gt;random&lt;/b&gt;, som blokkerer fram til tilstrekkelig entropi kan oppnås (og dette kan ta lang tid i situasjoner med lite entropi), og /dev/&lt;b&gt;urandom&lt;/b&gt;, som ikke vil blokkere selv om det er utilstrekkelig entropi (og dette kan muligens føre til svake nøkler).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF-rundetid &lt;/b&gt;&lt;br/&gt;Hvor mye tid (i millisekunder) som skal brukes til behandling av PBKDF2-adgangsfraser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Verdien 0 velger den innebygde forvalgte verdien (kjør &lt;i&gt;cryptsetup --help&lt;/i&gt; for flere detaljer).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Denne verdien kan om ønskelig økes på treige datamaskiner – dermed vil sikkerheten økes på bekostning av at det vil ta lenger tid å låse opp volum når adgangsfrasen skrives inn.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Velg oppstartsmetode&lt;/b&gt;&lt;br/&gt; %1 bruker oppstartslasteren GRUB for å laste inn %1 og MS Windows. &lt;p&gt;Som standard vil GRUB2 installeres i hovedpartisjonssektoren (MBR) eller ESP (EFI-systempartisjonen til 64-biters maskiner som har UEFI-oppstart), og erstatter dermed den gamle oppstartslasteren. Dette er vanlig. &lt;/p&gt;&lt;p&gt; GRUB2 kan alternativt installeres til en partisjonssektor (PBR), det vil si helt i begynnelsen av en angitt partisjon. Dette er kun ment for eksperter.&lt;/p&gt;&lt;p&gt;Det er også mulig å la være å installere GRUB i denne omgang. Da må en vite hva en gjør.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Aktivering av vanlige tjenester&lt;/b&gt;&lt;br/&gt; Velg hvilke tjenester som skal startes automatisk når %1 starter opp.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identifisering av datamaskinen&lt;/b&gt;&lt;br/&gt; Datamaskinens navn er et unikt navn som identifiserer maskinen hvis den er koblet til et nettverk. Domenet vil vanligvis ikke brukes hvis ikke internettleverandøren eller det lokale nettverket krever det.&lt;/p&gt;&lt;p&gt; Datamaskinens navn og domenenavnet kan kun inneholde alfanumeriske tegn, punktum og bindestrek. De kan ikke inneholde blanktegn eller starte eller slutte med bindestrek.&lt;/p&gt;&lt;p&gt; SaMBa-tjeneren må aktiveres hvis mapper eller skrivere skal deles med en lokal maskin som kjører MS Windows eller Mac OS X.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1851"/>
        <source>Localization Defaults</source>
        <translation>Forvalgt lokaltilpassing</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Velg standard lokaltilpassing. Denne vil tas i bruk hvis den ikke overstyres av brukeren.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1853"/>
        <source>Configure Clock</source>
        <translation>Still inn klokka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1854"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Systemklokka har Greenwich Meridian Time (GTM) eller Coordinated Universal Time (UTC) på Apple- og Unix-maskiner. Velg «Systemklokka har lokaltid» hvis ikke.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1856"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Systemet starter med tidssonen GMT/UTC. Dette kan endres etter omstart til den nye installasjonen ved å høyreklikke på klokka i panelet og velge «Egenskaper».</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Service Settings</source>
        <translation>Tjenesteinnstillinger</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Mannen i gata behøver ikke endre forvalgene. Brukere med ressurssvake maskiner kan slå av unødvendige tjenester for å redusere RAM-bruken – men vit hva du gjør.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1865"/>
        <source>Default User Login</source>
        <translation>Vanlig brukerkonto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1866"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Root-brukeren svarer til administrator i andre operativsystemer. Denne brukerkontoen bør ikke anvendes til ordinær bruk. Skriv inn et nytt brukernavn for den kontoen som skal brukes til vanlig innlogging. Senere kan flere brukere legges til med %1 sin brukerbehandling.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1870"/>
        <source>Passwords</source>
        <translation>Passord</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Skriv inn et nytt passord for den vanlige brukerkontoen og for root-kontoen. Hvert passord må for sikkerhets skyld skrives inn to ganger.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1873"/>
        <source>No passwords</source>
        <translation>Ingen passord</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>La passordfeltet være tomt hvis den vanlige brukerkontoen ikke behøver passord. Dette lar deg logge inn uten passord.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Dette bør kun skje når kontoen ikke trenger være sikker, slik som offentlige terminaler.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1885"/>
        <source>Old Home Directory</source>
        <translation>Gammel hjemmemappe</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1886"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Denne brukerkontoen har allerede en hjemmemappe. Velg hva som skal skje med denne mappa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1888"/>
        <source>Re-use it for this installation</source>
        <translation>Gjenbruk mappa i denne installasjonen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1889"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Brukerkontoen vil beholde den gamle hjemmemappa. Dette anbefales ved oppgradering, siden filer og oppsett vil beholdes.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Rename it and create a new directory</source>
        <translation>Gi den nytt navn og lag ny mappe</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Lag en ny hjemmemappe for brukerkontoen, og gi nytt navn til den gamle hjemmemappa. Filene og oppsettet vil ikke umiddelbart være synlige i den nye installasjonen, men vil ligge i den omdøpte mappa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Den gamle mappa vil få et tall i slutten av navnet, avhengig av hvor mange ganger den har endret navn tidligere.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>Delete it and create a new directory</source>
        <translation>Slett den og lag ny mappe</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1896"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Den gamle hjemmemappa vil slettes og den nye opprettes fra bunnen av.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Warning</source>
        <translation>Advarsel</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1898"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Alle filer og oppsett vil slettes for alltid hvis dette valget velges. Det vil være besværlig å gjenopprette dem.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1914"/>
        <source>Installation in Progress</source>
        <translation>Installering pågår</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1915"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>Installering av %1 pågår. En ny installasjon vil ta omlag 3-20 minutter, avhengig av maskinens hastighet og størrelsen til eventuelle partisjoner som skal formateres.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1917"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Hvis «Avbryt» velges så vil installasjonsprogrammet avbrytes så snart som mulig.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1919"/>
        <source>Change settings while you wait</source>
        <translation>Endre innstillinger mens du venter</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1920"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Velg &lt;b&gt;Neste&lt;/b&gt; eller &lt;b&gt;Tilbake&lt;/b&gt; mens %1 installeres for å angi øvrig nødvendig informasjon.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1922"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Dette kan tas i eget tempo. Installasjonsprogrammet vil pause for svar om nødvendig.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1931"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Fullført&lt;/b&gt;&lt;br/&gt; Installasjonen av %1 er nå fullført.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finne programmer&lt;/b&gt;&lt;br/&gt; %1 kommer med hundrevis av programmer. Bla gjennom menyen og forsøk dem. Flere av dem ble utviklet spesielt for %1-prosjektet. Disse vises i hovedmenyene. &lt;p&gt;%1 har dessuten mange vanlige Linux-programmer som kun kan kjøres fra kommandolinja og derfor ikke vises i menyen.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Lykke til med %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1941"/>
        <location filename="../minstall.cpp" line="2355"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Bidra til %1&lt;/b&gt;&lt;br/&gt;%1 understøttes av folk som deg. Noen bidrar med brukerstøtte i forumet – %2, eller oversetter hjelpefiler til andre språk eller korrekturleser, skriver hjelpetekster eller tester ny programvare.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1972"/>
        <source>Finish</source>
        <translation>Fullfør</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1976"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Next</source>
        <translation>Neste</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2013"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>Setter opp systemet. Vennligst vent.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2016"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Ferdig med oppsettet. Starter på nytt.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2020"/>
        <source>Could not complete configuration.</source>
        <translation>Klarte ikke fullføre oppsettet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2037"/>
        <source>Loading...</source>
        <translation>Laster …</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2079"/>
        <location filename="../minstall.cpp" line="2470"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2081"/>
        <location filename="../minstall.cpp" line="2478"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2280"/>
        <source>Confirmation</source>
        <translation>Bekreft</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2280"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Installasjonen og oppsettet er ikke fullført.
Vil du virkelig avbryte nå?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2341"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Få hjelp&lt;/b&gt;&lt;br/&gt;%2 har grunnleggende informasjon om %1.&lt;/p&gt;&lt;p&gt;%3-forumet har frivillige som bedriver brukerstøtte, %4&lt;/p&gt;&lt;p&gt;Husk å beskrive problemet og datamaskinen i noe detalj hvis du spør etter hjelp. Det kan ikke nytte å bare si at det ikke virker.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2349"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparerer installasjonen&lt;/b&gt;&lt;br/&gt;Hvis %1 ikke lenger kan starte fra harddisken så er det mulig å reparere dette ved å starte fra live-DVD eller live-USB og kjøre et av verktøyene i %1, eller ved å bruke et av de vanlige Linux-verktøyene for å reparere systemet.&lt;/p&gt;&lt;p&gt;%1 live-DVD eller live-USB kan også brukes til å gjenopprette data fra MS Windows-systemer.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2363"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Tilpass lydmikser&lt;/b&gt;&lt;br/&gt; %1 forsøker å sette opp lydmikseren automatisk, men av og til må man skru opp volumet og slå på dempede kanaler selv. &lt;/p&gt;&lt;p&gt;Menyen har snarvei til mikseren. Velg den for å åpne mikseren.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2371"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Hold %1 oppdatert&lt;/b&gt;&lt;br/&gt;For mer informasjon og oppdateringer besøk &lt;/p&gt;&lt;p&gt;%2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2376"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Takk&lt;/b&gt;&lt;br/&gt;Takk til alle som har bidratt til %1 med tid, penger, forslag, arbeid, ideer, promotering, ris og/eller ros.&lt;/p&gt;&lt;p&gt;%1 ville ikke eksistert uten dere.&lt;/p&gt;&lt;p&gt;%2 utviklingslag&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2428"/>
        <source>%1% root</source>
        <translation>%1% root</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2428"/>
        <source>%2% home</source>
        <translation>%2% home</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2475"/>
        <source>----</source>
        <translation>----</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2523"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2534"/>
        <source>Load key from file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2535"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2664"/>
        <source>System boot disk:</source>
        <translation>Systemets oppstartsdisk:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2678"/>
        <location filename="../minstall.cpp" line="2687"/>
        <source>Partition to use:</source>
        <translation>Bruk denne partisjonen:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation>Bruk passord</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Hjelp</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation>Sanntidslogg</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Lukk</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>Neste</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt + N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Samler informasjon - vennligst vent.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Vilkår for bruk</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Tastaturoppsett&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Modell:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation>Endre tastaturoppsett</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Oppsett:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Velg type installasjon</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Vanlig installasjon, bruk hele disken</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation>Tilpasset diskutforming</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="403"/>
        <location filename="../meinstall.ui" line="791"/>
        <source>Confirm password:</source>
        <translation>Bekreft passord:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <location filename="../meinstall.ui" line="808"/>
        <source>Encryption password:</source>
        <translation>Krypteringspassord:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="426"/>
        <location filename="../meinstall.ui" line="831"/>
        <location filename="../meinstall.ui" line="863"/>
        <source>Advanced encryption settings</source>
        <translation>Avansert oppsett av kryptering</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="442"/>
        <source>Use disk:</source>
        <translation>Bruk disk:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="468"/>
        <location filename="../meinstall.ui" line="705"/>
        <source>Encrypt</source>
        <translation>Kryptering</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="525"/>
        <source>Root</source>
        <translation>Root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="560"/>
        <source>Home</source>
        <translation>Home</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="624"/>
        <source>Choose partitions</source>
        <translation>Velg partisjoner</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation>Legg til en ny partisjon. Dette virker bare med ny utforming.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Device</source>
        <translation>Enhet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Size</source>
        <translation>Størrelse</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="695"/>
        <source>Label</source>
        <translation>Navn</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="700"/>
        <source>Use For</source>
        <translation>Bruk som</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="710"/>
        <source>Format</source>
        <translation>Formater</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mount Options</source>
        <translation>Monteringsalternativer</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="673"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation>Spør operativsystemet og last inn utformingen til alle disker på nytt.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="642"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation>Se etter dårlige sektorer (tar lenger tid)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="649"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation>Fjern eksisterende oppføring fra utformingen. Dette virker bare med oppføringer i ny utforming.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="734"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation>Merk den disken som skal slettes for ny utforming.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="745"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Kjør operativsystemets partisjonsverktøy.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="756"/>
        <source>Load key from file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="775"/>
        <source>Encryption options</source>
        <translation>Krypteringsinnstillinger</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="879"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="884"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="889"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="894"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="899"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="916"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="935"/>
        <source> mS</source>
        <translation> mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="957"/>
        <source>LUKS key hash:</source>
        <translation>Nøkkelhash for LUKS:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="970"/>
        <source>Key size:</source>
        <translation>Nøkkelstørrelse:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="996"/>
        <source>KDF round time:</source>
        <translation>KDF-rundetid</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1019"/>
        <source>Cipher:</source>
        <translation>Krypteringsmetode:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1039"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1044"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1049"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1054"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1076"/>
        <source>Benchmark...</source>
        <translation>Ytelsestest …</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1106"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1111"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1116"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1121"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1126"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1140"/>
        <source>IV generator:</source>
        <translation>IV-generator:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1153"/>
        <source>Chain mode:</source>
        <translation>Kjedemodus:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1173"/>
        <source>Kernel RNG:</source>
        <translation>Kjerne-RNG:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1181"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1186"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1213"/>
        <source>Select Boot Method</source>
        <translation>Velg oppstartsmetode</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>EFI System Partition</source>
        <translation>EFI-systempartisjon</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1253"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1272"/>
        <source>Partition Boot Record</source>
        <translation>Partisjonssektor</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation>Installer til:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1301"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Installer GRUB for Linux og Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1304"/>
        <location filename="../meinstall.ui" line="2414"/>
        <source>Alt+A</source>
        <translation>Alt + A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1320"/>
        <source>System boot disk:</source>
        <translation>Systemets oppstartsdisk:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1342"/>
        <source>Master Boot Record</source>
        <translation>Hovedpartisjonssektor</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1348"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1351"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1422"/>
        <source>Common Services to Enable</source>
        <translation>Aktivering av vanlige tjenester</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1441"/>
        <source>Service</source>
        <translation>Tjeneste</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1446"/>
        <source>Description</source>
        <translation>Beskrivelse</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1479"/>
        <source>Computer Network Names</source>
        <translation>Nettverksnavn</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1506"/>
        <source>Workgroup</source>
        <translation>Arbeidsgruppe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Workgroup:</source>
        <translation>Arbeidsgruppe:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1532"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa-tjener for MS-nettverk</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1548"/>
        <source>example.dom</source>
        <translation>eksempel.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1561"/>
        <source>Computer domain:</source>
        <translation>Domenenavn:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1587"/>
        <source>Computer name:</source>
        <translation>Datamaskinens navn:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1648"/>
        <source>Configure Clock</source>
        <translation>Still inn klokka</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1689"/>
        <source>Format:</source>
        <translation>Format:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Timezone:</source>
        <translation>Tidssone:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1762"/>
        <source>System clock uses local time</source>
        <translation>Systemklokka bruker lokaltid</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1794"/>
        <source>Localization Defaults</source>
        <translation>Forvalgt lokaltilpassing</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1834"/>
        <source>Locale:</source>
        <translation>Lokaltilpassing:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1856"/>
        <source>Service Settings (advanced)</source>
        <translation>Tjenesteinnstillinger (avansert)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1874"/>
        <source>Adjust which services should run at startup</source>
        <translation>Velg hvilke tjenester som skal kjøre under oppstart</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1877"/>
        <source>View</source>
        <translation>Vis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Root (administrator) Account</source>
        <translation>Root-konto (administrator)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1947"/>
        <source>Root password:</source>
        <translation>Root-passord:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>Confirm root password:</source>
        <translation>Bekreft root-passord:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2021"/>
        <source>Default User Account</source>
        <translation>Vanlig brukerkonto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2033"/>
        <source>Default user login name:</source>
        <translation>Brukernavn til vanlig bruker:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2049"/>
        <source>Default user password:</source>
        <translation>Passord til vanlig bruker:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2062"/>
        <source>Confirm user password:</source>
        <translation>Bekreft brukerpassord:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2123"/>
        <source>username</source>
        <translation>brukernavn</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2139"/>
        <source>Autologin</source>
        <translation>Automatisk innlogging</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2152"/>
        <source>Show passwords</source>
        <translation>Vis passord</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2165"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Endringer av skrivebordet i live-miljøet vil overføres til det installerte operativsystemet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2168"/>
        <source>Save live desktop changes</source>
        <translation>Lagre endringer av skrivebord</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2191"/>
        <source>Existing Home Directory</source>
        <translation>Eksisterende hjemmemappe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Hva skal gjøres med den gamle mappa?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Re-use it for this installation</source>
        <translation>Gjenbruk mappa i denne installasjonen</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2214"/>
        <source>Rename it and create a new directory</source>
        <translation>Gi den nytt navn og lag ny mappe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2221"/>
        <source>Delete it and create a new directory</source>
        <translation>Slett den og lag ny mappe</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2266"/>
        <source>Tips</source>
        <translation>Tips</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2310"/>
        <source>Installation complete</source>
        <translation>Installering fullført</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2316"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Start automatisk systemet på nytt når installasjonsprogrammet lukkes</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2335"/>
        <source>Reminders</source>
        <translation>Påminnelse</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2376"/>
        <source>Back</source>
        <translation>Tilbake</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2383"/>
        <source>Alt+K</source>
        <translation>Alt + K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Installation in progress</source>
        <translation>Installering pågår</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2411"/>
        <source>Abort</source>
        <translation>Avbryt</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="137"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="367"/>
        <source>EFI System Partition</source>
        <translation>EFI-systempartisjon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="368"/>
        <source>swap space</source>
        <translation>vekselfil</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="369"/>
        <source>swap space #%1</source>
        <translation>vekselfil #%1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>Preserve (%1)</source>
        <translation>Bevar (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="579"/>
        <source>&amp;Add partition</source>
        <translation>Legg til p&amp;artisjon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="584"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Fjern partisjon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="592"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="595"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="596"/>
        <location filename="../partman.cpp" line="690"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="603"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation>BTRFS-komprimering (&amp;ZLIB)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="604"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation>BTRFS-komprimering (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="627"/>
        <source>New &amp;layout</source>
        <translation>Ny &amp;utforming</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="628"/>
        <source>&amp;Reset layout</source>
        <translation>&amp;Nullstill utforming</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="631"/>
        <source>&amp;Standard install</source>
        <translation>&amp;Standardinstallasjon</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="632"/>
        <source>&amp;Encrypted system</source>
        <translation>&amp;Kryptert system</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="687"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="693"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="694"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="729"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="765"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="796"/>
        <source>Invalid use for %1: %2</source>
        <translation>Ugyldig bruk av %1: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="807"/>
        <source>%1 is already selected for: %2</source>
        <translation>%1 er allerede valgt for: %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="847"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation>Kan ikke bevare /home inni root (/) hvis separat /home-partisjon også monteres.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="854"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Velg en rotpartisjon.
Rotpartisjonen må være minst %1.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="860"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Velg en separat oppstartspartisjon når rota krypteres.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="872"/>
        <source>Delete the data on %1 except for /home</source>
        <translation>Slett data på %1, bortsett fra /home</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="875"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Gjenbruk (uten reformatering) %1 som %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="881"/>
        <source>%1, to be used for %2</source>
        <translation>%1, skal brukes som %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="884"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Disse valgte partisjonene er ikke Linux-partisjoner: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="892"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Vil du virkelig reformatere disse partisjonene?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="900"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>Installasjonsprogrammet for %1 vil nå formatere og dermed slette data på følgende partisjoner:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="908"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>Installasjonsprogrammet for %1 vil nå utføre følgende handlinger:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="912"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Disse handlingene kan ikke angres. Fortsette?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1010"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Det kan oppstå feil på disken med partisjonene som er valgt for installasjon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1014"/>
        <source>Smartmon tool output:</source>
        <translation>Utdata fra verktøyet Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1015"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Disken med partisjonene som er valgt for installasjon går gjennom S.M.A.R.T.-testene (smartctl), men de antyder at disken har høyere feilrate enn gjennomsnittet, og kan feile i nær framtid.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1020"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>I tilfelle tvil bør installasjonsprogrammet avbrytes og GSmartControl kjøres for ytterligere informasjon.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1022"/>
        <source>Do you want to abort the installation?</source>
        <translation>Vil du avbryte installasjonen?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1027"/>
        <source>Do you want to continue?</source>
        <translation>Vil du fortsette?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1196"/>
        <source>Clearing existing partition tables</source>
        <translation>Sletter eksisterende partisjonstabeller</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1204"/>
        <source>Preparing required partitions</source>
        <translation>Forbereder nødvendige partisjoner</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1259"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>Setter opp LUKS-krypterte containere</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1276"/>
        <source>Formatting: %1</source>
        <translation>Formaterer: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1467"/>
        <source>Mounting: %1</source>
        <translation>Monterer: %1</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation>Grafisk installasjonsprogram for MX Linux og antiX Linux</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation>Installer automatisk med oppsettsfila (mer info nedenfor).
– Advarsel: Kan være farlig – kan slette partisjon(er) automatisk.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation>Overstyrer trygghetskontroller av partisjoner og disker slik at de vises.
ADVARSEL: Kan ødelegge saker og ting. Brukes kun hvis du ikke bryr deg om data på disken.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation>Laster en oppsettsfil som angitt av &lt;config-file&gt;.
Som standard brukes /etc/minstall.conf
Dette oppsettet kan brukes med --auto for installasjon uten tilstedeværelse.
Installasjonsprogrammet oppretter (eller overskriver) /mnt/antiX/etc/minstall.conf og lagrer en kopi til /etc/minstalled.conf for framtidig bruk.
Installasjonsprogrammet skriver ingen passord eller ignorerte alternativer til ny oppsettsfil.
Legg merke til at dette er eksperimentelt. Framtidige versjoner vil ikke nødvendigvis være kompatible med eksisterende oppsettsfiler.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation>Bruk alltid GPT ved installasjon til hel disk, uavhengig av størrelse.
Uten dette alternativet vil GPT kun brukes på disker som er minst 2 TB store.
GPT brukes alltid ved installasjon til hel disk på UEFI-systener uavhengig av størrelse, selv uten dette alternativet.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation>Testmodus for installasjonsprogrammet. Partisjoner/disker vil FORMATERES uten at filer kopieres.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation>Installerer operativsystemet og utsetter brukerspørsmål til første omstart.
Ved omstart vil installasjonsprogrammet startes med --oobe slik at brukeren kan fylle inn detaljer.
Dette er nyttig for OEM-installasjoner, ved salg, eller hvis maskinen skal gis vekk med et ferdiginstallert OS.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation>Nøkkelklar. 
Startes automatisk hvis installert med alternativet --oem.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Testmodus for grafisk brukergrensesnitt. Man kan bevege seg mellom dialogvinduene uten å faktisk installere noe.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Installerer med rsync istedenfor cp på tilpassede partisjoner.
– formaterer ikke /root og virker ikke med kryptering.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Laster oppsettsfil som angitt av &lt;config-file&gt;.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation>Denne handlingen krever root-tilgang.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Fant ikke oppsettsfila (%1).</translation>
    </message>
</context>
</TS>
