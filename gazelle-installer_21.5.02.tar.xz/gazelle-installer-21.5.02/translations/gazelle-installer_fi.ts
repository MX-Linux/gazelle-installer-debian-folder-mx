<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fi">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Sammuta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation>%1 Asennusohjelma</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Tue %1:ia

%1 on sinunlaistesi ihmisten tukema. Jotkut auttavat toisia tukifoorumilla - %2, tai kääntävät ohjeita eri kielille, tekevät ehdotuksia uusista ominaisuuksista, kirjoittavat dokumentaatiota, tai auttavat kokeilemalla uusia sovelluksia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>Asennusohjelma ei käynnistynyt koska se näyttäisi olevan jo käynnissä.

Jos mahdollista, sulje se tai suorita &apos;pkill minstall&apos; päätteessä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation>Asennuslähdettä ei voida saavuttaa</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>32-bittinen käyttöjärjestelmä joka aloitettiin 64-bittisessä UEFI-moodissa on käynnissä. Järjestelmää ei voida käynnistää ellet valitse Legacy Boot:ia tai vastaavaa vaihtoehtoa uudelleenkäynnistykseen.
Suosittelemme että lopetat nyt ja käynnistät tilassa Legacy Boot 

Haluatko jatkaa asentamista?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 on itsenäinen Linux jakelu, joka pohjautuu Debianin vakaaseen (Stable) haaraan.

%1 käyttää joitakin MEPIS Linuxin komponentteja jotka on julkaistu Apachen vapaalla lisenssillä. Jotkin MEPIS-komponentit on muokattu %1:ia varten.

Pidä hauskaa käyttäessäsi %1:ia</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation>Asennuksen teeskentely %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="530"/>
        <source>Preparing to install %1</source>
        <translation>Valmistautuu asentamaan %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="542"/>
        <source>Failed to format required partitions.</source>
        <translation>Tarvittavien osioiden alustaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="553"/>
        <source>Paused for required operator input</source>
        <translation>Tauotettu tarvittavaa käyttäjän valintaa odottaen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="563"/>
        <source>Setting system configuration</source>
        <translation>Asetetaan järjestelmän kokoonpano</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="581"/>
        <source>Cleaning up</source>
        <translation>Siivotaan</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="583"/>
        <source>Finished</source>
        <translation>Viimeistelty</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="741"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>Epäkelpoja asetuksia on löytynyt asetustiedostossa (%1). Tarkista merkatut kentät sitä mukaa kun kohtaat niitä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="797"/>
        <source>Deleting old system</source>
        <translation>Poistetaan vanhaa järjestelmää</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="801"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Vanhan %1 poistaminen epäonnistui kohteessa.
Palataan vaiheeseen 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="808"/>
        <source>Creating system directories</source>
        <translation>Luodaan järjestelmähakemistoja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="818"/>
        <source>Fixing configuration</source>
        <translation>Korjataan rakennetta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="860"/>
        <source>Copying new system</source>
        <translation>Kopioidaan uutta järjestelmää</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="900"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation>Kopioinnin edistyminen tuntematon. Tiedostojärjestelmän tilastoja ei saatavilla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="909"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Kirjoittaminen epäonnistui %1 kohteeseen.
Palataan vaiheeseen 1.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="952"/>
        <source>Updating initramfs</source>
        <translation>Päivitetään initramfs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="962"/>
        <source>Installing GRUB</source>
        <translation>Asennetaan GRUB</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1030"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>GRUB:in asennus epäonnistui. Voit uudelleenkäynnistää live-tilaan ja käyttää GRUB Rescue valikkoa korjataksesi asennuksen.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">Virhe NVRAM käynnistysmuuttujan päivityksessä. Järjestelmä ei luultavasti käynnisty, mutta se voidaan korjata GRUB Rescue käynnistysvalikon avulla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1153"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>Käyttäjänimi ei voi sisältää erikoismerkkejä tai välilyöntejä.
Valitse toisenlainen nimi jatkaaksesi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1164"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Pahoittelut, tuo nimi on jo käytössä.
Valitse eri nimi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1174"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>Et määritellyt salasanaa pääkäyttäjälle. Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1183"/>
        <source>The home directory for %1 already exists.</source>
        <translation>Kotihakemisto käyttäjälle %1 on jo olemassa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1212"/>
        <source>Failed to set user account passwords.</source>
        <translation>Käyttäjätilien salasanojen asettaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1229"/>
        <source>Failed to save old home directory.</source>
        <translation>Vanhan kotikansion tallentaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1234"/>
        <source>Failed to delete old home directory.</source>
        <translation>Vanhan kotikansion poistaminen epäonnistui.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1252"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Käyttäjähakemistoa ei voitu luoda.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1257"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Valitettavasti käyttäjäkansion nimeäminen ei onnistunut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1278"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Valitettavasti omistusoikeuksien asettaminen käyttäjäkansiolle ei onnistunut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1324"/>
        <source>Please enter a computer name.</source>
        <translation>Syötä nimi tietokoneelle. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1328"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Pahoittelut, tietokoneesi nimi sisältää epäkelpoja merkkejä.
Sinun tulee valita eri
nimi ennen jatkamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1334"/>
        <source>Please enter a domain name.</source>
        <translation>Syötä verkko-domain nimi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1338"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Pahoittelut, tietokoneesi domain sisältää epäkelpoja merkkejä.
Sinun tulee valita eri
nimi jatkaaksesi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1345"/>
        <source>Please enter a workgroup.</source>
        <translation>Syötä työryhmä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1588"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>Hyväksytkö levyn alustamisen ja sen käytön kokonaisuudessaan (%1) näin %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1592"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>VAROITUS: valittu asema omaa vähintään 2Tb kapasiteetin ja se pitää alustaa käyttäen GPT:tä. Joissakin järjestelmissä GPT-alustettu levy ei käynnisty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1618"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>Sisältöä kohteessa /home ei voida säilyttää koska vaadittuja tietoja ei voitu hakea. </translation>
    </message>
    <message>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="vanished">Mikäli osio joka sisältää /home alueen on varustettu salauksella, varmista että oikeat &quot;Encrypt&quot; laatikot ovat valitut ja syötetty salasana on oikein.</translation>
    </message>
    <message>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="vanished">Asennusohjelma ei kyennyt salaamaan olemassaolevaa /home hakemistoa tai osiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1674"/>
        <source>General Instructions</source>
        <translation>Yleiset ohjeet</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>SULJE KAIKKI MUUT SOVELLUKSET ENNEN JATKAMISTA.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>Lue ohjeet jokaisella sivulla, tee valintasi, napsauta sitten aina Seuraava kun olet valmis jatkamaan. Tulet näkemään kehotteen varmistusta varten ennen minkään tuhoisan toiminnon toteuttamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>Limitations</source>
        <translation>Rajoitukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Muistathan, että tämä ohjelmisto toimitetaan SELLAISENAAN ilman mitään takuuta. On yksin sinun omalla vastuullasi tehdä varmuuskopiot tiedostoistasi ennen jatkamista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>Installation Options</source>
        <translation>Asennusvalinnat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation>Asennus vaatii noin %1 tilaa. %2 tai enemmän vaaditaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1686"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Mikäli ajat Mac- tai Windows-käyttöjärjestelmää (Vista:sta eteenpäin lukien), voi olla että sinun pitää käyttää kyseisen järjestelmän ohjelmia luodaksesi osiot ja käynnistyksen hallinnan ennen asennusta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1687"/>
        <source>Using the root-home space slider</source>
        <translation>Käytetään juurihakemisto-kotihakemiston levytilan liukusäädintä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation>Suurikokoisilla kiintolevyillä oletusasennus luo erilliset osiot juurihakemistolle sekä kotihakemistolle. Tällä liukusäätimellä voit määrittää paljonko tilaa kullekin osiolle varataan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1690"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Liikuta säädintä oikelle kasvattaaksesi &lt;b&gt;root&lt;/b&gt; tilaa. Liikuta säädintä vasemmalle kasvattaaksesi osiota &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1691"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Siirrä liukusäädin kokonaan oikealle jos haluat juuriaseman ja kotihakemiston samalle osiolle.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation>Jos suunnittelet asentavasi useita sovelluksia, tai suurikokoisia sovelluksia kuten kuvien, äänen tai videoidenmuokkausohjelmia, haluat luultavasti isomman &lt;b&gt;root&lt;/b&gt; osion.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation>Mikäli aiot tallentaa suuren määrän dataa, tai jos useampi ihminen käyttää tätä konetta, saatat haluta suuremman &lt;b&gt;home&lt;/b&gt; osion.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1696"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Kotihakemiston sijoittaminen erilliselle osiolle parantaa käyttöjärjestelmän toimintavarmuutta päivitettäessä. Se myös helpottaa varmuuskopiointia ja järjestelmän palautusta. Tämä myös parantaa yleistä suorituskykyä rajaamalla järjestelmätiedostot tiettyyn paikkaan kiintolevyllä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1698"/>
        <location filename="../minstall.cpp" line="1761"/>
        <source>Encryption</source>
        <translation>Salaus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1699"/>
        <location filename="../minstall.cpp" line="1762"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Kiintolevyn salaus on mahdollista LUKS:in kautta. Salasana vaaditaan.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1700"/>
        <location filename="../minstall.cpp" line="1763"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Erillinen salaamaton käynnistys-osio vaaditaan. Lisäasetuksia varten, sisältäen salauksen valinnat, käytä &lt;b&gt;Edistyneet salausasetukset&lt;/b&gt;painiketta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1702"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Kun salausta käytetään automaattisen asennuksen yhteydessä, erillinen käynnistys-osio luodaan automaattisesti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>Using a custom disk layout</source>
        <translation>Käytetään mukautettua kiintolevyn järjestelyä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Jos haluat hallita tarkemmin mihin %1 asennetaan, valitse &quot;&lt;b&gt;%2&lt;/b&gt;&quot; ja klikkaa &lt;b&gt;Next&lt;/b&gt;. Seuraavalla sivulla, voit valita ja konfiguroida tarvitsemiasi tallennuslaitteita sekä osioita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1719"/>
        <source>Choose Partitions</source>
        <translation>Valitse Osiot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>Osioluettelo sallii sinun valita mitä osioita käytetään tässä asennuksessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation>&lt;i&gt;Device&lt;/i&gt; - Tämä on lohkolaitteen nykyinen tai tuleva nimi, joka annetaan luodulle osiolle.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation>&lt;i&gt;Size&lt;/i&gt; - Osion koko. Tätä voidaan muuttaa vain täysin uudessa järjestelyssä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1723"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation>&lt;i&gt;Label&lt;/i&gt; - Nimikyltti joka määritetään osiolle kun se on alustettu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here. You can also type your own mount point, which must start with a slash (&quot;/&quot;).</source>
        <translation>&lt;i&gt;Use For&lt;/i&gt; - Käyttääksesi tätä osiota asennusvaiheessa, sinun täytyy valita täältä jotail. Voit myös kirjoittaa haluamasi liitospisteen, jonka täytyy alkaa kauttamerkillä (&quot;/&quot;).</translation>
    </message>
    <message>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption. To preserve the format of an existing encrypted partition, you must use the same passphrase that it was originally encrypted with.</source>
        <translation type="vanished">&lt;i&gt;Encrypt&lt;/i&gt; - Käytä LUKS-salausta tälle osiolle. Salasana asetetaan kaikille salatuksi valituille osioille. Säilyttääksesi jo olemassaolevan salatun osion, sinun tulee käyttää samaa salasanaa, jolla alkuperäinen salaus tehtiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Linux-tiedostojärjestelmät ext2, ext3, ext4, jfs, xfs, btrfs ja reiserfs ovat tuetut ja ext4 on suositeltu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation>&lt;i&gt;Mount Options&lt;/i&gt; - Tämä määrittelee liittämisen asetukset, joita käytetään tälle osiolle.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1731"/>
        <source>Menus and actions</source>
        <translation>Valikot ja toiminnot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation>Luettelon oikeanpuoleisella laidalla olevia painikkeita voidaan myös käyttää kohteiden muokkaamiseen</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1738"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>%1 vaatii juuriosion. Swap-sivutusosio on valinnainen mutta erittäin suositeltava. Mikäli haluat käyttää Keskeytä-levylle %1 keskeytystilaominaisuutta, tarvitset sivutustiedostolle osion joka on kooltaan suurempi kuin keskusmuistisi määrä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Mikäli valitset erillisen /home osion, tarkoittaa se helpompaa siirtymäpäivitystä tulevaisuudessa, mutta ei ole mahdollista päivitettäessä asennuksesta ilman erillistä koti-osiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1743"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1746"/>
        <source>Upgrading</source>
        <translation>Päivittäminen</translation>
    </message>
    <message>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="vanished">Päivittääksesi olemassaoleva Linux-asennus, valitse sama kotihakemiston osio kuin vanhassa ja valitse &lt;b&gt;säilytä&lt;/b&gt; tiedostojärjestelmän tyypiksi.</translation>
    </message>
    <message>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="vanished">Mikäli säilytät olemassaolevan /home kotihakemistopuun joka sijaitsee juuri-osiossasi, asennusohjelma ei uudelleenalusta tuota juuri-osiota. Tämän seurauksena asentaminen vie paljon enemmän aikaa kuin yleensä.   </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>Preferred Filesystem Type</source>
        <translation>Suositeltu Tiedostojärjestelmätyyppi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Saavuttaaksesi %1, voit alustaa osiot ext2, ext3, ext4, f2fs, jfs, xfs, btrfs tai reiser muodossa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1752"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Pakkauksen lisävalinnat ovat tarjolla kiintolevyille jotka käyttävät btrfs-tiedostojärjestelmää. Lzo on nopea, mutta pakkaus on vähäisempi. Zlib on hitaampi, korkeammalla pakkauksella.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Bad Blocks</source>
        <translation>Vikaantuneet lohkot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1755"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Mikäli valitset ext2, ext3 tai ext4 alustusmuodon, sinulla on vaihtoehtona tarkistaa ja korjata vikaantuneet kiintolevylohkot. Viallisten lohkojen tarkistaminen vie paljon aikaa, joten halunnet sivuuttaa tuon askeleen ellet epäile kiintolevylläsi todellakin olevan vikaantuneita lohkoja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>System partition management tool</source>
        <translation>Järjestelmän osioiden hallintatyökalu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>Other partitions</source>
        <translation>Muut osiot</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1769"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>Advanced Encryption Settings</source>
        <translation>Edistyneet Salausasetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1777"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Tämä sivu sallii LUKS-osiosalauksen hienosäädön.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>Useimmissa tapauksissa, vakioasetukset tarjoavat käytännöllisen tasapainon turvallisuuden ja  suorituskyvyn suhteen joka on sopiva arkaluontoisille sovelluksille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Tämä kirjoitus kattaa LUKS:issa käytettyjen parametrien perusteet, mutta ei ole tarkoitettu kaikenkattavaksi oppaaksi salaustekniikkaan. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1781"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Näiden asetusten muuttaminen ilman selkeää ymmärrystä salaustekniikkaan voi päätyä heikon salauksen käyttämiseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Kentän muokkaaminen vaikuttaa usein saatavilla oleviin vaihtoehtoihin sen alapuolella. Alapuoliset kentät voivat muuttua automaattisesti suositeltuihin arvoihin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1783"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Vaikkakin parempi suorituskyky tai korkeampi tietoturva voidaan saavuttaa muuttamalla asetuksia niiden suositelluista arvoista, teet sen kaikkinensa omalla vastuullasi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1785"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Voit käyttää &lt;b&gt;Benchmark-mittapuu&lt;/b&gt;painiketta (joka ajaa &lt;i&gt;cryptsetup mittapuun&lt;/i&gt;omassa pääteikkunassaan) vertaillaksesi suorituskykyä yleisissä hash-yhdistelmissä, salauksissa ja ketjutustiloissa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Huomioi että &lt;i&gt;cryptsetup mittapuu&lt;/i&gt;ei kata kaikkia mahdollisia yhdistelmiä tai valintoja ja kattaa yleisesti kaikkein useimmin suositut ratkaisut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>Cipher</source>
        <translation>Salaustekniikka</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1788"/>
        <source>A variety of ciphers are available.</source>
        <translation>Tarjolla on useita salaustekniikoita.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>oli yksi viidestä AES-finalisteista. Se omaa korkeamman tason turvalähtöisyyden kuin Rijndael ja kaikki muut AES-finalistit. Se on suorituskyvyltään parempi joillakin 64-bittisillä suorittimilla. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(tunnetaan myös nimellä&lt;i&gt;Rijndael&lt;/i&gt;) on erittäin yleinen salaustekniikka, ja monet nykyaikaiset suorittimet sisältävät ohjeet erityisesti AES:lle, sen yleisyyden johdosta. Vaikkakin Rijndael arvotettiin paremmaksi kuin Serpent sen suorituskyvyssä, mitään hyökkäystä ei pidetä tällä hetkellä käytännöllisenä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>on Blowfish:in seuraaja. Siitä tuli yksi niistä viidestä AES-finalistista, vaikkakaan se ei tullut valituksi standardille.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) oli AES-kilvassa ehdokkaana, kuitenkaan siitä ei finalistia tullut.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1793"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>on 64-bittinen lohkosalaustekniikka jonka loi Bruce Schneier. Arkaluontoisia tietoja sisältävään käyttöön sitä ei suositella koska vain CBC ja ECB moodit ovat tuettuja. Blowfish tukee avainkokoja 32 ja 448 bitin välillä jotka ovat monistuksia 8:sta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Chain mode</source>
        <translation>Ketjutustila</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Jos lohkot olisivat kaikki salattuja käyttäen samaa avainta, voi ilmaantua jatkumo jonka kautta ennakoitavissa perustekstiä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>XEX-perusteinen Tweaked-koodikirja ciphertext Stealing:illä) on nykyaikainen ketju-moodi, joka ylittää CBC:n ja EBC:n. Se on vakiollinen (ja suositeltu) ketju-moodi. Käyttämällä ESSIV:iä Plain64:n yli verottaa suorituskykyä ilman tiettävää turvaetua.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Cipher Block Chaining) on yksinkertaisempi kuin XTS, mutta haavoittuvainen padding oracle hyökkäykselle (jokseenkin lievennettynä ESSIV:in johdosta) eikä ole suositeltu arkaluontoisia tietoja sisältävään käyttötarkoitukseen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic Codebook) on vähemmän turvallinen kuin CBC eikä sitä tule käyttää arkaluontoisia tietoja sisältäviin käyttötarkoituksiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>IV generator</source>
        <translation>IV generaattori</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>XTS:n ja CBC:n suhtee, tämä määrittää kuinka &lt;b&gt;i&lt;/b&gt;nitalisaatio &lt;b&gt;v&lt;/b&gt;ektori tuotetaan. &lt;b&gt;ESSIV&lt;/b&gt;edellyttää hash-toiminnon, ja siitä syystä toinen pudotusvalikko tulee tarjolle mikäli se valitaan. Hash-arvot riippuvat valitusta salaustekniikasta.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>ECB moodi ei käytä IV:tä, joten kaikki nämä kentät poistuvat käytöstä jos ECB on valittu ketju-moodiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Key size</source>
        <translation>Avainkoko</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Asettaa avainkoon tavuina. Valittavissa olevat avainkoot ovat rajoitetut liittyen salaustekniikkaan ja ketju-moodiin.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>XTS salaustekniikka ketju-moodi puolittaa avaimen (esimerkiksi, AES-256 XTS-moodissa vaatii 512-bittisen avainkoon).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>LUKS key hash</source>
        <translation>LUKS avain-hash</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>Käytetty hash PBKDF2:ssa ja AF-puolittajassa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>SHA-1 ja RIPEMD-160 eivät ole enää suositeltuja arkaluontoisia tietoja käsittelevään käyttöön koska ne on havaittu rikkinäisiksi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Kernel RNG</source>
        <translation>Ytimen RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Asettaa mitä ytimen satunnaista numero-generaattoria käytetään pääavaimen avaimen luomiseksi (joka on pitkäaikainen avain).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Kaksi vaihtoehtoa on valittavissa: /dev/&lt;b&gt;random&lt;/b&gt;joka estää kunnes riittävä haje on saavutettu (voi kestää pitkään alhaisen hajeen tapauksissa), ja /dev/&lt;b&gt;urandom&lt;/b&gt;joka ei estä silloinkaan kun tarjolla on riittämätön haje (mahdollisesti heikommat avaimet).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>KDF kiertoaika &lt;/b&gt;&lt;br/&gt;Ajan määrä (millisekunneissa) käytettäväksi PBKDF2:n salauslause prosessoinnissa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>Arvo 0 valitsee sisäänkokoomisvakion (aja &lt;i&gt;cryptsetup --help&lt;/i&gt;nähdäksesi yksityiskohdat).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Jos sinulla on hidas kone, saatat nostaa tätä arvoa lisäturvallisuuden saavuttamiseksi, hyvittääkseen aikaa joka käytetään taltion avaamiseksi sen jälkeen kun salauslause on syötetty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Valitse Käynnistysmenetelmä&lt;/b&gt;&lt;br/&gt;%1 käyttää GRUB-käynnistyslatainta käynnistääkseen %1 ja MS-Windowsin. &lt;p&gt;Oletuksena GRUB2 asennetaan Pääkäynnistystaltioon (MBR) tai ESP:n (EFI-järjestelmäosio 64-bittisissä UEFI-käynnistyvissä järjestelmissä) käynnistysasemassasi ja korvaa käynnistyslataimen jota käytit aiemmin. Tämä on tavanomaista. &lt;/p&gt;&lt;p&gt; Jos valitset asentaa GRUB2 osiokäynnistystaltioon (PBR) sen sijaan, sitten GRUB2 asennetaan määritetyn osion alkuosaan. Tämä vaihtoehto on tarkoitettu vain kokeneille käyttäjille.&lt;/p&gt;&lt;p&gt; Mikäli ruksaat pois GRUB.in asentamisen, GRUB:ia ei tällä erää asenneta. Tämä on tarkoitettu vain kokeneille käyttäjille.&lt;/p&gt;   </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1834"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Kytkettävät tavanomaiset toiminnot &lt;/b&gt;&lt;br/&gt; Valitse toiminnot joita tulet tarvitsemaan järjestelmässäsi, sekä ne jotka haluat käynnistettävän automaattisesti kun aloitat %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Tietokoneen identiteetti &lt;/b&gt;&lt;br/&gt; Tietokoneen nimi on yleinen ainutlaatuinen nimi joka tunnistaa tietokoneesi jos se on kytkettynä verkkoon. Tietokoneen verkkoalue, domain, tuskin tulee käyttöön ellei sitten internetyhteyden tarjoajasi, ISP, tai paikallinen verkko vaadi sitä. &lt;/p&gt;&lt;p&gt; Tietokoneen ja verkkoalueen nimi voi sisältää vain aakkosnumeerisia merkkejä, pisteitä, yhdysmerkkejä. Ne eivät voi sisältää tyhjiä välejä eivätkä alkaa yhdysmerkeillä &lt;/p&gt;&lt;p&gt; Samba palvelin täytyy aktivoida jos haluat käyttää sitä jakaaksesi tiettyjä hakemistoja tai tulostimen paikallisen tietokoneen kanssa jonka käyttöjärjestelmänä on MS-Windows tai Mac OSX.&lt;/p&gt; </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1851"/>
        <source>Localization Defaults</source>
        <translation>Kotoistuksen oletukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1852"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation>Aseta oletusarvo sijainnille. Tämä valinta pysyy niin kauan kunnes käyttäjä muokkaa sitä.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1853"/>
        <source>Configure Clock</source>
        <translation>Kellon asetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1854"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation>Mikäli sinulla on Apple tai täysin puhdas Unix-työasema, järjestelmän kellonaika asetetaan oletuksena Greenwitchin aikaan (GMT) tai Koordinoituun yleisaikaan (UCT). Vaihtaaksesi tämän, valitse &quot;&lt;b&gt;Järjestelmän kello käyttää paikallista aikaa&lt;/b&gt;&quot; valintaruutu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1856"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation>Järjestelmä käynnistyy aikavyöhyke esiasetettuna GMT/UTC aikaan. Vaihtaaksesi aikavyöhykettä, järjestelmän käynnistyttyä uudelleen, klikkaa kakkospainikkeella kelloa Paneelissa ja valitse Ominaisuudet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Service Settings</source>
        <translation>Palveluiden asetukset</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation>Useimpien käyttäjien ei tulisi muuttaa oletusasetuksia. Pienitehoisilla koneilla olevat käyttäjät haluavat usein poistaa käytöstä tarpeettomia toimintoja pitääkseen RAM-muistin käytön mahdollisimman pienenä. Varmista että tiedät mitä teet!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1865"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1866"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation>Pääkäyttäjä on kuten Järjestelmänvalvoja toisissa käyttöjärjestelmissä. Sinun ei pitäisi ikinä käyttää pääkäyttäjän tiliä normaalissa päivittäisessä käytössä. Ole hyvä ja syötä nimi uudelle (oletus) käyttäjätilille joka tulee olemaan sinulla päivittäiskäytössä. Mikäli tarpeellista, voit luoda uusia käyttäjätilejä myöhemmin %1 User Manager:in avulla.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1870"/>
        <source>Passwords</source>
        <translation>Salasanat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1871"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation>Syötä uusi salasana oletus-käyttäjätilillesi sekä pääkäyttäjälle. Kumpikin salasana pitää syöttää kahdesti.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1873"/>
        <source>No passwords</source>
        <translation>Ei salasanoja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation>Jos et halua oletus-käyttäjätilillä olevan salasanaa, jätä sen salasanojen kentät tyhjiksi. Tämä sallii sinun kirjautua sisään ilman salasanaa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1876"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation>Tämä kannattaa ilmiselvästi tehdä vain tilanteissa joissa käyttäjätilin ei tarvitse olla turvallinen, kuten julkiset tietokoneet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1885"/>
        <source>Old Home Directory</source>
        <translation>Vanha Kotihakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1886"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Kotikansio on valmiiksi olemassa valitsemallesi käyttäjänimelle. Tämä ruutu sallii sinun valita mitä tälle hakemistolle tapahtuu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1888"/>
        <source>Re-use it for this installation</source>
        <translation>Käytä se uudelleen tätä asennusta varten</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1889"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>Vanhaa kotikansiota tullaan käyttämään tälle käyttäjätilille. Tämä on hyvä valinta päivityksen tullessa kyseeseen, ja tiedostosi kuin myös asetuksesi tulevat olemaan valmiina ennallaan. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1891"/>
        <source>Rename it and create a new directory</source>
        <translation>Uudelleennimeä se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1892"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Käyttäjälle tullaan luomaan uusi kotikansio, mutta vanha kotikansio nimetään uudelleen. Tiedostosi ja asetuksesi eivät tule olemaan välittömästi näkyvillä uudessa asennuksessa, mutta niihin pääsee käsiksi käyttäen uudelleennimettyä kansiota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>Vanhan hakemiston nimessä tulee olemaan numero sen lopussa, riippuen siitä kuinka minta kertaa tuo hakemisto on aiemmin uudelleennimetty.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>Delete it and create a new directory</source>
        <translation>Poista se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1896"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>Vanha hakemisto poistetaan ja luodaan tilalle täysin uusi.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Warning</source>
        <translation>Varoitus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1898"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Kaikki tiedostot ja asetukset poistetaan pysyvästi jos tämä vaihtoehto on valittuna. Mahdollisuutesi palauttaa ne ovat pienet.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1914"/>
        <source>Installation in Progress</source>
        <translation>Asennus Käynnissä</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1915"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>%1 asentuu. Puhtaan asennuksen ollessa kyseessä, se luultavasti kestää 3-20 minuuttia, riippuen järjestelmäsi nopeudesta ja uudelleenalustettavien osioiden koosta. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1917"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Jos napsautat Keskeytä painiketta, asennus pysäytetään niin pian kuin mahdollista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1919"/>
        <source>Change settings while you wait</source>
        <translation>Muuta asetuksia odottaessasi</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1920"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Sillä välin kun %1 asentuu, voit napsauttaa &lt;b&gt;Seuraava&lt;/b&gt;tai &lt;b&gt;Takaisin&lt;/b&gt; painikkeita lukeaksesi muita asennuksen vaatimia tietoja.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1922"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Saata nämä askeleet valmiiksi omaan tahtiisi. Asennusohjelma odottaa syötteitäsi tarpeen vaatiessa.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1931"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Onnittelut! &lt;/b&gt;&lt;br/&gt; Olet suorittanut asennuksen %1 &lt;/p&gt;&lt;p&gt;&lt;b&gt; Ohjelmien löytäminen &lt;/b&gt;&lt;br/&gt; Tarjolla on satoja erinomaisia ohjelmia asennettavaksi %1 Paras tapa oppia niistä on on selata käynnistysvalikkoa ja kokeilla. Monet näistä ohjelmista ovat kehitetyt yksinomaan %1 projektia varten. Nämä löytyvät päävalikoista. &lt;p&gt; Lisäksi %1 sisältää monia vakiollisia Linux-sovelluksia joita ajetaan komentokehotteesta ja täten eivät näy ohjelmien käynnistysvalikossa. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Pidä hauskaa käyttäessäsi %1:ia&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1941"/>
        <location filename="../minstall.cpp" line="2355"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Tuki %1 &lt;/b&gt;&lt;br/&gt; %1 on ihmisten kuten sinä tukema. Eräät auttavat muita tukifoorumilla - %2 - tai kääntävät aputiedostoja eri kielille, tai antavat ehdotuksia, kirjoittavat dokumentaatiota, tai auttavat uusien ohjelmien testaamisessa. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1972"/>
        <source>Finish</source>
        <translation>Lopeta</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1976"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1978"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2013"/>
        <source>Configuring sytem. Please wait.</source>
        <translation>Määritetään järjestelmää. Ole hyvä ja odota.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2016"/>
        <source>Configuration complete. Restarting system.</source>
        <translation>Järjestelmän määritys valmistui. Käynnistetään järjestelmä uudelleen.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2020"/>
        <source>Could not complete configuration.</source>
        <translation>Määritystä ei voitu suorittaa loppuun.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2037"/>
        <source>Loading...</source>
        <translation>Lataa...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2079"/>
        <location filename="../minstall.cpp" line="2470"/>
        <source>Root</source>
        <translation>Root-juurikäyttö</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2081"/>
        <location filename="../minstall.cpp" line="2478"/>
        <source>Home</source>
        <translation>Kotihakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2280"/>
        <source>Confirmation</source>
        <translation>Vahvistus</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2280"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Asennus ja konfigurointi on kesken..
Haluatko varmasti lopettaa nyt?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2341"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Avun hakeminen &lt;/b&gt;&lt;br/&gt; Perustiedot liittyen %1 on %2. &lt;/p&gt;&lt;p&gt; Vapaaehtoiset ovat valmiina auttamaan sinua %3 foorumilla, %4 &lt;/p&gt;&lt;p&gt; Kun pyydät apua, muista kuvailla ongelmasi sekä myös tietokoneesi niin hyvin kuin mahdollista. Yleensä lausunnot kuten &apos;se ei toiminut&apos; eivät ole avullisia.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2349"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Asennuksen korjaaminen&lt;/b&gt;&lt;br/&gt;Jos %1 lakkaa toimimasta kiintolevyllä, joskus ongelma on mahdollista korjata käynnistämällä järjestelmä LiveDVD:n tai LiveUSB:in kautta ja suorittamalla jokin vaihtoehto mukana olevasta %1 tai käyttämällä jotakin yleistä Linux-työkalua järjestelmän korjaamiseen.&lt;/p&gt;&lt;p&gt;Voit myös käyttää %1 LiveDVD:tä tai LiveUSB:ia palauttaaksesi tiedostoja MS-Windows käyttöjärjestelmistä!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2363"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt; Äänimikserin säätäminen &lt;/b&gt;&lt;br/&gt; %1 pyrkii määrittelemään äänimikserin sinulle valmiiksi mutta joskus on välttämätöntä itse säätää äänitasoja ja poistaa äänikanavien mykistys mikserissä kuullaksesi ääntä. &lt;/p&gt;&lt;p&gt; Mikserin oikopolkulinkki sijaitsee käynnistysvalikossa. Klikkaa sitä avataksesi mikserin. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2371"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Pidä %1-kopiosi ajan tasalla&lt;/b&gt;&lt;br/&gt;Saadaksesi lisätietoja sekä viimeisimmät päivitykset, vieraile osoitteessa&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2376"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Erityiskiitokset&lt;/b&gt;&lt;br/&gt;Kiitokset kaikille jotka ovat valinneet tukevansa %1 omalla ajalla, rahalla, ehdotuksilla, työllä, kehuilla, ideoilla, mainonnalla, ja/tai sitoutumisella.&lt;/p&gt;&lt;p&gt;Ilman teitä %1 ei olisi olemassa.&lt;/p&gt;&lt;p&gt;%2 Kehitystiimi&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2428"/>
        <source>%1% root</source>
        <translation>%1% juuriosio</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2428"/>
        <source>%2% home</source>
        <translation>%2% kotihakemisto</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2475"/>
        <source>----</source>
        <translation>----</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2523"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2534"/>
        <source>Load key from file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2535"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2664"/>
        <source>System boot disk:</source>
        <translation>Järjestelmän käynnistyslevy:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2678"/>
        <location filename="../minstall.cpp" line="2687"/>
        <source>Partition to use:</source>
        <translation>Osio jota käytetään:</translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation>Käytä salasanaa</translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ohje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Sulje</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>Seuraava</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Tietoja kerätään, odota.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Käyttöehdot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Näppäimistön asetukset&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Malli:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Muunnos:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation>Muuta näppäimistön asetuksia</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Asettelu:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Valitse asennustyyppi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation>Normaali asennus käyttäen koko levyä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="403"/>
        <location filename="../meinstall.ui" line="791"/>
        <source>Confirm password:</source>
        <translation>Salasanan varmistus:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="410"/>
        <location filename="../meinstall.ui" line="808"/>
        <source>Encryption password:</source>
        <translation>Salauksen salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="426"/>
        <location filename="../meinstall.ui" line="831"/>
        <location filename="../meinstall.ui" line="863"/>
        <source>Advanced encryption settings</source>
        <translation>Edistyneet salausasetukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="442"/>
        <source>Use disk:</source>
        <translation>Käytä levyä:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="468"/>
        <location filename="../meinstall.ui" line="705"/>
        <source>Encrypt</source>
        <translation>Salaa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="525"/>
        <source>Root</source>
        <translation>Root-juurikäyttö</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="560"/>
        <source>Home</source>
        <translation>Kotihakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="624"/>
        <source>Choose partitions</source>
        <translation>Valitse osiot</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="723"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Device</source>
        <translation>Laite</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="690"/>
        <source>Size</source>
        <translation>Koko</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="695"/>
        <source>Label</source>
        <translation>Nimilappu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="700"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="710"/>
        <source>Format</source>
        <translation>Muoto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="715"/>
        <source>Mount Options</source>
        <translation>Liittämisen asetukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="673"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="642"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation>Tarkista sektorit joissa on virheitä (kestää kauemmin)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="649"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="734"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="745"/>
        <source>Run the partition management application of this operating system.</source>
        <translation>Suorita tämän käyttöjärjestelmän osioiden hallintasovellus.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="756"/>
        <source>Load key from file...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="775"/>
        <source>Encryption options</source>
        <translation>Salauksen valinnat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="879"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="884"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="889"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="894"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="899"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="916"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="935"/>
        <source> mS</source>
        <translation>mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="957"/>
        <source>LUKS key hash:</source>
        <translation>LUKS hash-avain:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="970"/>
        <source>Key size:</source>
        <translation>Avaimen koko:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="996"/>
        <source>KDF round time:</source>
        <translation>KDF ympärysaika:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1019"/>
        <source>Cipher:</source>
        <translation>Salaustekniikka:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1039"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1044"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1049"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1054"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1059"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1076"/>
        <source>Benchmark...</source>
        <translation>Mittapuu...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1106"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1111"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1116"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1121"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1126"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1140"/>
        <source>IV generator:</source>
        <translation>IV generaattori:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1153"/>
        <source>Chain mode:</source>
        <translation>Ketju-moodi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1173"/>
        <source>Kernel RNG:</source>
        <translation>Ytimen RNG:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1181"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1186"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1213"/>
        <source>Select Boot Method</source>
        <translation>Valitse käynnistystapa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1250"/>
        <source>EFI System Partition</source>
        <translation>EFI Järjestelmäosio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1253"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1272"/>
        <source>Partition Boot Record</source>
        <translation>Osiokäynnistystaltio</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation>Kohde johon asennetaan:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1301"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Asenna GRUB Linuxille ja Windowsille</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1304"/>
        <location filename="../meinstall.ui" line="2414"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1320"/>
        <source>System boot disk:</source>
        <translation>Järjestelmän käynnistyslevy:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1342"/>
        <source>Master Boot Record</source>
        <translation>Pääkäynnistyslohko</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1348"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1351"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1422"/>
        <source>Common Services to Enable</source>
        <translation>Yleiset käyttöön otettavat palvelut</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1441"/>
        <source>Service</source>
        <translation>Palvelu</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1446"/>
        <source>Description</source>
        <translation>Kuvaus</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1479"/>
        <source>Computer Network Names</source>
        <translation>Tietokoneen Verkkonimet</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1506"/>
        <source>Workgroup</source>
        <translation>Työryhmä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1519"/>
        <source>Workgroup:</source>
        <translation>Työryhmä:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1532"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa-palvelin Microsoftin verkkojakoa varten</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1548"/>
        <source>example.dom</source>
        <translation>esimerkki.fi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1561"/>
        <source>Computer domain:</source>
        <translation>Tietokoneen verkkonimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1587"/>
        <source>Computer name:</source>
        <translation>Tietokoneen nimi:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1648"/>
        <source>Configure Clock</source>
        <translation>Kellon asetukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1689"/>
        <source>Format:</source>
        <translation>Muoto:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1717"/>
        <source>Timezone:</source>
        <translation>Aikavyöhyke:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1762"/>
        <source>System clock uses local time</source>
        <translation>Järjestelmän kello käyttää paikallista aikaa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1794"/>
        <source>Localization Defaults</source>
        <translation>Kotoistuksen oletukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1834"/>
        <source>Locale:</source>
        <translation>Sijainti:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1856"/>
        <source>Service Settings (advanced)</source>
        <translation>Palveluasetukset (edistyneille)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1874"/>
        <source>Adjust which services should run at startup</source>
        <translation>Määritä, mitkä palvelut tulisi käynnistää järjestelmän käynnistyessä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1877"/>
        <source>View</source>
        <translation>Näytä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1935"/>
        <source>Root (administrator) Account</source>
        <translation>Juuri-tili (pääkäyttäjä)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1947"/>
        <source>Root password:</source>
        <translation>Pääkäyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1992"/>
        <source>Confirm root password:</source>
        <translation>Vahvista pääkäyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2021"/>
        <source>Default User Account</source>
        <translation>Oletuskäyttäjätili</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2033"/>
        <source>Default user login name:</source>
        <translation>Käyttäjän oletuskäyttäjätunnus:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2049"/>
        <source>Default user password:</source>
        <translation>Käyttäjän oletussalasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2062"/>
        <source>Confirm user password:</source>
        <translation>Vahvista käyttäjän salasana:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2123"/>
        <source>username</source>
        <translation>käyttäjänimi</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2139"/>
        <source>Autologin</source>
        <translation>Kirjaudu automaattisesti</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2152"/>
        <source>Show passwords</source>
        <translation>Näytä salasanat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2165"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Liveympäristössä tehdyt työpöydän muutokset siirtyvät asennettuun käyttöjärjestelmään</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2168"/>
        <source>Save live desktop changes</source>
        <translation>Tallenna livetilan muutokset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2191"/>
        <source>Existing Home Directory</source>
        <translation>Olemassaoleva kotihakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Mitä haluaisit tehdä vanhan hakemiston suhteen?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Re-use it for this installation</source>
        <translation>Käytä se uudelleen tätä asennusta varten</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2214"/>
        <source>Rename it and create a new directory</source>
        <translation>Uudelleennimeä se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2221"/>
        <source>Delete it and create a new directory</source>
        <translation>Poista se ja luo uusi hakemisto</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2266"/>
        <source>Tips</source>
        <translation>Vinkkejä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2310"/>
        <source>Installation complete</source>
        <translation>Asennus on valmis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2316"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Uudelleenkäynnistä järjestelmä automaattiseti kun asennusohjelma suljetaan</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2335"/>
        <source>Reminders</source>
        <translation>Muistutukset</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2376"/>
        <source>Back</source>
        <translation>Takaisin</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2383"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Installation in progress</source>
        <translation>Asennus käynnissä</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2411"/>
        <source>Abort</source>
        <translation>Keskeytä</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="137"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="367"/>
        <source>EFI System Partition</source>
        <translation>EFI Järjestelmäosio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="368"/>
        <source>swap space</source>
        <translation>sivutustiedoston tila</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="369"/>
        <source>swap space #%1</source>
        <translation>sivutustiedoston tila #%1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>Preserve (%1)</source>
        <translation>Säilytä (%1)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="579"/>
        <source>&amp;Add partition</source>
        <translation>&amp;Lisää osio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="584"/>
        <source>&amp;Remove partition</source>
        <translation>&amp;Poista osio</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="592"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="595"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="596"/>
        <location filename="../partman.cpp" line="690"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="603"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation>BTRFS-pakkaus (&amp;ZLIB)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="604"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation>BTRFS-pakkaus (&amp;LZO)</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="627"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="628"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="631"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="632"/>
        <source>&amp;Encrypted system</source>
        <translation>&amp;Salattu järjestelmä</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="687"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="693"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="694"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="729"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="765"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="796"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="807"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="847"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="854"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Sinun täytyy valita juuriosio.
Juuriosion tulee olla vähintään %1. </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="860"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Sinun täytyy valita erillinen käynnistysosio salataksesi juurihakemiston.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="872"/>
        <source>Delete the data on %1 except for /home</source>
        <translation>Poista %1 kaikki tieto poislukien /home </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="875"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation>Käytä uudelleen (ei alustusta) %1 as %2</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="881"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="884"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Valitsemistasi osioista seuraavat eivät ole Linux-osioita:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="892"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Oletko varma että haluat alustaa nämä osiot uudelleen?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="900"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>%1 asennusohjelma alustaa ja tuhoaa kaiken tiedon seuraavissa osioissa:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="908"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>%1 asennusohjelma suorittaa nyt seuraavat toimenpiteet:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="912"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Näitä toimenpiteitä ei voida kumota. Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1010"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Levyt ja niiden asennukseen valitut osiot ovat vikautumassa:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1014"/>
        <source>Smartmon tool output:</source>
        <translation>Smartmon-työkalun ulosanti:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1015"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Asennukseen valitut levyt ja niiden osiot läpäisivät SMART-valvontatestin (smartctl), mutta suoritetut kokeet osoittavat keskimääräistä korkeampaa hajoamisvaaran tasoa lähitulevaisuudessa.  </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1020"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Jos olet epävarma, poistu asennusohjelmasta sekä aja GSmartControl-ohjelma saadaksesi enemmän tietoa.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1022"/>
        <source>Do you want to abort the installation?</source>
        <translation>Haluatko keskeyttää asennuksen?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1027"/>
        <source>Do you want to continue?</source>
        <translation>Haluatko jatkaa?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1196"/>
        <source>Clearing existing partition tables</source>
        <translation>Tyhjennetään olemassaolevia osiotauluja</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1204"/>
        <source>Preparing required partitions</source>
        <translation>Valmistellaan vaadittavia osioita</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1259"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>Asetetaan LUKS-salatut säiliöt</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1276"/>
        <source>Formatting: %1</source>
        <translation>Alustetaan: %1</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1467"/>
        <source>Mounting: %1</source>
        <translation>Liitetään: %1</translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation>Graafinen testiversio, voit siirtyä eteenpäin eri näkymiin ilman varsinaista asennusta.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation>Asennetaan käyttäen rsync:iä cp:n sijaan mukautetulla osioinnilla.
-- tämä ei formatoi /root-hakemistoa eikä toimi salauksen kanssa.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation>Lataa konfiguraatiotiedosto kuten&lt;config-file&gt; ilmaisee.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation>Tämä toiminto vaatii pääkäyttäjän oikeudet.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation>Asetustiedostoa (%1) ei löytynyt.</translation>
    </message>
</context>
</TS>
