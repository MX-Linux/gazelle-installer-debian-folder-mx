<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="cs">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="96"/>
        <source>%1 Installer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="56"/>
        <source>Shutdown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="113"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="344"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="466"/>
        <source>Pretending to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Do you want to abort the installation?</source>
        <translation type="vanished">Chcete přerušit instalaci? </translation>
    </message>
    <message>
        <source>Do you want to continue?</source>
        <translation type="vanished">Přejete si přesto pokračovat? </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="522"/>
        <source>Preparing to install %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="534"/>
        <source>Failed to format required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="545"/>
        <source>Paused for required operator input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="555"/>
        <source>Setting system configuration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="575"/>
        <source>Cleaning up</source>
        <translation>Čištění</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="735"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Formatting swap partition</source>
        <translation type="vanished">Formátování SWAP oddílu</translation>
    </message>
    <message>
        <source>Formatting the / (root) partition</source>
        <translation type="vanished">Formátuji oddíl / (root)</translation>
    </message>
    <message>
        <source>Formatting the /home partition</source>
        <translation type="vanished">Formátování oddílu /home</translation>
    </message>
    <message>
        <source>Mounting the /home partition</source>
        <translation type="vanished">Připojování oddílu /home</translation>
    </message>
    <message>
        <source>Sorry, could not open %1 LUKS container</source>
        <translation type="vanished">Omlouváme se, nelze otevřít LUKS kontejner %1</translation>
    </message>
    <message>
        <source>Creating required partitions</source>
        <translation type="vanished">Vytváření požadovaných oddílů</translation>
    </message>
    <message>
        <source>Preparing required partitions</source>
        <translation type="vanished">Příprava požadovaných oddílů</translation>
    </message>
    <message>
        <source>Mounting the / (root) partition</source>
        <translation type="vanished">Připojování oddílu / (root)</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="824"/>
        <source>Deleting old system</source>
        <translation>Odstraňování starého systému</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="828"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="835"/>
        <source>Creating system directories</source>
        <translation>Vytváření systémových adresářů</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="845"/>
        <source>Fixing configuration</source>
        <translation>Fixování nastavení</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="887"/>
        <source>Copying new system</source>
        <translation>Kopírování nového systému</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="927"/>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="936"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="954"/>
        <source>Installing GRUB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1039"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1055"/>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1170"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1181"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1200"/>
        <source>The home directory for %1 already exists.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1229"/>
        <source>Failed to set user account passwords.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1249"/>
        <source>Failed to save old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1256"/>
        <source>Failed to delete old home directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1276"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Je nám líto, vytvoření uživatelského adresáře selhalo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1284"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Je nám líto, pojmenování uživatelského adresáře selhalo.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1305"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Je nám líto, nelze nastavit vlastnictví uživatelské složky.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1352"/>
        <source>Please enter a computer name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1356"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1362"/>
        <source>Please enter a domain name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1366"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1373"/>
        <source>Please enter a workgroup.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1616"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1620"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1645"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1646"/>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1647"/>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>General Instructions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>Installation Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1715"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1716"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1718"/>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1720"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1728"/>
        <location filename="../minstall.cpp" line="1777"/>
        <source>Encryption</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <location filename="../minstall.cpp" line="1778"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <location filename="../minstall.cpp" line="1779"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>Limitations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1708"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Choose Partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1759"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1760"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1761"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1762"/>
        <source>Upgrading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1191"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="134"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="unfinished">Instalační program se nespustí protože již bězí na pozadí.

Prosím ukončete ho ak je to možné, nebo zadejte &apos;pkill minstall&apos; v terminálu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="165"/>
        <source>Cannot access installation source.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="216"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="577"/>
        <source>Finished</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1717"/>
        <source>Using the root-home space slider</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>Using a custom disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1749"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1763"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;keep&lt;/b&gt; as the file system type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1764"/>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1766"/>
        <source>Preferred Filesystem Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1767"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1768"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1770"/>
        <source>Bad Blocks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1771"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1773"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1774"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1780"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1781"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>Advanced Encryption Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1786"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1787"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1789"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1790"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1791"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1792"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1794"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>Cipher</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>A variety of ciphers are available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1799"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1801"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1802"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>Chain mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1804"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1805"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1806"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1807"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>IV generator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>Key size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1812"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1813"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>LUKS key hash</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1816"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>Kernel RNG</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1819"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1821"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1822"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1823"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1828"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1843"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1847"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identita počítače&lt;/b&gt;&lt;br/&gt;Název počítače je společný jedinečný název, který určuje Váš počítač, pokud je v síti. Je nepravděpodobné, že počítačová doména bude použita, pokud ji Váš poskytovatel sítě, nebo Vaše místní síť nevyžaduje.&lt;/p&gt;&lt;p&gt;Počítačové a doménová jména mohou obsahovat pouze alfanumerické znaky, tečky, pomlčky. Nemohou obsahovat mezery, začínat nebo končit pomlčkou.&lt;/p&gt;&lt;p&gt;Server SaMBa potřebuje být aktivován, pokud ho chcete použít ke sdílení některých z Vašich složek nebo tiskárnu s místním počítačem na kterém běží MS-WIndows nebo Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1860"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1861"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1862"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1863"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1865"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1867"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1868"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1874"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1879"/>
        <source>Passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1880"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1882"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1883"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1885"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2088"/>
        <location filename="../minstall.cpp" line="2472"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2090"/>
        <location filename="../minstall.cpp" line="2477"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>&lt;p&gt;&lt;b&gt;Localization Defaults&lt;/b&gt;&lt;br/&gt;Set the default keyboard and locale. These will apply unless they are overridden later by the user.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Configure Clock&lt;/b&gt;&lt;br/&gt;If you have an Apple or a pure Unix computer, by default the system clock is set to GMT or Universal Time. To change, check the box for &apos;System clock uses LOCAL.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Timezone Settings&lt;/b&gt;&lt;br/&gt;The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Service Settings&lt;/b&gt;&lt;br/&gt;Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing! </source>
        <translation type="vanished">&lt;p&gt;&lt;b&gt;Základní nastavení lokalizace&lt;/b&gt;&lt;br/&gt;Nastavte výchozí rozložení klávesnice a lokalitu. Tyto hodnoty budou použity do té doby kým nebodou uživatelem změněny .&lt;/p&gt;&lt;p&gt;&lt;b&gt;Nastavte hodiny&lt;/b&gt;&lt;br/&gt;Ak máte Apple nebo Unix počítač, z výroby jsou systémové hodiny nastaveny na GMT nebo Univerzální čas. Změníte ho, zašktrnutím políčka &apos;Systémový čas používá LOCAL.&apos;&lt;/p&gt;&lt;p&gt;&lt;b&gt;Nastavení časového pásma&lt;/b&gt;&lt;br/&gt;Systém se zpouští s časovým pásmem nastaveým na GMT/UTC. Pro změnu časového pásma klikněte po restartu v čerstvé instalaci pravým tlačítkem myši v liště na hodiny a zvolte Nastavení.&lt;/p&gt;&lt;p&gt;&lt;b&gt;Nastavení služeb&lt;/b&gt;&lt;br/&gt;Většina uživatelů by neměla měnit předvolené nastavení. Vlastníci počítačů s omezenými zdroji někdy chtějí vypnout nepotřebné služby za účelem držet spotřebu RAM na co nejnižší úrovni. Ujistěte se prosím, že víte co děláte!</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1894"/>
        <source>Old Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1895"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1897"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1898"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1900"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1901"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1903"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1904"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1905"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1906"/>
        <source>Warning</source>
        <translation>Varování</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1907"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1923"/>
        <source>Installation in Progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1924"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1926"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1928"/>
        <source>Change settings while you wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1929"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1931"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1940"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1949"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1950"/>
        <location filename="../minstall.cpp" line="2363"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1981"/>
        <source>Finish</source>
        <translation>Dokončit</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1985"/>
        <source>OK</source>
        <translation>OK</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1987"/>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2022"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2025"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2029"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2046"/>
        <source>Loading...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2288"/>
        <source>Confirmation</source>
        <translation>Potvrzení</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2288"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>Instalace a nastavení není kompletní.
Chcete nyní skutečně ukončit akci?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2349"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2357"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2371"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2379"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2384"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2431"/>
        <source>%1% root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2431"/>
        <source>%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2474"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2628"/>
        <source>System boot disk:</source>
        <translation>Zaváděcí disk systému:</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2642"/>
        <location filename="../minstall.cpp" line="2651"/>
        <source>Partition to use:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MLineEdit</name>
    <message>
        <location filename="../mlineedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Nápověda</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="151"/>
        <source>Next</source>
        <translation>Další</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="157"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="372"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2362"/>
        <source>Back</source>
        <translation>Předchozí</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2368"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2381"/>
        <source>Installation in progress</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2396"/>
        <source>Abort</source>
        <translation>Zrušení</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1290"/>
        <location filename="../meinstall.ui" line="2399"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="204"/>
        <source>Gathering Information, please stand by.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="239"/>
        <source>Terms of Use</source>
        <translation>Podmínky použití</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="266"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="280"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="303"/>
        <source>Change Keyboard Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="310"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Modify partitions:</source>
        <translation type="vanished">Upravit oddíly:</translation>
    </message>
    <message>
        <source>Run partition tool...</source>
        <translation type="vanished">Spustit správce oddílů...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="360"/>
        <source>Select type of installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Auto-install using entire disk </source>
        <translation type="vanished">Automatická instalace za použití celého disku </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="408"/>
        <location filename="../meinstall.ui" line="794"/>
        <source>Encryption password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>MB </source>
        <translation type="vanished">MB</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="401"/>
        <location filename="../meinstall.ui" line="777"/>
        <source>Confirm password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>Leave free space up to:</source>
        <translation type="vanished">Ponechaná volná kapacita:</translation>
    </message>
    <message>
        <source>Custom install on existing partitions</source>
        <translation type="vanished">Vlastní instalace na existujících oddílech</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="424"/>
        <location filename="../meinstall.ui" line="817"/>
        <location filename="../meinstall.ui" line="849"/>
        <source>Advanced encryption settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="466"/>
        <location filename="../meinstall.ui" line="675"/>
        <source>Encrypt</source>
        <translation>Zašifrovat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="440"/>
        <source>Use disk:</source>
        <translation>Použít disk:</translation>
    </message>
    <message>
        <source>Preferences</source>
        <translation type="vanished">Nastavení</translation>
    </message>
    <message>
        <source>Preserve data in /home (if upgrading)</source>
        <translation type="vanished">Zachovat data v /home (při aktualizaci)</translation>
    </message>
    <message>
        <source>Check for badblocks (takes longer)</source>
        <translation type="vanished">Zkontrolovat špatné bloky (trvá déle)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="622"/>
        <source>Choose partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>ext4</source>
        <translation type="vanished">ext4</translation>
    </message>
    <message>
        <source>ext3</source>
        <translation type="vanished">ext3</translation>
    </message>
    <message>
        <source>ext2</source>
        <translation type="vanished">ext2</translation>
    </message>
    <message>
        <source>jfs</source>
        <translation type="vanished">jfs</translation>
    </message>
    <message>
        <source>xfs</source>
        <translation type="vanished">xfs</translation>
    </message>
    <message>
        <source>btrfs</source>
        <translation type="vanished">btrfs</translation>
    </message>
    <message>
        <source>reiserfs</source>
        <translation type="vanished">reiserfs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="665"/>
        <source>Label</source>
        <translation>Jmenovka</translation>
    </message>
    <message>
        <source>root</source>
        <translation type="vanished">root</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="680"/>
        <source>Type</source>
        <translation>Typ</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="712"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="761"/>
        <source>Encryption options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="865"/>
        <source>SHA-512</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="870"/>
        <source>SHA-256</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="875"/>
        <source>Whirlpool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="880"/>
        <source>SHA-1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="885"/>
        <source>RIPEMD-160</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="902"/>
        <source>-bit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="921"/>
        <source> mS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="943"/>
        <source>LUKS key hash:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="956"/>
        <source>Key size:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="982"/>
        <source>KDF round time:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1005"/>
        <source>Cipher:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1025"/>
        <source>Serpent</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1030"/>
        <source>AES</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1035"/>
        <source>Twofish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1040"/>
        <source>CAST6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1045"/>
        <source>Blowfish</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1062"/>
        <source>Benchmark...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1092"/>
        <source>ESSIV</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1097"/>
        <source>Plain64</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1102"/>
        <source>Plain64BE</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1107"/>
        <source>Plain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1112"/>
        <source>BENBI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1126"/>
        <source>IV generator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1139"/>
        <source>Chain mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1159"/>
        <source>Kernel RNG:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1167"/>
        <source>urandom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1172"/>
        <source>random</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1199"/>
        <source>Select Boot Method</source>
        <translation>Vyberte způsob zavedení</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1236"/>
        <source>EFI System Partition</source>
        <translation>Oddíl systému EFI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1239"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1258"/>
        <source>Partition Boot Record</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1261"/>
        <source>PBR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1274"/>
        <source>Location to install on:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1287"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1306"/>
        <source>System boot disk:</source>
        <translation>Zaváděcí disk systému:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1328"/>
        <source>Master Boot Record</source>
        <translation>Master Boot Record</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1334"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1337"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1408"/>
        <source>Common Services to Enable</source>
        <translation>Společné služby k povolení</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1427"/>
        <source>Service</source>
        <translation>Služba</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1432"/>
        <source>Description</source>
        <translation>Popis</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1465"/>
        <source>Computer Network Names</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1492"/>
        <source>Workgroup</source>
        <translation>Pracovní skupina</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1505"/>
        <source>Workgroup:</source>
        <translation>Pracovní skupina:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1518"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>SaMBa Server pro MS připojování</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1534"/>
        <source>example.dom</source>
        <translation>příklad.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1547"/>
        <source>Computer domain:</source>
        <translation>Doména počítače:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1573"/>
        <source>Computer name:</source>
        <translation>Název počítače:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1634"/>
        <source>Configure Clock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>System clock uses LOCAL</source>
        <translation type="vanished">Systémové hodiny využívají LOCAL</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1675"/>
        <source>Format:</source>
        <translation>Formátovat:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1703"/>
        <source>Timezone:</source>
        <translation>Časové pásmo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1748"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1780"/>
        <source>Localization Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1820"/>
        <source>Locale:</source>
        <translation>Místní:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1842"/>
        <source>Service Settings (advanced)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1860"/>
        <source>Adjust which services should run at startup</source>
        <translation>Nastavit, které služby by měly spouštěny při startu </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1863"/>
        <source>View</source>
        <translation>Zobrazit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1921"/>
        <source>Root (administrator) Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1978"/>
        <source>Confirm root password:</source>
        <translation>Potvrzení hesla správce:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1933"/>
        <source>Root password:</source>
        <translation>Heslo správce:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2007"/>
        <source>Default User Account</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2109"/>
        <source>username</source>
        <translation>uživatelské jméno</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2048"/>
        <source>Confirm user password:</source>
        <translation>Potvrďte uživatelské heslo:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2035"/>
        <source>Default user password:</source>
        <translation>Výchozí uživatelské jméno:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2019"/>
        <source>Default user login name:</source>
        <translation>Výchozí uživatelské přihlašovací jméno:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="385"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="523"/>
        <source>Root</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="558"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="644"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="655"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="660"/>
        <source>Size</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="685"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="693"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="719"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="729"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="739"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2125"/>
        <source>Autologin</source>
        <translation>Automatické přihlašování</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2138"/>
        <source>Show passwords</source>
        <translation>Zobrazit hesla</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2151"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Změny nastavení pracovní plochy v live sezení budou převedené do plné instalace operačního systému.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2154"/>
        <source>Save live desktop changes</source>
        <translation>Uložte změny plochy live sezení</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2177"/>
        <source>Existing Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2186"/>
        <source>What would you like to do with the old directory?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2193"/>
        <source>Re-use it for this installation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2200"/>
        <source>Rename it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2207"/>
        <source>Delete it and create a new directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2252"/>
        <source>Tips</source>
        <translation>Tipy</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2296"/>
        <source>Installation complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2302"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2321"/>
        <source>Reminders</source>
        <translation>Připomenutí</translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="343"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="258"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="539"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="257"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="256"/>
        <source>EFI System Partition</source>
        <translation type="unfinished">Oddíl systému EFI</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="444"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="449"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="453"/>
        <source>BTRFS compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="454"/>
        <source>BTRFS compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="469"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="470"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="473"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="474"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="550"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="588"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="595"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="601"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="613"/>
        <source>Delete the data on %1 except for /home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="616"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="622"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="625"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="633"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="641"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="649"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="653"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="750"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="754"/>
        <source>Smartmon tool output:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="755"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="760"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="762"/>
        <source>Do you want to abort the installation?</source>
        <translation type="unfinished">Chcete přerušit instalaci? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>Do you want to continue?</source>
        <translation type="unfinished">Přejete si přesto pokračovat? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="941"/>
        <source>Clearing existing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="949"/>
        <source>Preparing required partitions</source>
        <translation type="unfinished">Příprava požadovaných oddílů</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1003"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1020"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1186"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="71"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="73"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="76"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation type="vanished">Instalační program se nespustí protože již bězí na pozadí.

Prosím ukončete ho ak je to možné, nebo zadejte &apos;pkill minstall&apos; v terminálu.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="113"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>You must run this app as root.</source>
        <translation type="vanished">Tuto aplikaci musíte spustit jako root.</translation>
    </message>
    <message>
        <location filename="../app.cpp" line="127"/>
        <source>Configuration file (%1) not found.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
