<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ca">
<context>
    <name>MInstall</name>
    <message>
        <location filename="../minstall.cpp" line="58"/>
        <source>Shutdown</source>
        <translation>Atura</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="98"/>
        <source>%1 Installer</source>
        <translation>%1 Installer</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="115"/>
        <source>Support %1

%1 is supported by people like you. Some help others at the support forum - %2, or translate help files into different languages, or make suggestions, write documentation, or help test new software.</source>
        <translation>Support %1

%1 té el suport de persones com vosaltres. Alguns donen ajuda al fòrum de suport - %2, tradueixen fitxers d&apos;ajuda a diferents idiomes, fan suggeriments, escriuen documentació, o ajuden a provar el programari nou.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="136"/>
        <source>The installer won&apos;t launch because it appears to be running already in the background.

Please close it if possible, or run &apos;pkill minstall&apos; in terminal.</source>
        <translation>L&apos;instal·lador no arrencarà perquè sembla que ja s&apos;està executant en segon pla.

Si us plau, tanqueu-lo si podeu, o executeu &apos;pkill minstall&apos; en un terminal.
</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="169"/>
        <source>Cannot access installation source.</source>
        <translation>No es pot accedir a la font d&apos;instal·lació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="220"/>
        <source>You are running 32bit OS started in 64 bit UEFI mode, the system will not be able to boot unless you select Legacy Boot or similar at restart.
We recommend you quit now and restart in Legacy Boot

Do you want to continue the installation?</source>
        <translation>Esteu executant un S.O. de 32bit arrencat en mode UEFI de 64 bit; el sistema no podrà arrencar llevat que seleccioneu Legacy Boot o semblant en tornar a engegar.
Us recomanem que sortiu ara i torneu a arrencar en mode Legacy Boot.

Voleu continuar la instal·lació?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="352"/>
        <source>%1 is an independent Linux distribution based on Debian Stable.

%1 uses some components from MEPIS Linux which are released under an Apache free license. Some MEPIS components have been modified for %1.

Enjoy using %1</source>
        <translation>%1 és una distribució Linux independent basada en Debian Stable.

%1 usa alguns components de MEPIS Linux que estan alliberats sota una llicència Apache. S&apos;han modificat alguns components MEPIS per a %1.

Gaudiu usant %1</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="474"/>
        <source>Pretending to install %1</source>
        <translation>Provant a instal·lar %1 </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="532"/>
        <source>Preparing to install %1</source>
        <translation>Preparant per instal·lar %1</translation>
    </message>
    <message>
        <source>Failed to format required partitions.</source>
        <translation type="vanished">Ha fallat en formatar les particions necessàries.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="558"/>
        <source>Paused for required operator input</source>
        <translation>En pausa esperant una entrada de l&apos;operador</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="569"/>
        <source>Setting system configuration</source>
        <translation>Configuració dels paràmetres del sistema</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="588"/>
        <source>Cleaning up</source>
        <translation>Neteja</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="590"/>
        <source>Finished</source>
        <translation>Finalitzat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="754"/>
        <source>Invalid settings found in configuration file (%1). Please review marked fields as you encounter them.</source>
        <translation>S&apos;han trobat paràmetres incorrectes al fitxer de configuració (%1). Si us plau, reviseu els camps marcats així que els trobeu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="810"/>
        <source>Deleting old system</source>
        <translation>Esborrant el sistema antic </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="814"/>
        <source>Failed to delete old %1 on destination.
Returning to Step 1.</source>
        <translation>Ha fallat en esborrar l&apos;antic %1 a la destinació.
Retornant al primer pas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="821"/>
        <source>Creating system directories</source>
        <translation>Creant els directoris de sistema </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="832"/>
        <source>Fixing configuration</source>
        <translation>Arranjant la configuració</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="888"/>
        <source>Copying new system</source>
        <translation>Copiant el nou sistema </translation>
    </message>
    <message>
        <source>Copy progress unknown. No file system statistics.</source>
        <translation type="vanished">Avanç de la còpia desconegut. No hi ha estadístiques del sistema de fitxers.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="911"/>
        <source>Failed to write %1 to destination.
Returning to Step 1.</source>
        <translation>Ha fallat en escriure %1 a la destinació.
Retornant al primer pas.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="955"/>
        <location filename="../minstall.cpp" line="1070"/>
        <source>Updating initramfs</source>
        <translation>Actualitzant initramfs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="965"/>
        <source>Installing GRUB</source>
        <translation>Instal·lant GRUB </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1000"/>
        <source>GRUB installation failed. You can reboot to the live medium and use the GRUB Rescue menu to repair the installation.</source>
        <translation>La instal·lació de GRUB ha fallat. Podeu tornar a arrencar amb el disc autònom i usar el menú GRUB Rescue per esmenar la instal·lació.</translation>
    </message>
    <message>
        <source>NVRAM boot variable update failure. The system may not boot, but it can be repaired with the GRUB Rescue boot menu.</source>
        <translation type="vanished">Ha fallat l&apos;actualització de les variables d&apos;arrencada NVRAM. El sistema no pot arrencar, però es pot arreglar amb el menú d&apos;arrencada GRUB Rescue.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1129"/>
        <source>The user name cannot contain special characters or spaces.
Please choose another name before proceeding.</source>
        <translation>El nom d&apos;usuari no pot contenir caràcters especials ni espais.
Si us plau, trieu-ne un altre abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1140"/>
        <source>Sorry, that name is in use.
Please select a different name.</source>
        <translation>Ho sento, aquest nom està en ús.
Si us plau, trieu un nom diferent. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1150"/>
        <source>You did not provide a password for the root account. Do you want to continue?</source>
        <translation>No heu facilitat cap contrasenya per a l&apos;administrador principal (root). Voleu continuar?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1159"/>
        <source>The home directory for %1 already exists.</source>
        <translation>El directori d&apos;usuari per a %1 ja hi és.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1188"/>
        <source>Failed to set user account passwords.</source>
        <translation>Ha fallat en establir les contrasenyes dels comptes d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1205"/>
        <source>Failed to save old home directory.</source>
        <translation>Ha fallat en desar l&apos;antic directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1210"/>
        <source>Failed to delete old home directory.</source>
        <translation>Ha fallat en esborrar l&apos;antic directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1228"/>
        <source>Sorry, failed to create user directory.</source>
        <translation>Ho sento, ha fallat la creació del directori d&apos;usuari. </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1233"/>
        <source>Sorry, failed to name user directory.</source>
        <translation>Ho sento, ha fallat en nomenar el directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1254"/>
        <source>Sorry, failed to set ownership of user directory.</source>
        <translation>Ho sento, ha fallat en establir la propietat del directori d&apos;usuari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1300"/>
        <source>Please enter a computer name.</source>
        <translation>Si us plau, entreu un nom per a l&apos;ordinador.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1304"/>
        <source>Sorry, your computer name contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Ho sento, el nom de l&apos;ordinador té caràcters no vàlids.
Cal que trieu un nom diferent
abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1310"/>
        <source>Please enter a domain name.</source>
        <translation>Si us plau, entreu un nom de domini.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1314"/>
        <source>Sorry, your computer domain contains invalid characters.
You&apos;ll have to select a different
name before proceeding.</source>
        <translation>Ho sento, el domini de l&apos;ordinador té caràcters no vàlids.
Cal que trieu un nom diferent
abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1321"/>
        <source>Please enter a workgroup.</source>
        <translation>Si us plau, entreu un grup de treball.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1511"/>
        <source>OK to format and use the entire disk (%1) for %2?</source>
        <translation>D&apos;acord en formatar i usar el disc sencer (%1) per %2?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1515"/>
        <source>WARNING: The selected drive has a capacity of at least 2TB and must be formatted using GPT. On some systems, a GPT-formatted disk will not boot.</source>
        <translation>ATENCIÓ: La unitat seleccionada té una capacitat de 2TB o més, i cal formatar-la usant GPT. En alguns sistemes, un disc formatat en GPT pot no arrencar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1541"/>
        <source>The data in /home cannot be preserved because the required information could not be obtained.</source>
        <translation>No es poden preservar les dades a /home perquè no s&apos;ha pogut obtenir la informació necessària.</translation>
    </message>
    <message>
        <source>If the partition containing /home is encrypted, please ensure the correct &quot;Encrypt&quot; boxes are selected, and that the entered password is correct.</source>
        <translation type="vanished">Si la partició que conté 7home està encriptada, si us plau assegureu-vos que s&apos;han seleccionat les caselles &quot;Encrypt&quot; adequades, i que la contrasenya és correcta. </translation>
    </message>
    <message>
        <source>The installer cannot encrypt an existing /home directory or partition.</source>
        <translation type="vanished">L&apos;instal·lador no pot encriptar un directori o partició /home existent.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1603"/>
        <source>General Instructions</source>
        <translation>Instruccions generals</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1604"/>
        <source>BEFORE PROCEEDING, CLOSE ALL OTHER APPLICATIONS.</source>
        <translation>ABANS DE CONTINUAR, TANQUEU TOTES LES ALTRES APLICACIONS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1605"/>
        <source>On each page, please read the instructions, make your selections, and then click on Next when you are ready to proceed. You will be prompted for confirmation before any destructive actions are performed.</source>
        <translation>A cada pàgina, si us plau llegiu les instruccions, feu les vostres seleccions, i cliqueu Següent quan esteu a punt de continuar. Se us demanarà confirmació abans de fer cap acció destructiva.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1607"/>
        <source>Limitations</source>
        <translation>Limitacions</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1608"/>
        <source>Remember, this software is provided AS-IS with no warranty what-so-ever. It is solely your responsibility to backup your data before proceeding.</source>
        <translation>Recordeu, aquest programari es facilita TAL-QUAL, sense cap garantia específica. És la vostra responsabilitat fer una còpia de seguretat abans de continuar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1613"/>
        <source>Installation Options</source>
        <translation>Opcions d&apos;instal·lació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1614"/>
        <source>Installation requires about %1 of space. %2 or more is preferred.</source>
        <translation>La instal·lació necessita al voltant de %1 d&apos;espai. Preferiblement,  %2 o més.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1615"/>
        <source>If you are running Mac OS or Windows OS (from Vista onwards), you may have to use that system&apos;s software to set up partitions and boot manager before installing.</source>
        <translation>Si esteu usant Mac OS o Windows OS (des de Vista endavant), haureu d&apos;usar el programari del sistema per ajustar les particions i el gestor d&apos;arrencada abans d&apos;instal·lar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1616"/>
        <source>Using the root-home space slider</source>
        <translation>Usant el control lliscant d&apos;espai root-home</translation>
    </message>
    <message>
        <source>On large drives, the default regular install results in separate root and home partitions. The slider allows you to control how much space is allocated to each partition.</source>
        <translation type="vanished">En unitats grans, la instal·lació estàndard crea particions separades per root i home. El control lliscant us permet determinar l&apos;espai que es reservarà per cada partició.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1620"/>
        <source>Move the slider to the right to increase the space for &lt;b&gt;root&lt;/b&gt;. Move it to the left to increase the space for &lt;b&gt;home&lt;/b&gt;.</source>
        <translation>Moveu el control lliscant cap a la dreta per augmentar l&apos;espai per a &lt;b&gt;root&lt;/b&gt;. Moveu-lo cap a l&apos;esquerra per augmentar l&apos;espai per a &lt;b&gt;home&lt;/b&gt;.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1621"/>
        <source>Move the slider all the way to the right if you want both root and home on the same partition.</source>
        <translation>Moveu el control lliscant  totalment cap a la dreta si voleu usar root i home a la mateixa partició.</translation>
    </message>
    <message>
        <source>If you plan to install many applications, or large applications such as graphics, audio and video editing packages, you probably want a larger &lt;b&gt;root&lt;/b&gt; partition.</source>
        <translation type="vanished">Si voleu instal·lar moltes aplicacions, o aplicacions grans tal com paquets d&apos;edició per a gràfics, àudio i vídeo, probablement voldreu una partició &lt;b&gt;root&lt;/b&gt; més gran.</translation>
    </message>
    <message>
        <source>If you are storing large quantity of data, or this computer is being used by many users, you may want a larger &lt;b&gt;home&lt;/b&gt; partition.</source>
        <translation type="vanished">Si voleu emmagatzemar gran quantitat de dades, o bé s&apos;usarà aquest ordinador per diversos usuaris, probablement  us cal una partició &lt;b&gt;home&lt;/b&gt; més gran.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1622"/>
        <source>Keeping the home directory in a separate partition improves the reliability of operating system upgrades. It also makes backing up and recovery easier. This can also improve overall performance by constraining the system files to a defined portion of the drive.</source>
        <translation>Tenir el directori home en una partició separada millora la fiabilitat de les actualitzacions del Sistema Operatiu. també facilita les còpies de seguretat i la recuperació. També pot millorar el rendiment en mantenir els fitxers de sistema en una part definida del disc.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1624"/>
        <location filename="../minstall.cpp" line="1698"/>
        <source>Encryption</source>
        <translation>Encriptació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1625"/>
        <location filename="../minstall.cpp" line="1699"/>
        <source>Encryption is possible via LUKS. A password is required.</source>
        <translation>Es pot encriptar amb LUKS. Caldrà una contrasenya.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1626"/>
        <location filename="../minstall.cpp" line="1700"/>
        <source>A separate unencrypted boot partition is required. For additional settings including cipher selection, use the &lt;b&gt;Advanced encryption settings&lt;/b&gt; button.</source>
        <translation>Cal una partició separada sense encriptar. Per paràmetres addicionals -incloent-hi la selecció del xifrat- useu el botó &lt;b&gt;Paràmetres avançats d&apos;encriptació&lt;/b&gt; .</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1628"/>
        <source>When encryption is used with autoinstall, the separate boot partition will be automatically created.</source>
        <translation>Quan s&apos;usa encriptació amb autoinstall, es crea automàticament una partició separada sense encriptar.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1629"/>
        <source>Using a custom disk layout</source>
        <translation>Usant una disposició del disc a mida</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1630"/>
        <source>If you need more control over where %1 is installed to, select &quot;&lt;b&gt;%2&lt;/b&gt;&quot; and click &lt;b&gt;Next&lt;/b&gt;. On the next page, you will then be able to select and configure the storage devices and partitions you need.</source>
        <translation>Si us cal més control sobre on s&apos;instal·la %1 trieu &quot;&lt;b&gt;%2&lt;/b&gt;&quot; i cliqueu&lt;b&gt;D&apos;acord&lt;/b&gt;. A la propera pàgina, podreu triar i configurar els dispositius d&apos;emmagatzematge i les particions que necessiteu.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1645"/>
        <source>Choose Partitions</source>
        <translation>Tria de Particions</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1646"/>
        <source>The partition list allows you to choose what partitions are used for this installation.</source>
        <translation>La llista de particions us permet triar quines particions s&apos;usaran per aquesta instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1647"/>
        <source>&lt;i&gt;Device&lt;/i&gt; - This is the block device name that is, or will be, assigned to the created partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1648"/>
        <source>&lt;i&gt;Size&lt;/i&gt; - The size of the partition. This can only be changed on a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1649"/>
        <source>&lt;i&gt;Label&lt;/i&gt; - The label that is assigned to the partition once it has been formatted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1660"/>
        <source>&lt;i&gt;Format&lt;/i&gt; - This is the partition&apos;s format. Available formats depend on what the partition is used for. When working with an existing layout, you may be able to preserve the format of the partition by selecting &lt;b&gt;Preserve&lt;/b&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1662"/>
        <source>The ext2, ext3, ext4, jfs, xfs, btrfs and reiserfs Linux filesystems are supported and ext4 is recommended.</source>
        <translation>Teniu suport per als sistemes de fitxers Linux ext2, ext3, ext4, jfs, xfs, btrfs i reiserfs; es recomana usar ext4.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1663"/>
        <source>&lt;i&gt;Mount Options&lt;/i&gt; - This specifies mounting options that will be used for this partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1664"/>
        <source>Menus and actions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1665"/>
        <source>A variety of actions are available by right-clicking any drive or partition item in the list.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1666"/>
        <source>The buttons to the right of the list can also be used to manipulate the entries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1667"/>
        <source>The installer cannot modify the layout already on the drive. To create a custom layout, mark the drive for a new layout with the &lt;b&gt;New layout&lt;/b&gt; menu action or button (%1). This clears the existing layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1670"/>
        <source>Basic layout requirements</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1671"/>
        <source>%1 requires a root partition. The swap partition is optional but highly recommended. If you want to use the Suspend-to-Disk feature of %1, you will need a swap partition that is larger than your physical memory size.</source>
        <translation>Cal una partició arrel per a %1. La partició d&apos;intercanvi és opcional però molt recomanada. Si voleu usar la característica de Suspendre al Disc de %1, cal una partició d&apos;intercanvi més gran que la mida de la vostra memòria física.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1673"/>
        <source>If you choose a separate /home partition it will be easier for you to upgrade in the future, but this will not be possible if you are upgrading from an installation that does not have a separate home partition.</source>
        <translation>Si escolliu una partició d&apos;usuaris (/home) separada, us resultarà més fàcil actualitzar el sistema en el futur, però això no serà possible si esteu actualitzant des d&apos;una instal·lació que no té una partició /home separada.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1679"/>
        <source>Need help creating a layout?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1680"/>
        <source>Just right-click on a drive to bring up a menu, and select a layout template. These layouts are similar to that of the regular install.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1681"/>
        <source>&lt;i&gt;Standard install&lt;/i&gt; - Suited to most setups. This template does not add a separate boot partition, and so it is unsuitable for use with an encrypted operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1682"/>
        <source>&lt;i&gt;Encrypted system&lt;/i&gt; - Contains the boot partition required to load an encrypted operating system. This template can also be used as the basis for a multi-boot system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1683"/>
        <source>Upgrading</source>
        <translation>Actualització</translation>
    </message>
    <message>
        <source>If you are preserving an existing /home directory tree located on your root partition, the installer will not reformat the root partition. As a result, the installation will take much longer than usual.</source>
        <translation type="vanished">Si trieu preservar l&apos;arbre de la partició /home existent situada a la partició arrel, l&apos;instal·lador no podrà reformatar la partició arrel. Com a resultat, la instal·lació trigarà molt més del normal.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="546"/>
        <source>Failed to prepare required partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="651"/>
        <location filename="../minstall.cpp" line="2475"/>
        <source>Unload %1-byte key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1617"/>
        <source>The drive can be divided into separate system (root) and user data (home) partitions using the slider.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1618"/>
        <source>The &lt;b&gt;root&lt;/b&gt; partition will contain the operating system and applications.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1619"/>
        <source>The &lt;b&gt;home&lt;/b&gt; partition will contain the data of all users, such as their settings, files, documents, pictures, music, videos, etc.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1650"/>
        <source>&lt;i&gt;Use For&lt;/i&gt; - To use this partition in an installation, you must select something here.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1651"/>
        <source>Format - Format without mounting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1652"/>
        <source>EFI - EFI System Partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1653"/>
        <source>boot - Boot manager (/boot).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1654"/>
        <source>root - System root (/).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1655"/>
        <source>swap - Swap space.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1656"/>
        <source>home - User data (/home).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1657"/>
        <source>In addition to the above, you can also type your own mount point. Custom mount points must start with a slash (&quot;/&quot;).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1658"/>
        <source>The installer treats &quot;/boot&quot;, &quot;/&quot;, and &quot;/home&quot; exactly the same as &quot;boot&quot;, &quot;root&quot;, and &quot;home&quot;, respectively.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1659"/>
        <source>&lt;i&gt;Encrypt&lt;/i&gt; - Use LUKS encryption for this partition. The password applies to all partitions selected for encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1675"/>
        <source>Partition boot flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1676"/>
        <source>For the installed operating system to boot, the boot flag must be set on the appropriate partition. This is usually the boot or root partition. The flag can be changed using the &lt;b&gt;Set boot flag&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1678"/>
        <source>A partition whose boot flag will be set is shown with its device name in &lt;i&gt;italic&lt;/i&gt; type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1684"/>
        <source>To upgrade from an existing Linux installation, select the same home partition as before and select &lt;b&gt;Preserve&lt;/b&gt; as the format.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1685"/>
        <source>If you do not use a separate home partition, select &lt;b&gt;Preserve /home&lt;/b&gt; on the root file system entry to preserve the existing /home directory located on your root partition. The installer will only preserve /home, and will delete everything else. As a result, the installation will take much longer than usual.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1687"/>
        <source>Preferred Filesystem Type</source>
        <translation>Tipus de Sistema  de Fitxers preferit</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1688"/>
        <source>For %1, you may choose to format the partitions as ext2, ext3, ext4, f2fs, jfs, xfs, btrfs or reiser.</source>
        <translation>Per %1, podeu triar formatar les particions com a ext2, ext3, ext4, f2fs, jfs, xfs, btrfs o reiser.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1689"/>
        <source>Additional compression options are available for drives using btrfs. Lzo is fast, but the compression is lower. Zlib is slower, with higher compression.</source>
        <translation>Es pot disposar d&apos;opcions de compressió addicionals als discos que usen BTRFS. LZO és més ràpid, però la compressió és menor. ZLIB és més lent, però comprimeix més.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1691"/>
        <source>Bad Blocks</source>
        <translation>Blocs defectuosos</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1692"/>
        <source>If you choose ext2, ext3 or ext4 as the format type, you have the option of checking and correcting for bad blocks on the drive. The badblock check is very time consuming, so you may want to skip this step unless you suspect that your drive has bad blocks.</source>
        <translation>Si trieu els formats ext2, ext3 o ext4, teniu l&apos;opció de comprovar i corregir els blocs defectuosos a la unitat.La comprovació de blocs dolents necessita molt temps, o sigui que potser voleu saltar aquest pas, llevat que sospiteu que el disc té blocs defectuosos.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1694"/>
        <source>System partition management tool</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1695"/>
        <source>For more control over the drive layouts (such as modifying the existing layout on a disk), click the partition management button (%1). This will run the operating system&apos;s partition management tool, which will allow you to create the exact layout you need.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1701"/>
        <source>To preserve an encrypted partition, right-click on it and select &lt;b&gt;Unlock&lt;/b&gt;. In the dialog that appears, enter a name for the virtual device and the password. When the device is unlocked, the name you chose will appear under &lt;i&gt;Virtual Devices&lt;/i&gt;, with similar options to that of a regular partition.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1703"/>
        <source>For the encrypted partition to be unlocked at boot, it needs to be added to the crypttab file. Use the &lt;b&gt;Add to crypttab&lt;/b&gt; menu action to do this.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1704"/>
        <source>Other partitions</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1705"/>
        <source>The installer allows other partitions to be created or used for other purposes, however be mindful that older systems cannot handle drives with more than 4 partitions.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1706"/>
        <source>Subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1707"/>
        <source>Some file systems, such as Btrfs, support multiple subvolumes in a single partition. These are not physical subdivisions, and so their order does not matter.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1709"/>
        <source>Use the &lt;b&gt;Scan subvolumes&lt;/b&gt; menu action to search an existing Btrfs partition for subvolumes. To create a new subvolume, use the &lt;b&gt;New subvolume&lt;/b&gt; menu action.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1711"/>
        <source>Existing subvolumes can be preserved, however the name must remain the same.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1712"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1713"/>
        <source>If the intaller detects any virtual devices such as opened LUKS partitions, LVM logical volumes or software-based RAID volumes, they may be used for the installation.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1714"/>
        <source>The use of virtual devices (beyond preserving encrypted file systems) is an advanced feature. You may have to edit some files (eg. initramfs, crypttab, fstab) to ensure the virtual devices used are created upon boot.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>Advanced Encryption Settings</source>
        <translation>Paràmetres avançats d&apos;encriptació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1721"/>
        <source>This page allows fine-tuning of LUKS encrypted partitions.</source>
        <translation>Aquesta pàgina permet l&apos;ajust fi de les particions encriptades LUKS.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1722"/>
        <source>In most cases, the defaults provide a practical balance between security and performance that is suitable for sensitive applications.</source>
        <translation>En molts casos, els valors per omissió donen un equilibri entre seguretat i rendiment que resulten adequats per les aplicacions sensibles.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1724"/>
        <source>This text covers the basics of the parameters used with LUKS, but is not meant to be a comprehensive guide to cryptography.</source>
        <translation>Aquest text tracta dels paràmetres bàsics usats per LUKS, però no pretén ser una guia complerta de criptografia.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1725"/>
        <source>Altering any of these settings without a sound knowledge in cryptography may result in weak encryption being used.</source>
        <translation>Alterar qualsevol d&apos;aquests paràmetres sense un bon coneixement de criptografia pot donar lloc a l&apos;ús d&apos;une encriptació feble.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1726"/>
        <source>Editing a field will often affect the available options below it. The fields below may be automatically changed to recommended values.</source>
        <translation>Editar un camp sovint afecta les opcions disponibles sota d&apos;aquest. Els camps de sota es poden canviar automàticament als valors recomanats.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1727"/>
        <source>Whilst better performance or higher security may be obtained by changing settings from their recommended values, you do so entirely at your own risk.</source>
        <translation>Tot i que es pot obtenir més rendiment o seguretat canviant els paràmetres dels valors recomanats, recordeu que ho feu sota la vostra responsabilitat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1729"/>
        <source>You can use the &lt;b&gt;Benchmark&lt;/b&gt; button (which runs &lt;i&gt;cryptsetup benchmark&lt;/i&gt; in its own terminal window) to compare the performance of common combinations of hashes, ciphers and chain modes.</source>
        <translation>Podeu usar el botó &lt;b&gt;Test de referència&lt;/b&gt; (que executa &lt;i&gt;cryptsetup benchmark&lt;/i&gt; a la seva pròpia finestra de terminal) per comparar el rendiment de combinacions usuals hash, xifrats i modes d&apos;encadenat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1730"/>
        <source>Please note that &lt;i&gt;cryptsetup benchmark&lt;/i&gt; does not cover all the combinations or selections possible, and generally covers the most commonly used selections.</source>
        <translation>Tingueu en compte que el &lt;i&gt;cryptsetup benchmark&lt;/i&gt; no cobreix totes les combinacions o seleccions possibles, en canvi cobreix les opcions més habituals.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>Cipher</source>
        <translation>Xifrat</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1732"/>
        <source>A variety of ciphers are available.</source>
        <translation>Es disposa d&apos;una varietat de xifrats.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1733"/>
        <source>was one of the five AES finalists. It is considered to have a higher security margin than Rijndael and all the other AES finalists. It performs better on some 64-bit CPUs.</source>
        <translation>és un dels cinc finalistes d&apos;AES. Es considera que té un marge de seguretat més alt que Rijndael i altres finalistes AES. Funciona millor en algunes CPU de 64 bit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1734"/>
        <source>(also known as &lt;i&gt;Rijndael&lt;/i&gt;) is a very common cipher, and many modern CPUs include instructions specifically for AES, due to its ubiquity. Although Rijndael was selected over Serpent for its performance, no attacks are currently expected to be practical.</source>
        <translation>(també conegut com a &lt;i&gt;Rijndael&lt;/i&gt;) és un xifrat molt comú i moltes CPUs modernes inclouen instruccions específiques per AES, degut a la seva ubiqüitat. Tot i que Rijndael va passar per davant de Serpent pel seu rendiment, no cal témer per atacs en la pràctica.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1735"/>
        <source>is the successor to Blowfish. It became one of the five AES finalists, although it was not selected for the standard.</source>
        <translation>és el successor de Blowfish. Ha estat un dels cinc finalistes d&apos;AES, tot i que no es va seleccionar com a estàndard.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1736"/>
        <source>(CAST-256) was a candidate in the AES contest, however it did not become a finalist.</source>
        <translation>(CAST-256) era un candidat en la prova AES, tanmateix no va arribar a finalista.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1737"/>
        <source>is a 64-bit block cipher created by Bruce Schneier. It is not recommended for sensitive applications as only CBC and ECB modes are supported. Blowfish supports key sizes between 32 and 448 bits that are multiples of 8.</source>
        <translation>és un xifrat de blocs de 64-bit creat per Bruce Schneier. No es recomana per aplicacions sensibles, atès que només té suport per als modes CBC i ECB. Blowfish dóna suport a mides de clau entre  32 i 448 bits que siguin múltiples de 8.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1739"/>
        <source>Chain mode</source>
        <translation>Mode d&apos;encadenat </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1739"/>
        <source>If blocks were all encrypted using the same key, a pattern may emerge and be able to predict the plain text.</source>
        <translation>Si tots els blocs s&apos;encripten usant la mateixa clau, pot aparèixer un patró i poder-se predir el text net.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1740"/>
        <source>XEX-based Tweaked codebook with ciphertext Stealing) is a modern chain mode, which supersedes CBC and EBC. It is the default (and recommended) chain mode. Using ESSIV over Plain64 will incur a performance penalty, with negligible known security gain.</source>
        <translation>(XEX-based Llibre de codis millorat amb sostracció de text xifrat)  és un mode d&apos;encadenat modern, que substitueix CBC i EBC. És el mode d&apos;encadenat per omissió (i recomanat). Usant ESSIV sobre Plain64 minvarà el rendiment, guany insignificant de seguretat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1741"/>
        <source>(Cipher Block Chaining) is simpler than XTS, but vulnerable to a padding oracle attack (somewhat mitigated by ESSIV) and is not recommended for sensitive applications.</source>
        <translation>(Cipher Block Chaining) és més senzill que XTS, però vulnerable a l&apos;atac de padding oracle (una mica alleujat per ESSIV) i no es recomana per aplicacions delicades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1742"/>
        <source>(Electronic CodeBook) is less secure than CBC and should not be used for sensitive applications.</source>
        <translation>(Electronic CodeBook) és menys segur que CBC i no s&apos;hauria d&apos;usar per aplicacions delicades.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>IV generator</source>
        <translation>Generador IV</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1744"/>
        <source>For XTS and CBC, this selects how the &lt;b&gt;i&lt;/b&gt;nitialisation &lt;b&gt;v&lt;/b&gt;ector is generated. &lt;b&gt;ESSIV&lt;/b&gt; requires a hash function, and for that reason, a second drop-down box will be available if this is selected. The hashes available depend on the selected cipher.</source>
        <translation>Per XTS i CBC, això selecciona com es genera el &lt;b&gt;v&lt;/b&gt;ector d&apos;&lt;b&gt;i&lt;/b&gt;nicialització. &lt;b&gt;ESSIV&lt;/b&gt; necessita una funció de resum, i per aquesta raó apareix un segon menú desplegable si s&apos;ha seleccionat. Els resums disponibles depenen del mode de xifrat escollit.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1745"/>
        <source>ECB mode does not use an IV, so these fields will all be disabled if ECB is selected for the chain mode.</source>
        <translation>El mode ECB no usa un IV, per tant aquests camps es desactiven si es tria ECB com a mode d&apos;encadenat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Key size</source>
        <translation>Mida de la clau</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1747"/>
        <source>Sets the key size in bits. Available key sizes are limited by the cipher and chain mode.</source>
        <translation>Tria la mida de la clau en bits. Les mides de la clau estan limitades pel mode xifrat i encadenat.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1748"/>
        <source>The XTS cipher chain mode splits the key in half (for example, AES-256 in XTS mode requires a 512-bit key size).</source>
        <translation>El mode de xifrat i encadenat divideix la clau en dos (per exemple, per AES-256 en mode XTS cal una mida de clau de 512).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>LUKS key hash</source>
        <translation>Hash de la clau LUKS</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1750"/>
        <source>The hash used for PBKDF2 and for the AF splitter.</source>
        <translation>El hash usat per PBKDF2 i per al separador AF</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1751"/>
        <source>SHA-1 and RIPEMD-160 are no longer recommended for sensitive applications as they have been found to be broken.</source>
        <translation>Ja no es recomana SHA-1 ni RIPEMD-160 per aplicacions delicades, ja que s&apos;ha comprovat que no anaven bé.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>Kernel RNG</source>
        <translation>Kernel RNG</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1753"/>
        <source>Sets which kernel random number generator will be used to create the master key volume key (which is a long-term key).</source>
        <translation>Selecciona quin generador de números aleatoris s&apos;usarà per a crear la clau mestra de la clau del volum (que és la clau a llarg termini).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1754"/>
        <source>Two options are available: /dev/&lt;b&gt;random&lt;/b&gt; which blocks until sufficient entropy is obtained (can take a long time in low-entropy situations), and /dev/&lt;b&gt;urandom&lt;/b&gt; which will not block even if there is insufficient entropy (possibly weaker keys).</source>
        <translation>Hi ha dues opcions a l&apos;abast: /dev/&lt;b&gt;random&lt;/b&gt; que bloqueja fins que hi ha prou entropia (pot trigar bastant en situacions de baixa entropia), i /dev/&lt;b&gt;urandom&lt;/b&gt; que no bloqueja encara que no hi hagi prou entropia (potser claus més febles).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1756"/>
        <source>KDF round time&lt;/b&gt;&lt;br/&gt;The amount of time (in milliseconds) to spend with PBKDF2 passphrase processing.</source>
        <translation>Temps mitjà KDF&lt;/b&gt;&lt;br/&gt;El temps total en milisegons) emprats en processar la contrasenya PBKDF2.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1757"/>
        <source>A value of 0 selects the compiled-in default (run &lt;i&gt;cryptsetup --help&lt;/i&gt; for details).</source>
        <translation>El valor 0 selecciona el valor compilat per omissió (executeu &lt;i&gt;cryptsetup --help&lt;/i&gt; per més detalls).</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1758"/>
        <source>If you have a slow machine, you may wish to increase this value for extra security, in exchange for time taken to unlock a volume after a passphrase is entered.</source>
        <translation>Si teniu una màquina lenta, potser voldreu augmentar aquest valor per augmentar la seguretat, a canvi del temps necessari per desbloquejar un volum després d&apos;entrar la contrasenya.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1763"/>
        <source>&lt;p&gt;&lt;b&gt;Select Boot Method&lt;/b&gt;&lt;br/&gt; %1 uses the GRUB bootloader to boot %1 and MS-Windows. &lt;p&gt;By default GRUB2 is installed in the Master Boot Record (MBR) or ESP (EFI System Partition for 64-bit UEFI boot systems) of your boot drive and replaces the boot loader you were using before. This is normal.&lt;/p&gt;&lt;p&gt;If you choose to install GRUB2 to Partition Boot Record (PBR) instead, then GRUB2 will be installed at the beginning of the specified partition. This option is for experts only.&lt;/p&gt;&lt;p&gt;If you uncheck the Install GRUB box, GRUB will not be installed at this time. This option is for experts only.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Trieu el mètode d&apos;arrencada&lt;/b&gt;&lt;br/&gt; %1 usa el carregador GRUB per arrencar %1 i MS-Windows. &lt;p&gt;Per omissió s&apos;instal·la GRUB2 al Master Boot Record (MBR) o ESP (EFI System Partition per sistemes d&apos;arrencada UEFI de 64-bit) del vostre disc d&apos;arrencada i substitueix el carregador que havíeu usat abans. Això és normal.&lt;/p&gt;&lt;p&gt;Si, en canvi, trieu instal·lar GRUB2 al Partition Boot Record (PBR), llavors GRUB2 s&apos;instal·larà al començament de la partició especificada. Aquesta opció es reserva per a experts.&lt;/p&gt;&lt;p&gt;Si desactiveu la casella [Instal·la  GRUB], el GRUB no s&apos;instal·larà ara. Aquesta opció és només per a experts.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1778"/>
        <source>&lt;p&gt;&lt;b&gt;Common Services to Enable&lt;/b&gt;&lt;br/&gt;Select any of these common services that you might need with your system configuration and the services will be started automatically when you start %1.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Serveis Comuns a activar&lt;/b&gt;&lt;br/&gt;seleccioneu els serveis comuns que podeu necessitar en la vostra configuració de sistema i aquests serveis s&apos;engegaran automàticament en arrencar %1.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1782"/>
        <source>&lt;p&gt;&lt;b&gt;Computer Identity&lt;/b&gt;&lt;br/&gt;The computer name is a common unique name which will identify your computer if it is on a network. The computer domain is unlikely to be used unless your ISP or local network requires it.&lt;/p&gt;&lt;p&gt;The computer and domain names can contain only alphanumeric characters, dots, hyphens. They cannot contain blank spaces, start or end with hyphens&lt;/p&gt;&lt;p&gt;The SaMBa Server needs to be activated if you want to use it to share some of your directories or printer with a local computer that is running MS-Windows or Mac OSX.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Identitat de l&apos;ordinador&lt;/b&gt;&lt;br/&gt;El nom de l&apos;ordinador és un nom únic que identifica el vostre ordinador quan forma part d&apos;una xarxa. El domini de l&apos;ordinador és improbable que sigui obligatori llevat que el vostre proveïdor d&apos;Internet (ISP) o bé la xarxa local ho necessitin.&lt;/p&gt;&lt;p&gt;Els noms d&apos;equip i de domini poden contenir només caràcters alfanumèrics, punts, i guionets. No poden contenir espais en blanc, començar o acabar amb guionets.&lt;/p&gt;&lt;p&gt;Cal activar el servidor SaMBa si voleu compartir els vostres directoris o impressores amb un ordinador local que usi MS-Windows o Mac OSX.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1795"/>
        <source>Localization Defaults</source>
        <translation>Localització per omissió</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1796"/>
        <source>Set the default locale. This will apply unless they are overridden later by the user.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1797"/>
        <source>Configure Clock</source>
        <translation>Configura el rellotge</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1798"/>
        <source>If you have an Apple or a pure Unix computer, by default the system clock is set to Greenwich Meridian Time (GMT) or Coordinated Universal Time (UTC). To change this, check the &quot;&lt;b&gt;System clock uses local time&lt;/b&gt;&quot; box.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1800"/>
        <source>The system boots with the timezone preset to GMT/UTC. To change the timezone, after you reboot into the new installation, right click on the clock in the Panel and select Properties.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1802"/>
        <source>Service Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1803"/>
        <source>Most users should not change the defaults. Users with low-resource computers sometimes want to disable unneeded services in order to keep the RAM usage as low as possible. Make sure you know what you are doing!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1809"/>
        <source>Default User Login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1810"/>
        <source>The root user is similar to the Administrator user in some other operating systems. You should not use the root user as your daily user account. Please enter the name for a new (default) user account that you will use on a daily basis. If needed, you can add other user accounts later with %1 User Manager.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1814"/>
        <source>Passwords</source>
        <translation>Contrasenyes</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1815"/>
        <source>Enter a new password for your default user account and for the root account. Each password must be entered twice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1817"/>
        <source>No passwords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1818"/>
        <source>If you want the default user account to have no password, leave its password fields empty. This allows you to log in without requiring a password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1820"/>
        <source>Obviously, this should only be done in situations where the user account does not need to be secure, such as a public terminal.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1829"/>
        <source>Old Home Directory</source>
        <translation>Director d&apos;usuaris anterior</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1830"/>
        <source>A home directory already exists for the user name you have chosen. This screen allows you to choose what happens to this directory.</source>
        <translation>Ja hi ha un directori d&apos;usuari amb el nom que heu triat. Aquesta pantalla us permet escollir què fer amb aquest directori.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1832"/>
        <source>Re-use it for this installation</source>
        <translation>Tornar a usar-lo per aquesta instal·lació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1833"/>
        <source>The old home directory will be used for this user account. This is a good choice when upgrading, and your files and settings will be readily available.</source>
        <translation>S&apos;usarà el director d&apos;usuari anterior. És una bona elecció quan actualitzeu, i es localitzaran fàcilment els vostres paràmetres i fitxers.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1835"/>
        <source>Rename it and create a new directory</source>
        <translation>Canviar-li el nom i crear un nou directori</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1836"/>
        <source>A new home directory will be created for the user, but the old home directory will be renamed. Your files and settings will not be immediately visible in the new installation, but can be accessed using the renamed directory.</source>
        <translation>Es crearà un nou directori per aquest usuari, però en mantindrà el directori antic amb un altre nom. Els vostres paràmetres i fitxers no seran visibles immediatament per la nova instal·lació, però seran accessibles usant el directori amb el nou nom.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1838"/>
        <source>The old directory will have a number at the end of it, depending on how many times the directory has been renamed before.</source>
        <translation>El directori anterior tindrà una xifra al final del nom, depenent de quantes vegades se li hagi canviat el nom.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1839"/>
        <source>Delete it and create a new directory</source>
        <translation>Esborrar-lo i crear un directori nou</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1840"/>
        <source>The old home directory will be deleted, and a new one will be created from scratch.</source>
        <translation>S&apos;esborrarà el directori d&apos;usuari anterior, i se&apos;n crearà un de bell nou.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1841"/>
        <source>Warning</source>
        <translation>Atenció </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1842"/>
        <source>All files and settings will be deleted permanently if this option is selected. Your chances of recovering them are low.</source>
        <translation>Si trieu aquesta opció, s&apos;esborraran permanentment tots els paràmetres i fitxers. La possibilitat de recuperar-los és mínima.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1858"/>
        <source>Installation in Progress</source>
        <translation>Instal·lació en curs</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1859"/>
        <source>%1 is installing. For a fresh install, this will probably take 3-20 minutes, depending on the speed of your system and the size of any partitions you are reformatting.</source>
        <translation>S&apos;està instal·lant %1. Per una instal·lació nova, calen entre 3 i 20 minuts, depenent de la velocitat del vostre sistema i la mida de les particions que esteu reformatant.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1861"/>
        <source>If you click the Abort button, the installation will be stopped as soon as possible.</source>
        <translation>Si cliqueu el botó d&apos;interrupció, la instal·lació s&apos;aturarà tan aviat com sigui possible.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1863"/>
        <source>Change settings while you wait</source>
        <translation>Canvia els paràmetres mentre espereu</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1864"/>
        <source>While %1 is being installed, you can click on the &lt;b&gt;Next&lt;/b&gt; or &lt;b&gt;Back&lt;/b&gt; buttons to enter other information required for the installation.</source>
        <translation>Mentre s&apos;instal·la %1 , podeu clicar els botons &lt;b&gt;Següent&lt;/b&gt; o &lt;b&gt;Enrere&lt;/b&gt; per introduir altres informacions necessàries per a la instal·lació.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1866"/>
        <source>Complete these steps at your own pace. The installer will wait for your input if necessary.</source>
        <translation>Completeu aquests passos al vostre ritme. L&apos;instal·lador esperarà la vostra entrada si és necessari.</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1875"/>
        <source>&lt;p&gt;&lt;b&gt;Congratulations!&lt;/b&gt;&lt;br/&gt;You have completed the installation of %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Finding Applications&lt;/b&gt;&lt;br/&gt;There are hundreds of excellent applications installed with %1 The best way to learn about them is to browse through the Menu and try them. Many of the apps were developed specifically for the %1 project. These are shown in the main menus. &lt;p&gt;In addition %1 includes many standard Linux applications that are run only from the command line and therefore do not show up in the Menu.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Enhorabona!&lt;/b&gt;&lt;br/&gt;Heu acomplert la instal·lació de %1&lt;/p&gt;&lt;p&gt;&lt;b&gt;Trobar Aplicacions&lt;/b&gt;&lt;br/&gt;Ja hi ha centenars d&apos;aplicacions instal·lades a %1 . La millor manera de familiaritzar-s&apos;hi és fullejar el Menú i provar-les. Moltes de les aplicacions s&apos;han desenvolupat especialment per al projecte %1. Aquestes es mostren als menús principals.&lt;p&gt;Però a més,  %1 inclou moltes aplicacions estàndard de Linux que s&apos;executen des de la línia d&apos;ordres i, per tant, no surten al Menú.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1884"/>
        <source>Enjoy using %1&lt;/b&gt;&lt;/p&gt;</source>
        <translation>Gaudiu usant %1&lt;/b&gt;&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1885"/>
        <location filename="../minstall.cpp" line="2299"/>
        <source>&lt;p&gt;&lt;b&gt;Support %1&lt;/b&gt;&lt;br/&gt;%1 is supported by people like you. Some help others at the support forum - %2 - or translate help files into different languages, or make suggestions, write documentation, or help test new software.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Suport de %1&lt;/b&gt;&lt;br/&gt;%1 té el suport de persones com vosaltres. Uns n&apos;ajuden altres al fòrum d&apos;ajuda (%2), tradueixen fitxers d&apos;ajuda a diversos idiomes, fan suggeriments, escriuen documentació o proven el programari nou.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1916"/>
        <source>Finish</source>
        <translation>Acaba</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1920"/>
        <source>OK</source>
        <translation>D&apos;acord</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1922"/>
        <source>Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1957"/>
        <source>Configuring sytem. Please wait.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1960"/>
        <source>Configuration complete. Restarting system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1964"/>
        <source>Could not complete configuration.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="1982"/>
        <source>Loading...</source>
        <translation>Carregant...</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2023"/>
        <location filename="../minstall.cpp" line="2410"/>
        <source>Root</source>
        <translation>Arrel</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2025"/>
        <location filename="../minstall.cpp" line="2418"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2224"/>
        <source>Confirmation</source>
        <translation>Confirmació</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2224"/>
        <source>The installation and configuration is incomplete.
Do you really want to stop now?</source>
        <translation>No s&apos;ha acabat la instal·lació i configuració.
De debò voleu aturar-la ara?</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2285"/>
        <source>&lt;p&gt;&lt;b&gt;Getting Help&lt;/b&gt;&lt;br/&gt;Basic information about %1 is at %2.&lt;/p&gt;&lt;p&gt;There are volunteers to help you at the %3 forum, %4&lt;/p&gt;&lt;p&gt;If you ask for help, please remember to describe your problem and your computer in some detail. Usually statements like &apos;it didn&apos;t work&apos; are not helpful.&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Obtenir Ajuda&lt;/b&gt;&lt;br/&gt;La informació bàsica quant a %1 està a %2.&lt;/p&gt;&lt;p&gt;Trobareu voluntaris per ajudar-vos al fòrum de %3 , %4&lt;/p&gt;&lt;p&gt;Si demaneu ajuda, si us plau recordeu-vos de descriure en detall l&apos;ordinador i el vostre problema. Normalment frases com &apos;No funciona&apos; no ajuden gens. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2293"/>
        <source>&lt;p&gt;&lt;b&gt;Repairing Your Installation&lt;/b&gt;&lt;br/&gt;If %1 stops working from the hard drive, sometimes it&apos;s possible to fix the problem by booting from LiveDVD or LiveUSB and running one of the included utilities in %1 or by using one of the regular Linux tools to repair the system.&lt;/p&gt;&lt;p&gt;You can also use your %1 LiveDVD or LiveUSB to recover data from MS-Windows systems!&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Reparar la instal·lació&lt;/b&gt;&lt;br/&gt;Si %1 deixa de funcionar des del disc dur, a vegades es pot arreglar arrencant des del DVD Autònom o Live USB i executant alguna de les utilitats incorporades a %1 o bé usant una de les eines clàssiques de Linux per reparar el sistema.&lt;/p&gt;&lt;p&gt;Fins i tot podeu usar el vostre DVD Autònom o Live USB de %1 per recuperar dades dels sistemes MS-Windows!&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2307"/>
        <source>&lt;p&gt;&lt;b&gt;Adjusting Your Sound Mixer&lt;/b&gt;&lt;br/&gt; %1 attempts to configure the sound mixer for you but sometimes it will be necessary for you to turn up volumes and unmute channels in the mixer in order to hear sound.&lt;/p&gt; &lt;p&gt;The mixer shortcut is located in the menu. Click on it to open the mixer. &lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Ajustatges del mesclador de so&lt;/b&gt;&lt;br/&gt; %1 prova de configurar el mesclador de so per vosaltres, però a vegades us serà necessari pujar el volum o desenmudir canals al mesclador per escoltar so.&lt;/p&gt; &lt;p&gt;Trobareu la drecera del mesclador al menú. Cliqueu-hi per obrir el mesclador. &lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2315"/>
        <source>&lt;p&gt;&lt;b&gt;Keep Your Copy of %1 up-to-date&lt;/b&gt;&lt;br/&gt;For more information and updates please visit&lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Mantingueu la vostra còpia de %1 al dia&lt;/b&gt;&lt;br/&gt;Per més informació i actualitzacions podeu visitar &lt;/p&gt;&lt;p&gt; %2&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2320"/>
        <source>&lt;p&gt;&lt;b&gt;Special Thanks&lt;/b&gt;&lt;br/&gt;Thanks to everyone who has chosen to support %1 with their time, money, suggestions, work, praise, ideas, promotion, and/or encouragement.&lt;/p&gt;&lt;p&gt;Without you there would be no %1.&lt;/p&gt;&lt;p&gt;%2 Dev Team&lt;/p&gt;</source>
        <translation>&lt;p&gt;&lt;b&gt;Agraïments&lt;/b&gt;&lt;br/&gt;Gràcies a tothom que ha triat donar suport a  %1 amb el seu temps, diners, suggeriments, treball, lloances, idees, promoció i/o ànims.&lt;/p&gt;&lt;p&gt;Sense vosaltres no hi hauria %1.&lt;/p&gt;&lt;p&gt;L&apos;Equip de Desenvolupament de %2.&lt;/p&gt;</translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2372"/>
        <source>%1% root
%2% home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2374"/>
        <source>Combined root and home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2415"/>
        <source>----</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2463"/>
        <source>Are you sure you want to unload the current key?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2474"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2594"/>
        <source>System boot disk:</source>
        <translation>Disc d&apos;arrencada: </translation>
    </message>
    <message>
        <location filename="../minstall.cpp" line="2608"/>
        <location filename="../minstall.cpp" line="2617"/>
        <source>Partition to use:</source>
        <translation>Partició a usar: </translation>
    </message>
</context>
<context>
    <name>MPassEdit</name>
    <message>
        <location filename="../mpassedit.cpp" line="95"/>
        <source>Use password</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MeInstall</name>
    <message>
        <location filename="../meinstall.ui" line="46"/>
        <source>Help</source>
        <translation>Ajuda </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="103"/>
        <source>Live Log</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="141"/>
        <source>Close</source>
        <translation>Tanca</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="152"/>
        <source>Next</source>
        <translation>Següent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="159"/>
        <source>Alt+N</source>
        <translation>Alt+N</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="206"/>
        <source>Gathering Information, please stand by.</source>
        <translation>Recollint informació, espereu si us plau.</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="241"/>
        <source>Terms of Use</source>
        <translation>Condicions d&apos;ús</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="268"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Keyboard Settings&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;center&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Disposició del teclat&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="275"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Model:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="282"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Variant:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="305"/>
        <source>Change Keyboard Settings</source>
        <translation>Canvia la disposició del teclat</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="312"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Layout:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p align=&quot;right&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Disposició:&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="362"/>
        <source>Select type of installation</source>
        <translation>Trieu el tipus d&apos;instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="374"/>
        <source>Regular install using the entire disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="387"/>
        <source>Customize the disk layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="400"/>
        <location filename="../meinstall.ui" line="781"/>
        <source>Confirm password:</source>
        <translation>Confirmeu la contrasenya: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="407"/>
        <location filename="../meinstall.ui" line="798"/>
        <source>Encryption password:</source>
        <translation>Contrasenya d&apos;encriptació: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="423"/>
        <location filename="../meinstall.ui" line="821"/>
        <location filename="../meinstall.ui" line="853"/>
        <source>Advanced encryption settings</source>
        <translation>Paràmetres avançats d&apos;encriptació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="439"/>
        <source>Use disk:</source>
        <translation>Usa el disc:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="465"/>
        <location filename="../meinstall.ui" line="702"/>
        <source>Encrypt</source>
        <translation>Encripta</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="522"/>
        <source>Root</source>
        <translation>Arrel</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="557"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="621"/>
        <source>Choose partitions</source>
        <translation>Trieu les particions</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="720"/>
        <source>Add a new partition entry. This only works with a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="682"/>
        <source>Device</source>
        <translation>Dispositiu </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="687"/>
        <source>Size</source>
        <translation>Mida </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="692"/>
        <source>Label</source>
        <translation>Etiqueta </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="697"/>
        <source>Use For</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="707"/>
        <source>Format</source>
        <translation>Format </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="712"/>
        <source>Mount Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="670"/>
        <source>Query the operating system and reload the layouts of all drives.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="639"/>
        <source>Check for bad sectors (takes longer)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="646"/>
        <source>Remove an existing entry from the layout. This only works with entries to a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="731"/>
        <source>Mark the selected drive to be cleared for a new layout.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="742"/>
        <source>Run the partition management application of this operating system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="765"/>
        <source>Encryption options</source>
        <translation>Opcions d&apos;encriptació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1135"/>
        <source>SHA-512</source>
        <translation>SHA-512</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1140"/>
        <source>SHA-256</source>
        <translation>SHA-256</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1145"/>
        <source>Whirlpool</source>
        <translation>Whirlpool</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1150"/>
        <source>SHA-1</source>
        <translation>SHA-1</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1155"/>
        <source>RIPEMD-160</source>
        <translation>RIPEMD-160</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="881"/>
        <source>-bit</source>
        <translation>-bit</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1175"/>
        <source> mS</source>
        <translation> mS</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="865"/>
        <source>LUKS key hash:</source>
        <translation>Hash de la clau LUKS:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="995"/>
        <source>Key size:</source>
        <translation>Mida de clau:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1105"/>
        <source>KDF round time:</source>
        <translation>KDF round time:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1092"/>
        <source>Cipher:</source>
        <translation>Xifrat: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="935"/>
        <source>Serpent</source>
        <translation>Serpent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="940"/>
        <source>AES</source>
        <translation>AES</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="945"/>
        <source>Twofish</source>
        <translation>Twofish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="950"/>
        <source>CAST6</source>
        <translation>CAST6</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="955"/>
        <source>Blowfish</source>
        <translation>Blowfish</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="982"/>
        <source>Benchmark...</source>
        <translation>Test de referència...</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1051"/>
        <source>ESSIV</source>
        <translation>ESSIV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1056"/>
        <source>Plain64</source>
        <translation>Plain64</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1061"/>
        <source>Plain64BE</source>
        <translation>Plain64BE</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1066"/>
        <source>Plain</source>
        <translation>Plain</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1071"/>
        <source>BENBI</source>
        <translation>BENBI</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1008"/>
        <source>IV generator:</source>
        <translation>Generador IV</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1034"/>
        <source>Chain mode:</source>
        <translation>Mode d&apos;encadenat:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="901"/>
        <source>Kernel RNG:</source>
        <translation>Kernel RNG:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="909"/>
        <source>urandom</source>
        <translation>urandom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="914"/>
        <source>random</source>
        <translation>random</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1210"/>
        <source>Select Boot Method</source>
        <translation>Trieu el mètode d&apos;arrencada</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1310"/>
        <source>EFI System Partition</source>
        <translation>EFI System Partition</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1313"/>
        <source>ESP</source>
        <translation>ESP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1259"/>
        <source>Partition Boot Record</source>
        <translation>Registre d&apos;arrencada de partició</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1262"/>
        <source>PBR</source>
        <translation>PBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1288"/>
        <source>Location to install on:</source>
        <translation>Ubicació on instal·lar:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1222"/>
        <source>Install GRUB for Linux and Windows</source>
        <translation>Instal·la GRUB per Linux i Windows</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1079"/>
        <source>Load key material...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1225"/>
        <location filename="../meinstall.ui" line="2410"/>
        <source>Alt+A</source>
        <translation>Alt+A</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1275"/>
        <source>System boot disk:</source>
        <translation>Disc d&apos;arrencada: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1335"/>
        <source>Master Boot Record</source>
        <translation>Registre d&apos;Arrencada Principal</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1341"/>
        <source>MBR</source>
        <translation>MBR</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1344"/>
        <source>Alt+B</source>
        <translation>Alt+B</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1418"/>
        <source>Common Services to Enable</source>
        <translation>Serveis comuns a habilitar </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1437"/>
        <source>Service</source>
        <translation>Servei </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1442"/>
        <source>Description</source>
        <translation>Descripció </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1475"/>
        <source>Computer Network Names</source>
        <translation>Noms de Xarxa d&apos;ordinadors</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1502"/>
        <source>Workgroup</source>
        <translation>WORKGROUP</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1515"/>
        <source>Workgroup:</source>
        <translation>Grup de treball: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1528"/>
        <source>SaMBa Server for MS Networking</source>
        <translation>Servidor SaMBa per a xarxa MS </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1544"/>
        <source>example.dom</source>
        <translation>exemple.dom</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1557"/>
        <source>Computer domain:</source>
        <translation>Domini de l&apos;ordinador:</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1583"/>
        <source>Computer name:</source>
        <translation>Nom d&apos;ordinador: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1644"/>
        <source>Configure Clock</source>
        <translation>Configura el rellotge</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1685"/>
        <source>Format:</source>
        <translation>Format: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1713"/>
        <source>Timezone:</source>
        <translation>Fus horari: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1758"/>
        <source>System clock uses local time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1790"/>
        <source>Localization Defaults</source>
        <translation>Localització per omissió</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1830"/>
        <source>Locale:</source>
        <translation>Locale: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1852"/>
        <source>Service Settings (advanced)</source>
        <translation>Paràmetres de Serveis (avançat)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1870"/>
        <source>Adjust which services should run at startup</source>
        <translation>Trieu quins serveis cal executar en engegar </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1873"/>
        <source>View</source>
        <translation>Veure </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1931"/>
        <source>Root (administrator) Account</source>
        <translation>Compte Root (administrador)</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1943"/>
        <source>Root password:</source>
        <translation>Contrasenya de root: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="1988"/>
        <source>Confirm root password:</source>
        <translation>Confirmeu la contrasenya de root: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2017"/>
        <source>Default User Account</source>
        <translation>Compte d&apos;usuari per omissió</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2029"/>
        <source>Default user login name:</source>
        <translation>Nom de registre d&apos;usuari per omissió: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2045"/>
        <source>Default user password:</source>
        <translation>Contrasenya d&apos;usuari per omissió: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2058"/>
        <source>Confirm user password:</source>
        <translation>Confirmeu la contrasenya d&apos;usuari: </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2119"/>
        <source>username</source>
        <translation>nomdusuari </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2135"/>
        <source>Autologin</source>
        <translation>Entrada automàtica </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2148"/>
        <source>Show passwords</source>
        <translation>Mostra contrasenyes </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2161"/>
        <source>Desktop modifications made in the live environment will be carried over to the installed OS</source>
        <translation>Les modificacions fetes a l&apos;entorn autònom es traslladaran al S. O. instal·lat </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2164"/>
        <source>Save live desktop changes</source>
        <translation>Desa els canvis de l&apos;escriptori autònom </translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2187"/>
        <source>Existing Home Directory</source>
        <translation>Directori d&apos;usuari existent</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2196"/>
        <source>What would you like to do with the old directory?</source>
        <translation>Què en voldríeu fer amb el directori antic?</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2203"/>
        <source>Re-use it for this installation</source>
        <translation>Tornar a usar-lo per aquesta instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2210"/>
        <source>Rename it and create a new directory</source>
        <translation>Canviar-li el nom i crear un nou directori</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2217"/>
        <source>Delete it and create a new directory</source>
        <translation>Esborrar-lo i crear un nou directori</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2262"/>
        <source>Tips</source>
        <translation>Trucs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2306"/>
        <source>Installation complete</source>
        <translation>Instal·lació completa</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2312"/>
        <source>Automatically reboot the system when the installer is closed</source>
        <translation>Torna a arrencar el sistema en acabar la instal·lació</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2331"/>
        <source>Reminders</source>
        <translation>Recordatoris</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2372"/>
        <source>Back</source>
        <translation>Enrere</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2379"/>
        <source>Alt+K</source>
        <translation>Alt+K</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2392"/>
        <source>Installation in progress</source>
        <translation>Instal·lació en curs</translation>
    </message>
    <message>
        <location filename="../meinstall.ui" line="2407"/>
        <source>Abort</source>
        <translation>Interromp </translation>
    </message>
</context>
<context>
    <name>PartMan</name>
    <message>
        <location filename="../partman.cpp" line="395"/>
        <source>EFI System Partition</source>
        <translation>Partició de Sistema EFI </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="396"/>
        <source>swap space</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="397"/>
        <source>swap space #%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="510"/>
        <source>Preserve (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="703"/>
        <location filename="../partman.cpp" line="761"/>
        <source>&amp;Add partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="705"/>
        <source>&amp;Remove partition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="138"/>
        <source>Virtual Devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="398"/>
        <source>format only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="510"/>
        <source>Preserve /home (%1)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="553"/>
        <location filename="../partman.cpp" line="971"/>
        <source>Create</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="715"/>
        <source>&amp;Lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="719"/>
        <source>&amp;Unlock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="726"/>
        <location filename="../partman.cpp" line="858"/>
        <source>Add to crypttab</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="732"/>
        <source>Set boot flag</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="739"/>
        <source>New subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="740"/>
        <source>Scan subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="764"/>
        <source>New &amp;layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="765"/>
        <source>&amp;Reset layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="766"/>
        <location filename="../partman.cpp" line="800"/>
        <source>&amp;Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="767"/>
        <source>&amp;Standard install</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="768"/>
        <source>&amp;Encrypted system</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="786"/>
        <source>Remove subvolume</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="803"/>
        <source>Compression (&amp;ZLIB)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="805"/>
        <source>Compression (&amp;LZO)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="855"/>
        <source>Unlock Drive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="861"/>
        <source>Virtual Device:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="862"/>
        <source>Password:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="897"/>
        <source>Could not unlock device. Possible incorrect password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="933"/>
        <source>Failed to close %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1005"/>
        <source>Preserve</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1046"/>
        <source>Invalid subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1056"/>
        <source>Duplicate subvolume label</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1066"/>
        <source>Invalid use for %1: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1078"/>
        <source>%1 is already selected for: %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1113"/>
        <source>Cannot preserve /home inside root (/) if a separate /home partition is also mounted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1122"/>
        <source>You must choose a root partition.
The root partition must be at least %1.</source>
        <translation>Cal triar una partició arrel.
La partició arrel ha de tenir %1 com a mínim.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1128"/>
        <source>You must choose a separate boot partition when encrypting root.</source>
        <translation>Cal triar una partició d&apos;arrencada separada quan s&apos;encripta l&apos;arrel.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1140"/>
        <source>Delete the data on %1 except for /home</source>
        <translation>Esborra les dades a %1 excepte per /home </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1143"/>
        <source>Reuse (no reformat) %1 as %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1149"/>
        <source>%1, to be used for %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1152"/>
        <source>The following partitions you selected are not Linux partitions:</source>
        <translation>Les particions següents que heu triat no són particions Linux: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1160"/>
        <source>Are you sure you want to reformat these partitions?</source>
        <translation>Esteu segur que voleu reformatar aquestes particions?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1168"/>
        <source>The %1 installer will now format and destroy the data on the following partitions:</source>
        <translation>L&apos;instal·lador %1 ara formatarà i destruirà les dades a les següents particions: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1176"/>
        <source>The %1 installer will now perform the following actions:</source>
        <translation>L&apos;instal·lador %1 ara efectuarà aquestes accions: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1180"/>
        <source>These actions cannot be undone. Do you want to continue?</source>
        <translation>Aquestes accions no es poden desfer. Voleu continuar?</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1278"/>
        <source>The disks with the partitions you selected for installation are failing:</source>
        <translation>Els discs amb les particions que heu seleccionat per la instal·lació estan fallant:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1282"/>
        <source>Smartmon tool output:</source>
        <translation>Sortida de l&apos;eina Smartmon:</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1283"/>
        <source>The disks with the partitions you selected for installation pass the SMART monitor test (smartctl), but the tests indicate it will have a higher than average failure rate in the near future.</source>
        <translation>Els discs amb les particions que heu seleccionat passen les proves SMART monitor (smartctl), però les proves indiquen que tenen una possibilitat de fallada en el futur superior a la mitjana: </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1288"/>
        <source>If unsure, please exit the Installer and run GSmartControl for more information.</source>
        <translation>Si no n&apos;esteu segurs, sortiu de l&apos;instal·lador i executeu GSmartControl per tenir més informació.</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1290"/>
        <source>Do you want to abort the installation?</source>
        <translation>Voleu interrompre la instal·lació? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1295"/>
        <source>Do you want to continue?</source>
        <translation>Voleu continuar? </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1442"/>
        <source>Preparing partition tables</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1462"/>
        <source>Preparing required partitions</source>
        <translation>Preparant les particions adients </translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1530"/>
        <source>Setting up LUKS encrypted containers</source>
        <translation>Configurant els contenidors encriptats LUKS</translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1550"/>
        <source>Formatting: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1642"/>
        <source>Preparing subvolumes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../partman.cpp" line="1786"/>
        <source>Mounting: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QApplication</name>
    <message>
        <location filename="../app.cpp" line="51"/>
        <source>Customizable GUI installer for MX Linux and antiX Linux</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="54"/>
        <source>Installs automatically using the configuration file (more information below).
-- WARNING: potentially dangerous option, it will wipe the partition(s) automatically.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="56"/>
        <source>Overrules sanity checks on partitions and drives, causing them to be displayed.
-- WARNING: this can break things, use it only if you don&apos;t care about data on drive.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="58"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.
By default /etc/minstall.conf is used.
This configuration can be used with --auto for an unattended installation.
The installer creates (or overwrites) /mnt/antiX/etc/minstall.conf and saves a copy to /etc/minstalled.conf for future use.
The installer will not write any passwords or ignored settings to the new configuration file.
Please note, this is experimental. Future installer versions may break compatibility with existing configuration files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="64"/>
        <source>Always use GPT when doing a whole-drive installation regardlesss of capacity.
Without this option, GPT will only be used on drives with at least 2TB capacity.
GPT is always used on whole-drive installations on UEFI systems regardless of capacity, even without this option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="67"/>
        <source>Do not unmount /mnt/antiX or close any of the associated LUKS containers when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="68"/>
        <source>Another testing mode for installer, partitions/drives are going to be FORMATED, it will skip copying the files.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="69"/>
        <source>Install the operating system, delaying prompts for user-specific options until the first reboot.
Upon rebooting, the installer will be run with --oobe so that the user can provide these details.
This is useful for OEM installations, selling or giving away a computer with an OS pre-loaded on it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="72"/>
        <source>Out Of the Box Experience option.
This will start automatically if installed with --oem option.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="74"/>
        <source>Test mode for GUI, you can advance to different screens without actially installing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="75"/>
        <source>Installing with rsync instead of cp on custom partitioning.
-- doesn&apos;t format /root and it doesn&apos;t work with encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="77"/>
        <source>Load a configuration file as specified by &lt;config-file&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="114"/>
        <source>This operation requires root access.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../app.cpp" line="128"/>
        <source>Configuration file (%1) not found.</source>
        <translation>No he trobat el fitxer de configuració (%1).</translation>
    </message>
</context>
</TS>
